package com.candstech.hondaecutool

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun EcuToolScreen(
    isConnected: Boolean,
    logText: String,
    hexText: String,
    progressValue: Float,
    progressLabel: String,
    operationStatus: OperationStatus,
    statusBannerText: String,
    outputFolderLabel: String,
    flashTargetLabel: String,
    xdfFileLabel: String,
    xdfTables: List<XdfTableDef>,
    selectedTableIndex: Int,
    onSelectTable: (Int) -> Unit,
    rowLabels: List<String>,
    colLabels: List<String>,
    fuelMap: List<List<Int>>,
    liveRpm: Int,
    liveTps: Int,
    liveAfr: Float,
    targetAfrInput: String,
    onTargetAfrChange: (String) -> Unit,
    onSelectOutputFolderClick: () -> Unit,
    onSelectFlashFileClick: () -> Unit,
    onSelectXdfFileClick: () -> Unit,
    onSaveEditedBinClick: () -> Unit,
    onScanClick: () -> Unit,
    onReadEepromClick: () -> Unit,
    onWriteEepromClick: () -> Unit,
    onValidateChecksumClick: () -> Unit,
    onCellEdit: (Int, Int, Int) -> Unit,
    onAutoAfrTuneClick: () -> Unit,
    onSimulateLiveReadClick: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var selectedRow by remember { mutableIntStateOf(0) }
    var selectedCol by remember { mutableIntStateOf(0) }
    var tableDropdownExpanded by remember { mutableStateOf(false) }
    val isBusy = operationStatus == OperationStatus.RUNNING

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "CANDSTECH ECU FLASHER",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "EEPROM • XDF Definition • Auto AFR",
                    color = Color(0xFFD4FF00),
                    fontSize = 11.sp
                )
            }
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = if (isConnected) Color(0xFF00C853) else Color(0xFFE10600)
            ) {
                Text(
                    text = if (isConnected) "ONLINE" else "OFFLINE",
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Banner Status Hasil
        if (statusBannerText.isNotEmpty()) {
            val bannerBg = when (operationStatus) {
                OperationStatus.SUCCESS -> Color(0xFF1B5E20)
                OperationStatus.ERROR -> Color(0xFFB71C1C)
                OperationStatus.RUNNING -> Color(0xFFE65100)
                OperationStatus.IDLE -> Color(0xFF263238)
            }
            val bannerBorder = when (operationStatus) {
                OperationStatus.SUCCESS -> Color(0xFF00E676)
                OperationStatus.ERROR -> Color(0xFFFF5252)
                OperationStatus.RUNNING -> Color(0xFFD4FF00)
                OperationStatus.IDLE -> Color.Gray
            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(bannerBg, RoundedCornerShape(6.dp))
                    .border(1.dp, bannerBorder, RoundedCornerShape(6.dp))
                    .padding(horizontal = 10.dp, vertical = 5.dp)
            ) {
                Text(text = statusBannerText, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(5.dp))
        }

        // Panel Progress Bar
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF181818)),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFF2E2E2E), RoundedCornerShape(6.dp))
        ) {
            Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(text = progressLabel, color = Color.LightGray, fontSize = 10.sp)
                    Text(
                        text = "${(progressValue * 100).roundToInt()}%",
                        color = Color(0xFFD4FF00),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(3.dp))
                LinearProgressIndicator(
                    progress = progressValue,
                    color = when (operationStatus) {
                        OperationStatus.SUCCESS -> Color(0xFF00E676)
                        OperationStatus.ERROR -> Color(0xFFFF5252)
                        else -> Color(0xFFD4FF00)
                    },
                    trackColor = Color(0xFF333333),
                    modifier = Modifier.fillMaxWidth().height(5.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(5.dp))

        // Panel Direktori Hasil, File .BIN, & File .XDF
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A)),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFF333333), RoundedCornerShape(8.dp))
        ) {
            Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                // 1. Folder Hasil
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f).padding(end = 6.dp)) {
                        Text("FOLDER HASIL (.BIN):", color = Color(0xFFD4FF00), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        Text(outputFolderLabel, color = Color.White, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Button(
                        onClick = onSelectOutputFolderClick,
                        enabled = !isBusy,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E2E2E)),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                        modifier = Modifier.height(26.dp)
                    ) { Text("Set Folder", fontSize = 9.sp, color = Color(0xFFD4FF00)) }
                }

                Divider(color = Color(0xFF2B2B2B))

                // 2. File Target .BIN
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f).padding(end = 6.dp)) {
                        Text("FILE ROM (.BIN):", color = Color(0xFFFF5252), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        Text(flashTargetLabel, color = Color.White, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Button(
                        onClick = onSelectFlashFileClick,
                        enabled = !isBusy,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E2E2E)),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                        modifier = Modifier.height(26.dp)
                    ) { Text("Pilih .BIN", fontSize = 9.sp, color = Color.White) }
                }

                Divider(color = Color(0xFF2B2B2B))

                // 3. File Definisi .XDF
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f).padding(end = 6.dp)) {
                        Text("DEFINISI MAP (.XDF):", color = Color(0xFF40C4FF), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        Text(xdfFileLabel, color = Color.White, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Button(
                        onClick = onSelectXdfFileClick,
                        enabled = !isBusy,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D47A1)),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                        modifier = Modifier.height(26.dp)
                    ) { Text("Pilih .XDF", fontSize = 9.sp, color = Color.White, fontWeight = FontWeight.Bold) }
                }
            }
        }

        Spacer(modifier = Modifier.height(5.dp))

        // Navigation Tabs
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color(0xFF1E1E1E),
            contentColor = Color(0xFFD4FF00)
        ) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }) {
                Text("FLASHER", modifier = Modifier.padding(vertical = 7.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }) {
                Text("LIVE EDIT", modifier = Modifier.padding(vertical = 7.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }) {
                Text("AUTO AFR", modifier = Modifier.padding(vertical = 7.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        when (selectedTab) {
            0 -> {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Button(
                        onClick = onScanClick,
                        enabled = !isBusy,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF333333)),
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(4.dp)
                    ) { Text("Scan USB", fontSize = 11.sp) }

                    Button(
                        onClick = onReadEepromClick,
                        enabled = !isBusy,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE10600)),
                        modifier = Modifier.weight(1.2f),
                        contentPadding = PaddingValues(4.dp)
                    ) { Text("Read & Save", fontSize = 11.sp, fontWeight = FontWeight.Bold) }

                    Button(
                        onClick = onValidateChecksumClick,
                        enabled = !isBusy,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1565C0)),
                        modifier = Modifier.weight(1.1f),
                        contentPadding = PaddingValues(4.dp)
                    ) { Text("Fix Cksum", fontSize = 11.sp) }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Button(
                    onClick = onWriteEepromClick,
                    enabled = !isBusy,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB71C1C)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("WRITE / FLASH FILE TARGET KE ECU", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text("HEX DUMP BUFFER", color = Color(0xFFD4FF00), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(75.dp)
                        .background(Color(0xFF141414), RoundedCornerShape(6.dp))
                        .border(1.dp, Color(0xFF333333), RoundedCornerShape(6.dp))
                        .padding(6.dp)
                ) {
                    LazyColumn {
                        item {
                            Text(
                                text = hexText,
                                color = Color(0xFF00E676),
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }

            1 -> {
                // Pemilih Tabel dari XDF
                val activeTableName = xdfTables.getOrNull(selectedTableIndex)?.let {
                    "${it.title} (0x${it.address.toString(16).uppercase(Locale.ROOT)})"
                } ?: "Pilih Tabel"

                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        onClick = { tableDropdownExpanded = true },
                        modifier = Modifier.fillMaxWidth().height(34.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "Tabel XDF: $activeTableName ▼",
                            color = Color(0xFFD4FF00),
                            fontSize = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    DropdownMenu(
                        expanded = tableDropdownExpanded,
                        onDismissRequest = { tableDropdownExpanded = false },
                        modifier = Modifier.background(Color(0xFF222222))
                    ) {
                        xdfTables.forEachIndexed { idx, tbl ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = "${tbl.title} [0x${tbl.address.toString(16).uppercase(Locale.ROOT)} | ${tbl.rows}x${tbl.cols}]",
                                        color = Color.White,
                                        fontSize = 11.sp
                                    )
                                },
                                onClick = {
                                    selectedRow = 0
                                    selectedCol = 0
                                    onSelectTable(idx)
                                    tableDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Grid Tabel XDF (Mendukung ukuran dinamis dengan scroll)
                val hScroll = rememberScrollState()
                val vScroll = rememberScrollState()
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(145.dp)
                        .verticalScroll(vScroll)
                        .horizontalScroll(hScroll)
                ) {
                    // Header Kolom
                    Row {
                        Text(
                            text = "Y \\ X",
                            color = Color(0xFFD4FF00),
                            fontSize = 10.sp,
                            modifier = Modifier.width(46.dp)
                        )
                        colLabels.forEach { lbl ->
                            Text(
                                text = lbl,
                                color = Color(0xFFD4FF00),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.width(42.dp)
                            )
                        }
                    }

                    // Baris Data
                    fuelMap.forEachIndexed { rIdx, rowValues ->
                        Row(
                            modifier = Modifier.padding(vertical = 1.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = rowLabels.getOrElse(rIdx) { "$rIdx" },
                                color = Color.White,
                                fontSize = 10.sp,
                                modifier = Modifier.width(46.dp)
                            )
                            rowValues.forEachIndexed { cIdx, cellVal ->
                                val isSelected = (rIdx == selectedRow && cIdx == selectedCol)
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier
                                        .width(42.dp)
                                        .padding(1.dp)
                                        .background(
                                            if (isSelected) Color(0xFFE10600) else Color(0xFF1E1E1E),
                                            RoundedCornerShape(4.dp)
                                        )
                                        .border(
                                            1.dp,
                                            if (isSelected) Color(0xFFD4FF00) else Color(0xFF333333),
                                            RoundedCornerShape(4.dp)
                                        )
                                        .clickable {
                                            selectedRow = rIdx
                                            selectedCol = cIdx
                                        }
                                        .padding(vertical = 3.dp)
                                ) {
                                    Text(
                                        text = "$cellVal",
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Kontrol Edit Sel
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = { onCellEdit(selectedRow, selectedCol, -5) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF333333)),
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(2.dp)
                    ) { Text("-5", fontSize = 11.sp) }

                    Button(
                        onClick = { onCellEdit(selectedRow, selectedCol, -1) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF424242)),
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(2.dp)
                    ) { Text("-1", fontSize = 11.sp) }

                    Button(
                        onClick = { onCellEdit(selectedRow, selectedCol, +1) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(2.dp)
                    ) { Text("+1", fontSize = 11.sp) }

                    Button(
                        onClick = { onCellEdit(selectedRow, selectedCol, +5) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B5E20)),
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(2.dp)
                    ) { Text("+5", fontSize = 11.sp) }

                    Button(
                        onClick = onSaveEditedBinClick,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0277BD)),
                        modifier = Modifier.weight(1.4f),
                        contentPadding = PaddingValues(2.dp)
                    ) { Text("Simpan", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                }
            }

            2 -> {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("LIVE SENSOR & AUTO AFR CORRECTION", color = Color(0xFFD4FF00), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(6.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("RPM: $liveRpm", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("TPS: $liveTps%", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text(
                                text = "AFR: ${String.format(Locale.ROOT, "%.1f", liveAfr)}",
                                color = if (liveAfr > 14.0f) Color(0xFFFF5252) else Color(0xFF69F0AE),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = targetAfrInput,
                                onValueChange = onTargetAfrChange,
                                label = { Text("Target AFR", fontSize = 11.sp) },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )

                            Button(
                                onClick = onSimulateLiveReadClick,
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF333333)),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Baca Sensor", fontSize = 11.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = onAutoAfrTuneClick,
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE10600)),
                                modifier = Modifier.weight(1.6f)
                            ) {
                                Text("AUTO KOREKSI AFR", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                            Button(
                                onClick = onSaveEditedBinClick,
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0277BD)),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Simpan .BIN", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text("LOG AKTIVITAS", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(Color(0xFF141414), RoundedCornerShape(6.dp))
                .border(1.dp, Color(0xFF333333), RoundedCornerShape(6.dp))
                .padding(6.dp)
        ) {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                item {
                    Text(
                        text = logText,
                        color = Color.LightGray,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp
                    )
                }
            }
        }
    }
}
