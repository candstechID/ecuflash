package com.candstech.hondaecutool

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.InputStream

data class XdfTableDef(
    val title: String,
    val address: Int,
    val rows: Int,
    val cols: Int,
    val elementSizeBits: Int = 8, // 8-bit atau 16-bit
    val isLittleEndian: Boolean = false,
    val rowLabels: List<String> = emptyList(),
    val colLabels: List<String> = emptyList()
)

object XdfParser {
    fun parse(inputStream: InputStream): List<XdfTableDef> {
        val tables = mutableListOf<XdfTableDef>()
        val parser = Xml.newPullParser()
        parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
        parser.setInput(inputStream, null)

        var eventType = parser.eventType
        var inTable = false
        var currentAxis = "" // "x", "y", "z"

        var title = "Unknown Table"
        var address = 0
        var rows = 8
        var cols = 6
        var elementBits = 8
        var flags = 0
        val xLabels = mutableListOf<String>()
        val yLabels = mutableListOf<String>()

        while (eventType != XmlPullParser.END_DOCUMENT) {
            val tagName = parser.name ?: ""
            when (eventType) {
                XmlPullParser.START_TAG -> {
                    when (tagName.uppercase()) {
                        "XDFTABLE" -> {
                            inTable = true
                            title = "Table_${tables.size + 1}"
                            address = 0
                            rows = 8
                            cols = 6
                            elementBits = 8
                            flags = 0
                            xLabels.clear()
                            yLabels.clear()
                        }
                        "XDFAXIS" -> {
                            if (inTable) {
                                currentAxis = parser.getAttributeValue(null, "id")?.lowercase() ?: ""
                            }
                        }
                        "TITLE" -> {
                            if (inTable && currentAxis.isEmpty()) {
                                title = parser.nextText().trim()
                            }
                        }
                        "EMBEDDEDDATA" -> {
                            if (inTable && (currentAxis == "z" || currentAxis.isEmpty())) {
                                val addrStr = parser.getAttributeValue(null, "mmedaddress") ?: "0"
                                address = parseHexOrInt(addrStr)
                                rows = parser.getAttributeValue(null, "mmedrowcount")?.toIntOrNull() ?: rows
                                cols = parser.getAttributeValue(null, "mmedcolcount")?.toIntOrNull() ?: cols
                                elementBits = parser.getAttributeValue(null, "mmedelementsizebits")?.toIntOrNull() ?: 8
                                val flagStr = parser.getAttributeValue(null, "mmedtypeflags") ?: "0"
                                flags = parseHexOrInt(flagStr)
                            }
                        }
                        "LABEL" -> {
                            if (inTable) {
                                val lblVal = parser.getAttributeValue(null, "value") ?: ""
                                if (currentAxis == "x") xLabels.add(lblVal)
                                if (currentAxis == "y") yLabels.add(lblVal)
                            }
                        }
                    }
                }
                XmlPullParser.END_TAG -> {
                    when (tagName.uppercase()) {
                        "XDFAXIS" -> currentAxis = ""
                        "XDFTABLE" -> {
                            if (inTable && address > 0 && rows > 0 && cols > 0) {
                                val finalRowLabels = if (yLabels.size >= rows) yLabels.take(rows)
                                else List(rows) { "${(it + 1) * 1000}" }

                                val finalColLabels = if (xLabels.size >= cols) xLabels.take(cols)
                                else List(cols) { "${(it * 100) / maxOf(1, cols - 1)}%" }

                                // Bit 1 (0x02) pada mmedtypeflags TunerPro menandakan LSB First (Little Endian)
                                val isLsb = (flags and 0x02) != 0

                                tables.add(
                                    XdfTableDef(
                                        title = title,
                                        address = address,
                                        rows = rows.coerceAtMost(32),
                                        cols = cols.coerceAtMost(24),
                                        elementSizeBits = if (elementBits == 16) 16 else 8,
                                        isLittleEndian = isLsb,
                                        rowLabels = finalRowLabels,
                                        colLabels = finalColLabels
                                    )
                                )
                            }
                            inTable = false
                        }
                    }
                }
            }
            eventType = parser.next()
        }
        return tables
    }

    private fun parseHexOrInt(raw: String): Int {
        val clean = raw.trim().lowercase()
        return try {
            if (clean.startsWith("0x")) {
                clean.removePrefix("0x").toLong(16).toInt()
            } else {
                clean.toInt()
            }
        } catch (_: Exception) {
            0
        }
    }
}
