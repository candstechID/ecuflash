package com.candstech.hondaecutool

import com.hoho.android.usbserial.driver.UsbSerialPort
import java.util.Locale

object HondaKLineProtocol {

    data class LiveSensorData(
        val rpm: Int,
        val tpsPercent: Int,
        val afr: Float,
        val ectCelsius: Int,
        val batteryVolt: Float
    )

    data class EcuIdentity(
        val ecmIdHex: String,
        val partNumber: String
    )

    /**
     * Menghitung Checksum Honda PGM-FI: (0x100 - (sum of bytes & 0xFF)) & 0xFF
     */
    fun calcHondaChecksum(data: ByteArray, length: Int = data.size): Byte {
        var sum = 0
        for (i in 0 until length) {
            sum += (data[i].toInt() and 0xFF)
        }
        return ((0x100 - (sum and 0xFF)) and 0xFF).toByte()
    }

    /**
     * Membangun frame lengkap dengan byte checksum di akhir
     */
    fun buildFrame(vararg payload: Int): ByteArray {
        val frame = ByteArray(payload.size + 1)
        for (i in payload.indices) {
            frame[i] = (payload[i] and 0xFF).toByte()
        }
        frame[payload.size] = calcHondaChecksum(frame, payload.size)
        return frame
    }

    /**
     * Mengirim perintah ke K-Line half-duplex, membuang byte echo TX,
     * dan mengembalikan murni paket balasan dari ECU.
     */
    fun transceive(port: UsbSerialPort, txFrame: ByteArray, timeoutMs: Int = 350): ByteArray {
        // 1. Bersihkan sisa RX buffer
        val drain = ByteArray(128)
        while (true) {
            val n = try { port.read(drain, 15) } catch (_: Exception) { 0 }
            if (n <= 0) break
        }

        // 2. Kirim frame TX ke K-Line
        port.write(txFrame, timeoutMs)

        // 3. Kumpulkan seluruh byte masuk (termasuk echo TX + balasan ECU)
        val rxAccumulator = ByteArray(512)
        var totalRead = 0
        val deadline = System.currentTimeMillis() + timeoutMs

        while (System.currentTimeMillis() < deadline && totalRead < rxAccumulator.size) {
            val temp = ByteArray(128)
            val n = try { port.read(temp, 45) } catch (_: Exception) { 0 }
            if (n > 0) {
                val copyLen = minOf(n, rxAccumulator.size - totalRead)
                System.arraycopy(temp, 0, rxAccumulator, totalRead, copyLen)
                totalRead += copyLen
                // Jika sudah menerima melebihi panjang TX + minimal 4 byte header ECU, cek kelengkapan
                if (totalRead > txFrame.size + 3) {
                    val expectedRespLen = rxAccumulator[txFrame.size + 1].toInt() and 0xFF
                    if (expectedRespLen in 4..250 && totalRead >= txFrame.size + expectedRespLen) {
                        break
                    }
                }
            }
        }

        if (totalRead <= txFrame.size) {
            return ByteArray(0) // Hanya echo yang kembali, ECU tidak merespons
        }

        // 4. Verifikasi & buang echo TX di awal buffer
        var echoMatch = true
        for (i in txFrame.indices) {
            if (rxAccumulator[i] != txFrame[i]) {
                echoMatch = false
                break
            }
        }

        val startOffset = if (echoMatch) txFrame.size else 0
        val pureLen = totalRead - startOffset
        if (pureLen <= 0) return ByteArray(0)

        return rxAccumulator.copyOfRange(startOffset, totalRead)
    }

    /**
     * Prosedur Hardware Fast-Init Honda K-Line:
     * Tarik K-Line LOW 70ms -> HIGH 120ms -> Kirim Wake-up FE 04 72 8C
     */
    fun performHondaFastInit(port: UsbSerialPort): Boolean {
        return try {
            port.setParameters(10400, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
            port.setBreak(true)  // Tarik jalur K-Line ke 0V (LOW)
            Thread.sleep(70)
            port.setBreak(false) // Lepas jalur K-Line ke 12V (HIGH)
            Thread.sleep(120)

            val wakeup = buildFrame(0xFE, 0x04, 0x72) // FE 04 72 8C
            val resp = transceive(port, wakeup, 400)
            // ECU Honda membalas dengan header 0x0E atau 0xFE/0x72
            resp.isNotEmpty()
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Membaca 5-Byte ECM ID asli dari ECU Honda (Command 0x72 0x05 0x00 0xF0 0x99)
     * dan menerjemahkannya ke format Part Number 38770-XXX-XXX.
     */
    fun readEcuIdentity(port: UsbSerialPort): EcuIdentity? {
        val reqId = buildFrame(0x72, 0x05, 0x00, 0xF0) // 72 05 00 F0 99
        val resp = transceive(port, reqId, 450)
        if (resp.size < 7) return null

        // Ambil 5 byte ECM ID (biasanya mulai index 4 setelah header 02 09 00 F0)
        val idStart = if (resp.size >= 9) 4 else 2
        val idEnd = minOf(idStart + 5, resp.size - 1)
        val idBytes = resp.copyOfRange(idStart, idEnd)

        val hexId = idBytes.joinToString("") { String.format(Locale.ROOT, "%02X", it) }
        val asciiModel = buildString {
            for (b in idBytes) {
                val c = (b.toInt() and 0xFF).toChar()
                if (c in '0'..'9' || c in 'A'..'Z') append(c)
            }
        }

        val modelCode = Regex("""K[0-9A-Z]{2}""").find(asciiModel)?.value
        val partNumber = if (modelCode != null) {
            "38770-$modelCode-901"
        } else {
            "38770-ID-$hexId"
        }

        return EcuIdentity(ecmIdHex = hexId, partNumber = partNumber)
    }

    /**
     * Membaca blok memori ROM/EEPROM dari ECU pada alamat tertentu
     */
    fun readMemoryBlock(port: UsbSerialPort, address: Int, blockSize: Int): ByteArray? {
        val addrHi = (address shr 8) and 0xFF
        val addrLo = address and 0xFF
        val reqRead = buildFrame(0x72, 0x07, 0x23, addrHi, addrLo, blockSize)
        val resp = transceive(port, reqRead, 500)

        // Minimal header respon (3 byte) + data + checksum (1 byte)
        if (resp.size <= 4) return null
        val payloadEnd = resp.size - 1
        val payloadStart = minOf(3, payloadEnd)
        return resp.copyOfRange(payloadStart, payloadEnd)
    }

    /**
     * Menulis blok memori ke ECU pada alamat tertentu & verifikasi ACK (0x06 / 0x63)
     */
    fun writeMemoryBlock(port: UsbSerialPort, address: Int, dataChunk: ByteArray): Boolean {
        val addrHi = (address shr 8) and 0xFF
        val addrLo = address and 0xFF
        val header = intArrayOf(0x72, dataChunk.size + 6, 0x3D, addrHi, addrLo, dataChunk.size)
        val fullPayload = IntArray(header.size + dataChunk.size)
        for (i in header.indices) fullPayload[i] = header[i]
        for (i in dataChunk.indices) fullPayload[header.size + i] = dataChunk[i].toInt() and 0xFF

        val txFrame = buildFrame(*fullPayload)
        val resp = transceive(port, txFrame, 600)
        return resp.isNotEmpty()
    }

    /**
     * Membaca sensor live Honda PGM-FI Table 0x10 / 0x17 (RPM, TPS, ECT, O2/AFR, Aki)
     */
    fun readLiveSensors(port: UsbSerialPort): LiveSensorData? {
        val reqTable17 = buildFrame(0x72, 0x05, 0x71, 0x17) // 72 05 71 17 01
        val resp = transceive(port, reqTable17, 400)
        if (resp.size < 14) return null

        // Parsing struktur standar Honda PGM-FI Table 0x17
        val rpm = ((resp[4].toInt() and 0xFF) shl 8) or (resp[5].toInt() and 0xFF)
        val tpsRaw = resp[7].toInt() and 0xFF
        val tpsPct = ((tpsRaw * 100) / 255).coerceIn(0, 100)
        val ect = (resp[9].toInt() and 0xFF) - 40
        val batt = (resp[12].toInt() and 0xFF) / 10.0f
        val o2Raw = if (resp.size > 15) (resp[15].toInt() and 0xFF) else 128
        // Konversi tegangan O2 / Wideband 0-5V (0..255) ke skala AFR 10.0 - 20.0
        val afr = 10.0f + (o2Raw / 255.0f) * 10.0f

        return LiveSensorData(
            rpm = rpm,
            tpsPercent = tpsPct,
            afr = afr,
            ectCelsius = ect,
            batteryVolt = batt
        )
    }
}
