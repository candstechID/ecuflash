package com.candstech.hondaecutool

object HondaEcuDetector {

    data class DetectionResult(
        val partNumber: String,
        val modelName: String,
        val tables: List<XdfTableDef>,
        val isBuiltInMatch: Boolean
    )

    // Regex untuk mencari pola Part Number ECU Honda (38770-XXX-XXX) atau ID Keihin di dalam biner
    private val partNumberRegex = Regex("""38770-[A-Z0-9]{3}-[A-Z0-9]{3}""")

    fun detectFromBin(rom: ByteArray): DetectionResult {
        // Konversi biner ke karakter ASCII yang terbaca untuk mencari string Part Number
        val asciiBuilder = StringBuilder(rom.size)
        for (b in rom) {
            val c = (b.toInt() and 0xFF).toChar()
            asciiBuilder.append(if (c in ' '..'~') c else '.')
        }
        val asciiDump = asciiBuilder.toString()

        val match = partNumberRegex.find(asciiDump)
        val foundPartNumber = match?.value ?: "UNKNOWN-PART-ID"

        return getBuiltInDefinition(foundPartNumber)
    }

    fun getBuiltInDefinition(partNumber: String): DetectionResult {
        val code = partNumber.uppercase()

        return when {
            // Honda Beat FI / Scoopy FI / Vario 110 FI (K25 / K44 / K16)
            code.contains("K25") || code.contains("K44") || code.contains("K16") -> DetectionResult(
                partNumber = partNumber,
                modelName = "Honda Beat / Scoopy / Vario 110 FI ($partNumber)",
                isBuiltInMatch = true,
                tables = listOf(
                    XdfTableDef(
                        title = "Main Fuel Map ($partNumber)",
                        address = 0x4200,
                        rows = 12,
                        cols = 8,
                        elementSizeBits = 8,
                        rowLabels = listOf("1400", "2000", "2800", "3600", "4500", "5500", "6500", "7500", "8500", "9500", "10500", "11500"),
                        colLabels = listOf("0%", "5%", "12%", "22%", "35%", "50%", "75%", "100%")
                    ),
                    XdfTableDef(
                        title = "Ignition Advance ($partNumber)",
                        address = 0x4300,
                        rows = 12,
                        cols = 8,
                        elementSizeBits = 8,
                        rowLabels = listOf("1400", "2000", "2800", "3600", "4500", "5500", "6500", "7500", "8500", "9500", "10500", "11500"),
                        colLabels = listOf("0%", "5%", "12%", "22%", "35%", "50%", "75%", "100%")
                    )
                )
            )

            // Honda Vario 125 / 150 (KZR / K59 / K60)
            code.contains("KZR") || code.contains("K59") || code.contains("K60") -> DetectionResult(
                partNumber = partNumber,
                modelName = "Honda Vario 125 / 150 ($partNumber)",
                isBuiltInMatch = true,
                tables = listOf(
                    XdfTableDef(
                        title = "Main Fuel Map ($partNumber)",
                        address = 0x5400,
                        rows = 14,
                        cols = 10,
                        elementSizeBits = 8,
                        rowLabels = listOf("1400", "2000", "2500", "3000", "3800", "4500", "5200", "6000", "6800", "7600", "8400", "9200", "10000", "11000"),
                        colLabels = listOf("0%", "4%", "10%", "18%", "28%", "40%", "55%", "70%", "85%", "100%")
                    ),
                    XdfTableDef(
                        title = "Ignition Timing ($partNumber)",
                        address = 0x5550,
                        rows = 14,
                        cols = 10,
                        elementSizeBits = 8,
                        rowLabels = listOf("1400", "2000", "2500", "3000", "3800", "4500", "5200", "6000", "6800", "7600", "8400", "9200", "10000", "11000"),
                        colLabels = listOf("0%", "4%", "10%", "18%", "28%", "40%", "55%", "70%", "85%", "100%")
                    )
                )
            )

            // Honda PCX 150 / ADV 150 (K97 / K0W)
            code.contains("K97") || code.contains("K0W") -> DetectionResult(
                partNumber = partNumber,
                modelName = "Honda PCX 150 / ADV 150 ($partNumber)",
                isBuiltInMatch = true,
                tables = listOf(
                    XdfTableDef(
                        title = "Main Fuel Map ($partNumber)",
                        address = 0x6100,
                        rows = 14,
                        cols = 10,
                        elementSizeBits = 8,
                        rowLabels = listOf("1400", "2000", "2500", "3000", "3800", "4500", "5200", "6000", "6800", "7600", "8400", "9200", "10000", "11200"),
                        colLabels = listOf("0%", "4%", "10%", "18%", "28%", "40%", "55%", "70%", "85%", "100%")
                    )
                )
            )

            // Honda CBR150R / CB150R / Sonic / Supra GTR (K15 / K45 / K56)
            code.contains("K15") || code.contains("K45") || code.contains("K56") -> DetectionResult(
                partNumber = partNumber,
                modelName = "Honda CBR150R / CB150R / Sonic ($partNumber)",
                isBuiltInMatch = true,
                tables = listOf(
                    XdfTableDef(
                        title = "Main Fuel Map ($partNumber)",
                        address = 0x7000,
                        rows = 16,
                        cols = 10,
                        elementSizeBits = 8,
                        rowLabels = listOf("1500", "2200", "3000", "3800", "4500", "5200", "6000", "6800", "7500", "8200", "9000", "9800", "10500", "11200", "12000", "13000"),
                        colLabels = listOf("0%", "4%", "10%", "18%", "28%", "40%", "55%", "70%", "85%", "100%")
                    )
                )
            )

            // Jika Part Number terdeteksi tapi belum ada di database built-in, gunakan fallback 0x4000
            else -> DetectionResult(
                partNumber = partNumber,
                modelName = if (partNumber == "UNKNOWN-PART-ID") "Part Number Tidak Ditemukan" else "ECU Terdeteksi: $partNumber (Gunakan .XDF / Default)",
                isBuiltInMatch = false,
                tables = listOf(
                    XdfTableDef(
                        title = "Default Fuel Table ($partNumber)",
                        address = 0x4000,
                        rows = 8,
                        cols = 6,
                        rowLabels = listOf("1500", "3000", "4500", "6000", "7500", "9000", "10500", "12000"),
                        colLabels = listOf("0%", "15%", "30%", "50%", "75%", "100%")
                    )
                )
            )
        }
    }
}
