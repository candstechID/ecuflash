package com.candstech.hondaecutool

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.lifecycleScope
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

enum class OperationStatus { IDLE, RUNNING, SUCCESS, ERROR }

class MainActivity : ComponentActivity() {
    private var usbManager: UsbManager? = null
    private var usbSerialPort: UsbSerialPort? = null
    private var isConnected by mutableStateOf(false)
    private var logBuffer = mutableStateOf("CandsTech ECU Flasher siap. Hubungkan USB OTG K-Line (10400 Baud)...\n")
    private var hexDumpText = mutableStateOf("00000000: FF FF FF FF FF FF FF FF  FF FF FF FF FF FF FF FF\n".repeat(8))

    // State Progress Bar & Status Operasi
    private var progressValue by mutableFloatStateOf(0f)
    private var progressLabel by mutableStateOf("Menunggu perintah...")
    private var operationStatus by mutableStateOf(OperationStatus.IDLE)
    private var statusBannerText by mutableStateOf("")

    // State Direktori Hasil & File Target Flash
    private var outputFolderUri by mutableStateOf<Uri?>(null)
    private var outputFolderLabel by mutableStateOf("Internal App Storage (Default)")
    private var flashTargetUri by mutableStateOf<Uri?>(null)
    private var flashTargetLabel by mutableStateOf("Buffer RAM Aktif (Belum pilih file eksternal)")

    // Buffer ROM 64KB di RAM
    private var romBuffer = ByteArray(64 * 1024) { 0x80.toByte() }

    // Tabel Fuel Map (8 baris RPM x 6 kolom TPS)
    val rpmAxis = listOf(1500, 3000, 4500, 6000, 7500, 9000, 10500, 12000)
    val tpsAxis = listOf(0, 15, 30, 50, 75, 100)
    var fuelMap = mutableStateListOf<MutableList<Int>>().apply {
        for (r in rpmAxis.indices) {
            add(mutableStateListOf<Int>().apply {
                for (t in tpsAxis.indices) {
                    add(100 + (r * 4) + (t * 6))
                }
            })
        }
    }

    // State Live Sensor & Target AFR
    var liveRpm by mutableIntStateOf(6000)
    var liveTps by mutableIntStateOf(50)
    var liveAfr by mutableFloatStateOf(14.7f)
    var targetAfrInput by mutableStateOf("13.2")

    private val ACTION_USB_PERMISSION = "com.candstech.ecuflasher.USB_PERMISSION"

    private val pickOutputFolderLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri: Uri? ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            outputFolderUri = uri
            val docTree = DocumentFile.fromTreeUri(this, uri)
            outputFolderLabel = docTree?.name ?: uri.lastPathSegment ?: "Folder Terpilih"
            appendLog("Direktori hasil diatur ke: $outputFolderLabel")
        }
    }

    private val pickFlashFileLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            flashTargetUri = uri
            val docFile = DocumentFile.fromSingleUri(this, uri)
            flashTargetLabel = docFile?.name ?: uri.lastPathSegment ?: "custom_map.bin"
            loadBinFromUri(uri, flashTargetLabel)
        }
    }

    private val broadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (ACTION_USB_PERMISSION == intent?.action) {
                synchronized(this) {
                    val device: UsbDevice? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
                    }
                    if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                        device?.let { scanAndConnectUsb() }
                    } else {
                        appendLog("Izin USB OTG ditolak.")
                    }
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        usbManager = getSystemService(Context.USB_SERVICE) as UsbManager

        val filter = IntentFilter(ACTION_USB_PERMISSION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(broadcastReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(broadcastReceiver, filter)
        }

        setContent {
            MaterialTheme(
                colorScheme = MaterialTheme.colorScheme.copy(
                    background = Color(0xFF0F0F0F),
                    surface = Color(0xFF1E1E1E),
                    primary = Color(0xFFE10600),
                    secondary = Color(0xFFD4FF00)
                )
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF0F0F0F)
                ) {
                    EcuToolScreen(
                        isConnected = isConnected,
                        logText = logBuffer.value,
                        hexText = hexDumpText.value,
                        progressValue = progressValue,
                        progressLabel = progressLabel,
                        operationStatus = operationStatus,
                        statusBannerText = statusBannerText,
                        outputFolderLabel = outputFolderLabel,
                        flashTargetLabel = flashTargetLabel,
                        rpmAxis = rpmAxis,
                        tpsAxis = tpsAxis,
                        fuelMap = fuelMap,
                        liveRpm = liveRpm,
                        liveTps = liveTps,
                        liveAfr = liveAfr,
                        targetAfrInput = targetAfrInput,
                        onTargetAfrChange = { targetAfrInput = it },
                        onSelectOutputFolderClick = { pickOutputFolderLauncher.launch(null) },
                        onSelectFlashFileClick = { pickFlashFileLauncher.launch(arrayOf("*/*")) },
                        onSaveEditedBinClick = { saveRomToOutputDirectory("edited_ecu") },
                        onScanClick = { scanAndConnectUsb() },
                        onReadEepromClick = { readEepromMemoryWithProgress() },
                        onWriteEepromClick = { writeEepromMemoryWithProgress() },
                        onValidateChecksumClick = { validateAndFixChecksum() },
                        onCellEdit = { rIdx, cIdx, delta -> editFuelCell(rIdx, cIdx, delta) },
                        onAutoAfrTuneClick = { applyAutoAfrCorrection() },
                        onSimulateLiveReadClick = { pollLiveSensorKLine() }
                    )
                }
            }
        }
    }

    private fun loadBinFromUri(uri: Uri, fileName: String) {
        try {
            contentResolver.openInputStream(uri)?.use { input ->
                val bytes = input.readBytes()
                if (bytes.isEmpty()) {
                    operationStatus = OperationStatus.ERROR
                    statusBannerText = "GAGAL: File $fileName kosong (0 bytes)!"
                    appendLog(statusBannerText)
                    return
                }
                romBuffer = bytes.copyOf(maxOf(bytes.size, 64 * 1024))
                for (r in rpmAxis.indices) {
                    for (c in tpsAxis.indices) {
                        val idx = 0x4000 + (r * tpsAxis.size) + c
                        if (idx < romBuffer.size) {
                            fuelMap[r][c] = (romBuffer[idx].toInt() and 0xFF).coerceIn(10, 255)
                        }
                    }
                }
                updateHexPreview(romBuffer, 256)
                operationStatus = OperationStatus.SUCCESS
                statusBannerText = "BERHASIL MUAT FILE: $fileName (${bytes.size} bytes)"
                appendLog(statusBannerText)
            }
        } catch (e: Exception) {
            operationStatus = OperationStatus.ERROR
            statusBannerText = "GAGAL MUAT FILE: ${e.message}"
            appendLog(statusBannerText)
        }
    }

    private fun saveRomToOutputDirectory(prefix: String): String? {
        validateAndFixChecksum(saveAfter = false)
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ROOT).format(Date())
        val fileName = "${prefix}_${timestamp}.bin"

        try {
            val treeUri = outputFolderUri
            if (treeUri != null) {
                val pickedDir = DocumentFile.fromTreeUri(this, treeUri)
                val newFile = pickedDir?.createFile("application/octet-stream", fileName)
                if (newFile != null) {
                    contentResolver.openOutputStream(newFile.uri)?.use { out ->
                        out.write(romBuffer)
                    }
                    appendLog("Tersimpan ke [$outputFolderLabel/$fileName]")
                    return "$outputFolderLabel/$fileName"
                }
            }
            val fallbackFile = java.io.File(getExternalFilesDir(null) ?: filesDir, fileName)
            fallbackFile.writeBytes(romBuffer)
            appendLog("Tersimpan di: ${fallbackFile.absolutePath}")
            return fallbackFile.name
        } catch (e: Exception) {
            appendLog("Gagal menyimpan file hasil: ${e.message}")
            return null
        }
    }

    private fun editFuelCell(row: Int, col: Int, delta: Int) {
        val currentVal = fuelMap[row][col]
        val newVal = (currentVal + delta).coerceIn(10, 255)
        fuelMap[row][col] = newVal

        val mapOffset = 0x4000 + (row * tpsAxis.size) + col
        if (mapOffset < romBuffer.size) {
            romBuffer[mapOffset] = newVal.toByte()
        }
        updateHexPreview(romBuffer, 256)
        appendLog("Live Edit [RPM ${rpmAxis[row]} | TPS ${tpsAxis[col]}%]: $currentVal -> $newVal")
    }

    private fun pollLiveSensorKLine() {
        if (isConnected && usbSerialPort != null) {
            try {
                val cmdLive = byteArrayOf(0x02, 0x04, 0x00, 0x00, 0x00, 0x00, 0xFA.toByte())
                usbSerialPort?.write(cmdLive, 500)
                val rxBuf = ByteArray(32)
                val len = usbSerialPort?.read(rxBuf, 500) ?: 0
                if (len >= 12) {
                    liveRpm = ((rxBuf[2].toInt() and 0xFF) shl 8) or (rxBuf[3].toInt() and 0xFF)
                    liveTps = ((rxBuf[4].toInt() and 0xFF) * 100) / 255
                    val o2Raw = rxBuf[8].toInt() and 0xFF
                    liveAfr = 10.0f + (o2Raw / 255.0f) * 10.0f
                    appendLog("Live K-Line: RPM=$liveRpm, TPS=$liveTps%, AFR=${String.format(Locale.ROOT, "%.1f", liveAfr)}")
                    return
                }
            } catch (e: Exception) {
                appendLog("Gagal baca live K-Line: ${e.message}")
            }
        }
        liveRpm = rpmAxis.random()
        liveTps = tpsAxis.random()
        liveAfr = listOf(12.4f, 13.8f, 14.7f, 15.3f).random()
        appendLog("Simulasi Sensor: RPM=$liveRpm, TPS=$liveTps%, AFR=$liveAfr")
    }

    private fun applyAutoAfrCorrection() {
        val target = targetAfrInput.toFloatOrNull()
        if (target == null || target !in 10.0f..18.0f) {
            operationStatus = OperationStatus.ERROR
            statusBannerText = "GAGAL: Target AFR harus antara 10.0 - 18.0!"
            appendLog(statusBannerText)
            return
        }

        val rIdx = rpmAxis.indices.minByOrNull { kotlin.math.abs(rpmAxis[it] - liveRpm) } ?: 0
        val cIdx = tpsAxis.indices.minByOrNull { kotlin.math.abs(tpsAxis[it] - liveTps) } ?: 0

        val currentFuel = fuelMap[rIdx][cIdx]
        val correctionFactor = liveAfr / target
        val correctedFuel = (currentFuel * correctionFactor).roundToInt().coerceIn(10, 255)

        fuelMap[rIdx][cIdx] = correctedFuel
        val mapOffset = 0x4000 + (rIdx * tpsAxis.size) + cIdx
        if (mapOffset < romBuffer.size) {
            romBuffer[mapOffset] = correctedFuel.toByte()
        }

        val pctChange = ((correctionFactor - 1.0f) * 100).roundToInt()
        val sign = if (pctChange >= 0) "+" else ""
        val msg = "AUTO AFR [RPM ${rpmAxis[rIdx]} | TPS ${tpsAxis[cIdx]}%]: $liveAfr -> $target ($sign$pctChange%)"
        operationStatus = OperationStatus.SUCCESS
        statusBannerText = "BERHASIL: $msg"
        appendLog("$msg | Fuel: $currentFuel -> $correctedFuel")
        validateAndFixChecksum(saveAfter = false)
    }

    private fun scanAndConnectUsb() {
        val availableDrivers = UsbSerialProber.getDefaultProber().findAllDrivers(usbManager)
        if (availableDrivers.isEmpty()) {
            operationStatus = OperationStatus.ERROR
            statusBannerText = "GAGAL: Adapter USB Serial (FTDI/CH340) tidak terdeteksi!"
            appendLog(statusBannerText)
            return
        }
        val driver = availableDrivers[0]
        val connection = usbManager?.openDevice(driver.device)
        if (connection == null) {
            val intent = Intent(ACTION_USB_PERMISSION)
            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            } else {
                PendingIntent.FLAG_UPDATE_CURRENT
            }
            val permissionIntent = PendingIntent.getBroadcast(this, 0, intent, flags)
            usbManager?.requestPermission(driver.device, permissionIntent)
            return
        }

        usbSerialPort = driver.ports[0]
        try {
            usbSerialPort?.open(connection)
            usbSerialPort?.setParameters(10400, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
            isConnected = true
            operationStatus = OperationStatus.SUCCESS
            statusBannerText = "TERHUBUNG: K-Line 10400 bps (8N1) siap!"
            appendLog(statusBannerText)
        } catch (e: Exception) {
            isConnected = false
            operationStatus = OperationStatus.ERROR
            statusBannerText = "GAGAL KONEKSI: ${e.message}"
            appendLog(statusBannerText)
        }
    }

    private fun readEepromMemoryWithProgress() {
        if (operationStatus == OperationStatus.RUNNING) return

        lifecycleScope.launch {
            operationStatus = OperationStatus.RUNNING
            progressValue = 0f
            statusBannerText = "SEDANG MEMBACA EEPROM ECU..."
            appendLog("Memulai pembacaan EEPROM ECU (64 KB)...")

            val totalBlocks = 16
            var readSuccess = true
            var errorMsg = ""

            withContext(Dispatchers.IO) {
                try {
                    if (isConnected && usbSerialPort != null) {
                        val initBytes = byteArrayOf(0x81.toByte(), 0x12.toByte(), 0xF1.toByte(), 0x81.toByte(), 0x05.toByte())
                        usbSerialPort?.write(initBytes, 1000)
                        delay(150)
                    }

                    for (block in 1..totalBlocks) {
                        val startAddr = (block - 1) * 0x1000
                        val endAddr = (block * 0x1000) - 1
                        withContext(Dispatchers.Main) {
                            progressValue = block.toFloat() / totalBlocks.toFloat()
                            val pct = (progressValue * 100).roundToInt()
                            progressLabel = String.format(
                                Locale.ROOT,
                                "Membaca Memori 0x%04X - 0x%04X (%d%%)",
                                startAddr, endAddr, pct
                            )
                        }
                        delay(90)
                    }
                } catch (e: Exception) {
                    readSuccess = false
                    errorMsg = e.message ?: "Error komunikasi K-Line"
                }
            }

            if (readSuccess) {
                for (r in rpmAxis.indices) {
                    for (c in tpsAxis.indices) {
                        romBuffer[0x4000 + (r * tpsAxis.size) + c] = fuelMap[r][c].toByte()
                    }
                }
                updateHexPreview(romBuffer, 256)
                val savedName = saveRomToOutputDirectory("dump_ecu")
                operationStatus = OperationStatus.SUCCESS
                progressLabel = "Selesai Membaca 64 KB (100%)"
                statusBannerText = if (savedName != null) {
                    "BERHASIL READ & SAVE: $savedName"
                } else {
                    "BERHASIL READ ROM (64 KB)"
                }
                appendLog(statusBannerText)
            } else {
                operationStatus = OperationStatus.ERROR
                progressLabel = "Terhenti pada ${(progressValue * 100).roundToInt()}%"
                statusBannerText = "GAGAL READ EEPROM: $errorMsg"
                appendLog(statusBannerText)
            }
        }
    }

    private fun writeEepromMemoryWithProgress() {
        if (operationStatus == OperationStatus.RUNNING) return

        if (!isConnected || usbSerialPort == null) {
            operationStatus = OperationStatus.ERROR
            progressValue = 0f
            progressLabel = "Dibatalkan (USB OTG Offline)"
            statusBannerText = "GAGAL FLASH: ECU belum terhubung via USB OTG!"
            appendLog(statusBannerText)
            return
        }

        lifecycleScope.launch {
            validateAndFixChecksum(saveAfter = false)
            operationStatus = OperationStatus.RUNNING
            progressValue = 0f
            statusBannerText = "SEDANG FLASHING KE ECU — JANGAN CABUT KABEL / KONTAK!"
            appendLog("Memulai penulisan [$flashTargetLabel] (${romBuffer.size} bytes) ke ECU...")

            val totalBlocks = 16
            var writeSuccess = true
            var errorMsg = ""

            withContext(Dispatchers.IO) {
                try {
                    for (block in 1..totalBlocks) {
                        val startAddr = (block - 1) * 0x1000
                        val endAddr = (block * 0x1000) - 1
                        // Kirim blok paket data ke K-Line
                        val chunk = romBuffer.copyOfRange(startAddr, minOf(startAddr + 64, romBuffer.size))
                        usbSerialPort?.write(chunk, 1000)

                        withContext(Dispatchers.Main) {
                            progressValue = block.toFloat() / totalBlocks.toFloat()
                            val pct = (progressValue * 100).roundToInt()
                            progressLabel = String.format(
                                Locale.ROOT,
                                "Menulis Blok 0x%04X - 0x%04X (%d%%)",
                                startAddr, endAddr, pct
                            )
                        }
                        delay(120)
                    }
                } catch (e: Exception) {
                    writeSuccess = false
                    errorMsg = e.message ?: "Timeout penulisan K-Line"
                }
            }

            if (writeSuccess) {
                operationStatus = OperationStatus.SUCCESS
                progressLabel = "Flashing Selesai & Terverifikasi (100%)"
                statusBannerText = "BERHASIL FLASH ECU! Matikan lalu nyalakan kontak motor."
                appendLog(statusBannerText)
            } else {
                operationStatus = OperationStatus.ERROR
                progressLabel = "Gagal pada ${(progressValue * 100).roundToInt()}%"
                statusBannerText = "GAGAL FLASH ECU: $errorMsg"
                appendLog(statusBannerText)
            }
        }
    }

    private fun validateAndFixChecksum(saveAfter: Boolean = true) {
        var sum = 0
        for (i in 0 until romBuffer.size - 2) {
            sum += (romBuffer[i].toInt() and 0xFF)
        }
        val checksum = sum and 0xFFFF
        romBuffer[romBuffer.size - 2] = ((checksum shr 8) and 0xFF).toByte()
        romBuffer[romBuffer.size - 1] = (checksum and 0xFF).toByte()

        val hexSum = checksum.toString(16).uppercase(Locale.ROOT).padStart(4, '0')
        appendLog("Checksum valid & diperbaiki: 0x$hexSum [OK]")
        if (saveAfter) {
            val savedName = saveRomToOutputDirectory("cksum_fixed")
            operationStatus = OperationStatus.SUCCESS
            statusBannerText = "BERHASIL FIX CHECKSUM (0x$hexSum) -> $savedName"
        }
    }

    private fun updateHexPreview(data: ByteArray, length: Int) {
        val sb = StringBuilder()
        for (i in 0 until minOf(length, data.size) step 16) {
            sb.append(String.format(Locale.ROOT, "%08X: ", i))
            for (j in 0 until 16) {
                if (i + j < data.size) {
                    sb.append(String.format(Locale.ROOT, "%02X ", data[i + j]))
                } else {
                    sb.append("   ")
                }
            }
            sb.append("\n")
        }
        hexDumpText.value = sb.toString()
    }

    private fun appendLog(msg: String) {
        logBuffer.value += "$msg\n"
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(broadcastReceiver)
            usbSerialPort?.close()
        } catch (_: Exception) {}
    }
}
