package com.candstech.hondaecutool

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.lifecycleScope
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

enum class OperationStatus { IDLE, RUNNING, SUCCESS, ERROR }

class MainActivity : ComponentActivity() {
    private var usbManager: UsbManager? = null
    private var usbSerialPort: UsbSerialPort? = null
    private var isConnected by mutableStateOf(false)
    private var logBuffer = mutableStateOf("CandsTech ECU Flasher siap. Hubungkan adapter FTDI/CH340 ke ECU Honda & nyalakan kontak ON.\n")
    private var hexDumpText = mutableStateOf("Belum ada data ROM dimuat. Klik 'Read & Save' dari ECU atau 'Pilih .BIN'.\n")

    // State Progress Bar & Status Operasi
    private var progressValue by mutableFloatStateOf(0f)
    private var progressLabel by mutableStateOf("Menunggu perintah...")
    private var operationStatus by mutableStateOf(OperationStatus.IDLE)
    private var statusBannerText by mutableStateOf("")

    // State Kode Part ECU Aktif
    private var detectedPartNumber by mutableStateOf("UNKNOWN-ECU")
    private var hasValidRomLoaded by mutableStateOf(false)

    // State Direktori Hasil (Default ke Documents/CandsTech)
    private var outputFolderUri by mutableStateOf<Uri?>(null)
    private var outputFolderLabel by mutableStateOf("Documents/CandsTech (Default)")
    private var flashTargetUri by mutableStateOf<Uri?>(null)
    private var flashTargetLabel by mutableStateOf("Belum ada file ROM (.BIN) dimuat")
    private var xdfFileLabel by mutableStateOf("Menunggu ROM (.BIN) atau pilih .XDF")

    // Daftar Tabel dari XDF / Auto-Detect
    private var xdfTables = mutableStateListOf<XdfTableDef>()
    private var selectedTableIndex by mutableIntStateOf(0)

    // Buffer ROM 64KB di RAM
    private var romBuffer = ByteArray(64 * 1024) { 0xFF.toByte() }

    // Tabel Aktif di Grid Live Edit
    var rowLabels = mutableStateListOf("1500", "3000", "4500", "6000", "7500", "9000", "10500", "12000")
    var colLabels = mutableStateListOf("0%", "15%", "30%", "50%", "75%", "100%")
    var activeMapData = mutableStateListOf<MutableList<Int>>()

    // State Live Sensor & Target AFR (Dari K-Line Real)
    var liveRpm by mutableIntStateOf(0)
    var liveTps by mutableIntStateOf(0)
    var liveAfr by mutableFloatStateOf(0.0f)
    var targetAfrInput by mutableStateOf("13.2")

    private val ACTION_USB_PERMISSION = "com.candstech.ecuflasher.USB_PERMISSION"

    private val pickOutputFolderLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri: Uri? ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            outputFolderUri = uri
            val docTree = DocumentFile.fromTreeUri(this, uri)
            outputFolderLabel = docTree?.name ?: uri.lastPathSegment ?: "Folder Terpilih"
            appendLog("Direktori hasil diubah ke: $outputFolderLabel")
        }
    }

    private val pickFlashFileLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            flashTargetUri = uri
            val docFile = DocumentFile.fromSingleUri(this, uri)
            flashTargetLabel = docFile?.name ?: uri.lastPathSegment ?: "custom_map.bin"
            loadBinFromUri(uri, flashTargetLabel)
        }
    }

    private val pickXdfFileLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            val docFile = DocumentFile.fromSingleUri(this, uri)
            val name = docFile?.name ?: uri.lastPathSegment ?: "definition.xdf"
            loadXdfFromUri(uri, name)
        }
    }

    private val broadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (ACTION_USB_PERMISSION == intent?.action) {
                synchronized(this) {
                    val device: UsbDevice? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
                    }
                    if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                        device?.let { scanAndConnectUsb() }
                    } else {
                        appendLog("Izin USB OTG ditolak.")
                    }
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        usbManager = getSystemService(Context.USB_SERVICE) as UsbManager

        xdfTables.add(
            XdfTableDef(
                title = "Fuel Map (Menunggu ROM)",
                address = 0x4000,
                rows = 8,
                cols = 6,
                rowLabels = listOf("1500", "3000", "4500", "6000", "7500", "9000", "10500", "12000"),
                colLabels = listOf("0%", "15%", "30%", "50%", "75%", "100%")
            )
        )
        loadTableFromRomBuffer(0)

        val filter = IntentFilter(ACTION_USB_PERMISSION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(broadcastReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(broadcastReceiver, filter)
        }

        setContent {
            MaterialTheme(
                colorScheme = MaterialTheme.colorScheme.copy(
                    background = Color(0xFF0F0F0F),
                    surface = Color(0xFF1E1E1E),
                    primary = Color(0xFFE10600),
                    secondary = Color(0xFFD4FF00)
                )
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF0F0F0F)
                ) {
                    EcuToolScreen(
                        isConnected = isConnected,
                        logText = logBuffer.value,
                        hexText = hexDumpText.value,
                        progressValue = progressValue,
                        progressLabel = progressLabel,
                        operationStatus = operationStatus,
                        statusBannerText = statusBannerText,
                        outputFolderLabel = outputFolderLabel,
                        flashTargetLabel = flashTargetLabel,
                        xdfFileLabel = xdfFileLabel,
                        xdfTables = xdfTables,
                        selectedTableIndex = selectedTableIndex,
                        onSelectTable = { idx -> loadTableFromRomBuffer(idx) },
                        rowLabels = rowLabels,
                        colLabels = colLabels,
                        fuelMap = activeMapData,
                        liveRpm = liveRpm,
                        liveTps = liveTps,
                        liveAfr = liveAfr,
                        targetAfrInput = targetAfrInput,
                        onTargetAfrChange = { targetAfrInput = it },
                        onSelectOutputFolderClick = { pickOutputFolderLauncher.launch(null) },
                        onSelectFlashFileClick = { pickFlashFileLauncher.launch(arrayOf("*/*")) },
                        onSelectXdfFileClick = { pickXdfFileLauncher.launch(arrayOf("*/*")) },
                        onSaveEditedBinClick = {
                            if (!hasValidRomLoaded) {
                                operationStatus = OperationStatus.ERROR
                                statusBannerText = "GAGAL SIMPAN: Belum ada data ROM yang dimuat/dibaca!"
                                appendLog(statusBannerText)
                            } else {
                                val saved = saveRomToOutputDirectory("edited")
                                if (saved != null) {
                                    operationStatus = OperationStatus.SUCCESS
                                    statusBannerText = "BERHASIL SIMPAN EDIT: $saved"
                                }
                            }
                        },
                        onScanClick = { scanAndConnectUsb() },
                        onReadEepromClick = { readEepromMemoryReal() },
                        onWriteEepromClick = { writeEepromMemoryReal() },
                        onValidateChecksumClick = { validateAndFixChecksum(saveAfter = true) },
                        onCellEdit = { rIdx, cIdx, delta -> editFuelCell(rIdx, cIdx, delta) },
                        onAutoAfrTuneClick = { applyAutoAfrCorrection() },
                        onSimulateLiveReadClick = { pollLiveSensorReal() }
                    )
                }
            }
        }
    }

    private fun autoDetectPartNumberAndLoadXdf(fallbackFileName: String? = null) {
        val detection = HondaEcuDetector.detectFromBin(romBuffer)

        if (detection.partNumber != "UNKNOWN-PART-ID") {
            detectedPartNumber = detection.partNumber
        } else if (detectedPartNumber == "UNKNOWN-ECU") {
            val regexFromName = Regex("""(38770-[A-Z0-9]{3}-[A-Z0-9]{3}|K[0-9A-Z]{2}-[0-9A-Z]{3}|K[0-9A-Z]{2})""", RegexOption.IGNORE_CASE)
            val nameMatch = fallbackFileName?.let { regexFromName.find(it)?.value?.uppercase(Locale.ROOT) }
            if (nameMatch != null) detectedPartNumber = nameMatch
        }

        val finalDef = if (detection.isBuiltInMatch) {
            detection
        } else {
            HondaEcuDetector.getBuiltInDefinition(detectedPartNumber)
        }

        xdfTables.clear()
        if (finalDef.isBuiltInMatch) {
            xdfTables.addAll(finalDef.tables)
            xdfFileLabel = "Auto-XDF: ${finalDef.modelName}"
        } else {
            val scannedMaps = BinMapScanner.scanBinForMaps(romBuffer)
            if (scannedMaps.isNotEmpty()) {
                xdfTables.addAll(scannedMaps)
                xdfFileLabel = "Auto-Scan XDF: $detectedPartNumber (${scannedMaps.size} tabel)"
            } else {
                xdfTables.addAll(finalDef.tables)
                xdfFileLabel = "Part: $detectedPartNumber (${finalDef.tables.size} tabel)"
            }
        }

        loadTableFromRomBuffer(0)
        appendLog("Identitas ECU: [$detectedPartNumber] -> $xdfFileLabel")
    }

    private fun loadXdfFromUri(uri: Uri, fileName: String) {
        if (fileName.lowercase(Locale.ROOT).endsWith(".bin")) {
            operationStatus = OperationStatus.ERROR
            statusBannerText = "SALAH FILE: '$fileName' adalah file ROM (.bin), pilih lewat tombol 'Pilih .BIN'!"
            appendLog(statusBannerText)
            return
        }

        try {
            contentResolver.openInputStream(uri)?.use { input ->
                val parsed = XdfParser.parse(input)
                if (parsed.isEmpty()) {
                    operationStatus = OperationStatus.ERROR
                    statusBannerText = "GAGAL PARSE XDF: Tidak ditemukan tag <XDFTABLE> di $fileName"
                    appendLog(statusBannerText)
                    return
                }
                xdfTables.clear()
                xdfTables.addAll(parsed)
                xdfFileLabel = "Manual XDF: $fileName (${parsed.size} tabel)"
                loadTableFromRomBuffer(0)

                operationStatus = OperationStatus.SUCCESS
                statusBannerText = "BERHASIL MUAT XDF: $fileName (${parsed.size} tabel)"
                appendLog(statusBannerText)
            }
        } catch (e: Exception) {
            operationStatus = OperationStatus.ERROR
            statusBannerText = "GAGAL BACA XDF: File bukan XML TunerPro .xdf valid!"
            appendLog("GAGAL BACA XDF ($fileName): ${e.message}")
        }
    }

    private fun loadTableFromRomBuffer(tableIndex: Int) {
        if (tableIndex !in xdfTables.indices) return
        selectedTableIndex = tableIndex
        val table = xdfTables[tableIndex]

        rowLabels.clear()
        rowLabels.addAll(table.rowLabels)
        colLabels.clear()
        colLabels.addAll(table.colLabels)

        activeMapData.clear()
        val byteStep = if (table.elementSizeBits == 16) 2 else 1

        for (r in 0 until table.rows) {
            val rowList = mutableStateListOf<Int>()
            for (c in 0 until table.cols) {
                val offset = table.address + ((r * table.cols + c) * byteStep)
                val value = if (offset + byteStep <= romBuffer.size) {
                    if (byteStep == 2) {
                        val b0 = romBuffer[offset].toInt() and 0xFF
                        val b1 = romBuffer[offset + 1].toInt() and 0xFF
                        if (table.isLittleEndian) (b1 shl 8) or b0 else (b0 shl 8) or b1
                    } else {
                        romBuffer[offset].toInt() and 0xFF
                    }
                } else {
                    0
                }
                rowList.add(value)
            }
            activeMapData.add(rowList)
        }
    }

    private fun loadBinFromUri(uri: Uri, fileName: String) {
        try {
            contentResolver.openInputStream(uri)?.use { input ->
                val bytes = input.readBytes()
                if (bytes.isEmpty()) {
                    operationStatus = OperationStatus.ERROR
                    statusBannerText = "GAGAL: File $fileName kosong!"
                    appendLog(statusBannerText)
                    return
                }
                romBuffer = bytes.copyOf(maxOf(bytes.size, 64 * 1024))
                hasValidRomLoaded = true
                detectedPartNumber = "UNKNOWN-ECU"
                autoDetectPartNumberAndLoadXdf(fallbackFileName = fileName)
                updateHexPreview(romBuffer, 256)

                operationStatus = OperationStatus.SUCCESS
                statusBannerText = "BERHASIL MUAT [$detectedPartNumber]: $fileName (${bytes.size} bytes)"
                appendLog(statusBannerText)
            }
        } catch (e: Exception) {
            operationStatus = OperationStatus.ERROR
            statusBannerText = "GAGAL MUAT .BIN: ${e.message}"
            appendLog(statusBannerText)
        }
    }

    private fun saveXdfToOutputDirectory(tables: List<XdfTableDef>, baseFileName: String) {
        val xdfXmlContent = BinMapScanner.generateXdfXml(
            tables = tables,
            title = "CandsTech_$detectedPartNumber"
        )
        val xdfFileName = "${baseFileName}.xdf"

        try {
            val treeUri = outputFolderUri
            if (treeUri != null) {
                val pickedDir = DocumentFile.fromTreeUri(this, treeUri)
                val newFile = pickedDir?.createFile("application/xml", xdfFileName)
                if (newFile != null) {
                    contentResolver.openOutputStream(newFile.uri)?.use { out ->
                        out.write(xdfXmlContent.toByteArray(Charsets.UTF_8))
                    }
                    appendLog("File XDF dibuat: [$outputFolderLabel/$xdfFileName]")
                    return
                }
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, xdfFileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/xml")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, "${Environment.DIRECTORY_DOCUMENTS}/CandsTech")
                }
                val itemUri = contentResolver.insert(MediaStore.Files.getContentUri("external"), values)
                if (itemUri != null) {
                    contentResolver.openOutputStream(itemUri)?.use { out ->
                        out.write(xdfXmlContent.toByteArray(Charsets.UTF_8))
                    }
                    appendLog("File XDF dibuat: Documents/CandsTech/$xdfFileName")
                    return
                }
            }

            val docsDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "CandsTech")
            if (!docsDir.exists()) docsDir.mkdirs()
            File(docsDir, xdfFileName).writeText(xdfXmlContent, Charsets.UTF_8)
            appendLog("File XDF dibuat: Documents/CandsTech/$xdfFileName")
        } catch (e: Exception) {
            appendLog("Gagal menulis file XDF: ${e.message}")
        }
    }

    private fun saveRomToOutputDirectory(tag: String): String? {
        validateAndFixChecksum(saveAfter = false)
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ROOT).format(Date())
        val safePartCode = detectedPartNumber.replace(Regex("[^A-Za-z0-9\\-]"), "_")
        val baseName = "${safePartCode}_${tag}_${timestamp}"
        val fileName = "${baseName}.bin"

        try {
            val treeUri = outputFolderUri
            if (treeUri != null) {
                val pickedDir = DocumentFile.fromTreeUri(this, treeUri)
                val newFile = pickedDir?.createFile("application/octet-stream", fileName)
                if (newFile != null) {
                    contentResolver.openOutputStream(newFile.uri)?.use { out ->
                        out.write(romBuffer)
                    }
                    saveXdfToOutputDirectory(xdfTables, baseName)
                    appendLog("Tersimpan ke [$outputFolderLabel/$fileName]")
                    return "$outputFolderLabel/$baseName (.bin & .xdf)"
                }
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/octet-stream")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, "${Environment.DIRECTORY_DOCUMENTS}/CandsTech")
                }
                val itemUri = contentResolver.insert(MediaStore.Files.getContentUri("external"), values)
                if (itemUri != null) {
                    contentResolver.openOutputStream(itemUri)?.use { out ->
                        out.write(romBuffer)
                    }
                    saveXdfToOutputDirectory(xdfTables, baseName)
                    appendLog("Tersimpan di: Documents/CandsTech/$fileName")
                    return "Documents/CandsTech/$baseName (.bin & .xdf)"
                }
            }

            val docsDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "CandsTech")
            if (!docsDir.exists()) docsDir.mkdirs()
            val outFile = File(docsDir, fileName)
            FileOutputStream(outFile).use { it.write(romBuffer) }
            saveXdfToOutputDirectory(xdfTables, baseName)
            return "Documents/CandsTech/$baseName (.bin & .xdf)"
        } catch (e: Exception) {
            appendLog("Gagal menyimpan file hasil: ${e.message}")
            return null
        }
    }

    private fun editFuelCell(row: Int, col: Int, delta: Int) {
        if (selectedTableIndex !in xdfTables.indices) return
        val table = xdfTables[selectedTableIndex]
        val maxVal = if (table.elementSizeBits == 16) 65535 else 255

        val currentVal = activeMapData[row][col]
        val newVal = (currentVal + delta).coerceIn(0, maxVal)
        activeMapData[row][col] = newVal

        val byteStep = if (table.elementSizeBits == 16) 2 else 1
        val offset = table.address + ((row * table.cols + col) * byteStep)
        if (offset + byteStep <= romBuffer.size) {
            if (byteStep == 2) {
                if (table.isLittleEndian) {
                    romBuffer[offset] = (newVal and 0xFF).toByte()
                    romBuffer[offset + 1] = ((newVal shr 8) and 0xFF).toByte()
                } else {
                    romBuffer[offset] = ((newVal shr 8) and 0xFF).toByte()
                    romBuffer[offset + 1] = (newVal and 0xFF).toByte()
                }
            } else {
                romBuffer[offset] = newVal.toByte()
            }
        }
        hasValidRomLoaded = true
        updateHexPreview(romBuffer, 256)
        appendLog("Edit [$detectedPartNumber] @ 0x${offset.toString(16).uppercase(Locale.ROOT)} [${rowLabels.getOrNull(row)} | ${colLabels.getOrNull(col)}]: $currentVal -> $newVal")
    }

    /**
     * Membaca sensor live REAL dari ECU Honda via K-Line (Table 0x17)
     */
    private fun pollLiveSensorReal() {
        val port = usbSerialPort
        if (!isConnected || port == null) {
            operationStatus = OperationStatus.ERROR
            statusBannerText = "GAGAL BACA SENSOR: USB OTG K-Line belum terhubung!"
            appendLog(statusBannerText)
            return
        }

        lifecycleScope.launch {
            val sensor = withContext(Dispatchers.IO) {
                HondaKLineProtocol.readLiveSensors(port)
            }
            if (sensor != null) {
                liveRpm = sensor.rpm
                liveTps = sensor.tpsPercent
                liveAfr = sensor.afr
                operationStatus = OperationStatus.SUCCESS
                statusBannerText = String.format(
                    Locale.ROOT,
                    "LIVE ECU: RPM=%d | TPS=%d%% | AFR=%.1f | ECT=%d°C | %.1fV",
                    sensor.rpm, sensor.tpsPercent, sensor.afr, sensor.ectCelsius, sensor.batteryVolt
                )
                appendLog(statusBannerText)
            } else {
                operationStatus = OperationStatus.ERROR
                statusBannerText = "TIMEOUT SENSOR: ECU tidak membalas paket Table 0x17 (Pastikan Kontak ON!)"
                appendLog(statusBannerText)
            }
        }
    }

    private fun applyAutoAfrCorrection() {
        if (liveAfr <= 0.0f || liveRpm <= 0) {
            operationStatus = OperationStatus.ERROR
            statusBannerText = "GAGAL AUTO AFR: Tekan 'Baca Sensor' dari ECU terlebih dahulu!"
            appendLog(statusBannerText)
            return
        }

        val target = targetAfrInput.toFloatOrNull()
        if (target == null || target !in 10.0f..18.0f) {
            operationStatus = OperationStatus.ERROR
            statusBannerText = "GAGAL: Target AFR harus antara 10.0 - 18.0!"
            appendLog(statusBannerText)
            return
        }
        if (activeMapData.isEmpty() || activeMapData[0].isEmpty()) return

        val rIdx = rowLabels.indices.minByOrNull {
            kotlin.math.abs((rowLabels[it].filter { ch -> ch.isDigit() }.toIntOrNull() ?: 6000) - liveRpm)
        } ?: 0
        val cIdx = colLabels.indices.minByOrNull {
            kotlin.math.abs((colLabels[it].filter { ch -> ch.isDigit() }.toIntOrNull() ?: 50) - liveTps)
        } ?: 0

        val currentFuel = activeMapData[rIdx][cIdx]
        val correctionFactor = liveAfr / target
        val correctedFuel = (currentFuel * correctionFactor).roundToInt()
        val delta = correctedFuel - currentFuel

        editFuelCell(rIdx, cIdx, delta)

        val pctChange = ((correctionFactor - 1.0f) * 100).roundToInt()
        val sign = if (pctChange >= 0) "+" else ""
        val msg = "AUTO AFR [$detectedPartNumber | ${rowLabels[rIdx]} | ${colLabels[cIdx]}]: $liveAfr -> $target ($sign$pctChange%)"
        operationStatus = OperationStatus.SUCCESS
        statusBannerText = "BERHASIL: $msg"
        validateAndFixChecksum(saveAfter = false)
    }

    private fun scanAndConnectUsb() {
        val availableDrivers = UsbSerialProber.getDefaultProber().findAllDrivers(usbManager)
        if (availableDrivers.isEmpty()) {
            operationStatus = OperationStatus.ERROR
            statusBannerText = "GAGAL: Adapter USB Serial (FTDI/CH340/CP2102) tidak terdeteksi!"
            appendLog(statusBannerText)
            return
        }
        val driver = availableDrivers[0]
        val connection = usbManager?.openDevice(driver.device)
        if (connection == null) {
            val intent = Intent(ACTION_USB_PERMISSION)
            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            } else {
                PendingIntent.FLAG_UPDATE_CURRENT
            }
            val permissionIntent = PendingIntent.getBroadcast(this, 0, intent, flags)
            usbManager?.requestPermission(driver.device, permissionIntent)
            return
        }

        val port = driver.ports[0]
        try {
            port.open(connection)
            port.setParameters(10400, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
            usbSerialPort = port
            isConnected = true
            operationStatus = OperationStatus.SUCCESS
            statusBannerText = "USB SERIAL SIAP (10400 8N1) — Klik 'Read & Save' untuk Fast-Init ECU"
            appendLog(statusBannerText)
        } catch (e: Exception) {
            isConnected = false
            operationStatus = OperationStatus.ERROR
            statusBannerText = "GAGAL KONEKSI USB: ${e.message}"
            appendLog(statusBannerText)
        }
    }

    /**
     * Pembacaan REAL EEPROM / ROM ECU Honda via Hardware Fast-Init K-Line
     */
    private fun readEepromMemoryReal() {
        if (operationStatus == OperationStatus.RUNNING) return

        val port = usbSerialPort
        if (!isConnected || port == null) {
            operationStatus = OperationStatus.ERROR
            progressValue = 0f
            progressLabel = "Dibatalkan (USB OTG Offline)"
            statusBannerText = "GAGAL READ: Hubungkan kabel USB OTG K-Line ke motor terlebih dahulu!"
            appendLog(statusBannerText)
            return
        }

        lifecycleScope.launch {
            operationStatus = OperationStatus.RUNNING
            progressValue = 0.05f
            progressLabel = "Mengirim Hardware Fast-Init (70ms LOW / 120ms HIGH)..."
            statusBannerText = "HANDSHAKE K-LINE HONDA..."
            appendLog("Menjalankan Fast-Init K-Line 10400 baud...")

            val initOk = withContext(Dispatchers.IO) {
                HondaKLineProtocol.performHondaFastInit(port)
            }

            if (!initOk) {
                operationStatus = OperationStatus.ERROR
                progressValue = 0f
                progressLabel = "Handshake Gagal (0 byte balasan ECU)"
                statusBannerText = "GAGAL HANDSHAKE ECU: Tidak ada respon dari K-Line! Cek Kontak ON, Aki, & Pin K-Line."
                appendLog(statusBannerText)
                return@launch
            }

            // Baca identitas 5-Byte ECM ID / Part Number asli dari ECU
            progressLabel = "Membaca ECM ID / Part Number ECU..."
            val ecuId = withContext(Dispatchers.IO) {
                HondaKLineProtocol.readEcuIdentity(port)
            }

            if (ecuId != null) {
                detectedPartNumber = ecuId.partNumber
                appendLog("ECM ID Terbaca: 0x${ecuId.ecmIdHex} -> Part Number: ${ecuId.partNumber}")
            } else {
                appendLog("Peringatan: ECM ID tidak terbaca di header, lanjut membaca blok memori...")
            }

            // Baca blok memori 64KB secara bertahap (256 blok x 256 byte)
            val totalSteps = 256
            val stepSize = 256
            var validBytesRead = 0
            var abortedError: String? = null

            withContext(Dispatchers.IO) {
                try {
                    for (step in 0 until totalSteps) {
                        val addr = step * stepSize
                        val blockData = HondaKLineProtocol.readMemoryBlock(port, addr, stepSize)

                        if (blockData != null && blockData.isNotEmpty()) {
                            val copyLen = minOf(blockData.size, romBuffer.size - addr)
                            System.arraycopy(blockData, 0, romBuffer, addr, copyLen)
                            validBytesRead += copyLen
                        }

                        if (step % 4 == 0 || step == totalSteps - 1) {
                            withContext(Dispatchers.Main) {
                                progressValue = (step + 1).toFloat() / totalSteps.toFloat()
                                val pct = (progressValue * 100).roundToInt()
                                progressLabel = String.format(
                                    Locale.ROOT,
                                    "Membaca 0x%04X - 0x%04X (%d%%) | RX: %d B",
                                    addr, addr + stepSize - 1, pct, validBytesRead
                                )
                            }
                        }
                    }
                } catch (e: Exception) {
                    abortedError = e.message ?: "Koneksi K-Line terputus"
                }
            }

            if (abortedError != null || validBytesRead == 0) {
                operationStatus = OperationStatus.ERROR
                progressLabel = "Gagal Baca Memori (RX: $validBytesRead bytes)"
                statusBannerText = "GAGAL READ EEPROM: ${abortedError ?: "ECU menolak perintah baca memori (Security/Seed-Key terkunci)"}"
                appendLog(statusBannerText)
                return@launch
            }

            hasValidRomLoaded = true
            flashTargetLabel = "ECU_DUMP_${detectedPartNumber}.bin ($validBytesRead bytes)"
            autoDetectPartNumberAndLoadXdf()
            updateHexPreview(romBuffer, 256)

            val savedName = saveRomToOutputDirectory("dump")
            operationStatus = OperationStatus.SUCCESS
            progressLabel = "Selesai Membaca [$detectedPartNumber] ($validBytesRead bytes)"
            statusBannerText = if (savedName != null) "BERHASIL READ & SAVE: $savedName" else "BERHASIL READ ROM [$detectedPartNumber]"
            appendLog(statusBannerText)
        }
    }

    /**
     * Penulisan REAL ROM ke ECU Honda via K-Line dengan verifikasi respon setiap blok
     */
    private fun writeEepromMemoryReal() {
        if (operationStatus == OperationStatus.RUNNING) return

        val port = usbSerialPort
        if (!isConnected || port == null) {
            operationStatus = OperationStatus.ERROR
            progressValue = 0f
            progressLabel = "Dibatalkan (USB OTG Offline)"
            statusBannerText = "GAGAL FLASH [$detectedPartNumber]: Hubungkan adapter USB OTG ke ECU terlebih dahulu!"
            appendLog(statusBannerText)
            return
        }

        if (!hasValidRomLoaded) {
            operationStatus = OperationStatus.ERROR
            progressValue = 0f
            progressLabel = "Dibatalkan (Buffer ROM Kosong)"
            statusBannerText = "GAGAL FLASH: Pilih file .BIN atau lakukan 'Read & Save' terlebih dahulu!"
            appendLog(statusBannerText)
            return
        }

        lifecycleScope.launch {
            validateAndFixChecksum(saveAfter = false)
            operationStatus = OperationStatus.RUNNING
            progressValue = 0.02f
            progressLabel = "Inisialisasi Mode Flashing ECU [$detectedPartNumber]..."
            statusBannerText = "SEDANG FLASHING [$detectedPartNumber] — JANGAN MATIKAN KONTAK!"
            appendLog("Memulai Fast-Init & Flashing [$detectedPartNumber] (${romBuffer.size} bytes)...")

            val initOk = withContext(Dispatchers.IO) {
                HondaKLineProtocol.performHondaFastInit(port)
            }

            if (!initOk) {
                operationStatus = OperationStatus.ERROR
                progressValue = 0f
                progressLabel = "Gagal Masuk Mode Boot/Flash"
                statusBannerText = "GAGAL FLASH: ECU tidak merespons Fast-Init K-Line!"
                appendLog(statusBannerText)
                return@launch
            }

            val chunkSize = 128
            val totalChunks = romBuffer.size / chunkSize
            var chunksWritten = 0
            var writeError: String? = null

            withContext(Dispatchers.IO) {
                try {
                    for (idx in 0 until totalChunks) {
                        val addr = idx * chunkSize
                        val chunk = romBuffer.copyOfRange(addr, addr + chunkSize)
                        val ack = HondaKLineProtocol.writeMemoryBlock(port, addr, chunk)
                        if (!ack) {
                            writeError = String.format(Locale.ROOT, "Tidak ada ACK dari ECU pada alamat 0x%04X", addr)
                            break
                        }
                        chunksWritten++

                        if (idx % 8 == 0 || idx == totalChunks - 1) {
                            withContext(Dispatchers.Main) {
                                progressValue = (idx + 1).toFloat() / totalChunks.toFloat()
                                val pct = (progressValue * 100).roundToInt()
                                progressLabel = String.format(
                                    Locale.ROOT,
                                    "Flashing 0x%04X - 0x%04X (%d%%)",
                                    addr, addr + chunkSize - 1, pct
                                )
                            }
                        }
                    }
                } catch (e: Exception) {
                    writeError = e.message ?: "Error transmisi K-Line"
                }
            }

            if (writeError != null || chunksWritten < totalChunks) {
                operationStatus = OperationStatus.ERROR
                progressLabel = "Terhenti pada ${(progressValue * 100).roundToInt()}%"
                statusBannerText = "GAGAL FLASH ECU: ${writeError ?: "Penulisan tidak lengkap"}"
                appendLog(statusBannerText)
            } else {
                operationStatus = OperationStatus.SUCCESS
                progressLabel = "Flashing [$detectedPartNumber] Selesai 100%"
                statusBannerText = "BERHASIL FLASH ECU [$detectedPartNumber]! Matikan kunci kontak 5 detik lalu nyalakan."
                appendLog(statusBannerText)
            }
        }
    }

    private fun validateAndFixChecksum(saveAfter: Boolean = true) {
        if (!hasValidRomLoaded && saveAfter) {
            operationStatus = OperationStatus.ERROR
            statusBannerText = "GAGAL CHECKSUM: Belum ada file .BIN yang dimuat!"
            appendLog(statusBannerText)
            return
        }

        var sum = 0
        for (i in 0 until romBuffer.size - 2) {
            sum += (romBuffer[i].toInt() and 0xFF)
        }
        val checksum = sum and 0xFFFF
        romBuffer[romBuffer.size - 2] = ((checksum shr 8) and 0xFF).toByte()
        romBuffer[romBuffer.size - 1] = (checksum and 0xFF).toByte()

        val hexSum = checksum.toString(16).uppercase(Locale.ROOT).padStart(4, '0')
        appendLog("Checksum [$detectedPartNumber] valid & diperbaiki: 0x$hexSum [OK]")
        if (saveAfter) {
            val savedName = saveRomToOutputDirectory("cksum")
            operationStatus = OperationStatus.SUCCESS
            statusBannerText = "BERHASIL FIX CHECKSUM (0x$hexSum) -> $savedName"
        }
    }

    private fun updateHexPreview(data: ByteArray, length: Int) {
        val sb = StringBuilder()
        for (i in 0 until minOf(length, data.size) step 16) {
            sb.append(String.format(Locale.ROOT, "%08X: ", i))
            for (j in 0 until 16) {
                if (i + j < data.size) {
                    sb.append(String.format(Locale.ROOT, "%02X ", data[i + j]))
                } else {
                    sb.append("   ")
                }
            }
            sb.append("\n")
        }
        hexDumpText.value = sb.toString()
    }

    private fun appendLog(msg: String) {
        logBuffer.value += "$msg\n"
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(broadcastReceiver)
            usbSerialPort?.close()
        } catch (_: Exception) {}
    }
}
