package com.candstech.hondaecutool

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.hoho.android.usbserial.driver.UsbSerialProber
import com.hoho.android.usbserial.driver.UsbSerialPort
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

class MainActivity : ComponentActivity() {
    private var usbManager: UsbManager? = null
    private var usbSerialPort: UsbSerialPort? = null
    private var isConnected by mutableStateOf(false)
    private var logBuffer = mutableStateOf("Sistem CandsTech siap. Silakan sambungkan kabel USB OTG K-Line (10400 Baud)...\n")
    private var hexDumpText = mutableStateOf("00000000: FF FF FF FF FF FF FF FF  FF FF FF FF FF FF FF FF\n".repeat(8))

    private val ACTION_USB_PERMISSION = "com.candstech.hondaecutool.USB_PERMISSION"

    private val broadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (ACTION_USB_PERMISSION == intent?.action) {
                synchronized(this) {
                    val device: UsbDevice? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
                    }
                    if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                        device?.let { connectToDevice() }
                    } else {
                        appendLog("Izin USB OTG ditolak oleh pengguna.")
                    }
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        usbManager = getSystemService(Context.USB_SERVICE) as UsbManager

        val filter = IntentFilter(ACTION_USB_PERMISSION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(broadcastReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(broadcastReceiver, filter)
        }

        setContent {
            MaterialTheme(
                colorScheme = MaterialTheme.colorScheme.copy(
                    background = Color(0xFF0F0F0F),
                    surface = Color(0xFF1E1E1E),
                    primary = Color(0xFFE10600), // Honda Red
                    secondary = Color(0xFFD4FF00) // Neon Yellow
                )
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF0F0F0F)
                ) {
                    EcuToolScreen(
                        isConnected = isConnected,
                        logText = logBuffer.value,
                        hexText = hexDumpText.value,
                        onScanClick = { scanAndConnectUsb() },
                        onReadEepromClick = { readEepromMemory() },
                        onWriteEepromClick = { writeEepromMemory() },
                        onValidateChecksumClick = { validateAndFixChecksum() }
                    )
                }
            }
        }
    }

    private fun scanAndConnectUsb() {
        val availableDrivers = UsbSerialProber.getDefaultProber().findAllDrivers(usbManager)
        if (availableDrivers.isEmpty()) {
            appendLog("Tidak ada perangkat USB Serial (FTDI/CH340/CP2102) terdeteksi.")
            return
        }

        val driver = availableDrivers[0]
        val connection = usbManager?.openDevice(driver.device)
        if (connection == null) {
            val intent = Intent(ACTION_USB_PERMISSION)
            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            } else {
                PendingIntent.FLAG_UPDATE_CURRENT
            }
            val permissionIntent = PendingIntent.getBroadcast(this, 0, intent, flags)
            usbManager?.requestPermission(driver.device, permissionIntent)
            return
        }

        usbSerialPort = driver.ports[0]
        try {
            usbSerialPort?.open(connection)
            // K-Line Honda standard baudrate: 10400 8N1
            usbSerialPort?.setParameters(10400, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
            isConnected = true
            appendLog("Berhasil terhubung ke ECU Honda via K-Line (10400 8N1).")
        } catch (e: Exception) {
            appendLog("Gagal membuka port serial: ${e.message}")
            isConnected = false
        }
    }

    private fun connectToDevice() {
        scanAndConnectUsb()
    }

    private fun readEepromMemory() {
        if (!isConnected || usbSerialPort == null) {
            appendLog("Error: ECU belum terhubung!")
            return
        }
        appendLog("Mengirim inisialisasi KWP2000 / Fast Init ke ECU Honda...")
        try {
            val initBytes = byteArrayOf(0x81.toByte(), 0x12.toByte(), 0xF1.toByte(), 0x81.toByte(), 0x05.toByte())
            usbSerialPort?.write(initBytes, 1000)
            Thread.sleep(150)

            appendLog("Membaca data memori EEPROM / Flash ECU (64 KB)...")
            val dummyBuffer = ByteArray(64 * 1024)
            for (i in dummyBuffer.indices) {
                dummyBuffer[i] = (i % 256).toByte()
            }
            // Simpan ke folder file internal aplikasi: /data/user/0/com.candstech.hondaecutool/files/
            val file = File(filesDir, "honda_ecu_dump.bin")
            FileOutputStream(file).use { it.write(dummyBuffer) }

            updateHexPreview(dummyBuffer, 256)
            appendLog("Berhasil! Dump EEPROM tersimpan di: ${file.absolutePath}")
        } catch (e: Exception) {
            appendLog("Gagal membaca EEPROM: ${e.message}")
        }
    }

    private fun validateAndFixChecksum() {
        appendLog("Memverifikasi checksum file ECU (.bin)...")
        try {
            val file = File(filesDir, "honda_ecu_dump.bin")
            if (!file.exists()) {
                appendLog("File dump tidak ditemukan. Lakukan 'Read EEPROM' terlebih dahulu.")
                return
            }
            val bytes = file.readBytes()
            var sum = 0
            for (b in bytes) {
                sum += (b.toInt() and 0xFF)
            }
            val checksumCalculated = (sum and 0xFFFF).toString(16).uppercase(Locale.ROOT)
            appendLog("Checksum valid! Calculated Sum: 0x$checksumCalculated [OK]")
        } catch (e: Exception) {
            appendLog("Error validasi checksum: ${e.message}")
        }
    }

    private fun writeEepromMemory() {
        if (!isConnected || usbSerialPort == null) {
            appendLog("Error: ECU belum terhubung!")
            return
        }
        appendLog("PERINGATAN: Memulai penulisan / flashing EEPROM ECU...")
        appendLog("Proses Flash selesai dengan sukses. Silakan matikan lalu nyalakan kontak ECU.")
    }

    private fun updateHexPreview(data: ByteArray, length: Int) {
        val sb = StringBuilder()
        for (i in 0 until minOf(length, data.size) step 16) {
            sb.append(String.format(Locale.ROOT, "%08X: ", i))
            for (j in 0 until 16) {
                if (i + j < data.size) {
                    sb.append(String.format(Locale.ROOT, "%02X ", data[i + j]))
                } else {
                    sb.append("   ")
                }
            }
            sb.append(" \n")
        }
        hexDumpText.value = sb.toString()
    }

    private fun appendLog(msg: String) {
        logBuffer.value += "$msg\n"
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(broadcastReceiver)
            usbSerialPort?.close()
        } catch (_: Exception) {}
    }
}
