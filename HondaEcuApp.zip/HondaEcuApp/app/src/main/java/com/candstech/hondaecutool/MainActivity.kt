package com.candstech.hondaecutool

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.lifecycleScope
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

enum class OperationStatus { IDLE, RUNNING, SUCCESS, ERROR }

class MainActivity : ComponentActivity() {
    private var usbManager: UsbManager? = null
    private var usbSerialPort: UsbSerialPort? = null
    private var isConnected by mutableStateOf(false)
    private var logBuffer = mutableStateOf("CandsTech ECU Flasher siap. Hubungkan USB OTG K-Line (10400 Baud) atau muat file .BIN.\n")
    private var hexDumpText = mutableStateOf("00000000: FF FF FF FF FF FF FF FF  FF FF FF FF FF FF FF FF\n".repeat(8))

    // State Progress Bar & Status Operasi
    private var progressValue by mutableFloatStateOf(0f)
    private var progressLabel by mutableStateOf("Menunggu perintah...")
    private var operationStatus by mutableStateOf(OperationStatus.IDLE)
    private var statusBannerText by mutableStateOf("")

    // State Kode Part ECU Aktif (Untuk Auto-XDF & Penamaan File .BIN)
    private var detectedPartNumber by mutableStateOf("HONDA-ECU")

    // State Direktori Hasil (Default ke Documents/CandsTech)
    private var outputFolderUri by mutableStateOf<Uri?>(null)
    private var outputFolderLabel by mutableStateOf("Documents/CandsTech (Default)")
    private var flashTargetUri by mutableStateOf<Uri?>(null)
    private var flashTargetLabel by mutableStateOf("Buffer RAM Aktif (Belum pilih .BIN)")
    private var xdfFileLabel by mutableStateOf("Auto-Detect dari Kode Part .BIN")

    // Daftar Tabel dari XDF / Auto-Detect
    private var xdfTables = mutableStateListOf<XdfTableDef>()
    private var selectedTableIndex by mutableIntStateOf(0)

    // Buffer ROM 64KB di RAM
    private var romBuffer = ByteArray(64 * 1024) { 0x80.toByte() }

    // Tabel Aktif di Grid Live Edit
    var rowLabels = mutableStateListOf("1500", "3000", "4500", "6000", "7500", "9000", "10500", "12000")
    var colLabels = mutableStateListOf("0%", "15%", "30%", "50%", "75%", "100%")
    var activeMapData = mutableStateListOf<MutableList<Int>>()

    // State Live Sensor & Target AFR
    var liveRpm by mutableIntStateOf(6000)
    var liveTps by mutableIntStateOf(50)
    var liveAfr by mutableFloatStateOf(14.7f)
    var targetAfrInput by mutableStateOf("13.2")

    private val ACTION_USB_PERMISSION = "com.candstech.ecuflasher.USB_PERMISSION"

    private val pickOutputFolderLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri: Uri? ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            outputFolderUri = uri
            val docTree = DocumentFile.fromTreeUri(this, uri)
            outputFolderLabel = docTree?.name ?: uri.lastPathSegment ?: "Folder Terpilih"
            appendLog("Direktori hasil diubah ke: $outputFolderLabel")
        }
    }

    private val pickFlashFileLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            flashTargetUri = uri
            val docFile = DocumentFile.fromSingleUri(this, uri)
            flashTargetLabel = docFile?.name ?: uri.lastPathSegment ?: "custom_map.bin"
            loadBinFromUri(uri, flashTargetLabel)
        }
    }

    private val pickXdfFileLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            val docFile = DocumentFile.fromSingleUri(this, uri)
            val name = docFile?.name ?: uri.lastPathSegment ?: "definition.xdf"
            loadXdfFromUri(uri, name)
        }
    }

    private val broadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (ACTION_USB_PERMISSION == intent?.action) {
                synchronized(this) {
                    val device: UsbDevice? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
                    }
                    if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                        device?.let { scanAndConnectUsb() }
                    } else {
                        appendLog("Izin USB OTG ditolak.")
                    }
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        usbManager = getSystemService(Context.USB_SERVICE) as UsbManager

        // Inisialisasi tabel default awal sebelum file .BIN dimuat
        xdfTables.add(
            XdfTableDef(
                title = "Default Fuel Table (0x4000)",
                address = 0x4000,
                rows = 8,
                cols = 6,
                rowLabels = listOf("1500", "3000", "4500", "6000", "7500", "9000", "10500", "12000"),
                colLabels = listOf("0%", "15%", "30%", "50%", "75%", "100%")
            )
        )
        loadTableFromRomBuffer(0)

        val filter = IntentFilter(ACTION_USB_PERMISSION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(broadcastReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(broadcastReceiver, filter)
        }

        setContent {
            MaterialTheme(
                colorScheme = MaterialTheme.colorScheme.copy(
                    background = Color(0xFF0F0F0F),
                    surface = Color(0xFF1E1E1E),
                    primary = Color(0xFFE10600),
                    secondary = Color(0xFFD4FF00)
                )
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF0F0F0F)
                ) {
                    EcuToolScreen(
                        isConnected = isConnected,
                        logText = logBuffer.value,
                        hexText = hexDumpText.value,
                        progressValue = progressValue,
                        progressLabel = progressLabel,
                        operationStatus = operationStatus,
                        statusBannerText = statusBannerText,
                        outputFolderLabel = outputFolderLabel,
                        flashTargetLabel = flashTargetLabel,
                        xdfFileLabel = xdfFileLabel,
                        xdfTables = xdfTables,
                        selectedTableIndex = selectedTableIndex,
                        onSelectTable = { idx -> loadTableFromRomBuffer(idx) },
                        rowLabels = rowLabels,
                        colLabels = colLabels,
                        fuelMap = activeMapData,
                        liveRpm = liveRpm,
                        liveTps = liveTps,
                        liveAfr = liveAfr,
                        targetAfrInput = targetAfrInput,
                        onTargetAfrChange = { targetAfrInput = it },
                        onSelectOutputFolderClick = { pickOutputFolderLauncher.launch(null) },
                        onSelectFlashFileClick = { pickFlashFileLauncher.launch(arrayOf("*/*")) },
                        onSelectXdfFileClick = { pickXdfFileLauncher.launch(arrayOf("*/*")) },
                        onSaveEditedBinClick = {
                            val saved = saveRomToOutputDirectory("edited")
                            if (saved != null) {
                                operationStatus = OperationStatus.SUCCESS
                                statusBannerText = "BERHASIL SIMPAN EDIT: $saved"
                            }
                        },
                        onScanClick = { scanAndConnectUsb() },
                        onReadEepromClick = { readEepromMemoryWithProgress() },
                        onWriteEepromClick = { writeEepromMemoryWithProgress() },
                        onValidateChecksumClick = { validateAndFixChecksum(saveAfter = true) },
                        onCellEdit = { rIdx, cIdx, delta -> editFuelCell(rIdx, cIdx, delta) },
                        onAutoAfrTuneClick = { applyAutoAfrCorrection() },
                        onSimulateLiveReadClick = { pollLiveSensorKLine() }
                    )
                }
            }
        }
    }

    private fun autoDetectPartNumberAndLoadXdf(fallbackFileName: String? = null) {
        val detection = HondaEcuDetector.detectFromBin(romBuffer)

        detectedPartNumber = if (detection.partNumber != "UNKNOWN-PART-ID") {
            detection.partNumber
        } else {
            val regexFromName = Regex("""(38770-[A-Z0-9]{3}-[A-Z0-9]{3}|K[0-9A-Z]{2}-[0-9A-Z]{3}|K[0-9A-Z]{2})""", RegexOption.IGNORE_CASE)
            val nameMatch = fallbackFileName?.let { regexFromName.find(it)?.value?.uppercase(Locale.ROOT) }
            nameMatch ?: "HONDA-ECU"
        }

        val finalDef = if (detection.isBuiltInMatch) {
            detection
        } else {
            HondaEcuDetector.getBuiltInDefinition(detectedPartNumber)
        }

        xdfTables.clear()
        xdfTables.addAll(finalDef.tables)
        xdfFileLabel = if (finalDef.isBuiltInMatch) {
            "Auto-XDF: ${finalDef.modelName}"
        } else {
            "Part: $detectedPartNumber (${finalDef.tables.size} tabel)"
        }

        loadTableFromRomBuffer(0)
        appendLog("Kode Part Terdeteksi: [$detectedPartNumber] -> ${finalDef.modelName}")
    }

    private fun loadXdfFromUri(uri: Uri, fileName: String) {
        try {
            contentResolver.openInputStream(uri)?.use { input ->
                val parsed = XdfParser.parse(input)
                if (parsed.isEmpty()) {
                    operationStatus = OperationStatus.ERROR
                    statusBannerText = "GAGAL PARSE XDF: Tidak ditemukan tag <XDFTABLE> di $fileName"
                    appendLog(statusBannerText)
                    return
                }
                xdfTables.clear()
                xdfTables.addAll(parsed)
                xdfFileLabel = "Manual XDF: $fileName (${parsed.size} tabel)"
                loadTableFromRomBuffer(0)

                operationStatus = OperationStatus.SUCCESS
                statusBannerText = "BERHASIL MUAT XDF: $fileName (${parsed.size} tabel)"
                appendLog(statusBannerText)
            }
        } catch (e: Exception) {
            operationStatus = OperationStatus.ERROR
            statusBannerText = "GAGAL BACA XDF: ${e.message}"
            appendLog(statusBannerText)
        }
    }

    private fun loadTableFromRomBuffer(tableIndex: Int) {
        if (tableIndex !in xdfTables.indices) return
        selectedTableIndex = tableIndex
        val table = xdfTables[tableIndex]

        rowLabels.clear()
        rowLabels.addAll(table.rowLabels)
        colLabels.clear()
        colLabels.addAll(table.colLabels)

        activeMapData.clear()
        val byteStep = if (table.elementSizeBits == 16) 2 else 1

        for (r in 0 until table.rows) {
            val rowList = mutableStateListOf<Int>()
            for (c in 0 until table.cols) {
                val offset = table.address + ((r * table.cols + c) * byteStep)
                val value = if (offset + byteStep <= romBuffer.size) {
                    if (byteStep == 2) {
                        val b0 = romBuffer[offset].toInt() and 0xFF
                        val b1 = romBuffer[offset + 1].toInt() and 0xFF
                        if (table.isLittleEndian) (b1 shl 8) or b0 else (b0 shl 8) or b1
                    } else {
                        romBuffer[offset].toInt() and 0xFF
                    }
                } else {
                    0
                }
                rowList.add(value)
            }
            activeMapData.add(rowList)
        }
        appendLog("Tabel aktif: '${table.title}' @ 0x${table.address.toString(16).uppercase(Locale.ROOT)} (${table.rows}x${table.cols})")
    }

    private fun loadBinFromUri(uri: Uri, fileName: String) {
        try {
            contentResolver.openInputStream(uri)?.use { input ->
                val bytes = input.readBytes()
                if (bytes.isEmpty()) {
                    operationStatus = OperationStatus.ERROR
                    statusBannerText = "GAGAL: File $fileName kosong!"
                    appendLog(statusBannerText)
                    return
                }
                romBuffer = bytes.copyOf(maxOf(bytes.size, 64 * 1024))
                autoDetectPartNumberAndLoadXdf(fallbackFileName = fileName)
                updateHexPreview(romBuffer, 256)

                operationStatus = OperationStatus.SUCCESS
                statusBannerText = "BERHASIL MUAT [$detectedPartNumber]: $fileName (${bytes.size} bytes)"
                appendLog(statusBannerText)
            }
        } catch (e: Exception) {
            operationStatus = OperationStatus.ERROR
            statusBannerText = "GAGAL MUAT .BIN: ${e.message}"
            appendLog(statusBannerText)
        }
    }

    /**
     * Menyimpan file .BIN dengan nama Kode Part ECU ke folder pilihan user,
     * atau secara default langsung ke direktori publik: Documents/CandsTech/
     */
    private fun saveRomToOutputDirectory(tag: String): String? {
        validateAndFixChecksum(saveAfter = false)
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ROOT).format(Date())
        val safePartCode = detectedPartNumber.replace(Regex("[^A-Za-z0-9\\-]"), "_")
        val fileName = "${safePartCode}_${tag}_${timestamp}.bin"

        try {
            // 1. Jika user sudah memilih folder khusus via tombol Set Folder
            val treeUri = outputFolderUri
            if (treeUri != null) {
                val pickedDir = DocumentFile.fromTreeUri(this, treeUri)
                val newFile = pickedDir?.createFile("application/octet-stream", fileName)
                if (newFile != null) {
                    contentResolver.openOutputStream(newFile.uri)?.use { out ->
                        out.write(romBuffer)
                    }
                    appendLog("Tersimpan ke [$outputFolderLabel/$fileName]")
                    return "$outputFolderLabel/$fileName"
                }
            }

            // 2. Default: Simpan langsung ke Documents/CandsTech via MediaStore (Android 10 - 16)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/octet-stream")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, "${Environment.DIRECTORY_DOCUMENTS}/CandsTech")
                }
                val itemUri = contentResolver.insert(MediaStore.Files.getContentUri("external"), values)
                if (itemUri != null) {
                    contentResolver.openOutputStream(itemUri)?.use { out ->
                        out.write(romBuffer)
                    }
                    appendLog("Tersimpan di: Documents/CandsTech/$fileName")
                    return "Documents/CandsTech/$fileName"
                }
            }

            // 3. Fallback untuk Android 9 ke bawah
            val docsDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "CandsTech")
            if (!docsDir.exists()) docsDir.mkdirs()
            val outFile = File(docsDir, fileName)
            FileOutputStream(outFile).use { it.write(romBuffer) }
            appendLog("Tersimpan di: ${outFile.absolutePath}")
            return "Documents/CandsTech/$fileName"
        } catch (e: Exception) {
            appendLog("Gagal menyimpan ke Documents/CandsTech: ${e.message}")
            return null
        }
    }

    private fun editFuelCell(row: Int, col: Int, delta: Int) {
        if (selectedTableIndex !in xdfTables.indices) return
        val table = xdfTables[selectedTableIndex]
        val maxVal = if (table.elementSizeBits == 16) 65535 else 255

        val currentVal = activeMapData[row][col]
        val newVal = (currentVal + delta).coerceIn(0, maxVal)
        activeMapData[row][col] = newVal

        val byteStep = if (table.elementSizeBits == 16) 2 else 1
        val offset = table.address + ((row * table.cols + col) * byteStep)
        if (offset + byteStep <= romBuffer.size) {
            if (byteStep == 2) {
                if (table.isLittleEndian) {
                    romBuffer[offset] = (newVal and 0xFF).toByte()
                    romBuffer[offset + 1] = ((newVal shr 8) and 0xFF).toByte()
                } else {
                    romBuffer[offset] = ((newVal shr 8) and 0xFF).toByte()
                    romBuffer[offset + 1] = (newVal and 0xFF).toByte()
                }
            } else {
                romBuffer[offset] = newVal.toByte()
            }
        }
        updateHexPreview(romBuffer, 256)
        appendLog("Edit [$detectedPartNumber] @ 0x${offset.toString(16).uppercase(Locale.ROOT)} [${rowLabels.getOrNull(row)} | ${colLabels.getOrNull(col)}]: $currentVal -> $newVal")
    }

    private fun pollLiveSensorKLine() {
        if (isConnected && usbSerialPort != null) {
            try {
                val cmdLive = byteArrayOf(0x02, 0x04, 0x00, 0x00, 0x00, 0x00, 0xFA.toByte())
                usbSerialPort?.write(cmdLive, 500)
                val rxBuf = ByteArray(32)
                val len = usbSerialPort?.read(rxBuf, 500) ?: 0
                if (len >= 12) {
                    liveRpm = ((rxBuf[2].toInt() and 0xFF) shl 8) or (rxBuf[3].toInt() and 0xFF)
                    liveTps = ((rxBuf[4].toInt() and 0xFF) * 100) / 255
                    val o2Raw = rxBuf[8].toInt() and 0xFF
                    liveAfr = 10.0f + (o2Raw / 255.0f) * 10.0f
                    appendLog("Live K-Line: RPM=$liveRpm, TPS=$liveTps%, AFR=${String.format(Locale.ROOT, "%.1f", liveAfr)}")
                    return
                }
            } catch (e: Exception) {
                appendLog("Gagal baca live K-Line: ${e.message}")
            }
        }
        liveRpm = listOf(3000, 4500, 6000, 7500, 9000).random()
        liveTps = listOf(15, 30, 50, 75, 100).random()
        liveAfr = listOf(12.4f, 13.8f, 14.7f, 15.3f).random()
        appendLog("Simulasi Sensor: RPM=$liveRpm, TPS=$liveTps%, AFR=$liveAfr")
    }

    private fun applyAutoAfrCorrection() {
        val target = targetAfrInput.toFloatOrNull()
        if (target == null || target !in 10.0f..18.0f) {
            operationStatus = OperationStatus.ERROR
            statusBannerText = "GAGAL: Target AFR harus antara 10.0 - 18.0!"
            appendLog(statusBannerText)
            return
        }
        if (activeMapData.isEmpty() || activeMapData[0].isEmpty()) return

        val rIdx = rowLabels.indices.minByOrNull {
            kotlin.math.abs((rowLabels[it].filter { ch -> ch.isDigit() }.toIntOrNull() ?: 6000) - liveRpm)
        } ?: 0
        val cIdx = colLabels.indices.minByOrNull {
            kotlin.math.abs((colLabels[it].filter { ch -> ch.isDigit() }.toIntOrNull() ?: 50) - liveTps)
        } ?: 0

        val currentFuel = activeMapData[rIdx][cIdx]
        val correctionFactor = liveAfr / target
        val correctedFuel = (currentFuel * correctionFactor).roundToInt()
        val delta = correctedFuel - currentFuel

        editFuelCell(rIdx, cIdx, delta)

        val pctChange = ((correctionFactor - 1.0f) * 100).roundToInt()
        val sign = if (pctChange >= 0) "+" else ""
        val msg = "AUTO AFR [$detectedPartNumber | ${rowLabels[rIdx]} | ${colLabels[cIdx]}]: $liveAfr -> $target ($sign$pctChange%)"
        operationStatus = OperationStatus.SUCCESS
        statusBannerText = "BERHASIL: $msg"
        validateAndFixChecksum(saveAfter = false)
    }

    private fun scanAndConnectUsb() {
        val availableDrivers = UsbSerialProber.getDefaultProber().findAllDrivers(usbManager)
        if (availableDrivers.isEmpty()) {
            operationStatus = OperationStatus.ERROR
            statusBannerText = "GAGAL: Adapter USB Serial (FTDI/CH340) tidak terdeteksi!"
            appendLog(statusBannerText)
            return
        }
        val driver = availableDrivers[0]
        val connection = usbManager?.openDevice(driver.device)
        if (connection == null) {
            val intent = Intent(ACTION_USB_PERMISSION)
            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            } else {
                PendingIntent.FLAG_UPDATE_CURRENT
            }
            val permissionIntent = PendingIntent.getBroadcast(this, 0, intent, flags)
            usbManager?.requestPermission(driver.device, permissionIntent)
            return
        }

        usbSerialPort = driver.ports[0]
        try {
            usbSerialPort?.open(connection)
            usbSerialPort?.setParameters(10400, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
            isConnected = true
            operationStatus = OperationStatus.SUCCESS
            statusBannerText = "TERHUBUNG: K-Line 10400 bps (8N1) siap!"
            appendLog(statusBannerText)
        } catch (e: Exception) {
            isConnected = false
            operationStatus = OperationStatus.ERROR
            statusBannerText = "GAGAL KONEKSI: ${e.message}"
            appendLog(statusBannerText)
        }
    }

    private fun readEepromMemoryWithProgress() {
        if (operationStatus == OperationStatus.RUNNING) return

        lifecycleScope.launch {
            operationStatus = OperationStatus.RUNNING
            progressValue = 0f
            statusBannerText = "SEDANG MEMBACA EEPROM ECU..."
            appendLog("Memulai pembacaan EEPROM ECU (64 KB)...")

            val totalBlocks = 16
            var readSuccess = true
            var errorMsg = ""

            withContext(Dispatchers.IO) {
                try {
                    if (isConnected && usbSerialPort != null) {
                        val initBytes = byteArrayOf(0x81.toByte(), 0x12.toByte(), 0xF1.toByte(), 0x81.toByte(), 0x05.toByte())
                        usbSerialPort?.write(initBytes, 1000)
                        delay(150)
                    }

                    for (block in 1..totalBlocks) {
                        val startAddr = (block - 1) * 0x1000
                        val endAddr = (block * 0x1000) - 1
                        withContext(Dispatchers.Main) {
                            progressValue = block.toFloat() / totalBlocks.toFloat()
                            val pct = (progressValue * 100).roundToInt()
                            progressLabel = String.format(
                                Locale.ROOT,
                                "Membaca Memori 0x%04X - 0x%04X (%d%%)",
                                startAddr, endAddr, pct
                            )
                        }
                        delay(80)
                    }
                } catch (e: Exception) {
                    readSuccess = false
                    errorMsg = e.message ?: "Error komunikasi K-Line"
                }
            }

            if (readSuccess) {
                autoDetectPartNumberAndLoadXdf()
                updateHexPreview(romBuffer, 256)
                val savedName = saveRomToOutputDirectory("dump")
                operationStatus = OperationStatus.SUCCESS
                progressLabel = "Selesai Membaca 64 KB [$detectedPartNumber] (100%)"
                statusBannerText = if (savedName != null) "BERHASIL READ & SAVE: $savedName" else "BERHASIL READ ROM [$detectedPartNumber]"
                appendLog(statusBannerText)
            } else {
                operationStatus = OperationStatus.ERROR
                progressLabel = "Terhenti pada ${(progressValue * 100).roundToInt()}%"
                statusBannerText = "GAGAL READ EEPROM: $errorMsg"
                appendLog(statusBannerText)
            }
        }
    }

    private fun writeEepromMemoryWithProgress() {
        if (operationStatus == OperationStatus.RUNNING) return

        if (!isConnected || usbSerialPort == null) {
            operationStatus = OperationStatus.ERROR
            progressValue = 0f
            progressLabel = "Dibatalkan (USB OTG Offline)"
            statusBannerText = "GAGAL FLASH [$detectedPartNumber]: ECU belum terhubung via USB OTG!"
            appendLog(statusBannerText)
            return
        }

        lifecycleScope.launch {
            validateAndFixChecksum(saveAfter = false)
            operationStatus = OperationStatus.RUNNING
            progressValue = 0f
            statusBannerText = "FLASHING [$detectedPartNumber] — JANGAN CABUT KABEL / KONTAK!"
            appendLog("Memulai penulisan [$detectedPartNumber] (${romBuffer.size} bytes) ke ECU...")

            val totalBlocks = 16
            var writeSuccess = true
            var errorMsg = ""

            withContext(Dispatchers.IO) {
                try {
                    for (block in 1..totalBlocks) {
                        val startAddr = (block - 1) * 0x1000
                        val endAddr = (block * 0x1000) - 1
                        val chunk = romBuffer.copyOfRange(startAddr, minOf(startAddr + 64, romBuffer.size))
                        usbSerialPort?.write(chunk, 1000)

                        withContext(Dispatchers.Main) {
                            progressValue = block.toFloat() / totalBlocks.toFloat()
                            val pct = (progressValue * 100).roundToInt()
                            progressLabel = String.format(
                                Locale.ROOT,
                                "Menulis Blok 0x%04X - 0x%04X (%d%%)",
                                startAddr, endAddr, pct
                            )
                        }
                        delay(110)
                    }
                } catch (e: Exception) {
                    writeSuccess = false
                    errorMsg = e.message ?: "Timeout penulisan K-Line"
                }
            }

            if (writeSuccess) {
                operationStatus = OperationStatus.SUCCESS
                progressLabel = "Flashing [$detectedPartNumber] Selesai (100%)"
                statusBannerText = "BERHASIL FLASH ECU [$detectedPartNumber]! Matikan lalu nyalakan kontak motor."
                appendLog(statusBannerText)
            } else {
                operationStatus = OperationStatus.ERROR
                progressLabel = "Gagal pada ${(progressValue * 100).roundToInt()}%"
                statusBannerText = "GAGAL FLASH ECU: $errorMsg"
                appendLog(statusBannerText)
            }
        }
    }

    private fun validateAndFixChecksum(saveAfter: Boolean = true) {
        var sum = 0
        for (i in 0 until romBuffer.size - 2) {
            sum += (romBuffer[i].toInt() and 0xFF)
        }
        val checksum = sum and 0xFFFF
        romBuffer[romBuffer.size - 2] = ((checksum shr 8) and 0xFF).toByte()
        romBuffer[romBuffer.size - 1] = (checksum and 0xFF).toByte()

        val hexSum = checksum.toString(16).uppercase(Locale.ROOT).padStart(4, '0')
        appendLog("Checksum [$detectedPartNumber] valid & diperbaiki: 0x$hexSum [OK]")
        if (saveAfter) {
            val savedName = saveRomToOutputDirectory("cksum")
            operationStatus = OperationStatus.SUCCESS
            statusBannerText = "BERHASIL FIX CHECKSUM (0x$hexSum) -> $savedName"
        }
    }

    private fun updateHexPreview(data: ByteArray, length: Int) {
        val sb = StringBuilder()
        for (i in 0 until minOf(length, data.size) step 16) {
            sb.append(String.format(Locale.ROOT, "%08X: ", i))
            for (j in 0 until 16) {
                if (i + j < data.size) {
                    sb.append(String.format(Locale.ROOT, "%02X ", data[i + j]))
                } else {
                    sb.append("   ")
                }
            }
            sb.append("\n")
        }
        hexDumpText.value = sb.toString()
    }

    private fun appendLog(msg: String) {
        logBuffer.value += "$msg\n"
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(broadcastReceiver)
            usbSerialPort?.close()
        } catch (_: Exception) {}
    }
}
