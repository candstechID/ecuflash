package com.candstech.ecuflasher.core.protocol

/**
 * Fail-closed per-operation validation registry.
 * A profile must be enabled only after a captured, repeatable hardware trace and
 * matching service information validate its exact protocol and ECU part number.
 */
object HondaProtocolReadiness {
    fun isRomReadValidated(partNumber: String?): Boolean = false
    fun isLiveDataValidated(partNumber: String?): Boolean = false
    fun isDtcValidated(partNumber: String?): Boolean = false
}
