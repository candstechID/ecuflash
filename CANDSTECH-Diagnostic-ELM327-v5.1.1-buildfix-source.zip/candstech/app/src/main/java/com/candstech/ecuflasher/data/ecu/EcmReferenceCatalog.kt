package com.candstech.ecuflasher.data.ecu

import android.content.Context
import org.json.JSONObject

/**
 * Read-only reader for the CANDSTECH ECM profile reference file.
 *
 * IMPORTANT: this is NOT a verified ECU database. The source declares every
 * profile RECONSTRUCTED and vehicleTested=false. Callers may display it as
 * research/reference material, but must not use it to select ROM offsets,
 * checksum algorithms, or authorize flashing.
 */
object EcmReferenceCatalog {
    private const val ASSET_PATH = "ecu/ecm_profiles.json"
    private const val EXPECTED_FORMAT = "candstech-ecm-profiles"

    data class Catalog(
        val format: String,
        val version: Int,
        val sourceStatus: String,
        val provenance: String,
        val verification: String,
        val declaredCount: Int,
        val profiles: List<Profile>
    ) {
        val isCountConsistent: Boolean get() = declaredCount == profiles.size
        val isSafeForAutomaticEcuMatching: Boolean get() = false
        val warning: String
            get() = "Referensi hasil rekonstruksi; belum diuji pada kendaraan. " +
                "Tidak boleh dipakai untuk menentukan offset ROM atau proses flashing."
    }

    data class Profile(
        val index: Int,
        val label: String,
        val ecmId: String,
        val publicId: String,
        val verification: String,
        val vehicleTested: Boolean,
        val placeholder: Boolean,
        val rawFields: Map<String, String>
    )

    fun load(context: Context): Catalog =
        context.assets.open(ASSET_PATH).bufferedReader(Charsets.UTF_8).use { reader ->
            parse(reader.readText())
        }

    /** Pure parser kept separate so the source format can be unit-tested. */
    fun parse(jsonText: String): Catalog {
        val root = JSONObject(jsonText)
        val format = root.optString("format", "")
        require(format == EXPECTED_FORMAT) {
            "Format katalog tidak dikenal: '$format'"
        }
        val array = root.optJSONArray("profiles")
            ?: throw IllegalArgumentException("Field profiles tidak ditemukan")
        val profiles = ArrayList<Profile>(array.length())
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            val fields = linkedMapOf<String, String>()
            val keys = item.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val value = item.opt(key)
                if (value != null && value != JSONObject.NULL) fields[key] = value.toString()
            }
            profiles += Profile(
                index = item.optInt("index", i),
                label = item.optString("label", "Data ECM"),
                ecmId = item.optString("ecmId", ""),
                publicId = item.optString("publicId", ""),
                verification = item.optString("verification", "UNVERIFIED"),
                vehicleTested = item.optBoolean("vehicleTested", false),
                placeholder = item.optBoolean("placeholder", false),
                rawFields = fields
            )
        }
        return Catalog(
            format = format,
            version = root.optInt("version", 0),
            sourceStatus = root.optString("status", "Tidak diketahui"),
            provenance = root.optString("provenance", ""),
            verification = root.optString("verification", "UNVERIFIED"),
            declaredCount = root.optInt("count", profiles.size),
            profiles = profiles
        )
    }
}
