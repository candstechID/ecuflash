package com.candstech.ecuflasher.core.usb

import android.hardware.usb.UsbDevice
import java.util.Locale

/** USB bridge identification only. This does NOT identify the vehicle-side protocol. */
enum class UsbBridgeKind(val label: String) {
    FTDI("FTDI"), CH34X("CH340/CH341"), CP210X("CP210x"), CDC_ACM("USB CDC/ACM"), OTHER("Unknown / unsupported")
}

data class UsbAdapterDescriptor(
    val deviceId: Int,
    val vendorId: Int,
    val productId: Int,
    val productName: String,
    val manufacturerName: String,
    val bridgeKind: UsbBridgeKind,
    val supportedByKnownFelHrIds: Boolean
) {
    val displayName: String
        get() = "${bridgeKind.label} | ${productName.ifBlank { "USB device" }} | VID:%04X PID:%04X".format(Locale.US, vendorId, productId)
}

object UsbAdapterSupport {
    private const val VID_FTDI = 0x0403
    private const val VID_SILABS = 0x10C4
    private const val VID_WCH = 0x1A86

    fun describe(device: UsbDevice): UsbAdapterDescriptor {
        val vid = device.vendorId
        val pid = device.productId
        val kind = when {
            vid == VID_FTDI -> UsbBridgeKind.FTDI
            vid == VID_SILABS -> UsbBridgeKind.CP210X
            vid == VID_WCH -> UsbBridgeKind.CH34X
            isCdcAcm(device) -> UsbBridgeKind.CDC_ACM
            else -> UsbBridgeKind.OTHER
        }
        // FelHR's own VID/PID tables decide whether createUsbSerialDevice() can open it.
        // This flag is deliberately conservative; USB IDs vary across clones/revisions.
        val known = when (kind) {
            UsbBridgeKind.FTDI -> pid in setOf(0x6001, 0x6010, 0x6011, 0x6014, 0x6015)
            UsbBridgeKind.CH34X -> pid in setOf(0x7523, 0x5523, 0x7522, 0x55D4)
            UsbBridgeKind.CP210X -> pid in setOf(0xEA60, 0xEA70, 0xEA71, 0xEA80, 0xEA90)
            UsbBridgeKind.CDC_ACM -> true
            UsbBridgeKind.OTHER -> false
        }
        return UsbAdapterDescriptor(
            deviceId = device.deviceId,
            vendorId = vid,
            productId = pid,
            productName = device.productName.orEmpty(),
            manufacturerName = device.manufacturerName.orEmpty(),
            bridgeKind = kind,
            supportedByKnownFelHrIds = known
        )
    }

    fun isCdcAcm(device: UsbDevice): Boolean {
        for (i in 0 until device.interfaceCount) {
            val intf = device.getInterface(i)
            if (intf.interfaceClass == 0x02 || intf.interfaceClass == 0x0A) return true
        }
        return false
    }
}
