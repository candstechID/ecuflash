package com.candstech.ecuflasher

import com.felhr.usbserial.UsbSerialDevice
import kotlinx.coroutines.delay
import java.util.concurrent.ConcurrentLinkedQueue

/** ELM327 AT-command transport. This is OBD-II only; it is not a Honda proprietary K-Line engine. */
class Elm327Session(private val port: UsbSerialDevice) {
    private val rx = ConcurrentLinkedQueue<Byte>()

    fun onBytes(data: ByteArray) { data.forEach { rx.add(it) } }
    fun clear() { rx.clear() }

    suspend fun command(command: String, timeoutMs: Long = 1800): String {
        clear()
        port.write((command.trim() + "\r").toByteArray(Charsets.US_ASCII))
        val out = StringBuilder()
        var elapsed = 0L
        while (elapsed < timeoutMs) {
            while (rx.isNotEmpty()) out.append((rx.poll()!!.toInt() and 0xff).toChar())
            if (out.contains(">")) break
            delay(20)
            elapsed += 20
        }
        return out.toString().replace("\u0000", "").trim()
    }

    suspend fun initialize(): String {
        val id = command("ATI", 2500)
        require(id.isNotBlank() && !id.contains("TIMEOUT", true)) { "ELM327 tidak merespons ATI" }
        command("ATE0")
        command("ATL0")
        command("ATS1")
        command("ATH0")
        command("ATAT1")
        command("ATST64")
        val protocol = command("ATSP0")
        val voltage = command("ATRV")
        val supported = command("0100", 3500)
        require(!supported.contains("UNABLE TO CONNECT", true) && !supported.contains("CAN ERROR", true) && !supported.contains("BUS INIT", true)) {
            "Adapter merespons, tetapi ECU OBD-II belum terhubung: $supported"
        }
        require(supported.contains("41 00", true) || supported.contains("4100", true)) { "Tidak ada respons PID 0100 yang valid: $supported" }
        return "ID=$id | PROTOCOL=$protocol | VOLT=$voltage | PID=$supported"
    }

    suspend fun readPid(pid: String): String = command("01$pid", 2500)
    suspend fun readDtc(): String = command("03", 3500)
    suspend fun clearDtc(): String = command("04", 3500)

    companion object {
        fun decodePid(pid: String, response: String): String {
            val hex = response.uppercase().replace(Regex("[^0-9A-F]"), "")
            val marker = "41$pid".uppercase()
            val at = hex.indexOf(marker)
            if (at < 0 || hex.length < at + marker.length + 2) return "N/A"
            val a = hex.substring(at + marker.length, at + marker.length + 2).toIntOrNull(16) ?: return "N/A"
            val b = if (hex.length >= at + marker.length + 4) hex.substring(at + marker.length + 2, at + marker.length + 4).toIntOrNull(16) ?: 0 else 0
            return when (pid.uppercase()) {
                "0C" -> "${((a * 256 + b) / 4)} rpm"
                "0D" -> "$a km/h"
                "11" -> "${(a * 100 / 255)} %"
                "05" -> "${a - 40} °C"
                "0F" -> "${a - 40} °C"
                "0B" -> "$a kPa"
                "42" -> "${(a * 256 + b) / 1000.0} V"
                else -> "$a"
            }
        }

        fun decodeDtc(response: String): List<String> {
            val hex = response.uppercase().replace(Regex("[^0-9A-F]"), "")
            val start = hex.indexOf("43")
            if (start < 0) return emptyList()
            val payload = hex.substring(start + 2)
            val result = mutableListOf<String>()
            var i = 0
            while (i + 4 <= payload.length) {
                val raw = payload.substring(i, i + 4)
                i += 4
                if (raw == "0000") continue
                val x = raw.toIntOrNull(16) ?: continue
                val type = when ((x shr 14) and 3) { 0 -> "P"; 1 -> "C"; 2 -> "B"; else -> "U" }
                val d1 = (x shr 12) and 3
                result += "$type$d1${(x shr 8) and 15}${(x shr 4) and 15}${x and 15}"
            }
            return result
        }
    }
}
