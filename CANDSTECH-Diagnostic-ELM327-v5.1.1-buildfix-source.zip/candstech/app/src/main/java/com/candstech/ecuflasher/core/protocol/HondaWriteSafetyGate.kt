package com.candstech.ecuflasher.core.protocol

/** Fail-closed until a specific ECU profile passes independent hardware validation. */
object HondaWriteSafetyGate {
    fun isValidatedFor(partNumber: String?): Boolean = false
}
