# CANDSTECH ECU Flasher — Candidate Runtime Resolver v20

## Scope

v20 integrates `honda_ecu_master_candidates.json` into the Android data layer as a separate, unresolved candidate registry. The candidate list can be loaded when the ECU database initializes and can be queried by exact physical part number. It does not promote a candidate to a verified ECU identity or diagnostic profile.

## Runtime flow

1. `EcmDatabase.loadFromAssets()` loads the ordinary motor/ECU/generation catalog.
2. The candidate overlay is loaded independently by `HondaEcuCandidateRegistry`.
3. The Live Data vehicle/ECU picker now displays the 489-record ECU catalog and the 27-row candidate master in separate sections. Candidate selection only shows reference metadata and does not set an active `EcmModel`. The data layer also exposes `EcmDatabase.candidateRecords(context)`.
4. A known physical part number can be reconciled with `EcmDatabase.candidateMatchesByPartNumber(context, partNumber)`.
5. Results preserve `NO_MATCH`, `UNIQUE_DATABASE_MATCH`, or `AMBIGUOUS_DATABASE_MATCH`. Duplicate database records are never silently collapsed.
6. Actual ECU response-ID lookup is separate: `EcmDatabase.candidatesByActualResponseId(context, responseId)`. It only checks a candidate's own `ecuResponseId` field. The reference IDs in `matchedDatabaseEcuResponseIds` are not promoted to candidate response IDs.
7. The alias field is display/reference metadata only. It is never accepted by the part-number matcher or response-ID matcher.

## Safety invariants

- Candidate rows are not `EcmModel` records and do not become active protocol profiles.
- `diagnosticDispatchEnabled`, `binReadEnabled`, and `binWriteEnabled` remain false for all current rows.
- Model-level operation gates also require `recordStatus == HARDWARE_VERIFIED` and `requiresPhysicalValidation == false`.
- An unverified candidate with any operation flag enabled causes the candidate asset parser to reject that row/asset load.
- No candidate data is used to synthesize K-Line requests, CAN frames, Live Data offsets/scales, DTC commands, BIN memory maps, checksums, or write procedures.
- A candidate response ID is only accepted from its own `ecuResponseId` field. Database reference IDs remain reference-only.
- Candidate overlay load failure is logged and does not replace or invalidate the normal ECU database.

## Validation

- Added unit tests for exact part-number matching, alias non-matching, ambiguous database matches, and disabled operations on unresolved candidates.
- Updated the Live Data vehicle/ECU picker to show the candidate overlay separately from the ECU identity catalog; selecting a candidate never assigns it as an active ECU model.
- All 15 JSON assets parse successfully.
- Candidate master contains 27 unique candidate IDs and 27 unique part numbers; all operation flags are false and all candidate ECU response IDs are null.
- Android Gradle compilation and unit tests were not run in this environment because the archive has no Gradle wrapper and no system Gradle/Android SDK was available.
- No physical ECU/adapter validation was performed.

## Next required work

Expose the candidate master in the vehicle/ECU picker without labelling it as a verified diagnostic profile. Then build a per-ECU evidence intake workflow (raw request, raw response, adapter/transport, ECU part number, ECU response ID, test conditions, repeatability) before activating any Live Data or DTC profile. BIN read/write remains separately gated by validated memory layout and write-safety evidence.
