# Stage 2 Progress — v20

- Added `HondaEcuCandidateRegistry` as a runtime-loadable candidate overlay, separate from verified `EcmModel` identities.
- Added exact physical part-number reconciliation with explicit unique/ambiguous/no-match outcomes.
- Added separate actual ECU response-ID lookup; aliases and database-reference response IDs are not treated as ECU response IDs.
- Candidate asset loads during database initialization, with isolated failure handling.
- Added unit tests for exact part matching, alias rejection, duplicate ambiguity, and operation gating.
- Added `CANDIDATE-RUNTIME-RESOLVER-v20.md` documenting the runtime contract and remaining work.
- No Live Data, DTC, BIN read, or BIN write capability was activated.
- Updated the Live Data vehicle/ECU picker with a separate 27-row unresolved candidate section; candidate selection is reference-only and does not alter active ECU identity or Live Data dispatch.
