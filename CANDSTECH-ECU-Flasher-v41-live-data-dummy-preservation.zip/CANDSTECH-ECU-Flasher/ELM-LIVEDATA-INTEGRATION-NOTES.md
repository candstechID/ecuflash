# ELM327 and Live Data integration notes

## Current transport separation

- `Elm327Session` is an ELM AT-command session for standardized OBD-II. It selects the adapter's OBD protocol using automatic protocol selection, requests Mode 01 supported-PID bitmaps, and reads only PIDs advertised as supported.
- PID 0F (intake-air temperature) is queried only when the supported-PID bitmap includes it. The standardized conversion is `A - 40 °C`.
- The RAW K-Line path is implemented separately through `HondaProtocolEngine` and `UsbTransport`; it uses Honda proprietary K-Line request frames and the database's `liveDataProfileId` routing.
- The current source does not contain a separate Honda proprietary K-Line-over-ELM327 engine. The ELM OBD-II session may use an OBD link selected by the adapter, but it is not the same as transmitting Honda proprietary 0x71 table requests. Do not describe it as that third engine or route those proprietary frames through it without a separately reviewed implementation.

## Safety and routing

- Do not open the same USB serial device simultaneously through two transports.
- ELM OBD-II support is discovered per connected ECU using Mode 01 bitmaps. A model database label does not prove that a PID is supported.
- K-Line table responses without an eligible ECU-specific decoder are retained as raw-only evidence. No sensor decoder is borrowed from another ECU.
- DTC clearing/programming remains separate from Live Data read-only discovery.

See `LIVE-DATA-DATABASE-INTEGRATION-v32.md` for the current Live Data routing rules.
