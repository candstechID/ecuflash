# Live Data Database ↔ Processing Engine — v32

## Scope

This revision connects existing database `liveDataProfileId` assignments to the direct K-Line Live Data engine. It does not modify sensor conversion formulas, offsets, scaling, validity ranges, or UI sensor labels.

## Runtime routing

1. ECU identity resolution must be `EXACT` before a database row can select a decoder.
2. `EcmModel.liveDataProfileId` selects a compiled table decoder when the profile has no known layout conflict. The current database has eligible Table 17 mappings; other compiled table IDs can be routed when explicit database assignments are added.
3. `generationEvidence` must be `REFERENCE` or `RECONSTRUCTED` for decoder selection. The compiled layout must also pass a structural completeness check: valid 5-byte request/checksum, expected K-Line header/service/table ID, non-empty payload layout, and every primary/alternate field offset within the declared payload. `HYPOTHESIS`, `CONFLICT`, and `UNRESOLVED` rows cannot select a parser. Generic Table 10 assignments remain raw-only because its current parser alias conflicts with independent Table 10 byte descriptions; the legacy exact-ID extension is preserved unchanged.
4. Duplicate/ambiguous ECU identities remain blocked by `EcmDatabase.resolveIdentity`; no first-match fallback is added.
5. The explicit exact-ID registry remains an optional extension for an already database-mapped ECU. It is no longer the only way a database profile can reach the engine.

## Probe behavior when no decoder is eligible

A live direct K-Line session can still run bounded read-only probes even if its identity is unknown, ambiguous, or its database profile is incomplete:

- Table 11: `72 05 71 11 07`
- Table 17: `72 05 71 17 01`
- Table 10: `72 05 71 10 08` as a separate raw-only candidate after the Table 11/17 sequence.

Each raw probe uses a bounded 350 ms response window so the Table 11/17 sequence stays within the community reference's short awake window. A checksum/length/header/service/table-echo-valid response is recorded as `LIVE_DATA_RAW_ONLY` and `LiveDataState.RAW_CAPTURED`. It is not passed to a decoder from another ECU. Raw RX bytes are logged before frame validation too, so checksum-rejected candidates remain available for diagnosis; invalid frames are never passed to a sensor parser. The monitor stops after the raw capture (or after an unmapped probe batch has no valid response) to avoid repeated probing.

If a database-selected table fails or its frame cannot be decoded, the engine may try the other Table 11/17/10 requests as raw-only evidence. It does not decode that fallback with the wrong table layout.

## Separate OBD-II path

The ELM327 OBD-II path remains independent. It discovers supported Mode 01 PIDs using `0100` and subsequent bitmap ranges; PID `0F` is read only if the ECU advertises it. PID 0F uses the standardized `A - 40 °C` formula. This path is not used as a K-Line fallback. The source currently lacks a separate Honda proprietary K-Line-over-ELM327 engine.

## Sensor decoder preservation

The existing `HondaLiveDataProfiles` field declarations and `LiveDataFrameParser` conversion logic are unchanged. The changes are limited to database routing, eligibility, raw-only probing, and monitor state handling.

## Evidence status

- Honda Keihin Table 11 → Table 17 fallback sequence: community protocol repository; useful for probe order, not proof of compatibility with every Honda ECU.
- ISO 14230-4 defines KWP2000 requirements for emission-related OBD use; it does not define every proprietary Honda motorcycle live-data table.
- SAE J1979 Mode 01 PID 0F and supported-PID discovery are standardized OBD-II behavior; this does not prove that every motorcycle ECU supports OBD-II.
- No new ECU family is marked hardware-verified by this change.

## Verification limits

The source archive contains no Gradle wrapper JAR and no installed Gradle executable in the working environment. JSON validation and source-level consistency checks can be run here, but Android/Gradle compilation and physical ECU testing remain pending.
