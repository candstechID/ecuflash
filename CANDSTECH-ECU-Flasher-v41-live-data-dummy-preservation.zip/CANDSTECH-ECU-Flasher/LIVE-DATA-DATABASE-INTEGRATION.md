# Integrasi Database ECU ke Engine Live Data

- `ecm_database.json`, `generation_mapping.json`, `motor_catalog.json`, dan `ecu_identity_catalog.json` tetap menjadi sumber database; `EcmDatabase` memuat dan menggabungkan metadata profil ke `EcmModel`.
- `liveDataProfileId` pada record ECU yang cocok secara `EXACT` memilih decoder yang sesuai jika layout tabelnya tidak memiliki konflik sumber. Table 17 menjadi mapping database yang aktif; Table 10 generic tetap raw-only karena semantik beberapa byte berbeda antar referensi.
- `generationEvidence` `REFERENCE` atau `RECONSTRUCTED` dapat memilih decoder untuk percobaan read-only bila layout memadai. `HYPOTHESIS`, `CONFLICT`, `UNRESOLVED`, dan Table 10 generic tidak memilih decoder.
- Duplikasi atau identitas ambigu tidak boleh dipilih berdasarkan urutan record.
- ECU dengan profil belum lengkap tetap dapat menjalani probing langsung K-Line: Table 11, Table 17, lalu Table 10. Respons valid tanpa mapping decoder disimpan sebagai raw evidence dan tidak dipaksakan ke parser ECU lain.
- ELM327 OBD-II menjalankan discovery PID standar secara mandiri. PID 0F hanya dibaca jika bitmap ECU menyatakan PID tersebut didukung.
- Jalur K-Line Direct dan ELM327 OBD-II tidak saling menjadi fallback. K-Line-over-ELM327 belum tersedia sebagai engine mandiri pada source ini.
- Formula, offset, skala, rentang validasi, dan parser sensor yang sudah ada tidak diubah dalam integrasi v32.

Rincian perubahan dan batas verifikasi: `LIVE-DATA-DATABASE-INTEGRATION-v32.md` dan `SOURCE-REFERENCE-AUDIT-v32.md`.
