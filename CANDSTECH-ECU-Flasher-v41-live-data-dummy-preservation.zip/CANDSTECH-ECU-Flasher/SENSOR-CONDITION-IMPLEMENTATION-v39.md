# v39 — Live Data sensor condition labels

## Scope
This update improves only the condition label shown beside already-decoded Live Data values. It does not alter transport, protocol requests, byte offsets, scaling/conversion formulas, DTC, RESET, or READ/WRITE.

## Implemented condition logic
- DUMMY metadata wins before any numeric classification. The existing exact K59A-A11 generation mapping marks IAT and IAT_VOLTAGE as DUMMY; the value itself remains visible.
- RPM: ENGINE OFF, IDLE, RUN; WARNING only when the active ECU profile supplies a warning RPM.
- ECT/EOT: COLD, WARM, NORMAL, HOT, OVERHEAT, and implausible extreme FAULT.
- IAT: COLD, NORMAL, HOT, implausible extreme FAULT; DUMMY takes priority.
- TPS and dual throttle channels: circuit FAULT outside the reference electrical window; CLOSED/PARTIAL/WIDE OPEN from angle; voltage LOW/NORMAL/HIGH where the profile provides the relevant bands.
- ECT/IAT/MAP voltage: circuit FAULT windows from the supplied reference; exact profile thresholds override generic windows.
- MAP: LOW/HIGH from exact profile limits when present; otherwise FAULT outside the broad plausible pressure window and LOW for very low running pressure.
- Battery: LOW/NORMAL/HIGH generic display band; exact ECU profile limits override.
- O2: NORMAL within the narrowband operating voltage window and FAULT outside. It does not infer RICH/LEAN from one sample; switching diagnosis needs a time series.
- Injector: zero pulse while RPM is running is FAULT; zero pulse with engine off is ENGINE OFF; positive pulse is NORMAL unless profile thresholds classify it otherwise.
- Vehicle speed: STOPPED/MOVING.
- STF and ignition advance remain profile-threshold driven to avoid inventing universal correction/timing limits.

## Scope limitations
- Bank Angle and CKP/Pulser reference data from the screenshots are retained in the reference asset, but the current LiveSensor parser does not expose dedicated decoded BAS/CKP channels. No fake rows or fabricated byte offsets were added.
- MAP/IAT reference voltage limits explicitly marked 3-in-1 are not assigned to every ECU. Exact ECU profile metadata continues to take priority.
- Generic temperature, battery, and RPM bands are practical display heuristics, not a replacement for model-specific Honda service limits. Exact ECU profile thresholds override them.

## Validation performed
- Evaluator compiled independently with Kotlin compiler using interface-compatible stubs.
- Eight focused Kotlin test methods passed (29 assertions in the standalone evaluator harness).
- Reference JSON parsed successfully.
- Source diff limited to LiveSensorConditionEvaluator, its focused tests, the DIAGNOSA SENSOR call to pass RPM context, and reference/changelog documentation.
- Full Android Gradle build not run: archive has no Gradle wrapper script/JAR and this runtime has no Gradle installation.
- No physical ECU test claimed.
