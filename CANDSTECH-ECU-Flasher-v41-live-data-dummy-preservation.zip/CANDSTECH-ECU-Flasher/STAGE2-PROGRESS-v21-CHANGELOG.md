# CANDSTECH ECU Flasher — Stage 2 v21

## Scope
Add a protocol-evidence intake contract and a fail-closed activation resolver. This stage does not claim new Honda protocol bytes or enable any candidate profile.

## Added
- `ProtocolEvidence.kt`: capture record model, independent transport enum, operation/direction enums, SHA-256 payload fingerprint, validation, repeatability evaluation, and exact-identity profile activation gate.
- `protocol_evidence_schema_v21.json`: export/capture contract and invariants.
- Unit tests for repeatability, mismatched payloads, CAN bitrate requirement, exact ECU matching, transport isolation, and refusal to activate on repeatability alone.

## Safety rules
- K-Line Direct FTDI, K-Line ELM327, and CAN ELM327 remain distinct transport values.
- K-Line capture requires baud rate; CAN capture requires CAN bitrate.
- Candidate ID, part number, and user alias are not substituted for an actual ECU response ID.
- Three identical captures are only repeatability evidence, not hardware verification.
- Activation requires exact ECU response ID, exact transport, exact allowlist membership, request and expected positive response bytes, `HARDWARE_VERIFIED`, and reviewer approval.
- DTC clear and BIN read/write are explicitly excluded from this diagnostic activation resolver.
- No request bytes or Honda profile was invented or enabled in this stage.

## Validation status
- Source-level review and JSON parsing are performed for this package.
- Android Gradle build, full unit-test suite, on-device archive persistence, and physical ECU/adapter tests remain outstanding.
- Evidence records are currently a data/validation contract; persistent UI capture/export workflow is not yet connected.
