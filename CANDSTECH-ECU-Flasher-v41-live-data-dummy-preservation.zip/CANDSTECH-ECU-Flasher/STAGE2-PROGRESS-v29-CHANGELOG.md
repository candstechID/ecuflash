# Stage 2 Progress v29 — DTC Read-Only TX Probe

## Correction to v28
The v28 change added transport TX/RX monitoring but did not itself cause the K-Line DTC path to transmit a request: the verified-profile gate correctly returned before any TX. This revision adds an explicit, user-triggered read-only evidence probe so the monitor has DTC requests to observe.

## Changes
- The K-Line `SCAN DTC` action now calls `probeDtcsReadOnly()`.
- The probe requires an exact ECU identity and the existing K-Line DTC candidate profile/ECU-ID allowlist. Unknown, conflicted, unsupported, non-exact, or mismatched transport identities are blocked with an explicit `NO TX` log.
- For an eligible exact candidate identity, it sends four reconstructed read-only query candidates sequentially:
  - `72 05 74 01 14` — CANDSTECH baseline 74/01.
  - `72 05 73 01 15` — older CANDSTECH 73/01 candidate; source conflict remains explicit.
  - `72 05 71 20 F8` — RevCore 71/20 candidate.
  - `72 05 00 00 89` — RevCore 00/00 candidate.
- Each TX is logged with its candidate ID and provenance. Each raw RX frame, timeout, or invalid-frame outcome is logged by the wire engine and correlated in the DTC probe summary.
- Raw responses are intentionally NOT decoded into DTC codes and do NOT imply that a candidate request is correct. The purpose is to collect real ECU evidence before selecting/validating a DTC protocol.
- ELM327 `SCAN DTC` continues to send standard OBD-II Mode 03, 07, and 0A commands; each command and raw response is recorded by the ELM session monitor.
- Clear DTC and BIN write/flash remain locked.

## Validation
- `DtcProfileResolver.kt` compiled in an isolated Kotlin harness.
- Probe resolver test passed: exact candidate ECU returns the four expected read-only requests; unknown ECU ID, transport mismatch, and conflicted identity return no requests.
- Full Android Gradle build and ECU/adapter hardware test were not run. The environment still lacks the Gradle wrapper script/JAR, installed Gradle, and Android SDK.

## Evidence status
All four K-Line requests remain `RECONSTRUCTED` candidates. A captured response is evidence for that ECU/setup only; it is not universal Honda compatibility and must be reviewed before any request/response parser is enabled.
