# UNKNOWN ECU Auto Discovery — v18 work-in-progress

## Scope implemented in this increment

The ELM327 path now has a read-only standardized OBD-II discovery sequence:

1. `ATI` adapter identification and ELM configuration remain in `Elm327Session.initialize()`.
2. `01 00`, then subsequent supported-PID bitmap ranges (`01 20`, `01 40`, etc.) are queried only when the previous bitmap advertises the next range.
3. Only supported PIDs with implemented decoders are polled for Live Data.
4. DTC services `03` (stored), `07` (pending), and `0A` (permanent) are queried separately.
5. Positive response markers are required to classify an empty DTC list as `0 DTC`; no positive response is shown as `NO RESPONSE / SERVICE UNSUPPORTED`.
6. Auto Discovery never invokes Mode `04` (clear DTC), programming services, or BIN write operations.

Implemented standard PID decoders include RPM, speed, throttle, coolant and intake temperature, MAP, MAF, ignition timing, fuel trims, O2 voltage/STFT, fuel level, runtime, distance, barometric pressure, and control-module voltage. Raw responses remain available in the discovery result for audit.

## Safety and identity boundaries

- This ELM route is OBD-II. `ATSP0` automatic protocol selection does not turn it into the Honda proprietary K-Line protocol engine.
- It is valid only when Mode `01` PID `00` returns a valid `41 00` response. If not, initialization fails rather than assuming OBD compatibility.
- A PID bitmap is evidence that an ECU claims to support a standardized PID; it does not prove that every returned sensor value is calibrated or physically correct.
- A PID with no valid positive response is omitted; it is not shown as zero.
- Unknown proprietary K-Line ECUs remain blocked from guessed Live Data/DTC commands. Their Auto Discovery requires a protocol-specific, bounded, read-only probe whitelist with validated framing/checksum and explicit evidence. This increment does not invent those commands.
- Unknown ECU Read BIN and Write BIN remain disabled. OBD PID discovery does not identify flash memory layout or programming protocol.

## Existing architecture retained

- `EcmDatabase` remains the central catalog for known vehicle/ECU identity resolution.
- The RAW K-Line engine and ELM327 AT-command route remain separate.
- Existing exact-identity gating for proprietary Honda K-Line Live Data and DTC is not weakened.
- No ECU is assigned K59A as a default or fallback.

## Remaining work before claiming universal support

1. Build a runtime-loaded capability registry from `live_data_profile_registry.json` and `dtc_profile_registry.json`; eliminate the remaining duplicated hardcoded profile dispatch tables.
2. Implement protocol-specific K-Line UNKNOWN discovery using only captured/validated read-only candidate requests. Do not promote raw bytes to named sensors until offsets/scales are supported by evidence.
3. Add CAN/ELM transport/session tests with real adapter responses, including multi-ECU response handling and timeout/error distinctions.
4. Add cross-model activation tests: model A -> model B -> UNKNOWN, proving that no stale profile/cache survives a switch.
5. Add BIN identity, layout, checksum, read, write, backup, and recovery profiles independently. No unknown ECU flash operation is allowed.

## Verification status

- `Elm327Session.kt` compiled with `kotlinc` against minimal local stubs for the USB serial and coroutine APIs: syntax/type check passed for this isolated file.
- Full Android/Gradle build was not run: this archive has no `gradlew` launcher and no system `gradle` executable in the build environment.
- No physical ELM327/ECU test was performed. Runtime behavior and hardware compatibility are therefore unverified.
