# CANDSTECH ECU Flasher v35 — Sensor condition labels and DIAGNOSA placement

## Implemented
- Removed the RESET TP button from the action row.
- Moved the existing DIAGNOSA action from the O2/AFR metric row into the former RESET TP position; it uses the same equal-width button row.
- Added a profile-driven sensor condition evaluator. It only adds text labels and does not alter decoded numeric values or formulas.
- Added explicit distinction for NO DATA, INVALID DATA, DUMMY, and unconfigured condition thresholds.
- Added per-record `sensorOrigins` and `conditionThresholds` metadata support to the ECU model/database loader.
- Added K59A-A11 metadata marking IAT and IAT_VOLTAGE as DUMMY. Existing displayed values are retained; no MAP dummy value is invented.
- Added evaluator unit tests for RPM, VSS, dummy origin, no-data handling, and profile-configured RPM limits.

## Safety / evidence constraints
- No universal sensor thresholds were invented. Threshold-dependent classifications display `CONFIG NOT VERIFIED` until that exact ECU record has validated values.
- RPM=0 is ENGINE OFF only when the parameter state is VALID. Missing response is NO DATA.
- AFR formula and all decoder conversion formulas are unchanged.
- No Actuator Test was added. No TP reset command was added.
- K59A's active Table 17 byte mapping was not changed by this status-label patch.

## Validation
- Source archive integrity is checked after packaging.
- Gradle build/tests cannot be executed in this environment because the project has no `gradle-wrapper.jar` and no system Gradle installation.
- No physical ECU/adapter test has been performed.
