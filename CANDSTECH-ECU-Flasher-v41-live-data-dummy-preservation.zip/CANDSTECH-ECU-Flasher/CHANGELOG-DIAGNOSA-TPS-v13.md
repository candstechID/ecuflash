# CANDSTECH ECU Flasher — TPS display and sensor diagnosis UI

Baseline: `CANDSTECH-ECU-Flasher-v12-generation-mapping-audit-source.zip`

## Changes
- Main Live Data no longer presents TPS as a percentage. The TPS card displays the ECU-derived angle in degrees (`TPS2 × 0.5°`) only.
- Removed secondary sensor cards from the main Live Data area; the main area keeps RPM, TPS angle, battery voltage, engine temperature, O2 voltage and host-estimated AFR.
- Added a `DIAGNOSA` button that opens a sensor table for parameters represented in the active ECU table/extension response.
- The sensor table shows actual decoded values only when their parameter state is `VALID`; otherwise it shows the explicit state (for example NOT READ, INVALID, STALE, NOT SUPPORTED, or unavailable during KOEO).
- Added `diagnosticValues` to `LiveTelemetry` so the diagnosis table can show decoded fields beyond the small set of summary cards, including extension-table values.
- Updated Live Data log TPS display to degrees.

## Not changed / still unverified
- No DTC command, DTC parser, or Clear DTC behavior was changed in this update. DTC protocol for the tested K59A-A11 ECU remains unresolved pending raw ECU TX/RX evidence.
- TPS raw offsets and conversion are not changed in this update; existing table-0x17 decoder still uses payload offsets 2 (ADC/voltage) and 3 (angle), which matched the supplied screenshot values. Only the main UI representation was changed to degrees.
- No APK build, Gradle test, or physical ECU test was run.
