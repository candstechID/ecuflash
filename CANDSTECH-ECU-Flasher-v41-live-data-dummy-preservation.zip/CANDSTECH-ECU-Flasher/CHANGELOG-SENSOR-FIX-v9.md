# CANDSTECH ECU Flasher — Sensor / AFR correction v9

Based on Stage1 progress v8 source.

## Changes

- Preserved the previously working ADC-derived TPS percentage display (`raw * 100 / 256`) pending ECU-specific calibration evidence.
- Kept TPS ADC count, TPS voltage and the separate TPS angle byte as distinct readings.
- Added ECT/EOT, IAT and MAP voltage telemetry/UI fields where the selected table provides them. ECT/EOT label follows the detected ECU temperature sensor type.
- Applied the supplied 8.8 fixed-point injector formula (`raw16 / 256`) to the primary tables; preserved the separate table 0x16 one-byte `/200` scale from the decompiled profile.
- Applied the supplied narrowband O2 conversion (`raw * 5 / 256`) and host-side estimate formula (`14.7 - ((O2_V - 0.45) * 3.0)`).
- Kept AFR clearly labelled as an estimate; ECU-reported AFR remains unsupported.
- Added regression tests for TPS separation, sensor conversion fields, O2/STF and the AFR estimate reference points.
- Added a scrollable Live Data sensor panel so the extra diagnostic readings remain accessible on smaller displays.

## Preserved constraints

- No new ECU IDs or family-wide support claims were added. Live Data remains selected only after exact ECU identity resolution.
- Existing USB/K-Line connection and ECU identity code was not changed.
- Unmapped IACV bytes were not guessed.
- The source table catalogue remains reconstructed and must be checked against actual ECU logs before treating every value as verified.

## Validation status

- Source-level checks and XML parsing: passed.
- Gradle build, unit-test execution and physical ECU/adapter test: not run.
