# CANDSTECH ECU Flasher v18 — UNKNOWN OBD Auto Discovery increment

## Changes
- Added typed result models for OBD PID readings, DTC snapshots, and auto-discovery output.
- Added standardized Mode 01 supported-PID bitmap traversal (query next bitmap only when advertised by the prior bitmap).
- Added read-only polling for supported standard PIDs, including O2 voltage/STFT and fuel trims.
- Added separate Mode 03 / 07 / 0A DTC scan channels (stored, pending, permanent).
- Kept Mode 04 clear DTC as a separate explicit operation; Auto Discovery never calls it.
- Wired the ELM327 Live Data button to supported-PID discovery and decoded live values.
- Wired ELM327 DTC scan to separate stored/pending/permanent categories with raw response logging.
- Kept ELM327 OBD-II route separate from RAW K-Line Honda proprietary engine.

## Not claimed
- Not universal discovery for proprietary Honda K-Line UNKNOWN ECUs.
- Not a completed CAN engine validation or a physical adapter test.
- Not Read BIN / Write BIN support.
- Not a verified full Android build; the archive does not contain a Gradle wrapper launcher and no system Gradle was available.
