# v26 — K59A DTC read path activation

## Root cause fixed
The active `HondaProtocolEngine.readDtcsInternal()` delegated to `HondaGenerationProfiles.dtcRequests(model)`, which unconditionally returned `null`. The Scan DTC action therefore exited before transmitting any request.

## Change
- Added a narrow exact-response-identity allowlist for ECU ID `0101C40F01` and profile ID `honda.kline.dtc.71_74`.
- That exact entry now dispatches the existing read-only baseline request pair `74/01` (current) and `73/01` (history) from `HondaEcuProfiles.genericBaseline`.
- Requests remain marked `RECONSTRUCTED`, not hardware-verified. No generation-wide, part-number-only, or unknown-ECU fallback is enabled. Conflicted generation records remain blocked.
- Existing parser requires valid frame length, checksum, response service/page and payload format before publishing DTC codes or a valid empty result.
- DTC profile registry now records the exact ECU ID and the actual request identifiers used by the implementation.
- Unit test updated to assert the exact K59A allowlist and rejection of part-number-only identity.

## Safety boundary
This enables a read-only diagnostic probe; it does not claim that the ECU will answer. If the ECU rejects or does not answer, the app should now show the actual TX/RX failure instead of `PROFILE UNAVAILABLE`. Clear DTC remains disabled because its command and acknowledgement have not been hardware-verified.

## Validation
ZIP integrity is checked at packaging. Android/Gradle compilation and physical ECU validation are not claimed in this environment. Capture the new TX/RX log after pressing Scan DTC to confirm whether this ECU accepts the reconstructed read requests.
