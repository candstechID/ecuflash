# CANDSTECH ECU Flasher — incremental sensor and DTC audit

## Applied source corrections

1. TPS percentage retains the prior ADC-derived display (`raw * 100 / 256`) for compatibility with the user's previously observed ADC=24 / approximately 9.4% result. TPS ADC count, voltage, and TPS angle remain separate fields. The angle-based percentage proposal was not sufficiently validated for this ECU.
2. Restored the reconstructed Honda live-data catalogue from the v9 baseline: primary tables 0x17/0x13/0x11/0x10 and extension tables 0x16/0x20/0xD1. O2/STF are decoded only from table 0x20; Gear bytes remain reconstructed and gear-number decoding is not invented.
3. DTC query list now sends only the current-DTC 0x74/0x01 request. The prior 0x71/0x20 request is a Live Data table request, and 0x00/0x00 is not a DTC read request; neither is used as a DTC fallback.
4. DTC response parsing now validates the reconstructed page structure, service (0x74 current / 0x73 history), page, reserved byte, length and checksum before interpreting code pairs. Unknown code pairs are retained as raw Honda codes.
5. If a response frame arrives but fails DTC structure validation, the result is now `UNRECOGNIZED` with raw hex, not `NO_RESPONSE`.

## Not yet completed / not claimed

- A separate History DTC query, state flow, and UI panel are not yet implemented. The parser recognizes service 0x73 for the later history path, but current UI scan reads current DTC only.
- Clear DTC remains locked in the UI. No clear command is authorized by this patch.
- Table layouts and DTC page format remain RECONSTRUCTED, not hardware-verified on the user's K59A-A11 ECU.
- No Gradle build, unit-test execution, adapter test, or physical ECU test was run. The test source was updated only; compile/runtime success is not claimed.


## v14 DTC parser/safety update

1. The response parser now additionally recognizes the reference's `0x71 0x74` current and `0x71 0x73` history response layout, including the 5-byte valid-empty response, but only when declared length and additive checksum validate. The older reconstructed `0x74/0x73 + page` parser remains supported separately.
2. DTC byte pairs are validated before decoding; malformed padding, odd payloads, unsupported subfunctions, wrong lengths, and bad checksums are rejected as unrecognized.
3. The clear-DTC engine entry point is hard-locked and transmits no candidate command until an exact family-specific request and ACK are verified on hardware.
4. This does not claim the supplied `72 05 71 74 A0` / `72 05 71 73 A1` request bytes are valid. Under the project's current additive checksum function, those checksum bytes do not validate; the screenshots also contain at least one example response whose stated checksum is inconsistent with that function. No new K-Line request is sent based solely on those examples.
5. The active DTC request catalog is still reconstructed and is not yet separated into independently verified Gen-1, Gen-2/3A, and CAN Gen-3B read profiles. History DTC is parser-ready but is not yet queried/presented as a separate UI result.
6. Added parser regression tests. Tests/build and hardware verification have not been run in this environment.


## Incremental DTC read-path update (v15 candidate)

1. Added a distinct History DTC request (`72 05 73 01 15`) beside the existing reconstructed Current DTC request (`72 05 74 01 14`) in the generic baseline profile. Both remain marked `RECONSTRUCTED`; they are not claimed to be compatible with all Honda K-Line ECUs.
2. The engine now processes Current and History independently, classifies a response by its validated response service, and keeps the two lists separate. A successful Current response is not overwritten by a History response or vice versa.
3. The UI's scan result now reports Current and History separately, including when one channel is valid while the other times out or returns an unrecognized frame.
4. Added a parser regression test for separate paged Current (`0x74/0x01`) and History (`0x73/0x01`) frames.
5. Clear DTC remains hard-locked and sends no command.

## Remaining DTC work / limitations

- The generic baseline read profile is not a verified Gen-1, Gen-2/3A, or CAN Gen-3B profile. No generation-wide request mapping is claimed.
- Keihin H99B, Keihin KWP, Shindengen H99B, and Denso H99B profiles still have no family-specific DTC read catalog. The known K59A-A11 identity resolves to Shindengen metadata, so this update does not establish DTC reading for that ECU.
- CAN Mode 03/07/0A parsing and ISO-TP response handling are not implemented by this update.
- Clear DTC remains disabled pending exact family-specific request/ACK captures and read-back verification.
- No Gradle build, unit-test execution, adapter test, or physical ECU test was run.
