# Stage 2 v23 Changelog

- Added exact ECU-ID-to-database model label in the CANDSTECH status banner.
- Compact verified identity example: `0101C40F01 | K59A | VARIO 150`.
- Kept AFR approximation `14.7 - ((O2_voltage - 0.45) * 3.0)` and explicitly gated calculation on valid narrowband voltage plus engine RPM > 0.
- KOEO O2 summary now displays `KOEO`, not an inactive raw voltage as if it were a live measurement.
- Hardened ELM327 DTC channel status so missing/truncated/unparsed responses cannot be mislabeled as `0 DTC`.
- Honda DTC UI state labels are explicit; no response remains distinct from a successful empty scan.
- No proprietary DTC, Clear DTC, or BIN capability was newly enabled.
