# v27 — Universal DTC profile resolver and single-ECU dispatch rollback

## Scope correction
- Replaced the v26 single-ECU DTC activation path. The v26 reconstructed 74/01 + 73/01 probe is no longer transmitted by the active engine.
- Removed the `HondaGenerationProfiles` dispatcher that hard-coded ECU ID `0101C40F01` and deleted its K59A-specific activation test.
- DTC dispatch is now resolved through `DtcProfileResolver` using the database `dtcProfileId`, exact ECU response identity, active transport, conflict status, and a hardware-verified ECU allow-list.

## Universal registry state
- K-Line profile `honda.kline.dtc.71_74` remains a reconstructed candidate only. The 37 database ECU identities that reference it are recorded as candidate identities, not as dispatch permissions.
- CAN/ELM profile `honda.can.obd2.03_07_0a_04` remains unresolved/conflicted. Its 29 database ECU identities are candidate metadata only; no CAN DTC request is enabled.
- Both profiles have empty verified ECU allow-lists and `dispatchEnabled=false` in `dtc_profile_registry.json`.
- A conflicted database record is rejected before profile dispatch. A CAN profile cannot be sent through the K-Line Direct engine.
- Unknown, unsupported, mismatched, and not-hardware-verified profiles produce explicit resolver states and transmit no request.
- Clear DTC remains locked. No unverified clear command or acknowledgement was activated.

## Tests added
- Reconstructed candidate profile does not dispatch merely because the ECU is K59A.
- The same candidate profile cannot leak to another ECU identity.
- Conflicted records are rejected.
- CAN profile cannot be selected by the K-Line Direct engine.
- Missing identity and unsupported profile states are explicit.

## Validation and limitations
- Both `ecm_database.json` and `dtc_profile_registry.json` parse successfully.
- All 66 non-UNSUPPORTED database DTC profile references resolve to a registry entry; no dangling profile IDs remain.
- DTC resolver Kotlin source compiles with Kotlin/JVM against minimal dependency stubs.
- Full Android Gradle build and repository unit-test suite were not run because this working copy has no Gradle executable and no complete Gradle wrapper JAR.
- No physical ECU TX/RX capture was available to validate a real DTC request/response pair. Therefore this revision intentionally does not claim that DTC scanning is operational on any ECU. It corrects the universal dispatch architecture and prevents reconstructed commands from being sent as if verified.
- Reviewed the supplied RevCore source archive's `HondaEcuProfiles` and `LegacyHondaProtocolEngine` smali: it contains the same generic reconstructed 74/01 and 73/01 candidates, while family-specific Keihin/Shindengen DTC catalogs remain empty/unresolved. This confirms the source archive does not provide a validated universal or per-family DTC response profile.
