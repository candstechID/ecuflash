# CANDSTECH ECU Flasher v33 — DTC decode and clear integration

## Changes
- K-Line DTC scan now parses the captured Honda `73 01` History and `74 01` Current response pages instead of presenting the raw probe as unparsed evidence.
- The parser consumes the reserved byte followed by `(mainCode, subCode)` pairs. Example `07 02` becomes blink DTC `7-2`; multiple pairs in one response are retained.
- Captured frames are covered by parser tests:
  - `02 0C 73 01 00 07 02 00 00 00 00 75` -> History DTC `7-2`.
  - `02 0C 74 01 00 00 00 00 00 00 00 7D` -> Current empty.
  - `02 0C 74 01 00 07 02 08 01 0C 01 5E` -> `7-2`, `8-1`, `12-1`.
- Removed unrelated `71/20` and `00/00` candidate probes from the explicit scan path.
- Clear DTC action now routes to the protocol engine. Honda K-Line sends `72 05 60 01 28` only when the exact ECU identity/profile passes the existing candidate gate, then rereads both DTC pages. It reports success only when both Current and History are empty; otherwise it reports unverified or remaining DTCs.
- ELM327 Mode 04 clear now immediately rescans stored/pending/permanent DTCs and reports the result rather than claiming success from the command response alone.

## Important validation boundary
- The DTC read parsing is covered by source-level unit tests and the supplied raw captures.
- The Honda K-Line clear request is a profile-gated implementation candidate. Its real ECU acknowledgement and post-clear behavior still require a physical ECU test before claiming universal Honda support.
- No APK build or physical ECU clear test is claimed in this delivery. This archive has no Gradle wrapper JAR or `gradlew` script in the source package.
