# CANDSTECH ECU Flasher v39 — Live Data condition status

- Replaced duplicate TPS voltage evaluator branches with one deterministic rule.
- Added simple operator labels for decoded RPM, ECT/EOT, IAT, TPS/dual-throttle, MAP, battery, O2, injector and vehicle-speed values.
- Added RPM context to MAP and injector evaluation so zero injector pulse while engine is running can be flagged.
- Exact ECU `conditionThresholds` override generic display heuristics.
- Exact ECU `sensorOrigins` metadata is evaluated first; K59A-A11 IAT and IAT voltage remain DUMMY.
- Preserved numeric decoding formulas, byte offsets, protocol engines, DTC and RESET.
- Added focused evaluator tests and documented limits.
- Bank Angle and CKP/Pulser are documented in the reference asset but are not emitted by the current LiveSensor parser; no fabricated live values or byte offsets were added.
- Validation: isolated Kotlin compilation and 8 focused test methods passed; JSON assets parsed; ZIP integrity verified. Full Android Gradle build and physical ECU test not performed.
