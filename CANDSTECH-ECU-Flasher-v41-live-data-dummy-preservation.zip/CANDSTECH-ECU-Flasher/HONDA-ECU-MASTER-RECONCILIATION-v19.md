# Honda ECU Master Database Reconciliation — v19 overlay

## Scope
This update adds a 27-row candidate inventory based on the user's two design tables and separates architecture, physical protocol, Live Data, DTC, and BIN capability. The candidate overlay is deliberately not auto-dispatched by the application.

## New assets
- `honda_ecu_master_candidates.json`: 27 candidate rows. `userSuppliedEcuAlias` is not treated as a real ECU response ID; `ecuResponseId` remains null until a captured ECU identity is matched.
- `ecu_architecture_registry.json`: architecture taxonomy, not a diagnostic decoder selector.
- `diagnostic_protocol_registry_v19.json`: three independent transport engines and protocol templates.
- `live_data_profile_registry_v19.json`: table/PID profile definitions with empty exact-ECU allowlists.
- `live_data_parameter_registry.json`: common sensor vocabulary without fabricated offsets or formulas.
- `dtc_profile_registry_v19.json`: K-Line reference commands and standard CAN service references, all dispatch-disabled.
- `honda_master_reconciliation_report.json`: machine-readable counts and corrections.

## Reconciliation against the existing 489-row database
The 27 candidate rows were matched by exact `partNumber`, not by motorcycle name or alias. **13 candidate rows** have at least one exact part-number match; **14 rows** do not exist under that exact part number in the current 489-row catalog. `38770-K56-N01` has multiple database records with the same part number and requires response-ID disambiguation. Existing `ecmId` values are catalog references, not newly hardware-captured IDs.

## Research-backed identity corrections
| Part number | Corrected manufacturer / MCU | Important limitation |
|---|---|---|
| 30400-K93-N01 | Keihin / SPC560 | K-Line/KWP and decoder not verified. |
| 30400-K2F-N11 | Keihin / RH850 | Protocol and decoder not verified. |
| 30400-K1AA-N01 | Shindengen / RH850:v1 | Protocol and decoder not verified. |
| 38770-K3B-N01 | Keihin / R8C | CAN claim not established; protocol unresolved. |
| 38770-K64-N01 | Keihin / SH7058 | CAN/ISO15765 and Euro-5 claim not established. |
| 38770-K56-N01 | Keihin / R8C; Sonic 150 | Supra GTR must use its distinct K56 suffix/part identity. |

## Existing normalized database changes
The matching records in `ecm_database.json` and `ecu_identity_catalog.json` have the identity corrections above applied where exact part numbers matched. The affected generation mappings are set to `UNKNOWN` / `UNRESOLVED`, and their Live Data/DTC profiles are disabled until the protocol and decoder are proven. No unknown model inherits another model's profile.

## Safety/dispatch changes
- Existing generic Live Data profile registry entries are marked reference/candidate only and `dispatchEnabled=false`.
- Existing DTC registry entries are marked not hardware verified and `dispatchEnabled=false`.
- Candidate rows do not enable BIN read/write.
- MCU family, generation group, and connector shape do not independently prove physical protocol.
- OBD-II/UDS service definitions do not prove that a particular motorcycle ECU supports those services.

## Not claimed
This update does not claim that the 27 candidates are fully researched, that all profile commands are correct, that a BIN can be safely read/written, or that hardware tests/builds have passed. It is a structured research overlay and conservative data correction.
