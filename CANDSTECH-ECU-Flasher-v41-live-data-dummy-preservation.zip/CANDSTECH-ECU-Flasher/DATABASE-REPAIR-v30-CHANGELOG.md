# Database repair v30

## Scope
- Uses v29 as the source baseline.
- Synchronizes the legacy `ecm_database.json` generation/profile metadata with the runtime-authoritative `generation_mapping.json`. Two rows (`K2F-N11`, `K1AA-N01`) had substantive generation/profile disagreements; five additional candidate rows had stale `generationCandidate` metadata; 71 rows had note-text drift. The authoritative runtime partition remains `motor_catalog.json` + `ecu_identity_catalog.json` + `generation_mapping.json`.
- Adds explicit reference-only profile records for Honda K-Line tables 11, 13, 16, 20 and D1. All new records have empty exact ECU allowlists and `dispatchEnabled=false`.
- Adds `live_data_layout_registry.json` with table-specific offsets, formulas, provenance, and evidence status. Offsets are payload-relative after the four-byte frame header.
- Table 11 IAT and ECT are distinct. Table 17 and Table 16 remain separate.
- Table 11 injector scale disagreement (user parser 0.004 vs v29 source /256) is explicitly unresolved; no scale is selected.
- Expands parameter vocabulary without inventing universal offsets.
- Preserves duplicate ECM IDs and part numbers as ambiguous; no first-match resolution.

## Safety
No new ECU dispatch, DTC clear, BIN read, or BIN write permission is enabled. No model/year-based protocol inference is added. K59A's existing exact-ID reconstructed capability is preserved without generalizing it.

## Audit
See `ecuengine/src/main/assets/database_repair_audit_v30.json` for counts, duplicates, stale row synchronization, and remaining limitations.

## Follow-up v31 — Runtime capability registry
- Connected `live_data_profile_registry.json` to the runtime allow-list.
- Exact ECU ID + enabled grant + KLINE_DIRECT transport are now mandatory before Live Data table requests can be selected.
- Disabled reference layouts remain non-dispatchable; no new ECU IDs were added.
- Unknown table IDs, duplicate profile IDs, and ambiguous multiple grants fail closed.
- Removed model-generation/profile-label fallback as a dispatch grant; profile metadata alone cannot cause a command to be sent.
- Added tests for exact ID, transport, disabled grants, extra identity bytes, and duplicate configuration.
