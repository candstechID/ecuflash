# CANDSTECH ECU Flasher v24 — Live Data / DTC / Profile Safety Repair

## Implemented in source
- Removed engine-RPM/KOEO gating from the active Live Data parser. Valid sensor responses remain visible with engine OFF or ON. The legacy KOEO enum value remains only for compatibility and is no longer emitted by the current parser.
- Removed the KOEO suppression of raw O2 and STF values in both reconstructed-table and PID-fallback paths. AFR estimation remains separately range-gated and is not represented as ECU-measured AFR.
- Added Vehicle Speed to the front Live Data metric row (`SPEED`, `km/h`). The value is shown only when the selected exact-ECU profile actually returns a valid speed field; a valid zero remains zero.
- Changed DTC profile/identity gaps to `PROFILE_UNAVAILABLE` state and explicit `PROFILE UNAVAILABLE / NOT SCANNED` UI wording. No unsupported command is transmitted and the UI must not call this `0 DTC`.
- Quarantined the legacy DTC read and clear methods. Their historical candidate requests (74/01, 71/20, 00/00, 60/01, 74/02, 04) are no longer transmitted by that engine.
- Synchronized the K59A Live Data registry metadata with actual exact-ID runtime behavior: runtime capability is reconstructed and exact-ID-only, but explicitly not hardware-verified.
- Updated KOEO unit-test expectations to assert that valid O2/STF values remain VALID regardless of engine state.

## Data/profile audit — unresolved items intentionally not fabricated
- Live Data K59A (`0101C40F01`) remains a reconstructed profile with seven tables (17, 13, 11, 10, 16, 20, D1). Table 17 and 11 include VSS offsets in the reconstructed layout; other table selections may not carry speed. No speed value is synthesized when absent.
- K59A O2 conversion remains source-reconstructed at 0.019610266350951835 V/count (0–5 V range). This conflicts with the narrowband AFR estimator's accepted 0–1 V input. The raw O2 value is now shown, but AFR is not estimated outside its validated narrowband range. Sensor type/scaling still requires electrical/raw-capture validation.
- No Honda K-Line DTC request/response profile is hardware-validated for K59A. The DTC registry therefore remains disabled; this is a known capability gap, not a parser timeout. Clear DTC remains disabled until exact ECU-specific command, ACK, and engine-OFF interlock are validated.
- Master reconciliation reports 27 candidate rows, 13 exact part matches, 14 unmatched rows, and a duplicate/multiple match for `38770-K56-N01` (records `K56-N01` and `FP-0101C90F11`, associated database ECU IDs `0101C90F01` and `0101C90F11`). This is retained as an explicit conflict; records were not merged or assigned one guessed ECU ID.
- Diagnostic protocol registry entries remain templates with unknown init/framing/timing fields and dispatch disabled. No protocol is inferred from MCU or model generation.

## Verification status
- JSON asset syntax validated locally.
- ZIP integrity validated after packaging.
- Android/Gradle unit tests and Android build were not run: this environment has no `gradle` executable and the archive contains wrapper properties but no `gradlew` launcher.
- No physical ECU/adapter test was performed. Do not describe this package as hardware-verified.
