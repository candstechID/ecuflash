# CANDSTECH ECU Flasher v34 — connection-based DTC engines

## DTC architecture
- DTC scan is no longer blocked by an exact ECU-ID/database match on the direct FTDI K-Line path.
- Added a connection-level Honda K-Line discovery catalog with all four supplied request frames, in order:
  - `72 05 74 01 14` — primary Current
  - `72 05 74 02 13` — Keihin History variant
  - `72 05 73 01 15` — Shindengen History variant
  - `72 05 73 02 14` — Shindengen alternate Current variant
- Every response must pass header/declared-length validation, parser structure checks, and service/page matching. A valid empty response is recorded as empty; timeout or unsupported response does not stop attempts of the other variants.
- DTC checksum validation is configurable. It remains enabled by default across the communication stack; the four-command discovery path disables checksum rejection only because the ECU-specific checksum family may be unknown. Header, declared length, service/page, and payload structure remain mandatory.
- Database DTC descriptions are used when known. Unknown codes remain visible as unverified codes; concise Indonesian labels are used for known sensor/actuator codes.

## Three independent connection selections
- `FTDI_KLINE`: direct USB serial K-Line; uses the four Honda-specific request variants and one shared Shindengen/Keihin FTDI clear request.
- `ELM_KLINE`: ELM327 OBD-II over ISO 9141-2 / ISO 14230 K-Line (protocols 3, 4, 5); scans Mode 03/07/0A and clears with Mode 04.
- `ELM_CAN`: ELM327 OBD-II over CAN; auto-detects CAN protocol 6–9, scans Mode 03/07/0A and clears with Mode 04.
- `Elm327KlineSession` and `Elm327CanSession` are separate session classes with separate protocol initialization and per-session transaction state; the common serial command primitive is shared only as the ELM adapter transport.
- ELM K-Line is the standardized OBD-II K-Line path; it does not blindly transmit Honda proprietary raw frames through an ELM adapter.
- Adapter mode cannot be changed while connected, preventing the UI from switching protocol engines mid-session.

## Clear DTC safeguards
- FTDI K-Line clear is attempted only after at least one valid DTC response is obtained. The shared request is followed by the same four-command rescan; success requires valid empty Current and History channels.
- ELM clear performs a pre-scan and sends Mode 04 only if at least one DTC service response is received. It then requires a positive `44` response and a responding post-clear scan before reporting success.
- A response timeout, unsupported service, incomplete verification, or remaining DTC is never reported as a verified clear.

## Validation status
- Added source tests for all four request frames, channel mapping, checksum-deferred parsing, and mandatory frame-length validation.
- Pure Kotlin DTC parser/catalog and frame-codec compilation was checked with `kotlinc`; supplied captured frames were manually exercised in a small local verification harness.
- Full Android/Gradle build was not run: the archive does not contain `gradlew` or the Gradle wrapper JAR, and no system Gradle installation is available in this environment.
- No physical ECU / FTDI / ELM327 hardware test is claimed. The shared FTDI clear request remains subject to real ECU acknowledgement and post-clear validation.


## v34.1 — remove remaining database gate from DTC UI
- Removed the `connStatus == ECU_IDENTIFIED` prerequisite from the SCAN DTC action for ELM327.
- Scan eligibility now depends only on an active transport session: ELM session for ELM K-Line/CAN, or open FTDI K-Line adapter for direct K-Line.
- ECU database matching remains optional enrichment for model identity and DTC descriptions; it is not a scan permission check.
- This is a source-level correction. Full Android build and physical ECU tests remain outstanding.
