# v38 — Honda sensor condition reference implementation

## Included
- Transcribed the four user-provided screenshots into `ecuengine/src/main/assets/sensor_condition_reference_honda_3in1.json`.
- Added evaluator support for profile-bound electrical circuit fault limits on TPS_VOLTAGE, ECT_VOLTAGE, IAT_VOLTAGE, and MAP_VOLTAGE.
- Added focused Kotlin tests for the new evaluator branches.
- Kept numeric decoding formulas and DTC/RESET source files unchanged.

## Important scope
The screenshots do not identify exact ECU IDs, model years, or ECU family applicability. MAP and IAT explicitly say 3-in-1 only. Therefore the reference catalog is not automatically assigned to all 489 ECU records. The evaluator only classifies a voltage as FAULT if the exact active ECU record supplies the corresponding two-value `conditionThresholds` entry. Otherwise it does not invent a diagnosis.

## Source interpretation
- TPS closed/full-throttle voltage bands are operating-position references; low/high circuit limits are separate.
- ECT/EOT circuit limits are not used as engine overheat thresholds.
- O2 rich/lean diagnosis requires time-series switching after warm-up; a single sample is insufficient.
- CKP, Bank Angle and VS values are stored in the reference catalog. The current LiveSensor enum does not expose dedicated CKP/BAS fields in this decoder, so no unsupported UI sensor rows were fabricated.

## Validation
- ZIP source archive integrity checked.
- Kotlin full Android build not performed; the project archive does not contain a Gradle wrapper JAR/script.
- No physical ECU validation claimed.
