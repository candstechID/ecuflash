# CANDSTECH ECU Flasher v22 — Consolidation & Safety Audit

## What this archive contains
This is a full source-tree continuation of v21, not a patch-only package. It retains the 489-record master database, 27-row Honda candidate overlay, runtime picker, independent K-Line Direct and OBD-II ELM paths, evidence schema, protocol resolver, tests, source attribution, and prior progress notes.

## v22 code changes
1. Persistent immutable evidence archive under app-private `filesDir/protocol-evidence`.
2. SHA-256 over decoded raw bytes and integrity verification when loading.
3. Evidence-linked profile activation requiring matching raw TX/RX, exact ECU response ID, exact transport, operation, one test run, hardware-verified status, reviewer approval, and reviewer identity.
4. Stronger repeatability comparison including adapter/firmware and test conditions.
5. Fail-closed legacy BIN Read/Write and generic legacy Honda raw-command paths in the app.
6. Retired duplicate legacy protocol engine blocked at its transceive boundary.
7. No implicit 64 KB ROM-size default.

## Current implementation status
- Master identity database and candidate picker: integrated as separate layers.
- K-Line Direct USB serial: source implementation exists; baseline identification probes remain reconstructed and are not yet tied to an exact per-ECU probe allowlist.
- ELM327 standardized OBD-II: source implementation exists.
- Honda proprietary K-Line over ELM327: not implemented.
- CAN over ELM327: not implemented; registry metadata is not an operational engine.
- Honda proprietary Live Data: one exact K59A profile is reconstructed from source, not hardware-verified; it is not universal.
- Proprietary Honda DTC: blocked until exact ECU/transport request-response evidence is available.
- Clear DTC: locked.
- BIN Read/Write: locked pending exact ECU memory map, read/write protocol, checksum, security access, and physical validation.
- Evidence archive API: implemented; automatic capture from live transports and evidence-review/export UI remain outstanding.

## Validation record
- 17 JSON assets parse.
- Database relation audit: 489 identity records, 489 generation mappings, 396 motor records; no orphan identity/generation/motor links.
- 27 candidate rows, 27 unique candidate part numbers; 0 candidate ECU response IDs and 0 enabled diagnostic/BIN flags.
- All five protocol/profile registries remain dispatch-disabled.
- Evidence/archive Kotlin/JVM smoke test passed JSON round-trip, disk persistence, and evidence-linked TX/RX activation.
- ZIP integrity test passed after packaging.

## Not verified
No full Android Gradle build, full JUnit suite, APK build, USB adapter test, or physical ECU test was run. The source archive has no Gradle wrapper script/JAR and no installed Gradle/Android SDK in the working environment. Do not treat source-level smoke tests as an Android build or hardware validation.
