# v37 — Sensor diagnosis label simplification

- Removed the `STUCK? (2s)` heuristic from the DIAGNOSA SENSOR UI.
- Removed `CONFIG NOT VERIFIED` and `STATUS NOT MAPPED` display labels for valid readings. If no validated ECU-specific threshold exists, the numeric value is shown without an invented condition.
- DUMMY remains displayed only from the active ECU profile's explicit sensor-origin metadata.
- Validated profile thresholds continue to produce direct condition labels such as LOW, HIGH, NORMAL, COLD, WARM, HOT, OVERHEAT, IDLE, RUN, WARNING, and FAULT.
- Missing, unsupported, invalid, or waiting telemetry is simplified to `NO DATA`.
- Corrected battery classification order so OVERVOLTAGE is checked before HIGH.
- Numeric sensor decoding formulas and values were not changed.
- DTC and RESET code paths were not intentionally modified.
- Validation: isolated Kotlin evaluator compiled and passed seven focused checks. Full Android APK build was not run because the source package has no Gradle wrapper script/JAR.
