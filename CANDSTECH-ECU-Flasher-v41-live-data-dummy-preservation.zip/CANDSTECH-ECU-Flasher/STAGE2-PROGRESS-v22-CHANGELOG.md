# CANDSTECH ECU Flasher — Stage 2 v22

## Scope
Integrate durable protocol-evidence storage and harden the previous evidence activation gate. This package is a source consolidation and safety-audit stage; it is not a claim that all vehicle protocols or ECU operations are complete.

## Added
- `ProtocolEvidenceArchive.kt`: app-private persistent archive, immutable evidence IDs, atomic temp-file write/rename, read/list/find/delete, JSON export, and SHA-256 integrity verification.
- `protocol_evidence_schema_v22.json`: archive and activation contract.
- Tests for JSON round-trip, persistent archive, duplicate-ID rejection, adapter-context repeatability, and evidence-linked activation.

## Evidence resolver hardening
- SHA-256 now fingerprints decoded wire bytes rather than the ASCII hex representation.
- Invalid hexadecimal cannot throw from the hash getter; validation reports the malformed capture.
- Repeatability compares ECU identity, part number, adapter model/firmware, transport settings, ignition/engine state, operation, direction, test run, and payload.
- A proposal marked `HARDWARE_VERIFIED` is still rejected unless it names a reviewer and references real archived TX and RX captures.
- The linked TX must exactly match the proposal request; linked RX must exactly match the expected positive response; both must belong to the same test run and exact ECU/transport/operation.

## Safety corrections found during source audit
- The legacy `MainActivity` raw Honda command sender and wake-up path are disabled.
- Legacy BIN Read is blocked until exact ECU identity, memory map, ROM size, address scheme, checksum, and protocol have hardware-verified evidence.
- Legacy BIN Write/Flash is blocked until the exact ECU-specific security access, erase/write sequence, checksum, and post-write verification are hardware-verified.
- The retired duplicate `LegacyHondaProtocolEngine` transport is also fail-closed at its single transceive boundary, preventing stale DTC-clear/read requests from bypassing the active engine gates.
- The old 64 KB default ROM-size assumption is removed; `selectedRomSizeKb` starts at zero. Manual ROM-size choices remain UI-only and cannot trigger a read while the legacy path is locked.
- Offline BIN opening/editing/export is not the same as ECU write and remains separate from the blocked wire operation.

## Consolidation audit findings (not silently marked complete)
- The candidate picker is integrated into the app, but candidate rows remain a non-dispatchable overlay.
- Honda K-Line Direct engine exists in `HondaProtocolEngine` / `KlineWireEngine`.
- ELM327 currently implements standardized OBD-II AT-command discovery only. A separate Honda proprietary K-Line-over-ELM engine is not implemented.
- A separate CAN-over-ELM transport/diagnostic engine is not implemented. CAN profile JSON is metadata only.
- The only exact proprietary Honda Live Data capability still registered is K59A `0101C40F01`, reconstructed from source material and not hardware-verified. Do not describe it as universal or verified.
- `HondaProtocolEngine.identifyEcu()` still uses family-neutral reconstructed baseline identification probes. These are read-only, but they are not yet bound to a per-ECU validated probe allowlist; this remains an open safety/integration item before broad unknown-ECU deployment.
- Persistent archive API is implemented, but automatic capture from the live K-Line/ELM transport and a user-facing evidence review/export screen are not yet wired.

## Validation performed
- All 16 asset JSON files parse.
- Core relational links remain intact: 489 identities, 489 generation mappings, 396 motor records; no orphan identity/generation/motor links.
- Candidate overlay remains 27 rows, 0 actual response IDs, 0 diagnostic/BIN enable flags.
- Profile registries remain fail-closed: 0 dispatch-enabled entries.
- Evidence/archive module compiled with Kotlin/JVM and a smoke test passed JSON round-trip, disk persistence, and linked TX/RX activation.
- Full Android Gradle build and complete JUnit suite were not run: no Gradle wrapper or installed Gradle/Android SDK is present in the working environment.
- No physical ECU/adapter tests were performed.
