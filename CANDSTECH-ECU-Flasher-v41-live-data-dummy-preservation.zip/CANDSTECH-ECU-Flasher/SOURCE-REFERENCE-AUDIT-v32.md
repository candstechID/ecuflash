# Source and Reference Audit — v32

## Project input

- Base: `CANDSTECH-ECU-Flasher-v31-runtime-registry.zip`
- Comparison: `CANDSTECH-ECU-Flasher-v29-dtc-read-only-probe.zip`
- Working communication reference: `candstech_diag2.zip`

The comparison project was inspected as a reference for source history and prior communication implementation. Its older parser formulas were not copied into the current sensor engine.

## Findings affecting this revision

- Runtime database records already carry `liveDataProfileId` and `generationEvidence`; the engine previously ignored those fields and depended only on a single explicit exact-ID runtime grant.
- Of 489 database records, 20 map to Table 17, 15 map to Table 10, and 425 are `UNSUPPORTED`.
- Table 17 records: 19 `REFERENCE`, 1 `RECONSTRUCTED`.
- Table 10 records: 2 `REFERENCE`, 4 `HYPOTHESIS`, 9 `CONFLICT`. All generic rows remain raw-probe-only because the compiled Table 10 parser aliases Table 11 while the independent K-Line reference shows different/unknown byte semantics for some fields; no generic Table 10 decoder is enabled. The existing exact-ID multi-table extension is preserved to avoid changing existing sensor behavior.
- OBD-II PID profile records: 29 `CONFLICT`; they do not activate the ELM route. ELM performs its own supported-PID discovery.
- Duplicate/ambiguous ECU identity resolution remains fail-closed; no arbitrary first matching row is used.
- `Elm327Session` is a standardized OBD-II ELM command path. It is not a Honda proprietary K-Line-over-ELM engine. This distinction is retained.
- The supplied comparison app's `HondaBikeProfiles.lookupByEcmId()` uses substring containment and first-match behavior; that lookup was not ported because it can map a partial identifier to the wrong model. Its old parser and frame offsets were also not copied into the current sensor decoder.

## External references checked

1. AutotronicCommunity `Honda_Keihin_KLine_Protocol` README: fast-init example and Table 11 request; when Table 11 returns the documented negative response, the repository proceeds to Table 17. Its published Table 11 sample response checksum also does not match the current CANDSTECH additive two's-complement validator, while the Table 17 sample does. This is community reverse-engineering material, not an official Honda compatibility matrix.
2. andreibaw `Honda_K-Line_KWP2000`: K-Line frame examples, Table 10 and Table D1 sample traffic. Its Table 10 sample describes some bytes as unknown/fuel-related, so the project keeps generic Table 10 decoder routing disabled until the conflict is resolved. The published Table 10/D1 sample response checksums do not match the current CANDSTECH additive two's-complement validator; they are not used as proof to weaken frame validation.
3. ISO 14230-4:2000 official ISO page: KWP2000 data-link requirements in the emission-related OBD context; the page states the document does not replace Parts 1–3 for the complete specification.
4. SAE J1979 Revised May 2007 copy: Mode 01 supported-PID discovery and PID 0F definition. PID 0F returns one data byte with a -40 °C offset. The PDF is a third-party-hosted copy of a copyrighted standard, so it is used only as a technical reference and is not redistributed.

## Files inspected / static checks

- All 19 JSON assets parsed successfully.
- Database partition record counts checked: motor catalog 396; ECU identity catalog 489; generation mapping 489; merged legacy database 489.
- Source file inventory: 118 files under `app` and `ecuengine`; 94 Kotlin files; final source archive total 161 files.
- All 19 JSON assets and both XML files parsed successfully; no actual merge-conflict marker lines were found.
- `LiveDataProfile.kt` sensor field declarations and `LiveDataFrameParser` code were byte-for-byte preserved; only database resolver logic and explanatory comments changed.
- `Elm327Session.kt` and the ELM OBD-II PID decoder were not modified.
- The changed `LiveDataProfile.kt`, `LiveTelemetry.kt`, and `HondaChecksum.kt` compiled with Kotlin compiler against minimal database stubs; a resolver smoke test passed for six compiled K-Line table IDs, the Table 10 raw-only rule, evidence gating, and exact-ID guard.
- A parser/declaration scan of the changed engine/UI source found no Kotlin syntax or redeclaration errors; unresolved Android/Compose dependencies prevent a full standalone `kotlinc` compile.
- Gradle wrapper JAR and Android SDK are absent and Gradle is not installed in the execution environment; the full Android app build and JUnit suite could not be run here.
- No hardware session was available; no physical ECU compatibility claim is made.


## v33 DTC integration
See `DTC-SCAN-CLEAR-v33-CHANGELOG.md` for captured 73/01 and 74/01 decoding, scan integration, and clear/rescan behavior.
