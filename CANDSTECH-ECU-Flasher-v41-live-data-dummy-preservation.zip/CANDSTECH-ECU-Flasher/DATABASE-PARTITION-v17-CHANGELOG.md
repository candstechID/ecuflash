# CANDSTECH ECU Flasher — Database Partition v17

## Implemented

- Split the combined catalog into `motor_catalog.json` (396 motor/variant identities), `ecu_identity_catalog.json` (489 exact ECU records linked by `motorId`), and `generation_mapping.json` (489 generation/profile assignments keyed by stable `recordId`).
- Added `generation_groups.json` describing the five requested generation families and their transport/activation constraints.
- Added `live_data_profile_registry.json` and `dtc_profile_registry.json` to separate profile identifiers, transport families, evidence state, and ECU capability scope from model identity.
- `EcmDatabase` now loads generation/profile assignment from `generation_mapping.json`; the legacy ECU catalog remains the source for exact model/ECU identity fields.
- Missing generation mapping is fail-closed: record resolves as `UNKNOWN` with no Live Data/DTC profile rather than borrowing another row's profile.
- Existing candidate/conflict assignments remain candidates/conflicts; no 160cc CAN record or Gen-1A record is activated by guessing.

## Sensor display correction

- The K59A exact-ECU profile already contains Table 0x20, O2 and STF fields, matching the bundled RevCore decompiled source: request `72 05 71 20 F8`; O2 uses exact source scale `0.019610266350951835`; STF uses exact source scale `0.007796874819209965`, range `-2..2`.
- O2/STF are engine-running parameters. During KOEO the decoder correctly marks them `NOT_AVAILABLE_IN_KOEO`, but the previous UI hid their decoded raw values and displayed `--` / `TIDAK AKTIF` only.
- Main O2 card and Diagnosa now display the decoded value with explicit `KOEO / WARM-UP` state. O2/STF conversion constants were restored from the decompiled RevCore profile rather than the altered approximations in the current Kotlin table. This distinguishes “response decoded but sensor not yet active” from “no response”.
- AFR is not claimed as ECU data; existing host-estimate policy remains separate.

## Verification status

- Source edits and static JSON checks are performed in this package.
- Unit tests/build and physical ECU response are not claimed until run successfully. Profile layouts remain reconstructed, not hardware-verified.
