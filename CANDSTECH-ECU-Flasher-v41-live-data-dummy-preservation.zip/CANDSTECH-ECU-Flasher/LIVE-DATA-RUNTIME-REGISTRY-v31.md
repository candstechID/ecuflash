# Live Data Runtime Registry Integration — v31 (Superseded)

Version 31 introduced parsing of `live_data_profile_registry.json` into `LiveDataCapabilityRegistry` and an exact-ID/transport check for explicit runtime grants.

That implementation treated the registry as the sole dispatch gate. This was too restrictive for a universal application because the ECU database already contains `liveDataProfileId` and `generationEvidence` for multiple ECU records.

**Superseded by `LIVE-DATA-DATABASE-INTEGRATION-v32.md`.** Version 32 makes the exact database profile assignment the normal decoder-routing source, while preserving exact identity matching and using raw-only probing for profiles that are incomplete or conflicting.

Version 31's static registry remains as an optional source of additional tables for a database-mapped ECU; it is no longer the universal allow-list.

The transport engines remain separate. No physical ECU compatibility or hardware verification is claimed by this registry change.
