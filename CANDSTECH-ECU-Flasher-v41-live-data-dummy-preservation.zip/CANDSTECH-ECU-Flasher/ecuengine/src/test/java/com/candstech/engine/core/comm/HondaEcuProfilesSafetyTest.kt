package com.candstech.engine.core.comm

import org.junit.Assert.assertTrue
import org.junit.Test

class HondaEcuProfilesSafetyTest {
    @Test fun unknownFamilyDoesNotInheritGenericOperationalRequests() {
        val profile = HondaEcuProfiles.forFamily(HondaEcuFamily.UNKNOWN)
        assertTrue(profile.dtcRead.isEmpty())
        assertTrue(profile.dtcClear.isEmpty())
        assertTrue(profile.liveDataTables.isEmpty())
        assertTrue(profile.liveDataServices.isEmpty())
        assertTrue(profile.baudCandidates.isEmpty())
    }

    @Test fun genericBaselineRemainsAnExplicitSeparateProfile() {
        val profile = HondaEcuProfiles.forFamily(HondaEcuFamily.GENERIC_H99B_KLINE)
        assertTrue(profile.hasIdentificationCatalog)
        assertTrue(profile.hasLiveDataCatalog)
    }
}
