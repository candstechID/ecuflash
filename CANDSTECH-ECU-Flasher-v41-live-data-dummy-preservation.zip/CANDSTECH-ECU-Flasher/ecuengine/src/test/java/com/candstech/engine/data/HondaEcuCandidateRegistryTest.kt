package com.candstech.engine.data

import com.candstech.engine.data.ecu.CandidatePartMatchStatus
import com.candstech.engine.data.ecu.EcmModel
import com.candstech.engine.data.ecu.HondaEcuCandidate
import com.candstech.engine.data.ecu.HondaEcuCandidateRegistry
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class HondaEcuCandidateRegistryTest {
    private fun candidate() = HondaEcuCandidate(
        candidateId = "HONDA_CAND_TEST",
        generationGroupCandidate = "GEN-1",
        architectureKeyCandidate = "KLINE|R8C",
        motor = "BeAT 110",
        variant = "BeAT K25",
        market = "ID/ASEAN",
        productionYears = "2012-2014",
        partNumber = "38770-K25-901",
        userSuppliedEcuAlias = "K25-901-01",
        ecuResponseId = null,
        manufacturerCandidate = "Keihin",
        mcuCandidate = "R8C",
        physicalProtocolCandidate = "KLINE",
        liveDataProfileCandidate = "LD_CANDIDATE_ONLY",
        dtcProfileCandidate = "DTC_CANDIDATE_ONLY",
        binProfileCandidate = "BIN_CANDIDATE_ONLY",
        recordStatus = "USER_PROVIDED_UNVERIFIED",
        diagnosticDispatchEnabled = false,
        binReadEnabled = false,
        binWriteEnabled = false,
        notes = "Unverified test fixture",
        requiresPhysicalValidation = true,
        matchedDatabaseRecordIds = listOf("K25-901"),
        exactPartMatchCount = 1,
        databaseMatchStatus = "EXACT_PART_MATCH",
        responseIdEvidenceStatus = "DATABASE_REFERENCE_ONLY"
    )

    @Test
    fun partNumberMatchingIsExactAndDoesNotTreatAliasAsIdentity() {
        val candidate = candidate()
        val database = listOf(
            EcmModel(
                id = "K25-901",
                partNumber = "38770-K25-901",
                ecmId = "0101340F01"
            )
        )

        val exact = HondaEcuCandidateRegistry.matchByPartNumber(
            "38770-K25-901", database, listOf(candidate)
        )
        assertEquals(1, exact.size)
        assertEquals(CandidatePartMatchStatus.UNIQUE_DATABASE_MATCH, exact.single().status)
        assertEquals("K25-901", exact.single().databaseRecords.single().id)

        assertTrue(
            HondaEcuCandidateRegistry.matchByPartNumber(
                "K25-901-01", database, listOf(candidate)
            ).isEmpty()
        )
    }

    @Test
    fun unresolvedCandidateCannotEnableAnyOperation() {
        val candidate = candidate()
        assertFalse(candidate.canDispatchDiagnostics)
        assertFalse(candidate.canReadBin)
        assertFalse(candidate.canWriteBin)
        assertTrue(candidate.requiresPhysicalValidation)
    }

    @Test
    fun duplicateDatabasePartMatchesRemainAmbiguous() {
        val candidate = candidate()
        val database = listOf(
            EcmModel(id = "K25-901-A", partNumber = "38770-K25-901"),
            EcmModel(id = "K25-901-B", partNumber = "38770-K25-901")
        )
        val result = HondaEcuCandidateRegistry.matchByPartNumber(
            "38770-K25-901", database, listOf(candidate)
        ).single()
        assertEquals(CandidatePartMatchStatus.AMBIGUOUS_DATABASE_MATCH, result.status)
        assertEquals(2, result.databaseRecords.size)
    }
}
