package com.candstech.engine.core.protocol

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class HondaKlineDtcCatalogTest {
    @Test fun exposesAllFourConnectionLevelRequestsInExpectedOrder() {
        assertEquals(
            listOf("7205740114", "7205740213", "7205730115", "7205730214"),
            HondaKlineDtcCatalog.readRequests.map { it.frame.joinToString("") { b -> "%02X".format(b.toInt() and 0xFF) } }
        )
        assertEquals(4, HondaKlineDtcCatalog.readRequests.size)
    }

    @Test fun responseMustMatchTheRequestServiceAndPage() {
        val history731 = byteArrayOf(0x02, 0x06, 0x73, 0x01, 0x00, 0x84.toByte())
        val history742 = byteArrayOf(0x02, 0x06, 0x74, 0x02, 0x00, 0x82.toByte())
        assertTrue(HondaKlineDtcCatalog.matchesResponse(HondaKlineDtcCatalog.readRequests[2], history731))
        assertTrue(HondaKlineDtcCatalog.matchesResponse(HondaKlineDtcCatalog.readRequests[1], history742))
        assertTrue(!HondaKlineDtcCatalog.matchesResponse(HondaKlineDtcCatalog.readRequests[1], history731))
    }

    @Test fun currentAndHistoryChannelsAreNotInferredFromEcuDatabase() {
        assertEquals(
            listOf(HondaKlineDtcChannel.CURRENT, HondaKlineDtcChannel.HISTORY,
                HondaKlineDtcChannel.HISTORY, HondaKlineDtcChannel.CURRENT),
            HondaKlineDtcCatalog.readRequests.map { it.channel }
        )
        assertTrue(HondaKlineDtcCatalog.clearRequest.contentEquals(byteArrayOf(0x72, 0x05, 0x60, 0x01, 0x28)))
    }
}
