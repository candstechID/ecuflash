package com.candstech.engine.core.comm

import com.candstech.engine.data.ecu.EcmModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class LiveSensorConditionEvaluatorTest {
    private val model = EcmModel("id", "part")
    private fun eval(sensor: LiveSensor, value: Double?, rpm: Double? = null, selected: EcmModel? = model) =
        LiveSensorConditionEvaluator.evaluate(sensor, value, LiveParameterState.VALID, selected, rpm)

    @Test fun dummyIsAnAnnotationAndNeverReplacesTheReceivedValue() {
        val dummy = model.copy(sensorOrigins = mapOf("IAT" to "DUMMY"))
        val receivedValue = 20.0
        assertEquals("DUMMY", LiveSensorConditionEvaluator.evaluate(
            LiveSensor.IAT, receivedValue, LiveParameterState.VALID, dummy
        ))
        assertEquals(20.0, receivedValue, 0.0)
        assertEquals("DUMMY", LiveSensorConditionEvaluator.evaluate(
            LiveSensor.IAT, receivedValue, LiveParameterState.STALE, dummy
        ))
    }

    @Test fun dummyIsNotShownWithoutAnActualNumericResponse() {
        val dummy = model.copy(sensorOrigins = mapOf("IAT" to "DUMMY"))
        assertNull(LiveSensorConditionEvaluator.evaluate(
            LiveSensor.IAT, null, LiveParameterState.NOT_RESPONDING, dummy
        ))
        assertNull(LiveSensorConditionEvaluator.evaluate(
            LiveSensor.IAT, null, LiveParameterState.INVALID_RESPONSE, dummy
        ))
    }

    @Test fun missingAndNonValidSamplesAreNotDiagnosedAsFault() {
        assertNull(LiveSensorConditionEvaluator.evaluate(LiveSensor.RPM, null, LiveParameterState.NOT_RESPONDING, model))
        assertNull(LiveSensorConditionEvaluator.evaluate(LiveSensor.IAT, 25.0, LiveParameterState.STALE, model))
        assertNull(LiveSensorConditionEvaluator.evaluate(LiveSensor.IAT, Double.NaN, LiveParameterState.VALID, model))
    }

    @Test fun rpmAndSpeedAreOperatingStates() {
        assertEquals("ENGINE OFF", eval(LiveSensor.RPM, 0.0))
        assertEquals("RUN", eval(LiveSensor.RPM, 1500.0))
        assertEquals("FAULT", eval(LiveSensor.RPM, 21000.0))
        assertEquals("STOPPED", eval(LiveSensor.SPEED, 0.0))
        assertEquals("MOVING", eval(LiveSensor.SPEED, 20.0))
    }

    @Test fun ectAndIatUseDecodedTemperatureBands() {
        assertEquals("COLD", eval(LiveSensor.ECT, 25.0))
        assertEquals("NORMAL", eval(LiveSensor.ECT, 90.0))
        assertEquals("HOT", eval(LiveSensor.ECT, 110.0))
        assertEquals("HOT", eval(LiveSensor.ECT, 115.0))
        assertEquals("OVERHEAT", eval(LiveSensor.ECT, 130.0))
        assertEquals("FAULT", eval(LiveSensor.ECT, 151.0))
        assertEquals("COLD", eval(LiveSensor.IAT, 5.0))
        assertEquals("NORMAL", eval(LiveSensor.IAT, 30.0))
        assertEquals("HOT", eval(LiveSensor.IAT, 50.0))
        assertEquals("FAULT", eval(LiveSensor.IAT, 101.0))
    }

    @Test fun allAnalogThrottleChannelsCheckElectricalRails() {
        val voltageSensors = listOf(
            LiveSensor.TPS_VOLTAGE, LiveSensor.TP1_VOLTAGE, LiveSensor.TP2_VOLTAGE,
            LiveSensor.AP1_VOLTAGE, LiveSensor.AP2_VOLTAGE
        )
        voltageSensors.forEach { sensor ->
            assertEquals("FAULT", eval(sensor, 0.10))
            assertEquals("NORMAL", eval(sensor, 2.50))
            assertEquals("FAULT", eval(sensor, 4.90))
        }
    }

    @Test fun temperatureAndMapVoltageCircuitsUseTheirOwnRailBands() {
        assertEquals("FAULT", eval(LiveSensor.ECT_VOLTAGE, 0.10))
        assertEquals("NORMAL", eval(LiveSensor.ECT_VOLTAGE, 2.50))
        assertEquals("FAULT", eval(LiveSensor.IAT_VOLTAGE, 4.80))
        assertEquals("FAULT", eval(LiveSensor.MAP_VOLTAGE, 0.20))
        assertEquals("NORMAL", eval(LiveSensor.MAP_VOLTAGE, 2.50))
        assertEquals("FAULT", eval(LiveSensor.MAP_VOLTAGE, 4.80))
    }

    @Test fun throttlePositionChannelsAreNotTreatedAsVoltageFaults() {
        listOf(LiveSensor.TPS_DEGREES, LiveSensor.TP1_DEGREES, LiveSensor.TP2_DEGREES,
            LiveSensor.AP1_DEGREES, LiveSensor.AP2_DEGREES).forEach { sensor ->
            assertEquals("CLOSED", eval(sensor, 0.0))
            assertEquals("PARTIAL", eval(sensor, 35.0))
            assertEquals("WIDE OPEN", eval(sensor, 80.0))
            assertEquals("FAULT", eval(sensor, 130.0))
        }
        assertEquals("CLOSED", eval(LiveSensor.TPS_PERCENT, 0.0))
        assertEquals("PARTIAL", eval(LiveSensor.TPS_PERCENT, 50.0))
        assertEquals("WIDE OPEN", eval(LiveSensor.TPS_PERCENT, 100.0))
        assertEquals("FAULT", eval(LiveSensor.TPS_PERCENT, 101.0))
        assertEquals("FAULT", eval(LiveSensor.TPS_ADC, 255.0))
        assertEquals("NORMAL", eval(LiveSensor.TPS_ADC, 24.0))
    }

    @Test fun mapAndBatteryHavePlausibilityConditions() {
        assertEquals("NORMAL", eval(LiveSensor.MAP, 100.0, 0.0))
        assertEquals("LOW", eval(LiveSensor.MAP, 18.0, 1800.0))
        assertEquals("FAULT", eval(LiveSensor.MAP, 160.0, 0.0))
        assertEquals("LOW", eval(LiveSensor.BATTERY, 11.0))
        assertEquals("NORMAL", eval(LiveSensor.BATTERY, 12.4))
        assertEquals("HIGH", eval(LiveSensor.BATTERY, 15.2))
    }

    @Test fun zeroInjectorPulseIsNotAutomaticallyAnElectricalFault() {
        assertEquals("ENGINE OFF", eval(LiveSensor.INJECTOR, 0.0, 0.0))
        assertEquals("NO PULSE", eval(LiveSensor.INJECTOR, 0.0, 1800.0))
        assertEquals("ACTIVE", eval(LiveSensor.INJECTOR, 2.4, 1800.0))
        assertEquals("FAULT", eval(LiveSensor.INJECTOR, -1.0, 1800.0))
    }

    @Test fun opaqueOrContextDependentSignalsAreNotGivenInventedDiagnosis() {
        listOf(LiveSensor.O2, LiveSensor.O2_RAW, LiveSensor.AFR, LiveSensor.STF,
            LiveSensor.MODE, LiveSensor.COR, LiveSensor.GEAR_STATE, LiveSensor.FLAG_A,
            LiveSensor.FLAG_B, LiveSensor.GEAR_POSITION).forEach { sensor ->
            assertNull("${sensor.name} must remain unclassified without verified semantics", eval(sensor, 1.0))
        }
        assertNull(eval(LiveSensor.IGNITION_ADVANCE, 15.0))
        assertEquals("FAULT", eval(LiveSensor.IGNITION_ADVANCE, 90.0))
    }

    @Test fun profileThresholdMapCannotChangeEngineEvaluator() {
        val configured = model.copy(conditionThresholds = mapOf(
            "RPM" to listOf(1300.0, 1800.0, 9000.0),
            "TPS_VOLTAGE" to listOf(0.45, 0.55, 4.65, 0.15, 4.92)
        ))
        assertEquals("RUN", LiveSensorConditionEvaluator.evaluate(
            LiveSensor.RPM, 1500.0, LiveParameterState.VALID, configured
        ))
        assertEquals("NORMAL", LiveSensorConditionEvaluator.evaluate(
            LiveSensor.TPS_VOLTAGE, 0.50, LiveParameterState.VALID, configured
        ))
    }
}
