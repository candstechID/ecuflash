package com.candstech.engine.core.comm

import com.candstech.engine.data.ecu.EcmModel
import com.candstech.engine.data.ecu.LiveDataCapabilityRegistry
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LiveDataDatabaseResolverTest {
    @After fun cleanup() = LiveDataCapabilityRegistry.clearForTest()

    private fun model(
        ecuId: String = "0104080F01",
        profile: String = "honda.kline.live.table17",
        evidence: String = "REFERENCE"
    ) = EcmModel(
        id = "DB-ENTRY",
        partNumber = "38770-TEST-001",
        ecmId = ecuId,
        liveDataProfileId = profile,
        generationEvidence = evidence
    )

    @Test fun databaseTable17ReferenceMappingIsRoutedWithoutRegistryWhitelist() {
        val capability = HondaLiveDataProfiles.capabilityForModel(model(), "01 04 08 0F 01")
        assertEquals("honda.kline.live.table17", capability?.capabilityId)
        assertEquals(listOf("17"), capability?.primaryTables?.map { it.tableId })
        assertTrue(capability?.extensionTables?.isEmpty() == true)
    }

    @Test fun table10ReferenceMappingRemainsRawOnlyBecauseItsLayoutHasConflictingOffsets() {
        // The compiled legacy Table 10 parser aliases Table 11, while an
        // independent Honda K-Line implementation documents different/unknown
        // semantics for several Table 10 bytes. Keep it probe-only for generic rows.
        assertNull(HondaLiveDataProfiles.capabilityForModel(
            model(profile = "honda.kline.live.table10"), "0104080F01"
        ))
    }

    @Test fun everyOtherCompiledKlineTableProfileCanBeSelectedByItsDatabaseProfileId() {
        val profiles = listOf("11", "13", "16", "17", "20", "D1")
        for (table in profiles) {
            val profileId = "honda.kline.live.table${table.lowercase()}"
            val capability = HondaLiveDataProfiles.capabilityForModel(
                model(profile = profileId), "0104080F01"
            )
            assertEquals("table $table", table, capability?.primaryTables?.singleOrNull()?.tableId)
        }
    }

    @Test fun hypothesisAndConflictRowsDoNotSelectAParser() {
        assertNull(HondaLiveDataProfiles.capabilityForModel(model(evidence = "HYPOTHESIS"), "0104080F01"))
        assertNull(HondaLiveDataProfiles.capabilityForModel(model(evidence = "CONFLICT"), "0104080F01"))
        assertNull(HondaLiveDataProfiles.capabilityForModel(model(evidence = "UNRESOLVED"), "0104080F01"))
    }

    @Test fun unknownOrMismatchedEcuIdDoesNotInheritDatabaseDecoder() {
        assertNull(HondaLiveDataProfiles.capabilityForModel(model(), "0104080F02"))
        assertNull(HondaLiveDataProfiles.capabilityForModel(model(), "UNKNOWN"))
        assertNull(HondaLiveDataProfiles.capabilityForModel(null, "0104080F01"))
    }
}
