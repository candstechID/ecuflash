package com.candstech.engine.core.protocol

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class NarrowbandAfrEstimateTest {
    @Test fun mapsReferenceVoltagesUsingTheRequestedScannerApproximation() {
        assertEquals(13.5f, NarrowbandAfrEstimate.fromVoltage(0.85f)!!, 0.001f)
        assertEquals(14.7f, NarrowbandAfrEstimate.fromVoltage(0.45f)!!, 0.001f)
        assertEquals(15.75f, NarrowbandAfrEstimate.fromVoltage(0.10f)!!, 0.001f)
    }

    @Test fun rejectsNonFiniteOrOutOfRangeVoltage() {
        assertNull(NarrowbandAfrEstimate.fromVoltage(Float.NaN))
        assertNull(NarrowbandAfrEstimate.fromVoltage(-0.01f))
        assertNull(NarrowbandAfrEstimate.fromVoltage(1.01f))
    }
}
