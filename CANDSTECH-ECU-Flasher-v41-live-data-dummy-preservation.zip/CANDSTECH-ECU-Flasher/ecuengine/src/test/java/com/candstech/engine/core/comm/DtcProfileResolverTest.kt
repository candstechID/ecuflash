package com.candstech.engine.core.comm

import com.candstech.engine.data.ecu.EcmModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DtcProfileResolverTest {
    private fun model(
        id: String,
        ecuId: String,
        profileId: String = "honda.kline.dtc.71_74",
        evidence: String = "REFERENCE"
    ) = EcmModel(
        id = id,
        partNumber = id,
        ecmId = ecuId,
        generationGroup = "UNKNOWN",
        generationEvidence = evidence,
        dtcProfileId = profileId
    )

    @Test fun reconstructedKlineCandidateNeverDispatchesForK59aAlone() {
        val result = DtcProfileResolver.resolve(
            model("K59A-A11", "0101C40F01", evidence = "RECONSTRUCTED"),
            DtcTransport.KLINE_DIRECT
        )
        assertFalse(result.canDispatch)
        assertEquals(DtcProfileResolutionStatus.PROFILE_NOT_HARDWARE_VERIFIED, result.status)
        assertTrue(result.requests.isEmpty())
    }

    @Test fun sameCandidateProfileDoesNotLeakToOtherEcuIdentities() {
        val unrelated = DtcProfileResolver.resolve(
            model("K2F-N01", "0104080F01"), DtcTransport.KLINE_DIRECT
        )
        assertFalse(unrelated.canDispatch)
        assertEquals(DtcProfileResolutionStatus.PROFILE_NOT_HARDWARE_VERIFIED, unrelated.status)
    }

    @Test fun conflictedDatabaseRecordIsRejectedBeforeProfileSelection() {
        val result = DtcProfileResolver.resolve(
            model("PCX160-CANDIDATE", "0103D00D01", "honda.can.obd2.03_07_0a_04", "CONFLICT"),
            DtcTransport.CAN_ELM327
        )
        assertEquals(DtcProfileResolutionStatus.DATABASE_CONFLICT, result.status)
        assertFalse(result.canDispatch)
    }

    @Test fun canProfileCannotBeUsedByKlineEngine() {
        val result = DtcProfileResolver.resolve(
            model("CAN-CANDIDATE", "0103D00D01", "honda.can.obd2.03_07_0a_04"),
            DtcTransport.KLINE_DIRECT
        )
        assertEquals(DtcProfileResolutionStatus.TRANSPORT_MISMATCH, result.status)
        assertFalse(result.canDispatch)
    }

    @Test fun missingIdentityAndUnsupportedProfilesAreExplicit() {
        assertEquals(
            DtcProfileResolutionStatus.IDENTITY_MISSING,
            DtcProfileResolver.resolve(model("NO-ID", ""), DtcTransport.KLINE_DIRECT).status
        )
        assertEquals(
            DtcProfileResolutionStatus.PROFILE_UNSUPPORTED,
            DtcProfileResolver.resolve(model("UNSUPPORTED", "0100000000", "UNSUPPORTED"), DtcTransport.KLINE_DIRECT).status
        )
    }
}
