package com.candstech.engine.core.evidence

import org.junit.Assert.*
import org.junit.Test
import java.nio.file.Files

class ProtocolEvidenceTest {
    private fun capture(index: Int = 1, direction: EvidenceDirection = EvidenceDirection.RX, raw: String = "41 42 43 44") = ProtocolEvidenceRecord(
        evidenceId = "ev-$index-${direction.name}", capturedAtEpochMs = 1_800_000_000_000,
        candidateId = "HONDA-K59A", exactEcuResponseId = "ECU-RESP-123",
        ecuPartNumber = "30400-K59-A11", adapterModel = "ELM327 USB",
        adapterFirmware = "1.5", transport = EvidenceTransport.KLINE_ELM327,
        baudRate = 10400, canBitrate = null, operation = EvidenceOperation.IDENTIFICATION,
        direction = direction, rawHex = raw, elapsedMs = 32,
        ignitionState = "ON", engineState = "OFF", testRunId = "run-1", repetitionIndex = index
    )

    @Test fun `three identical captures are repeatable but not hardware verified`() {
        val result = ProtocolEvidenceValidator.evaluateRepeatability(listOf(capture(1), capture(2), capture(3)))
        assertTrue(result.acceptedForArchive)
        assertTrue(result.repeatable)
    }

    @Test fun `different payload is not repeatable`() {
        val altered = capture(3).copy(rawHex = "41 42 43 45")
        val result = ProtocolEvidenceValidator.evaluateRepeatability(listOf(capture(1), capture(2), altered))
        assertFalse(result.repeatable)
    }

    @Test fun `different adapter context is not repeatable`() {
        val altered = capture(3).copy(adapterFirmware = "clone-2.1")
        val result = ProtocolEvidenceValidator.evaluateRepeatability(listOf(capture(1), capture(2), altered))
        assertFalse(result.repeatable)
    }

    @Test fun `malformed hexadecimal is rejected without hash exception`() {
        val malformed = capture().copy(rawHex = "GG 01")
        val result = ProtocolEvidenceValidator.evaluateRepeatability(listOf(malformed, malformed.copy(evidenceId = "ev-2"), malformed.copy(evidenceId = "ev-3")))
        assertFalse(result.acceptedForArchive)
        assertFalse(result.repeatable)
        assertTrue(malformed.sha256.isEmpty())
    }

    @Test fun `CAN capture requires bitrate`() {
        val result = ProtocolEvidenceValidator.validate(capture().copy(transport = EvidenceTransport.CAN_ELM327, baudRate = null))
        assertFalse(result.acceptedForArchive)
    }

    @Test fun `repeatable evidence cannot activate profile`() {
        val proposal = proposal(EvidenceReviewStatus.REPEATABLE_CAPTURE, approved = false)
        val result = DiagnosticProfileActivationResolver.resolve(
            proposal, "ECU-RESP-123", EvidenceTransport.KLINE_ELM327,
            listOf(capture(1, EvidenceDirection.TX, "71 00"), capture(1, EvidenceDirection.RX, "F1 00"))
        )
        assertFalse(result.enabled)
    }

    @Test fun `verified proposal requires matching linked TX and RX evidence`() {
        val proposal = proposal(EvidenceReviewStatus.HARDWARE_VERIFIED, approved = true)
        val evidence = listOf(
            capture(1, EvidenceDirection.TX, "71 00"),
            capture(1, EvidenceDirection.RX, "F1 00")
        )
        assertTrue(DiagnosticProfileActivationResolver.resolve(proposal, "ECU-RESP-123", EvidenceTransport.KLINE_ELM327, evidence).enabled)
        assertFalse(DiagnosticProfileActivationResolver.resolve(proposal, "ECU-RESP-123", EvidenceTransport.KLINE_DIRECT_FTDI, evidence).enabled)
        assertFalse(DiagnosticProfileActivationResolver.resolve(proposal, "OTHER", EvidenceTransport.KLINE_ELM327, evidence).enabled)
        assertFalse(DiagnosticProfileActivationResolver.resolve(proposal, "ECU-RESP-123", EvidenceTransport.KLINE_ELM327, evidence.dropLast(1)).enabled)
    }

    @Test fun `evidence JSON round trip preserves bytes and identity`() {
        val original = capture(1, EvidenceDirection.RX, "F1 00 7E")
        val decoded = ProtocolEvidenceJsonCodec.decode(ProtocolEvidenceJsonCodec.encode(original))
        assertEquals(original, decoded)
        assertEquals(original.sha256, decoded.sha256)
    }

    @Test fun `archive is persistent and evidence IDs are immutable`() {
        val directory = Files.createTempDirectory("ecu-evidence-test").toFile()
        try {
            val archive = ProtocolEvidenceArchive(directory)
            val record = capture(1)
            assertTrue(archive.save(record).saved)
            assertFalse(archive.save(record).saved)
            assertEquals(record, archive.find(record.evidenceId))
            assertEquals(1, archive.readAll().records.size)
            assertTrue(archive.exportJson().contains("\"schemaVersion\":1"))
            assertTrue(archive.delete(record.evidenceId))
            assertNull(archive.find(record.evidenceId))
        } finally {
            directory.deleteRecursively()
        }
    }

    private fun proposal(status: EvidenceReviewStatus, approved: Boolean) = DiagnosticProfileProposal(
        exactEcuResponseId = "ECU-RESP-123", transport = EvidenceTransport.KLINE_ELM327,
        operation = EvidenceOperation.IDENTIFICATION, requestHex = "71 00", expectedPositiveResponseHex = "F1 00",
        allowlistedExactEcuIds = setOf("ECU-RESP-123"), evidenceStatus = status,
        reviewerApproved = approved, evidenceIds = setOf("ev-1-TX", "ev-1-RX"), reviewerId = "reviewer-1"
    )
}
