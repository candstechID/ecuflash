package com.candstech.engine.data.ecu

import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class LiveDataCapabilityRegistryTest {
    @After fun cleanup() = LiveDataCapabilityRegistry.clearForTest()

    @Test fun onlyExactExplicitlyEnabledDirectKlineGrantIsAccepted() {
        LiveDataCapabilityRegistry.replaceForTest(listOf(
            LiveDataCapabilityGrant("k59a", "KLINE_DIRECT", true, setOf("0101C40F01"), listOf("17"), listOf("16"), false),
            LiveDataCapabilityGrant("reference", "KLINE_DIRECT", false, setOf("0101C40F02"), listOf("11"), emptyList(), false),
            LiveDataCapabilityGrant("elm", "KLINE_ELM", true, setOf("0101C40F03"), listOf("17"), emptyList(), false)
        ))
        assertEquals("k59a", LiveDataCapabilityRegistry.grantForExactEcu("01 01 C4 0F 01")?.profileId)
        assertNull(LiveDataCapabilityRegistry.grantForExactEcu("0101C40F0101"))
        assertNull(LiveDataCapabilityRegistry.grantForExactEcu("0101C40F02"))
        assertNull(LiveDataCapabilityRegistry.grantForExactEcu("0101C40F03"))
    }

    @Test fun duplicateProfileIdsFailClosed() {
        LiveDataCapabilityRegistry.replaceForTest(listOf(
            LiveDataCapabilityGrant("same", "KLINE_DIRECT", true, setOf("0101C40F01"), listOf("17"), emptyList(), false),
            LiveDataCapabilityGrant("same", "KLINE_DIRECT", true, setOf("0101C40F02"), listOf("11"), emptyList(), false)
        ))
        assertNull(LiveDataCapabilityRegistry.grantForExactEcu("0101C40F01"))
    }
}
