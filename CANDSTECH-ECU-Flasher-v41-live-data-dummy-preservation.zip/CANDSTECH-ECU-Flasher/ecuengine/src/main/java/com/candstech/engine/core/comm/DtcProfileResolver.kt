package com.candstech.engine.core.comm

import com.candstech.engine.data.ecu.EcmModel

/** Transport must match the physical communication engine; never infer it from MCU or model name. */
enum class DtcTransport { KLINE_DIRECT, KLINE_ELM327, CAN_ELM327 }

enum class DtcProfileResolutionStatus {
    READY,
    IDENTITY_MISSING,
    PROFILE_UNSUPPORTED,
    PROFILE_UNKNOWN,
    TRANSPORT_MISMATCH,
    ECU_ID_NOT_ALLOWLISTED,
    PROFILE_NOT_HARDWARE_VERIFIED,
    DATABASE_CONFLICT
}

data class DtcProfileResolution(
    val status: DtcProfileResolutionStatus,
    val profileId: String,
    val requests: List<EcuRequest> = emptyList(),
    val detail: String
) {
    val canDispatch: Boolean get() = status == DtcProfileResolutionStatus.READY && requests.isNotEmpty()
}

/**
 * Universal, fail-closed DTC profile resolver.
 * Candidate ECU IDs are deliberately not dispatch allow-lists. A request is
 * eligible only after a profile has an exact verified ECU ID, matching transport,
 * non-conflicted identity evidence, and hardware-verified request/response evidence.
 *
 * No profile in this source revision meets that threshold yet. This is intentional:
 * it prevents the previous single-ECU reconstructed probe from becoming a universal
 * command or being inherited by unrelated ECU records.
 */
object DtcProfileResolver {
    private data class Profile(
        val id: String,
        val transport: DtcTransport,
        val candidateEcuIds: Set<String>,
        val verifiedEcuIds: Set<String>,
        val requests: List<EcuRequest>,
        val hardwareVerified: Boolean
    )

    private val candidateIdsByProfile = mapOf(
            "honda.kline.dtc.71_74" to setOf(
                "0100C50D02",
                "0100FA1001",
                "0101010D02",
                "0101110F01",
                "01011B0F02",
                "01011E0F01",
                "0101230F01",
                "0101320671",
                "0101690F01",
                "0101730F01",
                "0101850D01",
                "0101AE0F01",
                "0101B00D01",
                "0101B10F01",
                "0101B11100",
                "0101BE0F01",
                "0101C40F01",
                "0101DA0F01",
                "0102040F01",
                "0102410F01",
                "0102410F11",
                "0102420F01",
                "0102E20F01",
                "0103100F01",
                "0103110F01",
                "0103790F01",
                "0103790F02",
                "0103790F03",
                "01037A0F01",
                "01037A0F02",
                "01037A0F03",
                "0104080F01",
                "0104130F01",
                "0104A40F01",
                "0104A50F01",
                "0104F00F01",
                "0104F10F01"
            ),
            "honda.can.obd2.03_07_0a_04" to setOf(
                "0103CF0D01",
                "0103D00D01",
                "0104030F01",
                "0104040F01",
                "01046B0F01",
                "01046C1801",
                "0104860801",
                "01048C0F01",
                "01048C0F11",
                "01048D0F01",
                "01048D0F11",
                "01048D1801",
                "01048E0D01",
                "0105020F01",
                "0105030F01",
                "0105030F11",
                "0105040D01",
                "0105050D01",
                "0105770F01",
                "0105B30D01",
                "0105B40D01",
                "0105B40D02",
                "0105B60F01",
                "0105B70F01",
                "0105B80F01",
                "0106130D01",
                "0106240F01",
                "0106250F01",
                "01065E0F01"
            )
    )

    private val profiles = listOf(
        Profile(
            id = "honda.kline.dtc.71_74",
            transport = DtcTransport.KLINE_DIRECT,
            candidateEcuIds = candidateIdsByProfile["honda.kline.dtc.71_74"].orEmpty(),
            verifiedEcuIds = emptySet(),
            requests = HondaEcuProfiles.genericBaseline.dtcRead,
            hardwareVerified = false
        ),
        Profile(
            id = "honda.can.obd2.03_07_0a_04",
            transport = DtcTransport.CAN_ELM327,
            candidateEcuIds = candidateIdsByProfile["honda.can.obd2.03_07_0a_04"].orEmpty(),
            verifiedEcuIds = emptySet(),
            requests = emptyList(),
            hardwareVerified = false
        )
    )

    /**
     * Explicit, read-only diagnostic probes for collecting raw ECU evidence.
     * These are NOT verified DTC profiles and must never be used for automatic
     * scans on unknown/non-exact ECU identities. The caller must expose this only
     * behind the user's explicit SCAN DTC action and must label results unverified.
     */
    fun readOnlyProbeRequests(model: EcmModel?, transport: DtcTransport): List<EcuRequest> {
        if (model == null || model.ecmId.isBlank()) return emptyList()
        if (model.generationEvidence.contains("CONFLICT", ignoreCase = true)) return emptyList()
        val profileId = model.dtcProfileId.trim()
        val expectedProfile = when (transport) {
            DtcTransport.KLINE_DIRECT -> "honda.kline.dtc.71_74"
            else -> return emptyList() // ELM OBD-II uses standardized Mode 03/07/0A in Elm327Session.
        }
        if (profileId != expectedProfile) return emptyList()
        val ecuId = canonical(model.ecmId)
        if (ecuId !in candidateIdsByProfile[expectedProfile].orEmpty()) return emptyList()

        // These two request/response pairs are the ones now evidenced by the
        // user's live capture. Do not send unrelated historical probe candidates.
        return listOf(
            EcuRequest("probe.dtc.7401", byteArrayOf(0x72, 0x05, 0x74, 0x01, 0x14),
                "Honda DTC Current 74/01", 700, 0, "DTC_CURRENT_7401", EvidenceStatus.RECONSTRUCTED),
            EcuRequest("probe.dtc.7301", byteArrayOf(0x72, 0x05, 0x73, 0x01, 0x15),
                "Honda DTC History 73/01", 700, 0, "DTC_HISTORY_7301", EvidenceStatus.RECONSTRUCTED)
        )
    }

    fun resolve(model: EcmModel?, transport: DtcTransport): DtcProfileResolution {
        if (model == null || model.ecmId.isBlank()) {
            return result(DtcProfileResolutionStatus.IDENTITY_MISSING, model?.dtcProfileId.orEmpty(), "ECU response identity is missing; no DTC request sent.")
        }
        if (model.generationEvidence.contains("CONFLICT", ignoreCase = true)) {
            return result(DtcProfileResolutionStatus.DATABASE_CONFLICT, model.dtcProfileId, "Database identity/profile is conflicted; no DTC request sent.")
        }
        val id = model.dtcProfileId.trim()
        if (id.isBlank() || id.equals("UNSUPPORTED", ignoreCase = true)) {
            return result(DtcProfileResolutionStatus.PROFILE_UNSUPPORTED, id, "No DTC profile is assigned to this ECU identity.")
        }
        val profile = profiles.firstOrNull { it.id == id }
            ?: return result(DtcProfileResolutionStatus.PROFILE_UNKNOWN, id, "DTC profile '$id' is not registered.")
        if (profile.transport != transport) {
            return result(DtcProfileResolutionStatus.TRANSPORT_MISMATCH, id, "Profile transport ${profile.transport} does not match active transport $transport.")
        }
        val ecuId = canonical(model.ecmId)
        if (ecuId !in profile.candidateEcuIds && ecuId !in profile.verifiedEcuIds) {
            return result(DtcProfileResolutionStatus.ECU_ID_NOT_ALLOWLISTED, id, "ECU ID $ecuId is not listed for this DTC profile.")
        }
        if (ecuId !in profile.verifiedEcuIds || !profile.hardwareVerified) {
            return result(DtcProfileResolutionStatus.PROFILE_NOT_HARDWARE_VERIFIED, id, "DTC request/response pair is not hardware-verified for ECU ID $ecuId.")
        }
        if (profile.requests.isEmpty()) {
            return result(DtcProfileResolutionStatus.PROFILE_UNSUPPORTED, id, "Verified DTC profile contains no requests.")
        }
        return DtcProfileResolution(DtcProfileResolutionStatus.READY, id, profile.requests, "Exact ECU, transport and hardware-verified DTC profile matched.")
    }

    private fun canonical(value: String): String = value.filter(Char::isLetterOrDigit).uppercase()

    private fun result(status: DtcProfileResolutionStatus, id: String, detail: String) =
        DtcProfileResolution(status, id, emptyList(), detail)
}
