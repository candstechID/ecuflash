package com.candstech.engine.core.protocol

/**
 * Connection-level Honda K-Line DTC discovery catalog.
 *
 * These four requests are tried on an explicitly active RAW/FTDI K-Line session,
 * even when the ECU identity is absent from the local database. The response
 * parser still validates framing/checksum and the response service/page must
 * match the request before its DTCs are accepted.
 */
enum class HondaKlineDtcChannel { CURRENT, HISTORY }

data class HondaKlineDtcRequest(
    val id: String,
    val frame: ByteArray,
    val responseService: Int,
    val responsePage: Int,
    val channel: HondaKlineDtcChannel,
    val label: String
)

object HondaKlineDtcCatalog {
    val readRequests: List<HondaKlineDtcRequest> = listOf(
        HondaKlineDtcRequest(
            id = "HONDA_7401_CURRENT",
            frame = byteArrayOf(0x72, 0x05, 0x74, 0x01, 0x14),
            responseService = 0x74, responsePage = 0x01,
            channel = HondaKlineDtcChannel.CURRENT,
            label = "Honda K-Line DTC utama 74/01"
        ),
        HondaKlineDtcRequest(
            id = "KEIHIN_7402_HISTORY",
            frame = byteArrayOf(0x72, 0x05, 0x74, 0x02, 0x13),
            responseService = 0x74, responsePage = 0x02,
            channel = HondaKlineDtcChannel.HISTORY,
            label = "Honda K-Line Keihin History 74/02"
        ),
        HondaKlineDtcRequest(
            id = "SHINDENGEN_7301_HISTORY",
            frame = byteArrayOf(0x72, 0x05, 0x73, 0x01, 0x15),
            responseService = 0x73, responsePage = 0x01,
            channel = HondaKlineDtcChannel.HISTORY,
            label = "Honda K-Line Shindengen History 73/01"
        ),
        HondaKlineDtcRequest(
            id = "SHINDENGEN_7302_CURRENT_ALT",
            frame = byteArrayOf(0x72, 0x05, 0x73, 0x02, 0x14),
            responseService = 0x73, responsePage = 0x02,
            channel = HondaKlineDtcChannel.CURRENT,
            label = "Honda K-Line Shindengen Current alternatif 73/02"
        )
    )

    /** Shared FTDI K-Line clear candidate for Shindengen and Keihin per user-provided project data. */
    val clearRequest: ByteArray = byteArrayOf(0x72, 0x05, 0x60, 0x01, 0x28)

    fun matchesResponse(request: HondaKlineDtcRequest, frame: ByteArray): Boolean =
        frame.size >= 5 &&
            (frame[2].toInt() and 0xFF) == request.responseService &&
            (frame[3].toInt() and 0xFF) == request.responsePage
}
