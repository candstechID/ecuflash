package com.candstech.engine.data.ecu

import org.json.JSONArray
import java.util.Locale

/**
 * Runtime allow-list loaded from live_data_profile_registry.json.
 * Layout records alone never grant dispatch. A grant requires dispatchEnabled,
 * an exact ECU ID and the expected transport. Duplicate grants fail closed.
 */
data class LiveDataCapabilityGrant(
    val profileId: String,
    val transport: String,
    val dispatchEnabled: Boolean,
    val exactEcuIds: Set<String>,
    val primaryTables: List<String>,
    val extensionTables: List<String>,
    val hardwareVerified: Boolean
)

object LiveDataCapabilityRegistry {
    @Volatile private var grants: List<LiveDataCapabilityGrant> = emptyList()

    fun loadJson(json: String) {
        val array = JSONArray(json)
        val parsed = ArrayList<LiveDataCapabilityGrant>(array.length())
        for (i in 0 until array.length()) {
            val item = array.getJSONObject(i)
            val ids = item.optJSONArray("exactEcuIds") ?: JSONArray()
            val primary = item.optJSONArray("primaryTables") ?: JSONArray()
            val extensions = item.optJSONArray("extensionTables") ?: JSONArray()
            parsed += LiveDataCapabilityGrant(
                profileId = item.optString("profileId", ""),
                transport = item.optString("transport", "NONE").uppercase(Locale.ROOT),
                dispatchEnabled = item.optBoolean("dispatchEnabled", false),
                exactEcuIds = (0 until ids.length()).mapNotNull { ids.optString(it, null) }
                    .map { normalizeId(it) }.filter { it.isNotEmpty() }.toSet(),
                primaryTables = (0 until primary.length()).map { primary.optString(it, "") },
                extensionTables = (0 until extensions.length()).map { extensions.optString(it, "") },
                hardwareVerified = item.optBoolean("hardwareVerified", false)
            )
        }
        // A repeated profile ID is ambiguous configuration, so discard all grants.
        grants = if (parsed.map { it.profileId }.distinct().size == parsed.size) parsed else emptyList()
    }

    fun grantForExactEcu(ecuId: String?, expectedTransport: String = "KLINE_DIRECT"): LiveDataCapabilityGrant? {
        val normalized = normalizeId(ecuId.orEmpty())
        if (normalized.isEmpty()) return null
        val matches = grants.filter { grant ->
            grant.profileId.isNotBlank() && grant.dispatchEnabled &&
                grant.transport == expectedTransport && grant.primaryTables.isNotEmpty() &&
                normalized in grant.exactEcuIds
        }
        return matches.singleOrNull()
    }

    fun allGrants(): List<LiveDataCapabilityGrant> = grants.toList()

    internal fun replaceForTest(value: List<LiveDataCapabilityGrant>) {
        grants = if (value.map { it.profileId }.distinct().size == value.size) value else emptyList()
    }
    internal fun clearForTest() { grants = emptyList() }

    private fun normalizeId(value: String): String =
        value.uppercase(Locale.ROOT).filter { it in '0'..'9' || it in 'A'..'F' }
}
