package com.candstech.engine.core.comm

import java.util.Locale
import com.candstech.engine.core.protocol.HondaChecksum
import com.candstech.engine.data.ecu.EcmModel
import com.candstech.engine.data.ecu.LiveDataCapabilityRegistry

/**
 * Declarative read-only live-data layout. Nothing here proves an ECU answers a
 * request; [verification] records how far the layout itself has been evidenced.
 *
 * The bundled Honda table catalogue is reconstructed from the project source
 * material and is explicitly marked RECONSTRUCTED, not hardware-verified.
 * Decoder selection is gated by an exact database identity and a complete,
 * non-conflicting profile. Unknown/incomplete identities can only use raw probes.
 */
enum class ProfileVerification {
    /** Proven by a documented wire capture or an owned, verifiable source. */
    VERIFIED,
    /** Transcribed from a reconstruction whose provenance is recorded. */
    RECONSTRUCTED,
    /** Documented example only; never an ECU compatibility claim. */
    REFERENCE,
    /** Plausible but unproven; must not be presented as compatibility. */
    HYPOTHESIS
}

enum class FieldEndian { BIG, LITTLE }

/**
 * Per-parameter availability. A value that is not [VALID] is never displayed as
 * zero: the UI shows the state instead. Engine state never suppresses a valid ECU response.
 */
enum class LiveParameterState {
    VALID,
    NOT_RESPONDING,
    /** Legacy state retained for serialized/UI compatibility; never emitted by current parser. */
    NOT_AVAILABLE_IN_KOEO,
    UNSUPPORTED,
    INVALID_RESPONSE,
    WAITING_FOR_DATA,
    STALE
}

/**
 * Pure state transitions shared by the wire engine, the UI and tests. A stale or
 * missing parameter never becomes a zero value; only its state changes.
 */
object LiveParameterStates {

    fun validSensors(states: Map<LiveSensor, LiveParameterState>): Set<LiveSensor> =
        states.filterValues { it == LiveParameterState.VALID }.keys

    /** After a link loss only previously VALID values are marked STALE. */
    fun stale(states: Map<LiveSensor, LiveParameterState>): Map<LiveSensor, LiveParameterState> =
        states.mapValues { (_, state) ->
            if (state == LiveParameterState.VALID) LiveParameterState.STALE else state
        }

    /**
     * Sensors the reconstructed ECU layouts never publish directly. AFR is the
     * notable one: the ECU exposes narrowband O2 voltage, not measured AFR.
     * The app may separately show an explicitly labelled host-side estimate;
     * this ECU field remains UNSUPPORTED so it cannot be mistaken for ECU data.
     * An existing decoded entry always wins.
     */
    val notPublishedByEcu: Map<LiveSensor, LiveParameterState> = mapOf(
        LiveSensor.AFR to LiveParameterState.UNSUPPORTED
    )

    /**
     * Adds [notPublishedByEcu] to a non-empty state map without overriding a
     * sensor that actually decoded. Empty maps stay empty so the UI keeps
     * showing its "no data yet" message rather than a lone unsupported row.
     */
    fun withNotPublished(states: Map<LiveSensor, LiveParameterState>): Map<LiveSensor, LiveParameterState> {
        if (states.isEmpty()) return states
        val merged = states.toMutableMap()
        for ((sensor, state) in notPublishedByEcu) {
            if (sensor !in merged) merged[sensor] = state
        }
        return merged
    }
}

/**
 * Parameter identifiers understood by the parser. The names are generic
 * diagnostic concepts, not a claim that any particular ECU publishes them.
 * AP/TP channels describe ride-by-wire throttle inputs.
 */
enum class LiveSensor {
    RPM,
    TPS_PERCENT,
    TPS_VOLTAGE,
    TPS_DEGREES,
    TPS_ADC,
    ECT,
    ECT_VOLTAGE,
    IAT,
    IAT_VOLTAGE,
    MAP,
    MAP_VOLTAGE,
    BATTERY,
    IGNITION_ADVANCE,
    INJECTOR,
    SPEED,
    MODE,
    O2,
    O2_RAW,
    AFR,
    STF,
    AP1_VOLTAGE,
    AP2_VOLTAGE,
    AP1_DEGREES,
    AP2_DEGREES,
    TP1_VOLTAGE,
    TP2_VOLTAGE,
    TP1_DEGREES,
    TP2_DEGREES,
    COR,
    GEAR_STATE,
    FLAG_A,
    FLAG_B,
    GEAR_POSITION
}

/**
 * One field inside a live-data payload.
 *
 * [alternateOffsets] supports a primary/fallback byte pair: the primary offset is
 * used unless it reads 0xFF, in which case the first alternate offset is tried.
 * A 0xFF byte is therefore only treated as "absent" for fields that declare
 * alternates; other fields keep their raw value and go through the normal range
 * check.
 */
data class LiveFieldSpec(
    val sensor: LiveSensor,
    val offset: Int,
    val length: Int = 1,
    val endian: FieldEndian = FieldEndian.BIG,
    val signed: Boolean = false,
    val scale: Double = 1.0,
    val bias: Double = 0.0,
    val unit: String = "",
    val validMin: Double,
    val validMax: Double,
    val alternateOffsets: List<Int> = emptyList(),
    /** Legacy metadata only; must not suppress values in KOEO. */
    val engineRunningOnly: Boolean = false,
    val note: String = ""
)

data class LiveTableProfile(
    val id: String,
    val tableId: String,
    val request: ByteArray,
    val payloadStart: Int,
    val minPayload: Int,
    val requiredSensors: Set<LiveSensor>,
    val fields: List<LiveFieldSpec>,
    val verification: ProfileVerification,
    val provenance: String,
    val notes: String = ""
) {
    /** Smallest complete frame (header, length, service, table, data, checksum). */
    val minFrameSize: Int get() = payloadStart + minPayload + 1
}

/** Exact ECU-ID capability: only the tables explicitly listed here may be queried. */
data class EcuLiveDataCapability(
    val ecuId: String,
    val capabilityId: String,
    val primaryTables: List<LiveTableProfile>,
    val extensionTables: List<LiveTableProfile>,
    val verification: ProfileVerification,
    val notes: String = ""
)

data class LiveParseResult(
    val profileId: String,
    val values: Map<LiveSensor, Double>,
    val available: Set<LiveSensor>,
    val rejected: Map<LiveSensor, String>,
    val states: Map<LiveSensor, LiveParameterState>,
    val dataValid: Boolean
)

object LiveDataFrameParser {
    /**
     * Parses an already de-framed payload. Framing, length and checksum are the
     * wire engine's responsibility; this function only applies offsets/scales and
     * range checks. An out-of-range or truncated field is omitted, never zeroed.
     */
    fun parse(payload: ByteArray, profile: LiveTableProfile): LiveParseResult {
        val values = mutableMapOf<LiveSensor, Double>()
        val available = mutableSetOf<LiveSensor>()
        val rejected = mutableMapOf<LiveSensor, String>()
        val states = mutableMapOf<LiveSensor, LiveParameterState>()

        for (field in profile.fields) {
            val offsets = listOf(field.offset) + field.alternateOffsets
            var chosen: Int? = null
            var reason = "payload terlalu pendek"
            for (offset in offsets) {
                if (offset + field.length > payload.size) continue
                val useAlternateRule = field.alternateOffsets.isNotEmpty()
                if (useAlternateRule && field.length == 1 && (payload[offset].toInt() and 0xFF) == 0xFF) {
                    reason = "byte 0xFF pada offset utama"
                    continue
                }
                chosen = offset
                reason = ""
                break
            }
            if (chosen == null) {
                rejected[field.sensor] = reason
                states[field.sensor] = if (reason.startsWith("payload")) {
                    LiveParameterState.NOT_RESPONDING
                } else {
                    LiveParameterState.INVALID_RESPONSE
                }
                continue
            }

            var raw = 0L
            for (i in 0 until field.length) {
                val index = chosen + if (field.endian == FieldEndian.BIG) i else field.length - 1 - i
                raw = (raw shl 8) or (payload[index].toLong() and 0xFF)
            }
            if (field.signed) {
                val shift = 64 - field.length * 8
                raw = (raw shl shift) shr shift
            }
            val value = raw * field.scale + field.bias
            if (value < field.validMin || value > field.validMax) {
                rejected[field.sensor] =
                    "nilai ${"%.3f".format(value)} di luar rentang ${field.validMin}..${field.validMax}"
                states[field.sensor] = LiveParameterState.INVALID_RESPONSE
                continue
            }
            values[field.sensor] = value
            available.add(field.sensor)
            states[field.sensor] = LiveParameterState.VALID
        }

        // No single sensor gates the frame. At key-on/engine-off RPM can be absent
        // or invalid while TPS, ECT, IAT and battery are still perfectly usable.
        val dataValid = available.isNotEmpty()
        return LiveParseResult(profile.id, values, available, rejected, states, dataValid)
    }
}

/**
 * Built-in Honda live-data catalogue reconstructed from the RevCore source
 * supplied for this project. These layouts are not hardware-verified on every
 * ECU; exact ECU identity plus database evidence is required before decoding.
 * Unknown or incomplete identities may only use the bounded raw-only probe path.
 */
object HondaLiveDataProfiles {
    private const val ADC = 0.01953125
    private const val PROVENANCE = "Rekonstruksi dari HondaLiveDataProfiles.java (RevCore / FLASHPRO firmware decoder); belum diverifikasi pada ECU fisik CANDSTECH."
    private fun f(sensor: LiveSensor, offset: Int, length: Int = 1, scale: Double = 1.0, bias: Double = 0.0,
                  unit: String = "", min: Double = 0.0, max: Double = 255.0,
                  alternate: List<Int> = emptyList(), running: Boolean = false, note: String = "") =
        LiveFieldSpec(sensor, offset, length, FieldEndian.BIG, false, scale, bias, unit, min, max, alternate, running, note)

    private fun table(id: String, request: IntArray, minPayload: Int, fields: List<LiveFieldSpec>, notes: String) =
        LiveTableProfile("revcore.vario150.$id", id, request.map { it.toByte() }.toByteArray(), 4, minPayload,
            emptySet(), fields, ProfileVerification.RECONSTRUCTED, PROVENANCE, notes)

    private val commonTps = listOf(
        // Preserve the previously displayed TPS percentage conversion from ADC.
        // Keep ADC count, voltage and the separate ECU TPS-angle byte distinct.
        // Do not replace the working display with the unverified 160-count angle
        // endpoint: the user's prior capture showed ADC=24 / 9.4% while angle=0°.
        f(LiveSensor.TPS_VOLTAGE, 2, scale = ADC, unit = "V", min = 0.0, max = 5.0),
        f(LiveSensor.TPS_ADC, 2, unit = "count", min = 0.0, max = 255.0),
        f(LiveSensor.TPS_PERCENT, 2, scale = 100.0 / 256.0, unit = "%", min = 0.0, max = 100.0,
            note = "Legacy ADC-derived display retained for compatibility; not a calibrated throttle angle."),
        f(LiveSensor.TPS_DEGREES, 3, scale = 0.5, unit = "deg", min = 0.0, max = 127.5)
    )
    private val ect = listOf(
        f(LiveSensor.ECT_VOLTAGE, 8, scale = ADC, unit = "V", min = 0.0, max = 5.0, alternate = listOf(4)),
        f(LiveSensor.ECT, 9, bias = -40.0, unit = "°C", min = -40.0, max = 150.0, alternate = listOf(5))
    )
    private val iat = listOf(
        f(LiveSensor.IAT_VOLTAGE, 6, scale = ADC, unit = "V", min = 0.0, max = 5.0),
        f(LiveSensor.IAT, 7, bias = -40.0, unit = "°C", min = -40.0, max = 100.0)
    )
    private val map = listOf(
        f(LiveSensor.MAP_VOLTAGE, 8, scale = ADC, unit = "V", min = 0.0, max = 5.0),
        f(LiveSensor.MAP, 9, unit = "kPa", min = 0.0, max = 255.0)
    )
    private fun rpm() = f(LiveSensor.RPM, 0, length = 2, unit = "rpm", min = 0.0, max = 20000.0)
    private fun battery(offset: Int) = f(LiveSensor.BATTERY, offset, scale = 0.1, unit = "V", min = 5.0, max = 20.0)
    // Main tables use 8.8 fixed-point milliseconds (raw16 / 256).
    // Table 0x16 is a separate one-byte /200 layout and overrides the scale.
    private fun injector(offset: Int, length: Int = 2, scale: Double = 1.0 / 256.0) =
        f(LiveSensor.INJECTOR, offset, length, scale = scale, unit = "ms", min = 0.0, max = 50.0)
    private fun ignition(offset: Int) = f(LiveSensor.IGNITION_ADVANCE, offset, scale = 0.5, bias = -64.0, unit = "deg", min = -70.0, max = 70.0)
    private fun speed(offset: Int) = f(LiveSensor.SPEED, offset, unit = "km/h", min = 0.0, max = 300.0)

    val table17 = table("17", intArrayOf(0x72,0x05,0x71,0x17,0x01), 16,
        listOf(rpm()) + commonTps + ect + iat + listOf(battery(10), injector(11), ignition(13), f(LiveSensor.MODE,14)) + listOf(speed(15)),
        "Tabel utama; ECT offset 8/9 dengan fallback 4/5; mode dan VSS. Injector 16-bit /256 ms.")
    val table13 = table("13", intArrayOf(0x72,0x05,0x71,0x13,0x05), 14,
        listOf(rpm()) + commonTps + listOf(f(LiveSensor.ECT_VOLTAGE,4,scale=ADC,unit="V",min=0.0,max=5.0), f(LiveSensor.ECT,5,bias=-40.0,unit="°C",min=-40.0,max=150.0)) + iat + map + listOf(battery(10),injector(11),ignition(13)),
        "Tabel utama alternatif; tidak memuat VSS/mode. Injector 16-bit /256 ms.")
    val table11 = table("11", intArrayOf(0x72,0x05,0x71,0x11,0x07), 17,
        listOf(rpm()) + commonTps + listOf(f(LiveSensor.ECT_VOLTAGE,4,scale=ADC,unit="V",min=0.0,max=5.0), f(LiveSensor.ECT,5,bias=-40.0,unit="°C",min=-40.0,max=150.0)) + iat + map + listOf(battery(12),speed(13),injector(14),ignition(16)),
        "Tabel utama alternatif; layout direkonstruksi dari source. Injector 16-bit /256 ms.")
    val table10 = table("10", intArrayOf(0x72,0x05,0x71,0x10,0x08), 17, table11.fields,
        "Layout identik tabel 11 menurut source Java.")
    val table16 = table("16", intArrayOf(0x72,0x05,0x71,0x16,0x02), 21,
        listOf(rpm(), f(LiveSensor.AP1_VOLTAGE,2,scale=ADC,unit="V",min=0.0,max=5.0), f(LiveSensor.AP2_VOLTAGE,3,scale=ADC,unit="V",min=0.0,max=5.0),
            f(LiveSensor.AP1_DEGREES,4,scale=0.5,unit="deg",min=0.0,max=127.5), f(LiveSensor.AP2_DEGREES,5,scale=0.5,unit="deg",min=0.0,max=127.5),
            f(LiveSensor.TP1_VOLTAGE,6,scale=ADC,unit="V",min=0.0,max=5.0), f(LiveSensor.TP2_VOLTAGE,7,scale=ADC,unit="V",min=0.0,max=5.0),
            f(LiveSensor.TP1_DEGREES,8,scale=0.5,unit="deg",min=0.0,max=127.5), f(LiveSensor.TP2_DEGREES,9,scale=0.5,unit="deg",min=0.0,max=127.5),
            f(LiveSensor.COR,10), f(LiveSensor.ECT_VOLTAGE,11,scale=ADC,unit="V",min=0.0,max=5.0), f(LiveSensor.ECT,12,bias=-40.0,unit="°C",min=-40.0,max=150.0),
            f(LiveSensor.IAT_VOLTAGE,13,scale=ADC,unit="V",min=0.0,max=5.0), f(LiveSensor.IAT,14,bias=-40.0,unit="°C",min=-40.0,max=100.0),
            f(LiveSensor.MAP_VOLTAGE,15,scale=ADC,unit="V",min=0.0,max=5.0), f(LiveSensor.MAP,16,unit="kPa"), battery(17), speed(18), injector(19,1,scale=0.005), ignition(20)),
        "Tabel ekstensi; RPM hanya fallback; injektor satu byte /200 menurut catatan source.")
    val table20 = table("20", intArrayOf(0x72,0x05,0x71,0x20,0xF8), 2,
        listOf(f(LiveSensor.O2,0,scale=0.019610266350951835,unit="V",min=0.0,max=5.0,running=false), f(LiveSensor.STF,1,scale=0.007796874819209965,min=-2.0,max=2.0,running=false)),
        "Skala/offset dipulihkan dari profil RevCore terdekompilasi: O2 byte 4 dan STF byte 5. Nilai mentah ditampilkan setiap kali respons ECU valid; validitas interpretasi sensor tetap memerlukan pengukuran fisik. AFR/lambda tidak disediakan ECU.")
    val tableD1 = table("D1", intArrayOf(0x72,0x05,0x71,0xD1,0x47), 7,
        listOf(f(LiveSensor.GEAR_STATE,0), f(LiveSensor.FLAG_A,4), f(LiveSensor.FLAG_B,5), f(LiveSensor.GEAR_POSITION,6)),
        "Byte status gear dan flag direkonstruksi; label flag belum diverifikasi.")

    val primaryTables = listOf(table17, table13, table11, table10)
    val extendedTables = listOf(table16, table20, tableD1)
    val tables = primaryTables + extendedTables
    val all = tables
    val baseline = table11

    /**
     * Exact-ID capability registry. This is not a default ECU selection: it is
     * consulted only after EcmDatabase has returned an EXACT identity match.
     * Legacy exact-ID extension grants remain supplementary. Database profile
     * routing for ordinary ECU records is handled by capabilityForModel(); this
     * lookup alone is not a universal decoder selector.
     */
    fun capabilityForEcu(ecmId: String?): EcuLiveDataCapability? {
        val grant = LiveDataCapabilityRegistry.grantForExactEcu(ecmId, "KLINE_DIRECT") ?: return null
        val normalized = ecmId?.uppercase(Locale.ROOT)?.filter { it in '0'..'9' || it in 'A'..'F' }
            ?.takeIf { it.matches(Regex("^(?:[0-9A-F]{10}|[0-9A-F]{12})$")) }
            ?: return null
        val primary = grant.primaryTables.map { forTable(it) ?: return null }
        val extensions = grant.extensionTables.map { forTable(it) ?: return null }
        if (primary.isEmpty() || primary.any { !hasCompleteCompiledLayout(it) } ||
            extensions.any { !hasCompleteCompiledLayout(it) }
        ) return null
        return EcuLiveDataCapability(
            ecuId = normalized,
            capabilityId = grant.profileId,
            primaryTables = primary,
            extensionTables = extensions,
            verification = if (grant.hardwareVerified) ProfileVerification.VERIFIED else ProfileVerification.RECONSTRUCTED,
            notes = if (grant.hardwareVerified) "Exact ECU-ID grant; hardware verified." else
                "Exact ECU-ID grant only; reconstructed layout, not hardware-verified."
        )
    }

    /** Database profile IDs map only to compiled, known table layouts. */
    private val DATABASE_PROFILE_TABLES = mapOf(
        "honda.kline.live.table11" to listOf("11"),
        "honda.kline.live.table13" to listOf("13"),
        "honda.kline.live.table16" to listOf("16"),
        "honda.kline.live.table17" to listOf("17"),
        "honda.kline.live.table20" to listOf("20"),
        "honda.kline.live.tabled1" to listOf("D1")
    )

    /**
     * Resolve a decoder from the database row selected by an EXACT ECU identity.
     * The database profile ID is the routing key; generation/model names are not.
     * REFERENCE and RECONSTRUCTED mappings are eligible for read-only trials
     * only when a compiled table layout is not known to conflict. HYPOTHESIS,
     * CONFLICT, UNRESOLVED and generic Table 10 rows remain probe-only.
     *
     * The explicit runtime registry may add the existing table set for an exact
     * profile, but it is not a global allow-list and is never required for other
     * database rows to use their own mapped table.
     */
    fun capabilityForModel(model: EcmModel?, ecmId: String?): EcuLiveDataCapability? {
        model ?: return null
        val normalized = normalizeEcuId(ecmId ?: model.ecmId) ?: return null
        val modelId = normalizeEcuId(model.ecmId) ?: return null
        if (normalized != modelId) return null

        val evidence = model.generationEvidence.trim().uppercase(Locale.ROOT)
        if (evidence !in setOf("REFERENCE", "RECONSTRUCTED")) return null

        val mappedTableIds = DATABASE_PROFILE_TABLES[model.liveDataProfileId.trim().lowercase(Locale.ROOT)]
            ?: return null
        val mappedProfiles = mappedTableIds.map { forTable(it) ?: return null }
        if (mappedProfiles.isEmpty() || mappedProfiles.any { !hasCompleteCompiledLayout(it) }) return null
        val mappedProfile = mappedProfiles.first()

        // A matching explicit grant may extend the table set for this exact ECU.
        // It cannot override the database's profile assignment or identity.
        val grant = LiveDataCapabilityRegistry.grantForExactEcu(normalized, "KLINE_DIRECT")
        if (grant != null) {
            val grantedPrimary = grant.primaryTables.map { forTable(it) ?: return null }
            val grantedExtensions = grant.extensionTables.map { forTable(it) ?: return null }
            if (grantedPrimary.any { !hasCompleteCompiledLayout(it) } ||
                grantedExtensions.any { !hasCompleteCompiledLayout(it) } || mappedProfile !in grantedPrimary
            ) return null
            val orderedPrimary = listOf(mappedProfile) + grantedPrimary.filterNot {
                it.tableId.equals(mappedProfile.tableId, ignoreCase = true)
            }
            return EcuLiveDataCapability(
                ecuId = normalized,
                capabilityId = model.liveDataProfileId,
                primaryTables = orderedPrimary,
                extensionTables = grantedExtensions,
                verification = if (grant.hardwareVerified) ProfileVerification.VERIFIED else ProfileVerification.RECONSTRUCTED,
                notes = if (grant.hardwareVerified) {
                    "Database mapping ${model.liveDataProfileId}; exact-ID table grant is hardware-verified."
                } else {
                    "Database mapping ${model.liveDataProfileId}; additional exact-ID table grant is reconstructed, not hardware-verified."
                }
            )
        }

        return EcuLiveDataCapability(
            ecuId = normalized,
            capabilityId = model.liveDataProfileId,
            primaryTables = listOf(mappedProfile),
            extensionTables = emptyList(),
            verification = ProfileVerification.RECONSTRUCTED,
            notes = "Database mapping ${model.liveDataProfileId} (${evidence}); read-only trial, not hardware-verified."
        )
    }

    /**
     * Structural completeness gate: a table must have a valid 5-byte request
     * checksum, a usable payload boundary, and fully in-range field offsets.
     * Hardware verification is deliberately not required for read-only trials.
     */
    private fun hasCompleteCompiledLayout(profile: LiveTableProfile): Boolean {
        if (profile.request.size != 5 || !HondaChecksum.validatePacket(profile.request)) return false
        if ((profile.request[0].toInt() and 0xFF) != 0x72 ||
            (profile.request[1].toInt() and 0xFF) != profile.request.size ||
            (profile.request[2].toInt() and 0xFF) != 0x71 ||
            (profile.request[3].toInt() and 0xFF) != profile.tableId.toIntOrNull(16)
        ) return false
        if (profile.payloadStart < 4 || profile.minPayload <= 0 || profile.fields.isEmpty()) return false
        return profile.fields.all { field ->
            field.offset >= 0 && field.length > 0 &&
                field.offset + field.length <= profile.minPayload &&
                field.alternateOffsets.all { it >= 0 && it + field.length <= profile.minPayload }
        }
    }

    private fun normalizeEcuId(value: String?): String? = value
        ?.uppercase(Locale.ROOT)
        ?.filter { it in '0'..'9' || it in 'A'..'F' }
        ?.takeIf { it.matches(Regex("^(?:[0-9A-F]{10}|[0-9A-F]{12})$")) }

    fun forTable(tableId: String): LiveTableProfile? = tables.firstOrNull { it.tableId.equals(tableId, true) }
}
