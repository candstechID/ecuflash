package com.candstech.engine.core.evidence

import com.candstech.engine.data.map.MiniJson
import java.io.File
import java.io.FileOutputStream
import java.nio.file.Files
import java.security.MessageDigest

/** Result of persisting one immutable raw capture. */
data class EvidenceArchiveWriteResult(val saved: Boolean, val path: String?, val errors: List<String>)
data class EvidenceArchiveReadResult(val records: List<ProtocolEvidenceRecord>, val errors: List<String>)

/**
 * App-private, durable evidence store. Each capture is an immutable JSON file;
 * a failed write never replaces an existing capture with the same evidenceId.
 * Construct with context.filesDir/protocol-evidence from the Android app layer.
 */
class ProtocolEvidenceArchive(private val directory: File) {
    @Synchronized
    fun save(record: ProtocolEvidenceRecord): EvidenceArchiveWriteResult {
        val validation = ProtocolEvidenceValidator.validate(record)
        if (!validation.acceptedForArchive) return EvidenceArchiveWriteResult(false, null, validation.errors)
        if (!directory.exists() && !directory.mkdirs()) {
            return EvidenceArchiveWriteResult(false, null, listOf("Folder arsip tidak dapat dibuat"))
        }
        if (!directory.isDirectory || !directory.canWrite()) {
            return EvidenceArchiveWriteResult(false, null, listOf("Folder arsip tidak dapat ditulis"))
        }
        val target = File(directory, "${sha256(record.evidenceId)}.json")
        if (target.exists()) return EvidenceArchiveWriteResult(false, target.absolutePath, listOf("evidenceId sudah ada; arsip bersifat immutable"))
        val temp = File(directory, ".${target.name}.${System.nanoTime()}.tmp")
        return try {
            FileOutputStream(temp).use { stream ->
                stream.write(ProtocolEvidenceJsonCodec.encode(record).toByteArray(Charsets.UTF_8))
                stream.fd.sync()
            }
            // Files.move without REPLACE_EXISTING rejects a concurrent duplicate ID.
            Files.move(temp.toPath(), target.toPath())
            EvidenceArchiveWriteResult(true, target.absolutePath, emptyList())
        } catch (error: Exception) {
            temp.delete()
            EvidenceArchiveWriteResult(false, null, listOf(error.message ?: "Gagal menyimpan evidence"))
        }
    }

    @Synchronized
    fun readAll(): EvidenceArchiveReadResult {
        if (!directory.exists()) return EvidenceArchiveReadResult(emptyList(), emptyList())
        if (!directory.isDirectory) return EvidenceArchiveReadResult(emptyList(), listOf("Lokasi arsip bukan direktori"))
        val records = mutableListOf<ProtocolEvidenceRecord>()
        val errors = mutableListOf<String>()
        directory.listFiles { file -> file.isFile && file.extension.equals("json", true) }
            .orEmpty().sortedBy { it.name }.forEach { file ->
                try {
                    val record = ProtocolEvidenceJsonCodec.decode(file.readText(Charsets.UTF_8))
                    val validation = ProtocolEvidenceValidator.validate(record)
                    if (!validation.acceptedForArchive) errors += "${file.name}: ${validation.errors.joinToString()}"
                    else records += record
                } catch (error: Exception) {
                    errors += "${file.name}: ${error.message ?: "format evidence rusak"}"
                }
            }
        return EvidenceArchiveReadResult(records.sortedBy { it.capturedAtEpochMs }, errors)
    }

    @Synchronized
    fun find(evidenceId: String): ProtocolEvidenceRecord? {
        if (evidenceId.isBlank()) return null
        val file = File(directory, "${sha256(evidenceId)}.json")
        if (!file.isFile) return null
        return runCatching { ProtocolEvidenceJsonCodec.decode(file.readText(Charsets.UTF_8)) }
            .getOrNull()?.takeIf { it.evidenceId == evidenceId }
    }

    @Synchronized
    fun delete(evidenceId: String): Boolean {
        if (evidenceId.isBlank()) return false
        val file = File(directory, "${sha256(evidenceId)}.json")
        return !file.exists() || file.delete()
    }

    /** Full JSON export suitable for a user-initiated share/save action. */
    fun exportJson(): String {
        val result = readAll()
        require(result.errors.isEmpty()) { "Arsip mengandung file rusak: ${result.errors.joinToString()}" }
        return "{\"schemaVersion\":1,\"records\":[${result.records.joinToString(",") { ProtocolEvidenceJsonCodec.encode(it) }}]}"
    }

    private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
}

/** Minimal explicit codec; it uses the project's strict JSON parser for reads. */
internal object ProtocolEvidenceJsonCodec {
    fun encode(record: ProtocolEvidenceRecord): String {
        fun q(value: String?): String = if (value == null) "null" else "\"${escape(value)}\""
        fun n(value: Number?): String = value?.toString() ?: "null"
        return buildString {
            append('{')
            append("\"evidenceId\":${q(record.evidenceId)},")
            append("\"capturedAtEpochMs\":${record.capturedAtEpochMs},")
            append("\"candidateId\":${q(record.candidateId)},")
            append("\"exactEcuResponseId\":${q(record.exactEcuResponseId)},")
            append("\"ecuPartNumber\":${q(record.ecuPartNumber)},")
            append("\"adapterModel\":${q(record.adapterModel)},")
            append("\"adapterFirmware\":${q(record.adapterFirmware)},")
            append("\"transport\":${q(record.transport.name)},")
            append("\"baudRate\":${n(record.baudRate)},")
            append("\"canBitrate\":${n(record.canBitrate)},")
            append("\"operation\":${q(record.operation.name)},")
            append("\"direction\":${q(record.direction.name)},")
            append("\"rawHex\":${q(record.rawHex)},")
            append("\"elapsedMs\":${n(record.elapsedMs)},")
            append("\"ignitionState\":${q(record.ignitionState)},")
            append("\"engineState\":${q(record.engineState)},")
            append("\"testRunId\":${q(record.testRunId)},")
            append("\"repetitionIndex\":${record.repetitionIndex},")
            append("\"operatorNote\":${q(record.operatorNote)},")
            append("\"sha256Bytes\":${q(record.sha256)}")
            append('}')
        }
    }

    fun decode(json: String): ProtocolEvidenceRecord {
        val map = MiniJson.parse(json) as? Map<*, *> ?: error("Root evidence harus object")
        fun string(key: String): String = map[key] as? String ?: error("Field $key harus string")
        fun nullableString(key: String): String? = map[key] as? String
        fun int(key: String): Int = (map[key] as? Number)?.toInt() ?: error("Field $key harus integer")
        fun long(key: String): Long = (map[key] as? Number)?.toLong() ?: error("Field $key harus integer")
        fun nullableInt(key: String): Int? = (map[key] as? Number)?.toInt()
        fun nullableLong(key: String): Long? = (map[key] as? Number)?.toLong()
        val record = ProtocolEvidenceRecord(
            evidenceId = string("evidenceId"),
            capturedAtEpochMs = long("capturedAtEpochMs"),
            candidateId = nullableString("candidateId"),
            exactEcuResponseId = nullableString("exactEcuResponseId"),
            ecuPartNumber = nullableString("ecuPartNumber"),
            adapterModel = string("adapterModel"),
            adapterFirmware = nullableString("adapterFirmware"),
            transport = EvidenceTransport.valueOf(string("transport")),
            baudRate = nullableInt("baudRate"),
            canBitrate = nullableInt("canBitrate"),
            operation = EvidenceOperation.valueOf(string("operation")),
            direction = EvidenceDirection.valueOf(string("direction")),
            rawHex = string("rawHex"),
            elapsedMs = nullableLong("elapsedMs"),
            ignitionState = nullableString("ignitionState"),
            engineState = nullableString("engineState"),
            testRunId = string("testRunId"),
            repetitionIndex = int("repetitionIndex"),
            operatorNote = nullableString("operatorNote") ?: ""
        )
        val storedHash = nullableString("sha256Bytes")
        require(storedHash == record.sha256) { "SHA-256 evidence tidak cocok" }
        return record
    }

    private fun escape(value: String): String = buildString(value.length + 8) {
        value.forEach { c ->
            when (c) {
                '\\' -> append("\\\\")
                '"' -> append("\\\"")
                '\b' -> append("\\b")
                '\u000C' -> append("\\f")
                '\n' -> append("\\n")
                '\r' -> append("\\r")
                '\t' -> append("\\t")
                else -> if (c < ' ') append("\\u%04x".format(c.code)) else append(c)
            }
        }
    }
}
