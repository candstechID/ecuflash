package com.candstech.engine.core.evidence

import java.security.MessageDigest
import java.util.Locale

/** Physical transports are intentionally not interchangeable. */
enum class EvidenceTransport {
    KLINE_DIRECT_FTDI,
    KLINE_ELM327,
    CAN_ELM327
}

enum class EvidenceDirection { TX, RX }
enum class EvidenceOperation { IDENTIFICATION, LIVE_DATA, DTC_READ, DTC_CLEAR, BIN_READ, BIN_WRITE, UNKNOWN }
enum class EvidenceReviewStatus { RAW_CAPTURE, REPEATABLE_CAPTURE, REVIEWED, HARDWARE_VERIFIED, REJECTED }

data class ProtocolEvidenceRecord(
    val evidenceId: String,
    val capturedAtEpochMs: Long,
    val candidateId: String?,
    val exactEcuResponseId: String?,
    val ecuPartNumber: String?,
    val adapterModel: String,
    val adapterFirmware: String?,
    val transport: EvidenceTransport,
    val baudRate: Int?,
    val canBitrate: Int?,
    val operation: EvidenceOperation,
    val direction: EvidenceDirection,
    val rawHex: String,
    val elapsedMs: Long?,
    val ignitionState: String?,
    val engineState: String?,
    val testRunId: String,
    val repetitionIndex: Int,
    val operatorNote: String = ""
) {
    /** Separators are removed only; invalid non-hex characters are never silently normalized away. */
    val normalizedRawHex: String get() = rawHex.uppercase(Locale.ROOT).replace(Regex("[\\s:-]"), "")
    val sha256: String get() {
        val hex = normalizedRawHex
        if (hex.isEmpty() || hex.length % 2 != 0 || !hex.all { it.digitToIntOrNull(16) != null }) return ""
        val bytes = hex.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
        return MessageDigest.getInstance("SHA-256").digest(bytes)
            .joinToString("") { "%02x".format(it) }
    }
}

data class EvidenceValidation(
    val acceptedForArchive: Boolean,
    val repeatable: Boolean,
    val errors: List<String>,
    val warnings: List<String>
)

object ProtocolEvidenceValidator {
    private val hexPattern = Regex("^(?:[0-9A-Fa-f]{2}[\\s:-]*)+$")

    fun validate(record: ProtocolEvidenceRecord): EvidenceValidation {
        val errors = mutableListOf<String>()
        val warnings = mutableListOf<String>()
        if (record.evidenceId.isBlank()) errors += "evidenceId kosong"
        if (record.capturedAtEpochMs <= 0L) errors += "timestamp tidak valid"
        if (record.adapterModel.isBlank()) errors += "model adapter wajib dicatat"
        if (record.testRunId.isBlank()) errors += "testRunId wajib dicatat"
        if (record.repetitionIndex < 1) errors += "repetitionIndex minimal 1"
        if (record.rawHex.isBlank() || !hexPattern.matches(record.rawHex.trim())) {
            errors += "rawHex harus berupa byte heksadesimal berpasangan"
        }
        if (record.elapsedMs != null && record.elapsedMs < 0) errors += "elapsedMs tidak boleh negatif"
        if (record.transport == EvidenceTransport.CAN_ELM327) {
            if (record.canBitrate == null || record.canBitrate <= 0) errors += "CAN bitrate wajib dicatat"
            if (record.baudRate != null) warnings += "baudRate serial bukan CAN bitrate; jangan dipakai sebagai pengganti"
        } else {
            if (record.baudRate == null || record.baudRate <= 0) errors += "baudRate wajib dicatat untuk K-Line"
            if (record.canBitrate != null) warnings += "canBitrate diabaikan untuk transport K-Line"
        }
        if (record.direction == EvidenceDirection.RX && record.normalizedRawHex.isEmpty()) {
            errors += "response RX kosong"
        }
        if (record.exactEcuResponseId.isNullOrBlank()) {
            warnings += "ECU response ID belum teridentifikasi; bukti tidak dapat mengaktifkan profil ECU spesifik"
        }
        if (record.candidateId.isNullOrBlank() && record.exactEcuResponseId.isNullOrBlank() && record.ecuPartNumber.isNullOrBlank()) {
            warnings += "tidak ada pengikat identitas ECU; capture hanya menjadi arsip transport"
        }
        return EvidenceValidation(errors.isEmpty(), false, errors, warnings)
    }

    /**
     * Repeatability compares the complete test context, not only payload bytes.
     * Three identical captures remain repeatability evidence, never hardware approval.
     */
    fun evaluateRepeatability(records: List<ProtocolEvidenceRecord>): EvidenceValidation {
        if (records.isEmpty()) return EvidenceValidation(false, false, listOf("tidak ada capture"), emptyList())
        val base = records.map { validate(it) }
        val errors = base.flatMap { it.errors }.distinct().toMutableList()
        val warnings = base.flatMap { it.warnings }.distinct().toMutableList()
        val first = records.first()
        if (records.any {
                it.transport != first.transport || it.operation != first.operation ||
                    it.direction != first.direction || it.exactEcuResponseId != first.exactEcuResponseId ||
                    it.candidateId != first.candidateId || it.ecuPartNumber != first.ecuPartNumber ||
                    it.adapterModel != first.adapterModel || it.adapterFirmware != first.adapterFirmware ||
                    it.baudRate != first.baudRate || it.canBitrate != first.canBitrate ||
                    it.ignitionState != first.ignitionState || it.engineState != first.engineState ||
                    it.testRunId != first.testRunId || it.sha256 != first.sha256
            }) {
            errors += "capture berbeda pada identitas, transport, adapter, kondisi uji, operasi, arah, atau payload"
        }
        if (records.map { it.repetitionIndex }.distinct().size != records.size) {
            errors += "repetitionIndex duplikat"
        }
        val repeatable = errors.isEmpty() && records.size >= 3
        if (records.size < 3) warnings += "minimal 3 pengulangan identik diperlukan untuk status repeatable"
        return EvidenceValidation(errors.isEmpty(), repeatable, errors, warnings.distinct())
    }
}

data class DiagnosticProfileProposal(
    val exactEcuResponseId: String,
    val transport: EvidenceTransport,
    val operation: EvidenceOperation,
    val requestHex: String,
    val expectedPositiveResponseHex: String,
    val allowlistedExactEcuIds: Set<String>,
    val evidenceStatus: EvidenceReviewStatus,
    val reviewerApproved: Boolean,
    val evidenceIds: Set<String> = emptySet(),
    val reviewerId: String? = null
)

data class ProfileActivationDecision(
    val enabled: Boolean,
    val reason: String
)

/** Fail-closed resolver; an approval flag without matching raw TX/RX evidence is insufficient. */
object DiagnosticProfileActivationResolver {
    private val hexPattern = Regex("^(?:[0-9A-Fa-f]{2}[\\s:-]*)+$")
    private fun normalizeHex(value: String): String = value.uppercase(Locale.ROOT).replace(Regex("[\\s:-]"), "")
    private fun validHex(value: String): Boolean = hexPattern.matches(value.trim())

    fun resolve(
        proposal: DiagnosticProfileProposal,
        activeEcuResponseId: String?,
        activeTransport: EvidenceTransport,
        evidenceRecords: List<ProtocolEvidenceRecord> = emptyList()
    ): ProfileActivationDecision {
        if (activeEcuResponseId.isNullOrBlank()) return ProfileActivationDecision(false, "ECU response ID aktual belum tersedia")
        if (proposal.exactEcuResponseId.isBlank() || !proposal.exactEcuResponseId.equals(activeEcuResponseId, ignoreCase = true)) {
            return ProfileActivationDecision(false, "proposal tidak cocok dengan ECU response ID aktif")
        }
        if (!proposal.allowlistedExactEcuIds.any { it.equals(activeEcuResponseId, ignoreCase = true) }) {
            return ProfileActivationDecision(false, "ECU tidak ada dalam exact allowlist profil")
        }
        if (proposal.transport != activeTransport) return ProfileActivationDecision(false, "transport berbeda; engine komunikasi tidak boleh dipertukarkan")
        if (proposal.operation !in setOf(EvidenceOperation.IDENTIFICATION, EvidenceOperation.LIVE_DATA, EvidenceOperation.DTC_READ)) {
            return ProfileActivationDecision(false, "operasi ini memerlukan alur keselamatan terpisah dan tidak diaktifkan oleh resolver diagnostik")
        }
        if (!validHex(proposal.requestHex) || !validHex(proposal.expectedPositiveResponseHex)) {
            return ProfileActivationDecision(false, "request dan positive response harus berupa byte heksadesimal valid")
        }
        if (proposal.evidenceStatus != EvidenceReviewStatus.HARDWARE_VERIFIED || !proposal.reviewerApproved || proposal.reviewerId.isNullOrBlank()) {
            return ProfileActivationDecision(false, "bukti belum HARDWARE_VERIFIED atau identitas reviewer tidak tersedia")
        }
        if (proposal.evidenceIds.size < 2) {
            return ProfileActivationDecision(false, "minimal satu capture TX dan satu capture RX harus ditautkan ke proposal")
        }
        val selected = evidenceRecords.filter { it.evidenceId in proposal.evidenceIds }
        if (selected.map { it.evidenceId }.toSet() != proposal.evidenceIds) {
            return ProfileActivationDecision(false, "sebagian evidenceId proposal tidak ditemukan")
        }
        if (selected.any { !ProtocolEvidenceValidator.validate(it).acceptedForArchive }) {
            return ProfileActivationDecision(false, "terdapat capture mentah yang tidak lolos validasi")
        }
        if (selected.any {
                it.transport != proposal.transport || it.operation != proposal.operation ||
                    !it.exactEcuResponseId.equals(proposal.exactEcuResponseId, ignoreCase = true)
            }) {
            return ProfileActivationDecision(false, "capture tidak cocok dengan ECU, transport, atau operasi proposal")
        }
        val tx = selected.filter { it.direction == EvidenceDirection.TX }
        val rx = selected.filter { it.direction == EvidenceDirection.RX }
        if (tx.none { it.normalizedRawHex == normalizeHex(proposal.requestHex) }) {
            return ProfileActivationDecision(false, "request proposal tidak ditemukan pada raw TX capture")
        }
        if (rx.none { it.normalizedRawHex == normalizeHex(proposal.expectedPositiveResponseHex) }) {
            return ProfileActivationDecision(false, "positive response proposal tidak ditemukan pada raw RX capture")
        }
        val runIds = selected.map { it.testRunId }.distinct()
        if (runIds.size != 1) return ProfileActivationDecision(false, "capture TX/RX harus berasal dari satu testRunId")
        return ProfileActivationDecision(true, "exact ECU, transport, allowlist, raw TX/RX evidence, dan review cocok")
    }
}
