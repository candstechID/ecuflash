package com.candstech.engine.core.comm

import com.candstech.engine.data.ecu.EcmModel
import java.util.Locale

/**
 * Interprets values that have already been decoded by Live Data Engine.
 * This class is intentionally read-only: it does not change decoding, scaling,
 * byte offsets, transport, ECU database, DTC, or RESET.
 *
 * Thresholds here are broad plausibility/operating bands, not ECU calibration
 * specifications. A value can be plausible without proving sensor calibration.
 * Parameters whose encoding or operating context is not known are deliberately
 * left without a diagnosis instead of being assigned a fabricated NORMAL/FAULT.
 */
object LiveSensorConditionEvaluator {
    fun evaluate(
        sensor: LiveSensor,
        value: Double?,
        state: LiveParameterState,
        model: EcmModel?,
        engineRpm: Double? = null
    ): String? {
        // DUMMY annotates the source; it never replaces the decoded numeric value.
        // Keep the annotation beside a received VALID/STALE sample only.
        if (value == null || !value.isFinite()) return null
        val origin = model?.sensorOrigins?.get(sensor.name)?.uppercase(Locale.ROOT)
        if (origin == "DUMMY" && state in setOf(LiveParameterState.VALID, LiveParameterState.STALE)) {
            return "DUMMY"
        }

        // Physical condition evaluation is limited to fresh valid samples.
        if (state != LiveParameterState.VALID) return null

        fun rangeFault(min: Double, max: Double): String =
            if (value < min || value > max) "FAULT" else "NORMAL"

        fun voltageRails(low: Double = 0.15, high: Double = 4.85): String = when {
            value < low -> "FAULT"
            value > high -> "FAULT"
            else -> "NORMAL"
        }

        fun position(max: Double = 127.5): String = when {
            value < 0.0 || value > max -> "FAULT"
            value <= 1.0 -> "CLOSED"
            value >= 78.0 -> "WIDE OPEN"
            else -> "PARTIAL"
        }

        return when (sensor) {
            // Engine/vehicle operating state.
            LiveSensor.RPM -> when {
                value < 0.0 || value > 20_000.0 -> "FAULT"
                value <= 0.0 -> "ENGINE OFF"
                else -> "RUN"
            }
            LiveSensor.SPEED -> when {
                value < 0.0 || value > 300.0 -> "FAULT"
                value <= 0.0 -> "STOPPED"
                else -> "MOVING"
            }

            // Temperature values are ECU-decoded °C, not voltage.
            LiveSensor.ECT -> when {
                value < -40.0 || value > 150.0 -> "FAULT"
                value <= 30.0 -> "COLD"
                value <= 100.0 -> "NORMAL"
                value <= 120.0 -> "HOT"
                else -> "OVERHEAT"
            }
            LiveSensor.IAT -> when {
                value < -40.0 || value > 100.0 -> "FAULT"
                value <= 10.0 -> "COLD"
                value <= 45.0 -> "NORMAL"
                else -> "HOT"
            }

            // 0–5 V analog sensor circuits. These bands detect obvious rail faults;
            // they do not validate a sensor's closed/open calibration.
            LiveSensor.TPS_VOLTAGE,
            LiveSensor.TP1_VOLTAGE,
            LiveSensor.TP2_VOLTAGE,
            LiveSensor.AP1_VOLTAGE,
            LiveSensor.AP2_VOLTAGE -> voltageRails()
            LiveSensor.ECT_VOLTAGE,
            LiveSensor.IAT_VOLTAGE -> voltageRails(high = 4.75)
            LiveSensor.MAP_VOLTAGE -> voltageRails(low = 0.25, high = 4.75)

            // Position channels describe position, not electrical health.
            LiveSensor.TPS_DEGREES,
            LiveSensor.TP1_DEGREES,
            LiveSensor.TP2_DEGREES,
            LiveSensor.AP1_DEGREES,
            LiveSensor.AP2_DEGREES -> position()
            LiveSensor.TPS_PERCENT -> when {
                value < 0.0 || value > 100.0 -> "FAULT"
                value <= 1.0 -> "CLOSED"
                value >= 95.0 -> "WIDE OPEN"
                else -> "PARTIAL"
            }
            LiveSensor.TPS_ADC -> when {
                value < 0.0 || value > 255.0 -> "FAULT"
                value <= 5.0 || value >= 250.0 -> "FAULT"
                else -> "NORMAL"
            }

            // MAP is interpreted only as a broad plausibility range. Low manifold
            // pressure while running can be normal at idle, so no idle/load diagnosis.
            LiveSensor.MAP -> when {
                value < 0.0 || value > 255.0 -> "FAULT"
                value < 10.0 || value > 150.0 -> "FAULT"
                engineRpm != null && engineRpm > 0.0 && value < 20.0 -> "LOW"
                else -> "NORMAL"
            }

            // Battery charging/supply voltage; operating mode affects exact limits.
            LiveSensor.BATTERY -> when {
                value < 0.0 || value > 20.0 -> "FAULT"
                value < 11.5 -> "LOW"
                value <= 15.0 -> "NORMAL"
                else -> "HIGH"
            }

            // Injector pulse width: zero can be fuel cut, so it is not automatically
            // a fault while RPM is present. Negative/out-of-range values are invalid.
            LiveSensor.INJECTOR -> when {
                value < 0.0 || value > 50.0 -> "FAULT"
                value == 0.0 && (engineRpm == null || engineRpm <= 0.0) -> "ENGINE OFF"
                value == 0.0 -> "NO PULSE"
                else -> "ACTIVE"
            }

            // One O2 sample cannot establish switching, warm-up, closed-loop state,
            // or sensor failure. AFR is not published by these ECU profiles; STF
            // encoding/semantics also need verified source evidence.
            LiveSensor.O2,
            LiveSensor.O2_RAW,
            LiveSensor.AFR,
            LiveSensor.STF -> null

            // A numeric ignition advance is highly dependent on RPM/load/temperature;
            // a universal NORMAL/FAULT band would be misleading.
            LiveSensor.IGNITION_ADVANCE -> if (value in -70.0..70.0) null else "FAULT"

            // These are opaque mode/status bytes in the reconstructed layout.
            // Their bit/value mapping has not been verified, so don't guess labels.
            LiveSensor.MODE,
            LiveSensor.COR,
            LiveSensor.GEAR_STATE,
            LiveSensor.FLAG_A,
            LiveSensor.FLAG_B,
            LiveSensor.GEAR_POSITION -> null
        }
    }
}
