package com.candstech.engine.data.ecu

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * Unverified Honda ECU master candidates.
 *
 * This registry is deliberately separate from [EcmDatabase]: candidate aliases,
 * architecture guesses and profile suggestions are never promoted to ECU response
 * IDs or diagnostic capabilities. It is a lookup/reconciliation layer only.
 */
data class HondaEcuCandidate(
    val candidateId: String,
    val generationGroupCandidate: String,
    val architectureKeyCandidate: String,
    val motor: String,
    val variant: String,
    val market: String,
    val productionYears: String,
    val partNumber: String,
    val userSuppliedEcuAlias: String?,
    val ecuResponseId: String?,
    val manufacturerCandidate: String,
    val mcuCandidate: String,
    val physicalProtocolCandidate: String,
    val liveDataProfileCandidate: String,
    val dtcProfileCandidate: String,
    val binProfileCandidate: String,
    val recordStatus: String,
    val diagnosticDispatchEnabled: Boolean,
    val binReadEnabled: Boolean,
    val binWriteEnabled: Boolean,
    val notes: String,
    val requiresPhysicalValidation: Boolean,
    val matchedDatabaseRecordIds: List<String>,
    val exactPartMatchCount: Int,
    val databaseMatchStatus: String,
    val responseIdEvidenceStatus: String
) {
    /** A hard safety invariant, even if a future asset is accidentally edited. */
    val canDispatchDiagnostics: Boolean
        get() = diagnosticDispatchEnabled && !requiresPhysicalValidation && recordStatus == "HARDWARE_VERIFIED"

    val canReadBin: Boolean
        get() = binReadEnabled && !requiresPhysicalValidation && recordStatus == "HARDWARE_VERIFIED"

    val canWriteBin: Boolean
        get() = binWriteEnabled && !requiresPhysicalValidation && recordStatus == "HARDWARE_VERIFIED"
}

enum class CandidatePartMatchStatus { NO_MATCH, UNIQUE_DATABASE_MATCH, AMBIGUOUS_DATABASE_MATCH }

data class HondaEcuCandidatePartMatch(
    val candidate: HondaEcuCandidate,
    val status: CandidatePartMatchStatus,
    val databaseRecords: List<EcmModel>
)

object HondaEcuCandidateRegistry {
    private const val ASSET_NAME = "honda_ecu_master_candidates.json"

    @Volatile
    private var cached: List<HondaEcuCandidate>? = null

    @Synchronized
    fun load(context: Context, forceReload: Boolean = false): List<HondaEcuCandidate> {
        if (!forceReload) cached?.let { return it }
        val raw = context.assets.open(ASSET_NAME).bufferedReader().use { it.readText() }
        val parsed = parse(raw)
        cached = parsed
        return parsed
    }

    /** Useful for deterministic tests and explicit database refreshes. */
    @Synchronized
    fun clearCache() {
        cached = null
    }

    /** Exact part-number matching only. ECU aliases are intentionally ignored. */
    fun matchByPartNumber(
        partNumber: String,
        database: List<EcmModel>,
        candidates: List<HondaEcuCandidate> = cached ?: emptyList()
    ): List<HondaEcuCandidatePartMatch> {
        val normalized = normalize(partNumber)
        if (normalized.isEmpty()) return emptyList()
        return candidates
            .filter { normalize(it.partNumber) == normalized }
            .map { candidate ->
                val records = database.filter { normalize(it.partNumber) == normalized }
                val status = when (records.size) {
                    0 -> CandidatePartMatchStatus.NO_MATCH
                    1 -> CandidatePartMatchStatus.UNIQUE_DATABASE_MATCH
                    else -> CandidatePartMatchStatus.AMBIGUOUS_DATABASE_MATCH
                }
                HondaEcuCandidatePartMatch(candidate, status, records)
            }
    }

    /**
     * ECU response ID matching is allowed only when a future candidate has an
     * independently populated response ID. A database reference ID copied into
     * matchedDatabaseEcuResponseIds is not treated as candidate ECU evidence.
     */
    fun matchByEcuResponseId(responseId: String): List<HondaEcuCandidate> {
        val normalized = normalize(responseId)
        if (normalized.isEmpty()) return emptyList()
        return (cached ?: emptyList()).filter {
            val candidateId = it.ecuResponseId
            !candidateId.isNullOrBlank() && normalize(candidateId) == normalized
        }
    }

    internal fun parse(json: String): List<HondaEcuCandidate> {
        val array = JSONArray(json)
        val result = ArrayList<HondaEcuCandidate>(array.length())
        val seenIds = mutableSetOf<String>()
        for (index in 0 until array.length()) {
            val item = array.getJSONObject(index)
            val id = item.optString("candidateId", "").trim()
            val part = item.optString("partNumber", "").trim()
            require(id.isNotEmpty()) { "candidateId kosong pada index $index" }
            require(part.isNotEmpty()) { "partNumber kosong pada kandidat $id" }
            require(seenIds.add(id)) { "candidateId duplikat: $id" }

            val responseId = item.nullableString("ecuResponseId")
            val diagnosticEnabled = item.optBoolean("diagnosticDispatchEnabled", false)
            val binReadEnabled = item.optBoolean("binReadEnabled", false)
            val binWriteEnabled = item.optBoolean("binWriteEnabled", false)
            val requiresValidation = item.optBoolean("requiresPhysicalValidation", true)
            val status = item.optString("recordStatus", "UNRESOLVED")
            // Never allow an unverified row to carry an active operation flag.
            require(!requiresValidation || (!diagnosticEnabled && !binReadEnabled && !binWriteEnabled)) {
                "Flag operasi aktif pada kandidat yang masih memerlukan validasi: $id"
            }
            require(responseId == null || responseId.isNotBlank()) {
                "ECU response ID kosong harus null pada kandidat $id"
            }

            result += HondaEcuCandidate(
                candidateId = id,
                generationGroupCandidate = item.optString("generationGroupCandidate", "UNKNOWN"),
                architectureKeyCandidate = item.optString("architectureKeyCandidate", "UNRESOLVED"),
                motor = item.optString("motor", ""),
                variant = item.optString("variant", ""),
                market = item.optString("market", ""),
                productionYears = item.optString("productionYears", ""),
                partNumber = part,
                userSuppliedEcuAlias = item.nullableString("userSuppliedEcuAlias"),
                ecuResponseId = responseId,
                manufacturerCandidate = item.optString("manufacturerCandidate", "UNRESOLVED"),
                mcuCandidate = item.optString("mcuCandidate", "UNRESOLVED"),
                physicalProtocolCandidate = item.optString("physicalProtocolCandidate", "UNRESOLVED"),
                liveDataProfileCandidate = item.optString("liveDataProfileCandidate", "UNASSIGNED"),
                dtcProfileCandidate = item.optString("dtcProfileCandidate", "UNASSIGNED"),
                binProfileCandidate = item.optString("binProfileCandidate", "UNASSIGNED"),
                recordStatus = status,
                diagnosticDispatchEnabled = diagnosticEnabled,
                binReadEnabled = binReadEnabled,
                binWriteEnabled = binWriteEnabled,
                notes = item.optString("notes", ""),
                requiresPhysicalValidation = requiresValidation,
                matchedDatabaseRecordIds = item.stringList("matchedDatabaseRecordIds"),
                exactPartMatchCount = item.optInt("exactPartMatchCount", 0).coerceAtLeast(0),
                databaseMatchStatus = item.optString("databaseMatchStatus", "NOT_RECONCILED"),
                responseIdEvidenceStatus = item.optString("responseIdEvidenceStatus", "UNRESOLVED")
            )
        }
        return result.toList()
    }

    private fun JSONObject.nullableString(key: String): String? {
        if (!has(key) || isNull(key)) return null
        return optString(key).trim().takeIf { it.isNotEmpty() }
    }

    private fun JSONObject.stringList(key: String): List<String> {
        val array = optJSONArray(key) ?: return emptyList()
        return buildList(array.length()) {
            for (i in 0 until array.length()) {
                val value = array.optString(i).trim()
                if (value.isNotEmpty()) add(value)
            }
        }
    }

    private fun normalize(value: String): String =
        value.uppercase(Locale.ROOT).filter { it.isLetterOrDigit() }
}
