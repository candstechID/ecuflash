# Live Sensor Condition Labels

- Show `DUMMY` only when the active ECU profile explicitly marks that sensor as DUMMY.
- For valid readings, show a simple condition label only when the active ECU profile has validated thresholds: `LOW`, `HIGH`, `NORMAL`, `COLD`, `WARM`, `HOT`, `OVERHEAT`, `IDLE`, `RUN`, `WARNING`, `FAULT`, and other direct operating states supported by the evaluator.
- Do not display `STUCK?`, `CONFIG NOT VERIFIED`, or `STATUS NOT MAPPED` in the sensor diagnosis list.
- Missing thresholds mean no condition suffix is shown. Never invent a threshold or borrow one from a different ECU family.
- Missing/invalid telemetry is shown as `NO DATA`; this is not a sensor fault diagnosis.
- A `FAULT` label is reserved for a validated sensor signal/condition rule. A generic missing frame or unsupported parameter is not a sensor fault.
- Numeric decoder formulas and decoded values are not modified by condition evaluation.
- DTC and RESET implementations are outside the scope of this change and must remain unchanged.
