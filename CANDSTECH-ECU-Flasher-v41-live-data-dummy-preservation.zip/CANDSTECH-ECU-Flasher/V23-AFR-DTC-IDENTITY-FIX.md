# CANDSTECH ECU Flasher v23 — AFR, DTC State, Verified Identity

## Changes

### Verified identity banner
- The K-Line identity banner now performs an exact database lookup using the ECU response ID.
- On a unique exact match it displays: `CANDSTECH: ECU TERVERIFIKASI — <ECU_ID> | <MODEL_CODE> | <MOTOR_NAME>`.
- Model code is taken from the matched database record ID prefix (for example `K59A-A11` -> `K59A`).
- The motorcycle display name is taken from the matched record; the year suffix and the K59A `LED` trim word are omitted for the compact banner.
- If the ECU ID is verified but no exact model record exists, the banner says `MODEL BELUM TERPETAKAN`; it does not guess a motorcycle.
- ELM327 OBD-II connection status is not mislabeled as a proprietary Honda ECU identity.

### AFR estimate
- The existing project approximation is retained exactly:
  `Est_AFR = 14.7 - ((O2_voltage - 0.45) * 3.0)`.
- It is a narrowband display estimate, not ECU-reported AFR and not a substitute for a wideband sensor.
- Calculation requires a valid O2 voltage in the estimator's accepted 0..1.0 V range and a proven running engine (`RPM > 0`).
- O2/STF remain unavailable in KOEO / engine-not-spinning state. The summary card now displays `KOEO` rather than presenting the raw inactive value as a live sensor voltage.
- A decoded value such as 3.726 V is outside the narrowband estimator range and therefore must not produce an AFR number. It needs raw-byte/scale verification before being treated as a physical O2 voltage.

### DTC status integrity
- Honda K-Line status rendering distinguishes `0 DTC`, `NO RESPONSE`, `FORMAT TIDAK DIKENALI`, and `NOT SCANNED`.
- The ELM327 OBD-II status renderer only reports `0 DTC` after a positive service marker and a complete all-zero DTC payload. Missing, truncated, or unparsed positive responses are not reported as zero codes.
- No unverified Honda proprietary DTC request has been enabled. DTC Clear remains outside this change.

## Validation and limitations
- Source archive integrity and JSON parsing are checked at packaging time.
- Full Android Gradle build, device installation, and physical ECU tests remain required.
- The K59A table layouts remain reconstructed unless separately supported by hardware captures. This patch does not upgrade their evidence status.
