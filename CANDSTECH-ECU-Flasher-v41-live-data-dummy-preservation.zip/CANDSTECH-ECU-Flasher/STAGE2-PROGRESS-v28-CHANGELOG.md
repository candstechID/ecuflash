# Stage 2 Progress v28 — Raw TX/RX Monitoring

## Changes
- Added ELM327 TX logging with the exact ASCII command bytes, including the terminating CR byte.
- Added ELM327 RX fragment logging with exact bytes received from the USB serial callback, before text/protocol parsing.
- Added per-command transaction IDs to associate ELM327 RX fragments and response summaries with their initiating TX.
- Added explicit statuses for complete response, partial response, empty timeout, partial timeout, TX failure, and stale RX bytes found before a new command.
- Serialized ELM327 commands with a coroutine Mutex so concurrent PID/DTC requests cannot clear or consume each other's RX data.
- Connected the shared communication sniffer TX/RX events to the existing on-screen log panel, covering the active K-Line transceiver and ELM327 route.

## Validation
- `Elm327Session.kt` passed an isolated Kotlin compile using minimal API stubs.
- Full Android Gradle build and device/ECU hardware test were not run in this environment; Gradle wrapper JAR/script and installed Gradle/Android SDK are unavailable.
- TX/RX logging records transport bytes only. It does not certify a protocol request as correct or mark any ECU profile hardware-verified.

## Safety
- v28 itself added monitoring only; K-Line DTC TX remained blocked by the hardware-verification gate. The explicit read-only K-Line DTC evidence probe is added in v29.
- Clear DTC remains locked.
- BIN write/flash remains locked.
