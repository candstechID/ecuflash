# Live Data DUMMY Value Preservation — v41

## Scope

This patch changes only the Live Data condition evaluator and its focused unit tests. It does not change ECU database assets, sensor decoding formulas, byte offsets, scaling, communication engines, DTC, or RESET.

## Required behavior

- A received and decoded numeric sample remains the value displayed by DIAGNOSA SENSOR.
- The existing UI formats the numeric sample first, then appends the evaluator's condition text. For an ECU/profile source marked `DUMMY`, a sample of `20` is therefore shown as `20 · DUMMY` (with the parameter's existing unit when applicable).
- `DUMMY` is source information, not a replacement numeric value and not a physical sensor fault diagnosis.
- A retained numeric sample marked `STALE` may continue to show its value with `DUMMY`.
- A missing/null response does not show a fabricated numeric value or a standalone `DUMMY` label; the existing UI's no-data/invalid-response state remains in control.
- Non-DUMMY valid samples continue through the existing condition rules.

## Validation

The focused `LiveSensorConditionEvaluatorTest` suite was compiled and executed with a local Kotlin/JVM test harness: 12 tests passed. This is not a full Gradle/Android build and does not replace testing against a physical ECU.
