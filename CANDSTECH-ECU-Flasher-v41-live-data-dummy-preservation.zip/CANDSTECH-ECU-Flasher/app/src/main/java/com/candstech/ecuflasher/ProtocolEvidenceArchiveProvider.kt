package com.candstech.ecuflasher

import android.content.Context
import com.candstech.engine.core.evidence.ProtocolEvidenceArchive
import java.io.File

/** App-layer factory for the private, persistent raw protocol evidence archive. */
object ProtocolEvidenceArchiveProvider {
    fun create(context: Context): ProtocolEvidenceArchive =
        ProtocolEvidenceArchive(File(context.applicationContext.filesDir, "protocol-evidence"))
}
