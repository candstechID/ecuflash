# Honda ECU Generation Mapping — Database Dispatch Audit

## Purpose

The ECU database is now the source of truth for model-to-generation, Live Data profile, and DTC profile selection. Kotlin runtime code reads the selected exact ECU record; it does not infer a profile from model name, displacement, manufacturer, or model year.

## Database fields added to all 489 records

- `generationGroup`: active group or `UNKNOWN`
- `generationCandidate`: optional candidate group when evidence is incomplete/conflicting
- `generationEvidence`: `VERIFIED`, `RECONSTRUCTED`, `REFERENCE`, `HYPOTHESIS`, `CONFLICT`, or `UNRESOLVED`
- `liveDataProfileId`: explicit table/profile key or `UNSUPPORTED`
- `dtcProfileId`: explicit DTC command/parser key or `UNSUPPORTED`
- `profileNotes`: reason and evidence limitation

## Active group assignments

Exact database records tied to the supplied reference grouping were assigned as Gen-1B, Gen-2, or Gen-3A. This includes CB150R-old records K15-903/K15-921 (Gen-1B), K59A-A11, the K81 family records, CBR150R K45 records, K1AA BeAT, K2F Scoopy, and K0J Genio records. K59A-A11 retains its prior exact-ID reconstructed Live Data capability; other group assignments use the reference table family and are not hardware-verified.

Gen-1A records are not activated because the exact BeAT KZL/Scoopy K16 identities in the supplied reference are not cleanly matched by the database; K16/KZL-like rows remain candidate-only where their stored identity or manufacturer conflicts. Candidate rows store table `0x10` and the Gen-1A DTC profile ID, but remain non-operational. Gen-1B is assigned to the database CB150R-old records K15-903/K15-921 using the supplied reference grouping; KZR-labelled Vario 125 rows conflict with their stored Shindengen manufacturer metadata and remain candidate-only. Older CBR250R records remain candidate-only pending exact ECU/protocol evidence.

160cc records are candidate Gen-3B only. The supplied reference says CAN-Bus, while multiple corresponding database records currently carry K-Line protocol metadata. They remain `UNKNOWN` with `CONFLICT` evidence; their candidate profile IDs record OBD PID `01 11` and DTC modes `03/07/0A/04`, but the runtime does not activate them. `HondaGenerationProfiles.canDtcCommands()` exposes the candidate command set for a future CAN transport. The current FTDI K-Line engine never sends CAN/OBD commands.

## Runtime dispatch

- `EcmDatabase` loads the new metadata into `EcmModel`.
- Live Data requires an EXACT ECU database identity and calls `HondaLiveDataProfiles.capabilityForModel()` using `liveDataProfileId` (table `0x10` or `0x17`).
- DTC requires an EXACT ECU database identity and calls `HondaGenerationProfiles.dtcRequests()` using `generationGroup` and `dtcProfileId`. It no longer falls back to a family-generic DTC command when the database record has no DTC profile.
- Gen-1A includes a Current fallback request `71/72`; it is attempted only if the primary Current request did not yield a valid response.
- The DTC parser accepts Current `71/74`, Gen-1A fallback `71/72`, and History `71/73`; it still validates frame length and checksum and separates Current from History.
- Clear DTC remains locked. A positive ACK alone is not treated as proof of clearing.
- CAN-Bus Gen-3B is not transmitted by the current FTDI K-Line engine.

## Checksum discrepancy in supplied command example

The screenshot lists Current `72 05 71 74 A0`, History `72 05 71 73 A1`, and Gen-1A fallback `72 05 71 72 A2`. These final bytes do not match the current project's documented additive two's-complement checksum in `HondaFrameCodec`. The code therefore generates requests using that codec: Current `A4`, History `A5`, fallback `A6`. The Clear candidate `72 05 72 60 B7` does match the same checksum arithmetic, but Clear remains disabled. If a raw ECU capture proves the A0/A1/A2 convention, the profile must be revised from that capture rather than guessed.

## Verification limits

- Database JSON syntax and record count are checked.
- Source-level tests were added for generation DTC command selection and fallback parsing. They have not been run.
- No Gradle build was run.
- No APK was built.
- No physical ECU DTC request/response was tested; the new K-Line DTC commands remain reference-level until hardware capture confirms them.

## v17 database partition update

The combined catalog is now partitioned into `motor_catalog.json` (396 motor/variant identities), `ecu_identity_catalog.json` (489 ECU identities linked by `motorId`), and `generation_mapping.json` (489 generation/profile assignments keyed by `recordId`). `generation_groups.json` defines the five family taxonomy entries. `live_data_profile_registry.json` and `dtc_profile_registry.json` separate profile identifiers, transport and evidence status. `EcmDatabase` joins the three identity/mapping partitions by stable IDs. If a mapping row is missing, the runtime fails closed to `UNKNOWN` / `UNSUPPORTED` rather than inheriting another ECU's profile.

The partition is a normalized mapping of the existing evidence, not a claim that all 489 ECUs are protocol-supported. Current active groups remain 24 records; unresolved and conflicting records remain inactive.
