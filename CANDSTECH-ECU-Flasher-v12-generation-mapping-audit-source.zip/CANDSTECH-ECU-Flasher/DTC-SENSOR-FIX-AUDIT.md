# CANDSTECH ECU Flasher — incremental sensor and DTC audit

## Applied source corrections

1. TPS percentage retains the prior ADC-derived display (`raw * 100 / 256`) for compatibility with the user's previously observed ADC=24 / approximately 9.4% result. TPS ADC count, voltage, and TPS angle remain separate fields. The angle-based percentage proposal was not sufficiently validated for this ECU.
2. Restored the reconstructed Honda live-data catalogue from the v9 baseline: primary tables 0x17/0x13/0x11/0x10 and extension tables 0x16/0x20/0xD1. O2/STF are decoded only from table 0x20; Gear bytes remain reconstructed and gear-number decoding is not invented.
3. DTC query list now sends only the current-DTC 0x74/0x01 request. The prior 0x71/0x20 request is a Live Data table request, and 0x00/0x00 is not a DTC read request; neither is used as a DTC fallback.
4. DTC response parsing now validates the reconstructed page structure, service (0x74 current / 0x73 history), page, reserved byte, length and checksum before interpreting code pairs. Unknown code pairs are retained as raw Honda codes.
5. If a response frame arrives but fails DTC structure validation, the result is now `UNRECOGNIZED` with raw hex, not `NO_RESPONSE`.

## Not yet completed / not claimed

- A separate History DTC query, state flow, and UI panel are not yet implemented. The parser recognizes service 0x73 for the later history path, but current UI scan reads current DTC only.
- Clear DTC remains locked in the UI. No clear command is authorized by this patch.
- Table layouts and DTC page format remain RECONSTRUCTED, not hardware-verified on the user's K59A-A11 ECU.
- No Gradle build, unit-test execution, adapter test, or physical ECU test was run. The test source was updated only; compile/runtime success is not claimed.
