# Honda ECU Generation Mapping Audit

## Scope
Initial mapping is limited to Indonesian-market models already present in `ecuengine/src/main/assets/ecm_database.json`, prioritising BeAT, Vario, Scoopy, Supra, Revo, PCX, and CBR. The source database remains unchanged in this audit pass.

## Reference groups extracted from the supplied reference images

| Reference group | Transport | Reference Live Data | Connector note | Evidence level |
|---|---|---|---|---|
| Gen-1 | K-Line, 10,400 bps | table `0x10` | 4-pin red | Reference image only |
| Gen-2 | K-Line, 10,400 bps | table `0x17` | 4-pin red | Reference image only |
| Gen-3A | K-Line, 10,400 bps | table `0x17` | 6-pin red | Reference image only |
| Gen-3B | CAN, 500 kbps | OBD-II standard PID | OBD-II | Reference image only |

These labels are retained as reference classifications, not yet asserted as verified compatibility for every database record. In particular, table ID `0x17` alone cannot distinguish Gen-2 from Gen-3A. A generation assignment requires matching ECU identity and communication evidence (initialisation, request/response framing, connector/transport, and supported tables).

## Exact Vario 150 identities that must not be merged

| Database ID | ECU ID | Part number | Database description | Manufacturer / MCU | Status |
|---|---|---|---|---|---|
| K59A-A11 | `0101C40F01` | `30400-K59A-A11` | VARIO 150 LED (2016-2017) | Shindengen / R8C | Exact identity used in prior physical ECU identification; Live Data layout is reconstructed, not hardware-verified |
| K59F-A01 | `0102450F01` | `30400-K59F-A01` | VARIO 150 LED (2018) | Shindengen / V850 | Identity in database; generation/profile not established here |
| K59J-A71 | `0103060F01` | `30400-K59J-A71` | VARIO 150 SMARTKEY (2018-2019) | Shindengen / V850 | Identity in database; generation/profile not established here |
| K59J-A711 | `0103060F11` | `30400-K59J-A711` | VARIO 150 (K59J-A711) | Shindengen / V850 | Separate ECU ID; do not merge with K59J-A71 |

The user identifies the 2015 Vario 150 model family as K59A. Treat K59A as the model-family alias for that application, but do not rewrite the exact ECU ID or part number from a detected ECU. The database currently contains an inconsistent year annotation for K59A-A11 (record year `2019` while the description says `2016-2017`); it is intentionally not silently corrected in this pass.

A separate reference-image entry that appears as `38770-K59-A11` / Keihin conflicts with the exact project record `30400-K59A-A11` / Shindengen. They remain separate identities until a matching ECU ID or authoritative part-number evidence resolves the discrepancy.

## Runtime safety change in this source revision

`HondaEcuProfiles.forFamily(UNKNOWN)` now returns an empty, non-operational profile. The generic baseline remains available only as an explicit profile and for the dedicated baseline identification probe path. Unknown family selection no longer inherits generic DTC read, DTC clear, or Live Data requests.

## Not yet classified

No generation has been assigned to the remaining ECU IDs solely from model year, displacement, manufacturer, MCU, or table number. The 489-record database has no verified generation/protocol field, and the current source has only one exact-ID Live Data capability entry (`0101C40F01`). More exact image rows and ECU response evidence are required before safely populating Gen-1 / Gen-2 / Gen-3A / Gen-3B assignments.

## Verification limits

- No APK/Gradle build was run.
- No ECU hardware test was run.
- Existing Live Data table definitions remain reconstructed; this audit does not promote them to hardware-verified.
- No DTC or ECU WRITE protocol was changed.
