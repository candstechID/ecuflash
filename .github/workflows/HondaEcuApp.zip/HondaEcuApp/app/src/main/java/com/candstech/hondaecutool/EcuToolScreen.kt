package com.candstech.hondaecutool

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun EcuToolScreen(
    isConnected: Boolean,
    logText: String,
    hexText: String,
    onScanClick: () -> Unit,
    onReadEepromClick: () -> Unit,
    onWriteEepromClick: () -> Unit,
    onValidateChecksumClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "CANDS TECH ECU",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Honda EEPROM & K-Line Flasher",
                    color = Color(0xFFD4FF00),
                    fontSize = 12.sp
                )
            }
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (isConnected) Color(0xFF00C853) else Color(0xFFE10600)
            ) {
                Text(
                    text = if (isConnected) "CONNECTED" else "DISCONNECTED",
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Action Buttons Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = onScanClick,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF333333)),
                modifier = Modifier.weight(1.8f)
            ) {
                Text("Scan USB", fontSize = 11.sp)
            }
            Button(
                onClick = onReadEepromClick,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE10600)),
                modifier = Modifier.weight(2.2f)
            ) {
                Text("Read EEPROM", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Button(
                onClick = onValidateChecksumClick,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D47A1)),
                modifier = Modifier.weight(2f)
            ) {
                Text("Checksum", fontSize = 11.sp)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = onWriteEepromClick,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB71C1C)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Write / Flash EEPROM ke ECU", fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Hex Viewer
        Text(
            text = "LIVE MEMORY HEX DUMP",
            color = Color(0xFFD4FF00),
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(4.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp)
                .background(Color(0xFF141414), RoundedCornerShape(6.dp))
                .border(1.dp, Color(0xFF333333), RoundedCornerShape(6.dp))
                .padding(8.dp)
        ) {
            LazyColumn {
                item {
                    Text(
                        text = hexText,
                        color = Color(0xFF00E676),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Terminal Log
        Text(
            text = "K-LINE TERMINAL LOG",
            color = Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(4.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(Color(0xFF141414), RoundedCornerShape(6.dp))
                .border(1.dp, Color(0xFF333333), RoundedCornerShape(6.dp))
                .padding(8.dp)
        ) {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                item {
                    Text(
                        text = logText,
                        color = Color.LightGray,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}
