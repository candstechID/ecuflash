package com.candstech.engine.core.storage

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CandsTechStorageTest {

    @Test
    fun sanitizesVehicleNamesForFileSystemUse() {
        assertEquals("Honda_Vario", CandsTechStorage.sanitizeName("Honda Vario (160)"))
        assertEquals("ECU", CandsTechStorage.sanitizeName("   "))
        assertEquals("A_B_C", CandsTechStorage.sanitizeName("A/B:C"))
    }

    @Test
    fun buildsBackupNameWithIdentityAndDateSuffix() {
        val name = CandsTechStorage.buildBackupFileName("Honda Beat", "1234567890")
        assertTrue(name.startsWith("Honda_Beat_1234567890_Backup_"))
        assertTrue(name.endsWith(".bin"))
    }

    @Test
    fun buildsMapAndExportNamesWithExpectedExtensions() {
        assertTrue(CandsTechStorage.buildMapFileName("Vario 160").endsWith(".map"))
        assertTrue(CandsTechStorage.buildExportFileName("log.txt").startsWith("log_Export_"))
        assertTrue(CandsTechStorage.buildExportFileName("log.txt").endsWith(".txt"))
    }
}
