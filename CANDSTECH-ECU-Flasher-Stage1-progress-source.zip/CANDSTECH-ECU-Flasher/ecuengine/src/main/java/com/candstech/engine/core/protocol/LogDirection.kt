package com.candstech.engine.core.protocol

enum class LogDirection {
    TX,
    RX,
    SYS,
    ERR
}
