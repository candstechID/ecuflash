package com.candstech.engine.core.protocol

enum class CommEventCategory {
    ALL,
    ERROR,
    FTDI,
    KLINE,
    PROTOCOL,
    RX,
    SYSTEM,
    TX,
    USB
}
