package com.candstech.engine.core.protocol

enum class IgnitionState {
    UNKNOWN,
    CHECKING,
    ON_DETECTED,
    LINK_LOST,
    OFF_OR_DISCONNECTED
}
