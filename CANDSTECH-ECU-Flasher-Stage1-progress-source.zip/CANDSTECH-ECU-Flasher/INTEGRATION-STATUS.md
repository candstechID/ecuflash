# CANDSTECH ECU Flasher — integration status

## Work completed in this source pass

- Routed the app's **SCAN DTC** action through `HondaProtocolEngine.readDtcs()` rather than the legacy `UsbSerialDevice` path. The result UI now distinguishes valid empty response, parsed codes, no response, and unrecognized payload.
- Disabled the UI actions for **CLEAR DTC** and **RESET TP** during Stage 1. They now report that the operation is gated instead of sending write/reset requests through the legacy serial path.
- Replaced remaining user-facing `REVCORE` labels in the app connection status and engine log headers with `CANDSTECH`; source attribution and license documents remain intact.

- Integrated the 53 production Kotlin/Java source files and 19 unit-test files from the supplied working-baseline project into the dedicated `:ecuengine` module.
- Renamed internal package namespace from `com.revcore.android` to `com.candstech.engine`; moved source and test paths accordingly.
- Renamed the storage source file/class to CANDSTECH naming.
- Updated Gradle module references to `:ecuengine`.
- Replaced the three-record synthetic demonstration ECM asset with the 489-record vehicle database from the supplied source archive. The JSON records were copied without record-level edits; their verification flags and caveats must remain visible to callers.
- Kept third-party attribution and license notices as separate documentation. Original source provenance is retained there; no third-party attribution was removed.
- Kept the app's existing ELM327 AT-command session separate from the raw USB serial/K-Line engine.

## Existing integration boundary

- The app UI currently opens the new USB serial transport through `openAdapterOnly(...)` and starts ECU identification through `identifyEcu()`.
- The SCAN DTC UI action now calls the engine. Live Data UI polling is not yet wired to `queryLiveData()`. The ROM workflow still uses the legacy serial path and remains outside Stage 1 acceptance.
- The `:ecuengine` module contains transport, K-Line framing/echo handling, Honda protocol logic, identity parsing, Live Data parsing, DTC code, communication logging, and unit tests.
- Tests use fake transports for protocol behavior. They do not prove physical adapter/ECU compatibility.
- DTC clear, TP reset and ROM write remain gated; none is part of the Stage 1 hardware acceptance test.
- The Live Data catalog remains empty pending restoration of a user-authorized, attributable profile set and validation of table offsets/scales. Consequently, the UI must not show fabricated sensor values.

## Stage 1 coverage snapshot

- 1A USB serial/adapter transport: source integrated; adapter-open UI path present.
- 1B K-Line transport: source integrated; physical hardware retest pending.
- 1C initialization/framing/checksum/echo: source and unit tests integrated; physical ECU retest pending.
- 1D transaction serialization/retry/recovery: partial coverage exists in session/transport code and tests; reconnect recovery must be reviewed before calling complete.
- 1E communication logger/sniffer: source integrated; UI export and full diagnostic trace workflow require review.
- 1F simulator/test harness: fake-transport unit tests exist for echo, timeout, split/partial response, checksum failure, and retry. This is not a full ECU simulator.

## Build and hardware status

- No Gradle build or Android APK build was run in this pass. The working container has JDK 21 but no installed Gradle executable or Gradle wrapper JAR; the repository workflow is configured to provision Gradle 8.14 and Android SDK 36 in GitHub Actions.
- No unit tests were executed in this pass.
- No physical ECU test was performed in this environment. User-reported success of the original baseline is treated as prior evidence for its original setup, not as proof of this renamed/integrated source build.
- The supplied project archive lacks `gradle-wrapper.jar`; the wrapper properties alone are insufficient for a local wrapper build. CI/build setup still needs validation.

## Safety and data boundaries

- ECU catalog entries are not all verified diagnostic/remap targets. Preserve record-level evidence and warnings.
- Unknown ECU IDs must not be guessed from partial similarity.
- Unknown protocol requests must not be sent.
- `ORIGINAL.zip` is not included or modified.
