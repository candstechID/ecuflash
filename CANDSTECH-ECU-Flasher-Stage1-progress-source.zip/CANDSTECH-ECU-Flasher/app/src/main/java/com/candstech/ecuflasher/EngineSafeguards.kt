package com.candstech.ecuflasher

import java.util.Locale

data class SafeguardResult(
    val isSafe: Boolean,
    val warnings: List<String>
)

object EngineSafeguards {
    private const val MAX_SAFE_RPM_MATIC = 11500
    private const val MAX_SAFE_IGNITION_DEG = 42.0f
    private const val MIN_SAFE_AFR = 11.2f
    private const val MAX_SAFE_AFR = 15.2f

    fun validateTuningParameters(
        rpmLimit: Int,
        maxIgnitionDeg: Float,
        targetAfr: Float,
        fuelEnrichmentPercent: Float
    ): SafeguardResult {
        val warnings = mutableListOf<String>()

        if (rpmLimit > MAX_SAFE_RPM_MATIC) {
            warnings.add("PERINGATAN RPM: Limit $rpmLimit RPM melebihi batas aman klep standar ($MAX_SAFE_RPM_MATIC RPM). Risiko floating!")
        }
        if (maxIgnitionDeg > MAX_SAFE_IGNITION_DEG) {
            val ignFmt = String.format(Locale.US, "%.1f", maxIgnitionDeg)
            warnings.add("PERINGATAN IGNITION: Advance $ignFmt° terlalu maju. Risiko detonasi / ngelitik!")
        }
        if (targetAfr < MIN_SAFE_AFR) {
            warnings.add("PERINGATAN AFR: Campuran terlalu basah ($targetAfr). Busi berisiko mati/brebet.")
        } else if (targetAfr > MAX_SAFE_AFR) {
            warnings.add("PERINGATAN AFR: Campuran terlalu kering ($targetAfr). Risiko piston overheat!")
        }
        if (fuelEnrichmentPercent > 35f || fuelEnrichmentPercent < -25f) {
            warnings.add("PERINGATAN FUEL: Koreksi debit injektor (${fuelEnrichmentPercent.toInt()}%) di luar toleransi harian.")
        }

        return SafeguardResult(
            isSafe = warnings.isEmpty(),
            warnings = warnings
        )
    }

    fun clampByteValue(value: Int): Byte {
        return value.coerceIn(0, 255).toByte()
    }
}
