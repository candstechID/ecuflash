package com.candstech.ecuflasher

data class TuningPreset(
    val id: String,
    val name: String,
    val description: String,
    val fuelMultiplier: Float,
    val ignitionOffset: Int,
    val rpmLimitTarget: Int,
    val targetAfr: Float
)

object AiPresetEngine {
    val presets = listOf(
        TuningPreset(
            id = "STOCK_ECO",
            name = "1. Standard Harian / Irit",
            description = "Mapping standar pabrik Honda PGM-FI, aman untuk harian & irit BBM.",
            fuelMultiplier = 1.00f,
            ignitionOffset = 0,
            rpmLimitTarget = 9500,
            targetAfr = 14.5f
        ),
        TuningPreset(
            id = "DAILY_SPORT",
            name = "2. Kirian / Knalpot Racing (Stage 1)",
            description = "Tambah debit bensin +6% & maju pengapian +2° untuk akselerasi bawah-tengah.",
            fuelMultiplier = 1.06f,
            ignitionOffset = 2,
            rpmLimitTarget = 10300,
            targetAfr = 13.4f
        ),
        TuningPreset(
            id = "BOREUP_TOURING",
            name = "3. Bore Up 130cc - 150cc Touring",
            description = "Debit bensin +14% & timing +3° menjaga suhu ruang bakar tetap adem.",
            fuelMultiplier = 1.14f,
            ignitionOffset = 3,
            rpmLimitTarget = 10800,
            targetAfr = 12.8f
        ),
        TuningPreset(
            id = "HEREX_ROAD_RACE",
            name = "4. Balap / Road Race (Full Open)",
            description = "Debit bensin +20%, pengapian agresif +4°, limit 11.400 RPM.",
            fuelMultiplier = 1.20f,
            ignitionOffset = 4,
            rpmLimitTarget = 11400,
            targetAfr = 12.3f
        )
    )

    fun applyPresetToBin(
        binData: ByteArray,
        tables: MutableMap<String, XDFTableInfo>,
        preset: TuningPreset
    ): Pair<Int, SafeguardResult> {
        var modifiedCells = 0
        val fuelPct = (preset.fuelMultiplier - 1.0f) * 100f
        val safeguard = EngineSafeguards.validateTuningParameters(
            rpmLimit = preset.rpmLimitTarget,
            maxIgnitionDeg = 32.0f + preset.ignitionOffset,
            targetAfr = preset.targetAfr,
            fuelEnrichmentPercent = fuelPct
        )

        tables.values.forEach { table ->
            val isFuel = table.title.contains("Fuel", ignoreCase = true)
            val isIgn = table.title.contains("Ign", ignoreCase = true)

            if (isFuel || isIgn) {
                for (r in 0 until table.rows) {
                    for (c in 0 until table.cols) {
                        val current = BinParser.readCell(binData, table, r, c)
                        if (current > 0) {
                            val updated = if (isFuel) {
                                (current * preset.fuelMultiplier).toInt()
                            } else {
                                current + preset.ignitionOffset
                            }
                            if (BinParser.writeCell(binData, table, r, c, updated)) {
                                modifiedCells++
                            }
                        }
                    }
                }
            }
        }
        return Pair(modifiedCells, safeguard)
    }
}
