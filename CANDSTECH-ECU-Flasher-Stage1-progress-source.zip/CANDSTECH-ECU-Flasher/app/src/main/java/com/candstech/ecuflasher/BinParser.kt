package com.candstech.ecuflasher

import java.io.InputStream
import javax.xml.parsers.DocumentBuilderFactory
import org.w3c.dom.Element

data class XDFTableInfo(
    val title: String,
    val address: Int,
    val rows: Int,
    val cols: Int,
    val elementSizeBits: Int = 8,
    val equation: String = "X",
    val category: String = "General"
)

object BinParser {
    fun parseXdfStream(inputStream: InputStream): MutableMap<String, XDFTableInfo> {
        val tables = mutableMapOf<String, XDFTableInfo>()
        try {
            val factory = DocumentBuilderFactory.newInstance()
            val builder = factory.newDocumentBuilder()
            val doc = builder.parse(inputStream)
            doc.documentElement.normalize()

            val tableNodes = doc.getElementsByTagName("XDFTABLE")
            for (i in 0 until tableNodes.length) {
                val node = tableNodes.item(i) as? Element ?: continue
                val title = node.getElementsByTagName("title").item(0)?.textContent?.trim()
                    ?: "Table_${i + 1}"

                val embedded = node.getElementsByTagName("EMBEDDEDDATA").item(0) as? Element
                val rawAddr = embedded?.getAttribute("mmedaddress")?.trim() ?: "0x0"
                val cleanAddr = rawAddr.removePrefix("0x").removePrefix("0X")
                val address = cleanAddr.toIntOrNull(16) ?: 0
                val rows = embedded?.getAttribute("mmedrowcount")?.toIntOrNull()?.coerceAtLeast(1) ?: 1
                val cols = embedded?.getAttribute("mmedcolcount")?.toIntOrNull()?.coerceAtLeast(1) ?: 1
                val bits = embedded?.getAttribute("mmedelementsizebits")?.toIntOrNull() ?: 8

                val mathNode = node.getElementsByTagName("MATH").item(0) as? Element
                val eq = mathNode?.getAttribute("equation")?.takeIf { it.isNotBlank() } ?: "X"

                tables[title] = XDFTableInfo(
                    title = title,
                    address = address,
                    rows = rows,
                    cols = cols,
                    elementSizeBits = bits,
                    equation = eq
                )
            }
        } catch (_: Exception) {
        }

        if (tables.isEmpty()) {
            loadDefaultHondaKeihinTables(tables)
        }
        return tables
    }

    fun loadDefaultHondaKeihinTables(targetMap: MutableMap<String, XDFTableInfo>) {
        targetMap["Main Fuel Base Map (TPS vs RPM)"] = XDFTableInfo("Main Fuel Base Map (TPS vs RPM)", 0x4000, 12, 16, 8, "X * 0.05", "Fuel")
        targetMap["Ignition Advance Timing Map"] = XDFTableInfo("Ignition Advance Timing Map", 0x4200, 12, 16, 8, "X * 0.5", "Ignition")
        targetMap["RPM Hard Rev Limiter"] = XDFTableInfo("RPM Hard Rev Limiter", 0x5100, 1, 4, 16, "X", "Limiter")
        targetMap["Target AFR Closed-Loop"] = XDFTableInfo("Target AFR Closed-Loop", 0x5300, 8, 8, 8, "14.7 * (128 / X)", "AFR")
    }

    fun readCell(binData: ByteArray, table: XDFTableInfo, row: Int, col: Int): Int {
        val offset = table.address + (row * table.cols) + col
        return if (offset in binData.indices) {
            binData[offset].toInt() and 0xFF
        } else {
            0
        }
    }

    fun writeCell(binData: ByteArray, table: XDFTableInfo, row: Int, col: Int, newValue: Int): Boolean {
        val offset = table.address + (row * table.cols) + col
        return if (offset in binData.indices) {
            binData[offset] = EngineSafeguards.clampByteValue(newValue)
            true
        } else {
            false
        }
    }

    fun calculateChecksum16(binData: ByteArray): Int {
        var sum = 0
        for (b in binData) {
            sum = (sum + (b.toInt() and 0xFF)) and 0xFFFF
        }
        return sum
    }

    // Checksum 8-bit Honda resmi (dari HondaECU.py: ((sum(data) ^ 0xFF) + 1) & 0xFF)
    fun checksum8bitHonda(data: ByteArray): Int {
        var sum = 0
        for (b in data) {
            sum += (b.toInt() and 0xFF)
        }
        return ((sum xor 0xFF) + 1) and 0xFF
    }

    // Checksum 8-bit blok write (dari HondaECU.py: 0xff - ((sum(data) - 1) >> 8))
    fun checksum8bitBlock(data: ByteArray): Int {
        var sum = 0
        for (b in data) {
            sum += (b.toInt() and 0xFF)
        }
        return (0xFF - ((sum - 1) shr 8)) and 0xFF
    }

    // Validasi & perbaiki checksum file .BIN pada offset standar Honda (ukuran - 8, misal 0x3FFF8 untuk 256KB)
    fun fixHondaRomChecksum(binData: ByteArray, overrideOffset: Int? = null): Triple<Int, Int, Boolean> {
        if (binData.size < 16) return Triple(0, 0, false)
        val cksumOffset = overrideOffset ?: (binData.size - 8)
        val fileCksum = binData[cksumOffset].toInt() and 0xFF
        var sum = 0
        for (i in binData.indices) {
            if (i != cksumOffset) {
                sum += (binData[i].toInt() and 0xFF)
            }
        }
        val calcCksum = ((sum xor 0xFF) + 1) and 0xFF
        val fixed = fileCksum != calcCksum
        if (fixed) {
            binData[cksumOffset] = calcCksum.toByte()
        }
        return Triple(fileCksum, calcCksum, fixed)
    }

    // Hitung kunci akses keamanan (Seed-Key) Shindengen berdasarkan parameter BIN (signature 11 12 13 14 15 15 17 + 0xEE)
    fun computeShindengenWriteKey(binData: ByteArray, seed0: Int, seed1: Int): Int? {
        val sig = byteArrayOf(0x11, 0x12, 0x13, 0x14, 0x15, 0x15, 0x17)
        var sigPos = -1
        for (i in 0..(binData.size - sig.size)) {
            var match = true
            for (j in sig.indices) {
                if (binData[i + j] != sig[j]) {
                    match = false
                    break
                }
            }
            if (match) {
                sigPos = i
                break
            }
        }
        if (sigPos < 0) return null
        for (off in sigPos..(binData.size - 9)) {
            val b0 = binData[off].toInt() and 0xFF
            val b8 = binData[off + 8].toInt() and 0xFF
            if (b0 == 0xEE && (b8 == 0x00 || b8 == 0xFF) && off >= 6) {
                val v5 = (binData[off - 6].toInt() and 0xFF) or ((binData[off - 5].toInt() and 0xFF) shl 8)
                val v6 = (binData[off - 4].toInt() and 0xFF) or ((binData[off - 3].toInt() and 0xFF) shl 8)
                val v7 = (binData[off - 2].toInt() and 0xFF) or ((binData[off - 1].toInt() and 0xFF) shl 8)
                val seedVal = ((seed0 and 0xFF) shl 8) or (seed1 and 0xFF)
                val v8 = (v6 * ((seedVal + v5) and 0xFFFF)) and 0xFFFF
                return if (v7 > 0) (v8 + (seedVal % v7)) and 0xFFFF else (v8 + seedVal) and 0xFFFF
            }
        }
        return null
    }

    // Validasi & perbaiki checksum 32-bit Shindengen (pola D0 07 setelah 11 12 13 14 15 15 17, simpan di foundLoc - 4)
    fun fixShindengenRomChecksum32(binData: ByteArray): Triple<Long, Long, Boolean> {
        val sig = byteArrayOf(0x11, 0x12, 0x13, 0x14, 0x15, 0x15, 0x17)
        var sigPos = -1
        for (i in 0..(binData.size - sig.size)) {
            var match = true
            for (j in sig.indices) {
                if (binData[i + j] != sig[j]) {
                    match = false
                    break
                }
            }
            if (match) {
                sigPos = i
                break
            }
        }
        if (sigPos < 0) return Triple(0L, 0L, false)

        var foundLoc = -1
        for (i in sigPos..(binData.size - 2)) {
            if ((binData[i].toInt() and 0xFF) == 0xD0 && (binData[i + 1].toInt() and 0xFF) == 0x07) {
                foundLoc = i and 0x7FFFFFFC.inv().inv()
                foundLoc = (i / 4) * 4
                break
            }
        }
        val csumOffset = foundLoc - 4
        if (foundLoc < 8 || csumOffset < 0 || csumOffset + 4 > binData.size) return Triple(0L, 0L, false)

        fun readU32LE(off: Int): Long {
            return ((binData[off].toLong() and 0xFFL)) or
                ((binData[off + 1].toLong() and 0xFFL) shl 8) or
                ((binData[off + 2].toLong() and 0xFFL) shl 16) or
                ((binData[off + 3].toLong() and 0xFFL) shl 24)
        }

        val oldCsum = readU32LE(csumOffset)
        var totalSum = 0L
        var pos = 0
        while (pos + 4 <= binData.size) {
            if (pos != csumOffset) {
                totalSum = (totalSum + readU32LE(pos)) and 0xFFFFFFFFL
            }
            pos += 4
        }
        val newCsum = (0L - totalSum) and 0xFFFFFFFFL
        val fixed = oldCsum != newCsum
        if (fixed) {
            binData[csumOffset] = (newCsum and 0xFFL).toByte()
            binData[csumOffset + 1] = ((newCsum shr 8) and 0xFFL).toByte()
            binData[csumOffset + 2] = ((newCsum shr 16) and 0xFFL).toByte()
            binData[csumOffset + 3] = ((newCsum shr 24) and 0xFFL).toByte()
        }
        return Triple(oldCsum, newCsum, fixed)
    }


    // Deteksi arsitektur MCU dari isi file .BIN (SV850, SH850, Keihin H8C, Keihin M32R)
    fun detectEcuArchitectureFromBin(binData: ByteArray): String {
        if (binData.isEmpty()) return "Unknown"
        fun hasSig(sig: ByteArray): Boolean {
            if (binData.size < sig.size) return false
            for (i in 0..(binData.size - sig.size)) {
                var ok = true
                for (j in sig.indices) {
                    if (binData[i + j] != sig[j]) {
                        ok = false
                        break
                    }
                }
                if (ok) return true
            }
            return false
        }
        if (hasSig(byteArrayOf(0x53, 0x56, 0x38, 0x35, 0x30))) return "Shindengen V850"
        if (hasSig(byteArrayOf(0x53, 0x48, 0x38, 0x35, 0x30))) return "Shindengen RH850"
        if (hasSig(byteArrayOf(0x11, 0x12, 0x13, 0x14, 0x15, 0x15, 0x17))) return "Shindengen RH850"
        if (hasSig(byteArrayOf(0xFF.toByte(), 0xFF.toByte(), 0xFF.toByte(), 0xAA.toByte(), 0xAA.toByte(), 0xAA.toByte(), 0xAA.toByte()))) return "Keihin M32R"
        if (hasSig(byteArrayOf(0xFF.toByte(), 0xFF.toByte(), 0xAA.toByte(), 0xAA.toByte()))) return "Keihin H8C"
        return "Keihin / Generic"
    }

    // Penentuan otomatis Start Offset & Checksum Offset berdasarkan ukuran file .BIN & vendor
    fun detectBinOffsets(binData: ByteArray, arch: String): Pair<Int, Int?> {
        if (arch.startsWith("Shindengen")) {
            return Pair(0, null)
        }
        return when (binData.size) {
            0x10000 -> Pair(0x8000, 0x7600)    // 64KB
            0x20000 -> Pair(0x8000, 0xDFEF)    // 128KB
            0x40000 -> Pair(0x0, 0x3FFF8)      // 256KB
            0x80000 -> Pair(0x0, 0x7FFF8)      // 512KB
            0x100000 -> Pair(0x0, 0xFFFF8)     // 1MB
            else -> Pair(0, (binData.size - 8).coerceAtLeast(0))
        }
    }

}
