package com.candstech.engine.core.protocol

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class HondaDtcResponseParserTest {
    private fun frame(vararg body: Int): ByteArray {
        val prefix = byteArrayOf(0x02, (body.size + 3).toByte()) + body.map { it.toByte() }.toByteArray()
        return prefix + HondaChecksum.calculatePacketChecksum(prefix)
    }

    @Test fun parsesValidEmptyCurrent71_74Response() {
        val parsed = HondaDtcDatabase.parseDtcResponse(byteArrayOf(0x02, 0x05, 0x71, 0x74, 0x14))
        assertEquals(emptyList<HondaDtc>(), parsed?.dtcs)
        assertEquals("honda-pgmfi-71-74-current", parsed?.format)
    }

    @Test fun parsesCurrentAndHistoryPairFramesSeparately() {
        val current = HondaDtcDatabase.parseDtcResponse(frame(0x71, 0x74, 0x08, 0x01))
        val history = HondaDtcDatabase.parseDtcResponse(frame(0x71, 0x73, 0x07, 0x02))
        assertEquals(listOf(8 to 1), current?.dtcs?.map { it.codeNumber to it.subCode })
        assertEquals(listOf(7 to 2), history?.dtcs?.map { it.codeNumber to it.subCode })
    }

    @Test fun parsesPagedCurrentAndHistoryResponsesSeparately() {
        val current = HondaDtcDatabase.parseDtcResponse(frame(0x74, 0x01, 0x00, 0x08, 0x01))
        val history = HondaDtcDatabase.parseDtcResponse(frame(0x73, 0x01, 0x00, 0x07, 0x02))
        assertEquals(listOf(8 to 1), current?.dtcs?.map { it.codeNumber to it.subCode })
        assertEquals(listOf(7 to 2), history?.dtcs?.map { it.codeNumber to it.subCode })
        assertEquals(true, current?.format?.contains("current"))
        assertEquals(true, history?.format?.contains("history"))
    }

    @Test fun rejectsBadChecksumAndOddPayload() {
        assertNull(HondaDtcDatabase.parseDtcResponse(byteArrayOf(0x02, 0x05, 0x71, 0x74, 0x00)))
        assertNull(HondaDtcDatabase.parseDtcResponse(frame(0x71, 0x74, 0x08)))
    }

    @Test fun parsesGen1FallbackCurrent71_72Response() {
        val parsed = HondaDtcDatabase.parseDtcResponse(frame(0x71, 0x72, 0x08, 0x01))
        assertEquals(listOf(8 to 1), parsed?.dtcs?.map { it.codeNumber to it.subCode })
        assertEquals("honda-pgmfi-71-72-current-fallback", parsed?.format)
    }

    @Test fun rejectsUnsupportedServiceAndMalformedPadding() {
        assertNull(HondaDtcDatabase.parseDtcResponse(frame(0x70, 0x72, 0x08, 0x01)))
        assertNull(HondaDtcDatabase.parseDtcResponse(frame(0x71, 0x74, 0x00, 0x01)))
    }
}
