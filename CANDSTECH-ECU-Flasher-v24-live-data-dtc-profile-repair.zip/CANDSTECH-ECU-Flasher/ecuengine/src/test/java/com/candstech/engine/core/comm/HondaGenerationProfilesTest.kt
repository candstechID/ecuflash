package com.candstech.engine.core.comm

import com.candstech.engine.data.ecu.EcmModel
import org.junit.Assert.assertNull
import org.junit.Test

class HondaGenerationProfilesTest {
    @Test fun reconstructedGenerationDoesNotEnableUnverifiedDtcCommands() {
        val model = EcmModel(
            id = "K59A-A11", partNumber = "30400-K59A-A11", ecmId = "0101C40F01",
            generationGroup = "GEN_2_ESP_SPORT", generationEvidence = "RECONSTRUCTED",
            dtcProfileId = "honda.kline.dtc.71_74"
        )
        assertNull(HondaGenerationProfiles.dtcRequests(model))
    }

    @Test fun referenceGenerationDoesNotEnableGenericDtcCommands() {
        val model = EcmModel(
            id = "GEN1A", partNumber = "GEN1A", generationGroup = "GEN_1A_SHINDENGEN",
            generationEvidence = "REFERENCE", dtcProfileId = "honda.kline.dtc.71_74"
        )
        assertNull(HondaGenerationProfiles.dtcRequests(model))
    }

    @Test fun unknownOrConflictedCanProfileDoesNotEnableCandidateCommands() {
        val model = EcmModel(
            id = "PCX160-CANDIDATE", partNumber = "PCX160-CANDIDATE",
            generationGroup = "UNKNOWN", generationCandidate = "GEN_3B_CANBUS_160",
            generationEvidence = "CONFLICT", dtcProfileId = "honda.can.obd2.03_07_0a_04"
        )
        assertNull(HondaGenerationProfiles.canDtcCommands(model))
    }
}
