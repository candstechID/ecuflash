package com.candstech.engine.core.comm

import com.candstech.engine.data.ecu.EcmModel

/** Database-driven protocol dispatch. Reference-level profiles are read-only candidates. */
data class HondaCanDtcCommandSet(
    val adapterProtocol: String = "ATSP6",
    val currentMode: String = "03",
    val pendingHistoryMode: String = "07",
    val permanentMode: String = "0A",
    val clearMode: String = "04",
    val tpsLivePid: String = "0111",
    val tpsByteIndex: Int = 0
)

object HondaGenerationProfiles {
    private fun req(id: String, bytes: ByteArray, label: String, evidence: EvidenceStatus) =
        EcuRequest(id, bytes, label, 900, 10, "DTC_READ_QUERY", evidence)

    private val gen1a = listOf(
        req("dtc.read.7174", HondaFrameCodec.buildBaseline(0x71, 0x74), "Gen-1A Current DTC 71/74", EvidenceStatus.HYPOTHESIS),
        req("dtc.read.7172", HondaFrameCodec.buildBaseline(0x71, 0x72), "Gen-1A Current DTC fallback 71/72", EvidenceStatus.HYPOTHESIS),
        req("dtc.read.7173.history", HondaFrameCodec.buildBaseline(0x71, 0x73), "Gen-1A History DTC 71/73", EvidenceStatus.HYPOTHESIS)
    )
    private val klineCommon = listOf(
        req("dtc.read.7174", HondaFrameCodec.buildBaseline(0x71, 0x74), "Honda K-Line Current DTC 71/74", EvidenceStatus.HYPOTHESIS),
        req("dtc.read.7173.history", HondaFrameCodec.buildBaseline(0x71, 0x73), "Honda K-Line History DTC 71/73", EvidenceStatus.HYPOTHESIS)
    )

    /**
     * No generic Honda K-Line DTC command is currently hardware-validated against
     * an exact ECU response identity. Reference command bytes are retained in the
     * registry for research only; never transmit them from a generation label.
     */
    fun dtcRequests(model: EcmModel?): List<EcuRequest>? = null

    fun liveTableId(model: EcmModel?): String? = when (model?.liveDataProfileId) {
        "honda.kline.live.table10" -> "10"
        "honda.kline.live.table17" -> "17"
        else -> null
    }

    /** Candidate CAN profile is stored for future CAN transport integration only. */
    fun canDtcCommands(model: EcmModel?): HondaCanDtcCommandSet? {
        model ?: return null
        val isGen3b = model.generationGroup == "GEN_3B_CANBUS_160" ||
            model.generationCandidate == "GEN_3B_CANBUS_160"
        if (!isGen3b || model.dtcProfileId != "honda.can.obd2.03_07_0a_04") return null
        if (model.generationEvidence != "VERIFIED") return null
        return HondaCanDtcCommandSet()
    }
}
