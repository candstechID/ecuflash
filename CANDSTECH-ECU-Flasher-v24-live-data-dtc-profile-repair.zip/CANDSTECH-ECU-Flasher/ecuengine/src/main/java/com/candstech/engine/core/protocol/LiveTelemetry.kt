package com.candstech.engine.core.protocol

import com.candstech.engine.core.comm.LiveParameterState
import com.candstech.engine.core.comm.LiveSensor
import com.candstech.engine.data.ecu.TempSensorType

/**
 * Live-data availability is separate from adapter/ECU/session state: values may
 * be unavailable because no profile exists, no reply arrived, or the payload was
 * rejected. STALE means the last valid values are no longer current.
 */
enum class LiveDataState {
    UNAVAILABLE,
    WAITING_RESPONSE,
    ACTIVE,
    STALE,
    UNSUPPORTED_PROFILE,
    INVALID_PAYLOAD
}

data class LiveTelemetry(
    val timestamp: Long = System.currentTimeMillis(),
    val engineRpm: Int = 0,
    /** TPS percentage is derived from the ECU TPS-angle byte, not the ADC byte. */
    val tpsPercent: Float = 0.0f,
    val tpsVoltage: Float = 0.0f,
    val tpsAdc: Int = -1,
    val tpsDegrees: Float = 0.0f,
    val engineTempC: Int = 0,
    val ectVoltage: Float = 0.0f,
    val intakeAirTempC: Int = 0,
    val iatVoltage: Float = 0.0f,
    val mapKpa: Int = 0,
    val mapVoltage: Float = 0.0f,
    val batteryVoltage: Float = 0.0f,
    val o2Voltage: Float = 0.0f,
    /** Host-side narrowband scanner estimate; not an ECU-reported AFR measurement. */
    val afrEstimate: Float = 0.0f,
    val stfPercent: Float = 0.0f,
    val injectorPulseMs: Float = 0.0f,
    val ignitionAdvanceDeg: Float = 0.0f,
    val vehicleSpeedKmh: Int = 0,
    val gearPosition: String = "N",
    val milActive: Boolean = false,
    val tempSensorType: TempSensorType = TempSensorType.ECT,
    /**
     * True when at least one parameter in the frame decoded and passed its range
     * check. RPM is not required: key-on/engine-off frames remain usable.
     */
    val isDataValid: Boolean = false,
    val lastUpdatedMs: Long = 0L,
    val lastReadAttemptMs: Long = 0L,
    val isRpmAvailable: Boolean = false,
    val isTpsAvailable: Boolean = false,
    val isTpsDegreesAvailable: Boolean = false,
    val isTpsVoltageAvailable: Boolean = false,
    val isTpsAdcAvailable: Boolean = false,
    val isTempAvailable: Boolean = false,
    val isEctVoltageAvailable: Boolean = false,
    val isIatAvailable: Boolean = false,
    val isIatVoltageAvailable: Boolean = false,
    val isMapAvailable: Boolean = false,
    val isMapVoltageAvailable: Boolean = false,
    val isBattAvailable: Boolean = false,
    val isInjectorAvailable: Boolean = false,
    val isIgnitionAvailable: Boolean = false,
    val isSpeedAvailable: Boolean = false,
    val isO2Available: Boolean = false,
    val isAfrEstimateAvailable: Boolean = false,
    val isStfAvailable: Boolean = false,
    val activeTableHex: String = "",
    /** Per-parameter state; the only source the UI should use to hide values. */
    val parameterStates: Map<LiveSensor, LiveParameterState> = emptyMap(),
    /** Actual decoded ECU values for the DIAGNOSA sensor table; excludes invented defaults. */
    val diagnosticValues: Map<LiveSensor, Double> = emptyMap()
) {
    val isEngineSpinning: Boolean
        get() = isDataValid && isRpmAvailable && engineRpm > 0

    fun stateOf(sensor: LiveSensor): LiveParameterState =
        parameterStates[sensor] ?: LiveParameterState.UNSUPPORTED

    fun isValid(sensor: LiveSensor): Boolean = stateOf(sensor) == LiveParameterState.VALID
}

/**
 * Approximate scanner-style narrowband mapping requested for this project.
 * This is not a physical AFR measurement: a narrowband sensor is nonlinear and
 * only indicates rich/lean around stoichiometry. Keep the UI label "Est. AFR".
 */
object NarrowbandAfrEstimate {
    fun fromVoltage(voltage: Float): Float? =
        if (voltage.isFinite() && voltage in 0.0f..1.0f) {
            14.7f - ((voltage - 0.45f) * 3.0f)
        } else null
}
