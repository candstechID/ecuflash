# Integrasi Database Motor ke Live Data

- `ecm_database.json` tetap menjadi sumber data utama (489 record ECU); database dimuat saat `MainActivity.onCreate()` melalui `EcmDatabase.init()`.
- Tab Live Data kini menyediakan pencarian record berdasarkan nama motor, nomor part, ID database, pabrikan, tahun, dan ECU ID.
- Saat ECU teridentifikasi, record yang cocok dari database ditampilkan otomatis.
- Status profil Live Data ditampilkan terpisah dari status record database. Record motor/ECU tidak otomatis berarti protokol atau tabel sensor sudah diketahui.
- Pemilihan motor manual hanya untuk melihat record dan status dukungan. Pemilihan manual TIDAK mengganti identitas ECU aktual, tidak memaksa frame, dan tidak mengaktifkan profil motor lain.
- Pengiriman Live Data tetap menggunakan exact ECU-ID capability registry di `HondaLiveDataProfiles`. Saat ini hanya ECU ID `0101C40F01` yang mempunyai profil tabel rekonstruksi terdaftar.
- Semua 489 record tetap tersedia untuk identifikasi/pencarian; profil untuk ECU lain harus ditambahkan satu per satu setelah frame request, format respons, offset, scaling, dan dukungan sensornya dibuktikan.

Tidak dilakukan build APK atau pengujian hardware pada perubahan ini.

## v17 O2/STF display and conversion correction

- Table `0x20` remains an extension table attached only to the exact reconstructed ECU capability `0101C40F01`.
- O2/STF conversion constants are restored from the supplied RevCore decompiled `HondaLiveDataProfiles` profile: O2 `0.019610266350951835`, STF `0.007796874819209965`, with STF range `-2..2`.
- During KOEO the decoded bytes are retained in `diagnosticValues`; the UI now displays the measured decoded value with a KOEO/warm-up label instead of hiding it as `--`.
- A KOEO label means the parameter is not yet meaningful as a running-engine feedback value. It does not mean the Table 0x20 request failed or that the sensor is absent.
