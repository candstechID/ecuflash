# Integrasi Database Motor ke Live Data

- `ecm_database.json` tetap menjadi sumber data utama (489 record ECU); database dimuat saat `MainActivity.onCreate()` melalui `EcmDatabase.init()`.
- Tab Live Data kini menyediakan pencarian record berdasarkan nama motor, nomor part, ID database, pabrikan, tahun, dan ECU ID.
- Saat ECU teridentifikasi, record yang cocok dari database ditampilkan otomatis.
- Status profil Live Data ditampilkan terpisah dari status record database. Record motor/ECU tidak otomatis berarti protokol atau tabel sensor sudah diketahui.
- Pemilihan motor manual hanya untuk melihat record dan status dukungan. Pemilihan manual TIDAK mengganti identitas ECU aktual, tidak memaksa frame, dan tidak mengaktifkan profil motor lain.
- Pengiriman Live Data tetap menggunakan exact ECU-ID capability registry di `HondaLiveDataProfiles`. Saat ini hanya ECU ID `0101C40F01` yang mempunyai profil tabel rekonstruksi terdaftar.
- Semua 489 record tetap tersedia untuk identifikasi/pencarian; profil untuk ECU lain harus ditambahkan satu per satu setelah frame request, format respons, offset, scaling, dan dukungan sensornya dibuktikan.

Tidak dilakukan build APK atau pengujian hardware pada perubahan ini.
