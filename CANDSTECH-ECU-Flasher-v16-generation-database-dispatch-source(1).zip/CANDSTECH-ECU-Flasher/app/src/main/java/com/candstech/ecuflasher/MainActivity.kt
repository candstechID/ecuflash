package com.candstech.ecuflasher

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import com.felhr.usbserial.UsbSerialDevice
import com.felhr.usbserial.UsbSerialInterface
import com.candstech.ecuflasher.core.usb.UsbAdapterSupport
import com.candstech.engine.core.protocol.HondaProtocolEngine
import com.candstech.engine.core.comm.LivePollPolicy
import com.candstech.engine.core.comm.HondaLiveDataProfiles
import com.candstech.engine.core.comm.LiveSensor
import com.candstech.engine.core.comm.LiveParameterState
import com.candstech.engine.data.ecu.EcmModel
import com.candstech.engine.data.ecu.EcmDatabase
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentLinkedQueue
import kotlinx.coroutines.*

val BgDark = Color(0xFF0F0F0F)
val CardDark = Color(0xFF1E1E1E)
val BorderDark = Color(0xFF333333)
val HondaRed = Color(0xFFE10600)
val NeonYellow = Color(0xFFD4FF00)

// Kamus pencocokan ECM ID (5-byte Hex) & Kode Part Motor Honda (280+ entri Keihin & Shindengen)
data class EcuProfileSpec(
    val code: String,
    val model: String,
    val partNo: String,
    val startOffset: String,
    val csumLoc: String,
    val vendor: String,
    val romKb: Int?,
    val ecmIdHex: String = ""
)

val hondaEcuDatabase = listOf(
        EcuProfileSpec("K59J", "Vario 150 ISS", "30400-K59J-A71", "0", "AUTO", "Shindengen", 256, ""),
        EcuProfileSpec("K59A", "Vario 150", "30400-K59A-A11", "0", "AUTO", "Shindengen", 384, "0101C40F01"),
        EcuProfileSpec("K59F", "Vario 150", "30400-K59F-A01", "0", "AUTO", "Shindengen", 256, ""),
        EcuProfileSpec("K59", "Vario 150", "30400-K59-M01", "0", "AUTO", "Shindengen", 256, ""),
        EcuProfileSpec("K60R", "Vario 125 ISS", "30400-K60R-B61 / B71", "0", "AUTO", "Shindengen", 256, ""),
        EcuProfileSpec("K60K", "Vario 125", "30400-K60K-B31", "0", "AUTO", "Shindengen", 256, ""),
        EcuProfileSpec("K25G", "BeAT eSP", "30400-K25G-611", "0", "AUTO", "Shindengen", 64, ""),
        EcuProfileSpec("K81H", "BeAT Street", "30400-K81H-N52", "0", "AUTO", "Shindengen", 64, ""),
        EcuProfileSpec("K1AA-N03", "BeAT", "30400-K1AA-N03", "0", "AUTO", "Shindengen", 256, "01037A0F03"),
        EcuProfileSpec("K1AA", "BeAT Street", "30400-K1AA-N02", "0", "AUTO", "Shindengen", 64, ""),
        EcuProfileSpec("KZRA", "Vario 125 Old", "30400-KZRA-B21 / 601", "0", "AUTO", "Shindengen", 384, "01018E0F01"),
        EcuProfileSpec("KZR", "Vario 125 Old", "30400-KZR-601 / B11", "0", "AUTO", "Shindengen", 64, ""),
        EcuProfileSpec("K0WA", "ADV 150", "30400-K0WA-N01", "0", "AUTO", "Shindengen", 384, ""),
        EcuProfileSpec("K0WL", "ADV 160", "30400-K0WL-NB1", "0", "AUTO", "Shindengen", 512, ""),
        EcuProfileSpec("K1Z", "PCX 160", "30400-K1ZG-N21", "0", "AUTO", "Shindengen", 512, ""),
        EcuProfileSpec("K2S", "Vario 160", "30400-K2SA-N02", "0", "AUTO", "Shindengen", 512, ""),
        EcuProfileSpec("K61", "BeAT POP", "30400-K61-601", "0", "AUTO", "Shindengen", 64, ""),
        EcuProfileSpec("K44", "BeAT eSP K44", "30400-K44-V01", "0", "AUTO", "Shindengen", 64, ""),
        EcuProfileSpec("K2F", "Scoopy-i (2021-2024)", "38770-K2F-N01", "0", "3FFF8", "Keihin", 256, "0104080F01"),
        EcuProfileSpec("MKK", "Africa Twin CRF1000L / CRF1100L", "38770-MKK-D02", "0", "FFFF8", "Keihin", 512, "0102A40101"),
        EcuProfileSpec("KVG", "Honda Generic ECM", "38770-KVG-V42", "4000", "7600", "Keihin", 64, "0100F91103"),
        EcuProfileSpec("K25", "Honda Generic ECM", "38770-K25-901", "4000", "7600", "Keihin", 64, "0101340F01"),
        EcuProfileSpec("K46", "Honda Generic ECM", "38770-K46-N01", "8000", "0", "Keihin", 128, "0101A10F01"),
        EcuProfileSpec("K41", "Honda Generic ECM", "38770-K41-N01", "8000", "0", "Keihin", 128, "01018B0F01"),
        EcuProfileSpec("MFN", "Honda Generic ECM", "38770-MFN-D01", "0", "3FFF8", "Keihin", 256, "01006A0101"),
        EcuProfileSpec("MFN", "Honda Generic ECM", "38770-MFN-F01", "0", "3FFF8", "Keihin", 256, "01006A0301"),
        EcuProfileSpec("MKJ", "Honda Generic ECM", "38770-MKJ-D02", "0", "FFFF8", "Keihin", 512, "0102F60102"),
        EcuProfileSpec("MGC", "Honda Generic ECM", "38770-MGC-D32", "0", "3FFF8", "Keihin", 256, "0101390102"),
        EcuProfileSpec("K15", "CB150R Streetfire", "38770-K15-903", "4000", "7600", "Keihin", 64, "01011B0F02"),
        EcuProfileSpec("K15", "CB150R Streetfire", "38770-K15-921", "8000", "0", "Keihin", 128, "0101DA0F01"),
        EcuProfileSpec("K15", "CB150R Streetfire", "38770-K15-888", "8000", "0", "Keihin", 128, "0103130F11"),
        EcuProfileSpec("K15", "CB150R Streetfire", "38770-K15-601", "8000", "0", "Keihin", 128, "0103130F01"),
        EcuProfileSpec("K18", "Honda Generic ECM", "38770-K18-961", "8000", "0", "Keihin", 128, "0102E70F01"),
        EcuProfileSpec("K0A", "CB300R Neo Sports Cafe (2018-2024)", "38770-K0A-R11", "8000", "0", "Keihin", 128, "0102A22101"),
        EcuProfileSpec("KVK", "Honda Generic ECM", "38770-KVK-B31", "0", "DFEF", "Keihin", 64, "0101080801"),
        EcuProfileSpec("K0A", "CB300R Neo Sports Cafe (2018-2024)", "38770-K0A-A01", "8000", "0", "Keihin", 128, "0102B70401"),
        EcuProfileSpec("MFM", "Honda Generic ECM", "38770-MFM-651", "0", "3FFF8", "Keihin", 256, "01004C0701"),
        EcuProfileSpec("MFM", "Honda Generic ECM", "38770-MFM-702", "0", "3FFF8", "Keihin", 256, "01004C0601"),
        EcuProfileSpec("MJW", "CBR500R / CB500F / CB500X (2016-2018)", "38770-MJW-D51", "0", "3FFF8", "Keihin", 256, "0101F20101"),
        EcuProfileSpec("MJW", "CBR500R / CB500F / CB500X (2016-2018)", "38770-MJW-N41", "0", "3FFF8", "Keihin", 256, "0101F20F01"),
        EcuProfileSpec("MJW", "CBR500R / CB500F / CB500X (2016-2018)", "38770-MJW-B41", "0", "3FFF8", "Keihin", 256, "0101F20801"),
        EcuProfileSpec("MGZ", "CBR500R / CB500F / CB500X (2013-2015)", "38770-MGZ-D02", "0", "3FFF8", "Keihin", 256, "0101250101"),
        EcuProfileSpec("MGZ", "CBR500R / CB500F / CB500X (2013-2015)", "38770-MGZ-A03", "0", "3FFF8", "Keihin", 256, "0101250501"),
        EcuProfileSpec("MGZ", "CBR500R / CB500F / CB500X (2013-2015)", "38770-MGZ-C03", "0", "3FFF8", "Keihin", 256, "0101250B02"),
        EcuProfileSpec("MGZ", "CBR500R / CB500F / CB500X (2013-2015)", "38770-MGZ-C02", "0", "3FFF8", "Keihin", 256, "0101250B01"),
        EcuProfileSpec("MJW", "CBR500R / CB500F / CB500X (2016-2018)", "38770-MJW-D91", "0", "3FFF8", "Keihin", 256, "0101DE0101"),
        EcuProfileSpec("MJW", "CBR500R / CB500F / CB500X (2016-2018)", "38770-MJW-961", "0", "3FFF8", "Keihin", 256, "0101DE0F01"),
        EcuProfileSpec("MJW", "CBR500R / CB500F / CB500X (2016-2018)", "38770-MJW-NM1", "0", "3FFF8", "Keihin", 256, "0102780F01"),
        EcuProfileSpec("MJW", "CBR500R / CB500F / CB500X (2016-2018)", "38770-MJW-???", "0", "3FFF8", "Keihin", 256, "0102780D01"),
        EcuProfileSpec("MFG", "Honda Generic ECM", "38770-MFG-D02", "0", "3FFF8", "Keihin", 256, "0100390101"),
        EcuProfileSpec("MJE", "CBR650F / CB650F (2014-2018)", "38770-MJE-D41", "0", "3FFF8", "Keihin", 256, "01019C0101"),
        EcuProfileSpec("MJE", "CBR650F / CB650F (2014-2018)", "38770-MJE-TB1", "0", "7FFF8", "Keihin", 512, "01027D0D01"),
        EcuProfileSpec("MJE", "CBR650F / CB650F (2014-2018)", "38770-MJE-G12", "0", "3FFF8", "Keihin", 256, "01014E1201"),
        EcuProfileSpec("MJE", "CBR650F / CB650F (2014-2018)", "38770-MJE-G52", "0", "3FFF8", "Keihin", 256, "01019C1201"),
        EcuProfileSpec("MKN", "CBR650R / CB650R (2019-2024)", "38770-MKN-D51", "0", "7FFF8", "Keihin", 512, "0103050101"),
        EcuProfileSpec("MKN", "CBR650R / CB650R (2019-2024)", "38770-MKN-HF2", "0", "7FFF8", "Keihin", 512, "0103BF0E01"),
        EcuProfileSpec("MFA", "Honda Generic ECM", "38770-MFA-D03", "0", "3FFF8", "Keihin", 256, "0100300101"),
        EcuProfileSpec("MEL", "CBR1000RR Fireblade (2004-2007)", "38770-MEL-613", "0", "3FFFC", "Keihin", 256, "01000F0202"),
        EcuProfileSpec("MEL", "CBR1000RR Fireblade (2004-2007)", "38770-MEL-622", "0", "3FFFC", "Keihin", 256, "01000F0302"),
        EcuProfileSpec("MEL", "CBR1000RR Fireblade (2004-2007)", "38770-MEL-643", "0", "3FFFC", "Keihin", 256, "01000F0102"),
        EcuProfileSpec("MEL", "CBR1000RR Fireblade (2004-2007)", "38770-MEL-D01", "0", "3FFFC", "Keihin", 256, "01001A0101"),
        EcuProfileSpec("MEL", "CBR1000RR Fireblade (2004-2007)", "38770-MEL-A21", "0", "3FFF8", "Keihin", 256, "01002B0401"),
        EcuProfileSpec("MEL", "CBR1000RR Fireblade (2004-2007)", "38770-MEL-A22", "0", "3FFF8", "Keihin", 256, "01002B0402"),
        EcuProfileSpec("MEL", "CBR1000RR Fireblade (2004-2007)", "38770-MEL-F21", "0", "3FFF8", "Keihin", 256, "01002B0301"),
        EcuProfileSpec("MEL", "CBR1000RR Fireblade (2004-2007)", "38770-MEL-L22", "0", "3FFF8", "Keihin", 256, "01002B0502"),
        EcuProfileSpec("MEL", "CBR1000RR Fireblade (2004-2007)", "38770-MEL-D21", "0", "3FFF8", "Keihin", 256, "01002B0101"),
        EcuProfileSpec("MFL", "CBR1000RR Fireblade (2008-2011)", "38770-MFL-644", "0", "3FFF8", "Keihin", 256, "01005E0103"),
        EcuProfileSpec("MFL", "CBR1000RR Fireblade (2008-2011)", "38770-MFL-702", "0", "3FFF8", "Keihin", 256, "01005E0601"),
        EcuProfileSpec("MFL", "CBR1000RR Fireblade (2008-2011)", "38770-MFL-622", "0", "3FFF8", "Keihin", 256, "01005E0301"),
        EcuProfileSpec("MFL", "CBR1000RR Fireblade (2008-2011)", "38770-MFL-773", "0", "3FFF8", "Keihin", 256, "01005E0503"),
        EcuProfileSpec("MFL", "CBR1000RR Fireblade (2008-2011)", "38770-MFL-671", "0", "3FFF8", "Keihin", 256, "01005E0401"),
        EcuProfileSpec("MFL", "CBR1000RR Fireblade (2008-2011)", "38770-MFL-741", "0", "3FFF8", "Keihin", 256, "0100B00301"),
        EcuProfileSpec("MFL", "CBR1000RR Fireblade (2008-2011)", "38770-MFL-691", "0", "3FFF8", "Keihin", 256, "0100B00401"),
        EcuProfileSpec("MFL", "CBR1000RR Fireblade (2008-2011)", "38770-MFL-861", "0", "3FFF8", "Keihin", 256, "0100B00501"),
        EcuProfileSpec("MFL", "CBR1000RR Fireblade (2008-2011)", "38770-MFL-871", "0", "3FFF8", "Keihin", 256, "0100B00801"),
        EcuProfileSpec("MFL", "CBR1000RR Fireblade (2008-2011)", "38770-MFL-761", "0", "3FFF8", "Keihin", 256, "0100B00102"),
        EcuProfileSpec("MFL", "CBR1000RR Fireblade (2008-2011)", "38770-MFL-J41", "0", "3FFF8", "Keihin", 256, "0100B00601"),
        EcuProfileSpec("MFL", "CBR1000RR Fireblade (2008-2011)", "38770-MFL-J21", "0", "3FFF8", "Keihin", 256, "0100B70601"),
        EcuProfileSpec("MFL", "CBR1000RR Fireblade (2008-2011)", "38770-MFL-L21", "0", "3FFF8", "Keihin", 256, "0100B70501"),
        EcuProfileSpec("MFL", "CBR1000RR Fireblade (2008-2011)", "38770-MFL-F21", "0", "3FFF8", "Keihin", 256, "0100B70301"),
        EcuProfileSpec("MFL", "CBR1000RR Fireblade (2008-2011)", "38770-MFL-D21", "0", "3FFF8", "Keihin", 256, "0100B70101"),
        EcuProfileSpec("MFL", "CBR1000RR Fireblade (2008-2011)", "38770-MFL-A21", "0", "3FFF8", "Keihin", 256, "0100B70401"),
        EcuProfileSpec("MGP", "CBR1000RR Fireblade (2012-2016)", "38770-MGP-L01", "0", "3FFF8", "Keihin", 256, "0100F30501"),
        EcuProfileSpec("MGP", "CBR1000RR Fireblade (2012-2016)", "38770-MGP-F01", "0", "3FFF8", "Keihin", 256, "0100F30301"),
        EcuProfileSpec("MGP", "CBR1000RR Fireblade (2012-2016)", "38770-MGP-A01", "0", "3FFF8", "Keihin", 256, "0100F30401"),
        EcuProfileSpec("MGP", "CBR1000RR Fireblade (2012-2016)", "38770-MGP-J01", "0", "3FFF8", "Keihin", 256, "0100F30601"),
        EcuProfileSpec("MGP", "CBR1000RR Fireblade (2012-2016)", "38770-MGP-D01", "0", "3FFF8", "Keihin", 256, "0100F30101"),
        EcuProfileSpec("MGP", "CBR1000RR Fireblade (2012-2016)", "38770-MGP-T42", "0", "3FFF8", "Keihin", 256, "0101830D01"),
        EcuProfileSpec("MGP", "CBR1000RR Fireblade (2012-2016)", "38770-MGP-A92", "0", "3FFF8", "Keihin", 256, "0101830401"),
        EcuProfileSpec("MGP", "CBR1000RR Fireblade (2012-2016)", "38770-MGP-F63", "0", "3FFF8", "Keihin", 256, "0101830302"),
        EcuProfileSpec("MGP", "CBR1000RR Fireblade (2012-2016)", "38770-MGP-D62", "0", "3FFF8", "Keihin", 256, "0101830101"),
        EcuProfileSpec("MKF", "CBR1000RR SP / Fireblade (2017-2019)", "38770-MKF-A22", "0", "FFFF8", "Keihin", 512, "0102480401"),
        EcuProfileSpec("MKF", "CBR1000RR SP / Fireblade (2017-2019)", "38770-MKF-H11", "0", "FFFF8", "Keihin", 512, "0102490E01"),
        EcuProfileSpec("MKF", "CBR1000RR SP / Fireblade (2017-2019)", "38770-MKF-L13", "0", "FFFF8", "Keihin", 512, "0102490501"),
        EcuProfileSpec("MKF", "CBR1000RR SP / Fireblade (2017-2019)", "38770-MKF-D43", "0", "FFFF8", "Keihin", 512, "0102490101"),
        EcuProfileSpec("MKFA", "CBR1000RR SP / Fireblade (2017-2019)", "38770-MKFA-A22", "0", "FFFF8", "Keihin", 512, "0103380D01"),
        EcuProfileSpec("MKFA", "CBR1000RR SP / Fireblade (2017-2019)", "38770-MKFA-DK2", "0", "FFFF8", "Keihin", 512, "0103380101"),
        EcuProfileSpec("NLR", "Honda Generic ECM", "38770-NLR-B31", "0", "3FFF8", "Keihin", 256, "01005EFD74"),
        EcuProfileSpec("MKFA", "CBR1000RR SP / Fireblade (2017-2019)", "38770-MKFA-D72", "0", "FFFF8", "Keihin", 512, "0102850111"),
        EcuProfileSpec("MKF", "CBR1000RR SP / Fireblade (2017-2019)", "38770-MKF-D72", "0", "FFFF8", "Keihin", 512, "0102850101"),
        EcuProfileSpec("NLS", "Honda Generic ECM", "38770-NLS-000", "0", "FFFF8", "Keihin", 512, "01028501FF"),
        EcuProfileSpec("KTY", "Honda Generic ECM", "38770-KTY-H52", "0", "DFEF", "Keihin", 64, "0100C60102"),
        EcuProfileSpec("K98", "CB150R Neo Sports Cafe (2017-2024)", "38770-K98-E02", "8000", "0", "Keihin", 128, "0102A10101"),
        EcuProfileSpec("KPP", "CBR150R (2011-2015)", "38770-KPP-N02", "0", "DFEF", "Keihin", 64, "0100FA1001"),
        EcuProfileSpec("KPP", "CBR150R (2011-2015)", "38770-KPP-602", "0", "DFEF", "Keihin", 64, "0101110F01"),
        EcuProfileSpec("K45", "CBR150R LED (2016-2024)", "38770-K45-N01", "8000", "0", "Keihin", 128, "0101B10F01"),
        EcuProfileSpec("K45", "CBR150R LED (2016-2024)", "38770-K45-N42", "8000", "0", "Keihin", 128, "0102040F01"),
        EcuProfileSpec("K94", "CBR150R (Indonesia)", "38770-K94-T02", "8000", "0", "Keihin", 128, "0102A00D01"),
        EcuProfileSpec("K45", "CBR150R LED (2016-2024)", "38770-K45-NA1", "8000", "0", "Keihin", 128, "0103250F01"),
        EcuProfileSpec("K45", "CBR150R LED (2016-2024)", "38770-K45-NA1", "8000", "0", "Keihin", 128, "0103250F11"),
        EcuProfileSpec("KPP", "CBR150R (2011-2015)", "38770-KPP-T03", "0", "DFEF", "Keihin", 64, "0100C50D02"),
        EcuProfileSpec("KYJ", "CBR250R (2011-2014)", "38770-KYJ-922", "0", "DFEF", "Keihin", 64, "0100B80502"),
        EcuProfileSpec("KYJ", "CBR250R (2011-2014)", "38770-KYJ-971", "0", "DFEF", "Keihin", 64, "0100B80F01"),
        EcuProfileSpec("K33", "CBR300R / CB300F (2014-2020)", "38770-K33-N03", "E0000", "B000", "Keihin", 1024, "0101790F02"),
        EcuProfileSpec("K33", "CBR300R / CB300F (2014-2020)", "38770-K33-D22", "E0000", "B000", "Keihin", 1024, "0101790101"),
        EcuProfileSpec("KYJ", "CBR250R (2011-2014)", "38770-KYJ-R11", "0", "18FFE", "Keihin", 64, "0101320671"),
        EcuProfileSpec("K64", "Honda Generic ECM", "38770-K64-J01", "0", "7FFF8", "Keihin", 512, "0101E40601"),
        EcuProfileSpec("K64", "Honda Generic ECM", "38770-K64-N04", "0", "7FFF8", "Keihin", 512, "0101E40F03"),
        EcuProfileSpec("K64", "Honda Generic ECM", "38770-K64-N01", "0", "7FFF8", "Keihin", 512, "0101E40F11"),
        EcuProfileSpec("K64", "Honda Generic ECM", "38770-K64-NB1", "0", "7FFF8", "Keihin", 512, "0103DC0F01"),
        EcuProfileSpec("K33", "CBR300R / CB300F (2014-2020)", "38770-K33-D02", "E0000", "B000", "Keihin", 1024, "0101740101"),
        EcuProfileSpec("KOA", "Honda Generic ECM", "38770-KOA-T11", "8000", "0", "Keihin", 128, "0102B70D02"),
        EcuProfileSpec("MGZ", "CBR500R / CB500F / CB500X (2013-2015)", "38770-MGZ-U02", "0", "3FFF8", "Keihin", 256, "0101250701"),
        EcuProfileSpec("MJW", "CBR500R / CB500F / CB500X (2016-2018)", "38770-MJW-N11", "0", "3FFF8", "Keihin", 256, "0101DD0F01"),
        EcuProfileSpec("MJW", "CBR500R / CB500F / CB500X (2016-2018)", "38770-MJW-T11", "0", "3FFF8", "Keihin", 256, "0101DD0D01"),
        EcuProfileSpec("MJW", "CBR500R / CB500F / CB500X (2016-2018)", "38770-MJW-AQ1", "0", "3FFF8", "Keihin", 256, "0102F20511"),
        EcuProfileSpec("MJW", "CBR500R / CB500F / CB500X (2016-2018)", "38770-MJW-DR1", "0", "3FFF8", "Keihin", 256, "0102F20111"),
        EcuProfileSpec("MGM", "Honda Generic ECM", "38770-MGM-D11", "0", "3FFF8", "Keihin", 256, "0100E00101"),
        EcuProfileSpec("MEE", "Honda Generic ECM", "38770-MEE-622", "0", "3FFE0", "Keihin", 64, "0100020302"),
        EcuProfileSpec("MEE", "Honda Generic ECM", "38770-MEE-612", "0", "3FFE0", "Keihin", 64, "0100020202"),
        EcuProfileSpec("MEE", "Honda Generic ECM", "38770-MEE-613", "0", "3FFE0", "Keihin", 64, "0100020203"),
        EcuProfileSpec("MEE", "Honda Generic ECM", "38770-MEE-F02", "0", "3FFFC", "Keihin", 256, "01001B0301"),
        EcuProfileSpec("MEE", "Honda Generic ECM", "38770-MEE-D01", "0", "3FFFC", "Keihin", 256, "01001B0101"),
        EcuProfileSpec("MEE", "Honda Generic ECM", "38770-MEE-A02", "0", "3FFFC", "Keihin", 256, "01001B0401"),
        EcuProfileSpec("MFJ", "Honda Generic ECM", "38770-MFJ-D04", "0", "3FFF8", "Keihin", 256, "0100330103"),
        EcuProfileSpec("MFJ", "Honda Generic ECM", "38770-MFJ-F03", "0", "3FFF8", "Keihin", 256, "0100330302"),
        EcuProfileSpec("MFJ", "Honda Generic ECM", "38770-MFJ-D42", "0", "3FFF8", "Keihin", 256, "01007C0102"),
        EcuProfileSpec("MJC", "Honda Generic ECM", "38770-MJC-D01", "0", "3FFF8", "Keihin", 256, "0101420101"),
        EcuProfileSpec("MJC", "Honda Generic ECM", "38770-MJC-A01", "0", "3FFF8", "Keihin", 256, "0101420401"),
        EcuProfileSpec("N1A", "Honda Generic ECM", "38770-N1A-D00", "0", "3FFF8", "Keihin", 256, "0100330171"),
        EcuProfileSpec("N1A", "Honda Generic ECM", "38770-N1A-D11", "0", "3FFF8", "Keihin", 256, "0101420171"),
        EcuProfileSpec("MJE", "CBR650F / CB650F (2014-2018)", "38770-MJE-A02", "0", "3FFF8", "Keihin", 256, "01014E0401"),
        EcuProfileSpec("MJE", "CBR650F / CB650F (2014-2018)", "38770-MJE-T15", "0", "3FFF8", "Keihin", 256, "01014E0D03"),
        EcuProfileSpec("MJE", "CBR650F / CB650F (2014-2018)", "38770-MJE-T52", "0", "3FFF8", "Keihin", 256, "01019C0D02"),
        EcuProfileSpec("MJE", "CBR650F / CB650F (2014-2018)", "38770-MJE-S11", "0", "3FFF8", "Keihin", 256, "0102101011"),
        EcuProfileSpec("MJE", "CBR650F / CB650F (2014-2018)", "38770-MJE-VB1", "0", "7FFF8", "Keihin", 512, "01027D0701"),
        EcuProfileSpec("MJE", "CBR650F / CB650F (2014-2018)", "38770-MJE-BB1", "0", "7FFF8", "Keihin", 512, "01027D0101"),
        EcuProfileSpec("MJE", "CBR650F / CB650F (2014-2018)", "38770-MJE-HB3", "0", "7FFF8", "Keihin", 512, "01027D0E02"),
        EcuProfileSpec("MKN", "CBR650R / CB650R (2019-2024)", "38770-MKN-D11", "0", "7FFF8", "Keihin", 512, "01031A0101"),
        EcuProfileSpec("MKN", "CBR650R / CB650R (2019-2024)", "38770-MKN-U11", "0", "7FFF8", "Keihin", 512, "01031A1801"),
        EcuProfileSpec("MKN", "CBR650R / CB650R (2019-2024)", "38770-MKN-T11", "0", "7FFF8", "Keihin", 512, "01031A0D01"),
        EcuProfileSpec("MKN", "CBR650R / CB650R (2019-2024)", "38770-MKN-HB2", "0", "7FFF8", "Keihin", 512, "0103BE0E01"),
        EcuProfileSpec("MKN", "CBR650R / CB650R (2019-2024)", "38770-MKN-DB1", "0", "7FFF8", "Keihin", 512, "01031A1201"),
        EcuProfileSpec("MKN", "CBR650R / CB650R (2019-2024)", "38770-MKN-L32", "0", "7FFF8", "Keihin", 512, "01031A0501"),
        EcuProfileSpec("MKG", "Honda Generic ECM", "38770-MKG-N52", "0", "3FFF8", "Keihin", 256, "01025C0F01"),
        EcuProfileSpec("MJP", "Honda Generic ECM", "38770-MJP-DA1", "0", "7FFF8", "Keihin", 512, "0102560101"),
        EcuProfileSpec("KYK", "Honda Generic ECM", "38770-KYK-D12", "8000", "0", "Keihin", 128, "0102DE0501"),
        EcuProfileSpec("K28", "Honda Generic ECM", "38770-K28-A62", "8000", "0", "Keihin", 128, "0102DD0501"),
        EcuProfileSpec("K84", "Honda Generic ECM", "38770-K84-901", "8000", "0", "Keihin", 128, "0102320F01"),
        EcuProfileSpec("K99", "Honda Generic ECM", "38770-K99-B02", "E0000", "B000", "Keihin", 1024, "0103160801"),
        EcuProfileSpec("KZZ", "CRF250L / CRF250M / CRF250 Rally", "38770-KZZ-902", "E0000", "B000", "Keihin", 1024, "01011A0D01"),
        EcuProfileSpec("KZZ", "CRF250L / CRF250M / CRF250 Rally", "38770-KZZ-914", "E0000", "B000", "Keihin", 1024, "01011A0503"),
        EcuProfileSpec("KZZ", "CRF250L / CRF250M / CRF250 Rally", "38770-KZZ-J01", "8000", "0", "Keihin", 128, "0102360D01"),
        EcuProfileSpec("KZZ", "CRF250L / CRF250M / CRF250 Rally", "38770-KZZ-J81", "8000", "0", "Keihin", 128, "0102360101"),
        EcuProfileSpec("KZZ", "CRF250L / CRF250M / CRF250 Rally", "38770-KZZ-A22", "E0000", "B000", "Keihin", 1024, "01015B0D01"),
        EcuProfileSpec("K95", "Honda Generic ECM", "38770-K95-A41", "E0000", "B000", "Keihin", 1024, "0102890101"),
        EcuProfileSpec("KZZ", "CRF250L / CRF250M / CRF250 Rally", "38770-KZZ-L41", "8000", "0", "Keihin", 128, "0102360F01"),
        EcuProfileSpec("K1T", "CRF300L / CRF300 Rally (2021-2024)", "38770-K1T-T01", "8000", "0", "Keihin", 128, "0104070D01"),
        EcuProfileSpec("K1T", "CRF300L / CRF300 Rally (2021-2024)", "38770-K1T-A11", "8000", "0", "Keihin", 128, "0104070501"),
        EcuProfileSpec("MKE", "Honda Generic ECM", "38770-MKE-A71", "E0000", "B000", "Keihin", 1024, "0102E80501"),
        EcuProfileSpec("MKE", "Honda Generic ECM", "38770-MKE-AF3", "C000", "0", "Keihin", 128, "0103B60503"),
        EcuProfileSpec("MKE", "Honda Generic ECM", "38770-MKE-A81", "E0000", "B000", "Keihin", 1024, "0102E90501"),
        EcuProfileSpec("K47", "Honda Generic ECM", "38770-K47-M01", "8000", "0", "Keihin", 128, "0103261801"),
        EcuProfileSpec("MEW", "Honda Generic ECM", "38770-MEW-D41", "0", "3FFF8", "Keihin", 256, "01009C0101"),
        EcuProfileSpec("K76", "Honda Generic ECM", "38770-K76-M02", "8000", "0", "Keihin", 128, "01029E1801"),
        EcuProfileSpec("K76", "Honda Generic ECM", "38770-K76-T62", "8000", "0", "Keihin", 128, "0102B50D01"),
        EcuProfileSpec("MFT", "Honda Generic ECM", "38770-MFT-642", "0", "3FFF8", "Keihin", 256, "01008F0101"),
        EcuProfileSpec("MGF", "Honda Generic ECM", "38770-MGF-D12", "0", "3FFF8", "Keihin", 256, "0100ED0101"),
        EcuProfileSpec("KYZ", "Wave 125i ปลาวาฬ (2012-2017)", "38770-KYZ-T03", "4000", "7600", "Keihin", 64, "0100FB0E02"),
        EcuProfileSpec("KYZ", "Wave 125i ปลาวาฬ (2012-2017)", "38770-KYZ-V21", "4000", "7600", "Keihin", 64, "01010C1101"),
        EcuProfileSpec("KYZ", "Wave 125i ปลาวาฬ (2012-2017)", "38770-KYZ-V71", "4000", "7600", "Keihin", 64, "01015F1101"),
        EcuProfileSpec("K73", "Wave 125i LED (2018-2022)", "38770-K73-V42", "8000", "0", "Keihin", 128, "0103141101"),
        EcuProfileSpec("K0J", "Honda Generic ECM", "30400-K0J-N01", "0", "3FFF8", "Keihin", 256, "0103110F01"),
        EcuProfileSpec("K26", "MSX 125 / MSX SF / Grom 125 (2013-2020)", "38770-K26-911", "4000", "7600", "Keihin", 64, "0101350501"),
        EcuProfileSpec("K26", "MSX 125 / MSX SF / Grom 125 (2013-2020)", "38770-K26-931", "4000", "7600", "Keihin", 64, "0101350101"),
        EcuProfileSpec("K26", "MSX 125 / MSX SF / Grom 125 (2013-2020)", "38770-K26-B13", "8000", "0", "Keihin", 128, "0102130501"),
        EcuProfileSpec("K26", "MSX 125 / MSX SF / Grom 125 (2013-2020)", "38770-K26-C31", "8000", "0", "Keihin", 128, "0102570501"),
        EcuProfileSpec("K56", "Sonic 150R / Winner 150 / Supra GTR 150", "38770-K56-N11", "8000", "0", "Keihin", 128, "0101CA0F01"),
        EcuProfileSpec("K56", "Sonic 150R / Winner 150 / Supra GTR 150", "38770-K56-NJ1", "8000", "0", "Keihin", 128, "0103920F01"),
        EcuProfileSpec("MKA", "Honda Generic ECM", "38770-MKA-D71", "0", "7FFF8", "Keihin", 512, "0801DF0101"),
        EcuProfileSpec("GGE", "Honda Generic ECM", "38770-GGE-941", "0", "DFEF", "Keihin", 64, "01006D1101"),
        EcuProfileSpec("GGE", "Honda Generic ECM", "38770-GGE-901", "0", "DFEF", "Keihin", 64, "0100B41101"),
        EcuProfileSpec("KYE", "Honda Generic ECM", "38770-KYE-942", "4000", "7600", "Keihin", 64, "0101700F01"),
        EcuProfileSpec("K0F", "Monkey 125 (2018-2020)", "38770-K0F-A01", "8000", "0", "Keihin", 128, "0102CA0501"),
        EcuProfileSpec("MJL", "Honda Generic ECM", "38770-MJL-Y11", "0", "3FFF8", "Keihin", 256, "0101820101"),
        EcuProfileSpec("MCG", "Honda Generic ECM", "38770-MCG-602", "E0000", "B000", "Keihin", 1024, "0101220801"),
        EcuProfileSpec("K87", "Rebel 300 (2017-2024)", "38770-K87-T52", "E0000", "B000", "Keihin", 1024, "01025A0D01"),
        EcuProfileSpec("K03", "Wave 110i (2019-2020)", "38770-K03-N32", "8000", "0", "Keihin", 128, "0101870F02"),
        EcuProfileSpec("K58", "Wave 110i / Wave 125i (2020-2022)", "38770-K58-N41", "8000", "0", "Keihin", 128, "0102E40F01"),
        EcuProfileSpec("KPG", "Honda Generic ECM", "38770-KPG-H01", "8000", "0", "Keihin", 128, "0102D71F01"),
        EcuProfileSpec("K56", "Sonic 150R / Winner 150 / Supra GTR 150", "38770-K56-M01", "8000", "0", "Keihin", 128, "0101CD1801"),
        EcuProfileSpec("K56", "Sonic 150R / Winner 150 / Supra GTR 150", "38770-K56-M91", "8000", "0", "Keihin", 128, "0103931801"),
        EcuProfileSpec("HR6", "Honda Generic ECM", "38770-HR6-MO2", "0", "7FFF8", "Keihin", 512, "0D02FC0401"),
        EcuProfileSpec("K2F", "Scoopy-i (2021-2024)", "30400-K2F-N11", "0", "3FFF8", "Keihin", 256, "0104130F01"),
        EcuProfileSpec("K93", "Honda Generic ECM", "30400-K93-N01", "0", "3FFF8", "Keihin", 256, "01027F0F01"),
        EcuProfileSpec("K93", "Honda Generic ECM", "30400-K93-T01", "0", "3FFF8", "Keihin", 256, "0102810D01"),
        EcuProfileSpec("GFM", "Honda Generic ECM", "38770-GFM-601", "0", "DFEF", "Keihin", 64, "01006B0801"),
        EcuProfileSpec("KTW", "Honda Generic ECM", "38770-KTW-903", "0", "DFEF", "Keihin", 64, "0100450103"),
        EcuProfileSpec("KTW", "Honda Generic ECM", "38770-KTW-B02", "0", "DFEF", "Keihin", 64, "0100530101"),
        EcuProfileSpec("K53", "Honda Generic ECM", "38770-K53-DB2", "0", "DFEF", "Keihin", 64, "0102B10101"),
        EcuProfileSpec("K53", "Honda Generic ECM", "38770-K53-D03", "8000", "0", "Keihin", 128, "0101B80103"),
        EcuProfileSpec("K56", "Sonic 150R / Winner 150 / Supra GTR 150", "38770-K56-N01", "8000", "0", "Keihin", 128, "0101C90F01"),
        EcuProfileSpec("KZL", "Spacy-i / Zoomer-X (2012-2014)", "38770-KZL-E12", "4000", "7600", "Keihin", 64, "0101021101"),
        EcuProfileSpec("KZL", "Spacy-i / Zoomer-X (2012-2014)", "38770-KZL-C31", "4000", "7600", "Keihin", 64, "01011E0F01"),
        EcuProfileSpec("K0G", "Super Cub 110 Pro", "38770-K0G-962", "8000", "0", "Keihin", 128, "01030E0501"),
        EcuProfileSpec("KZV", "Dream Super Cub 110 (2013-2017)", "38770-KZV-A61", "8000", "0", "Keihin", 128, "0101BA0D01"),
        EcuProfileSpec("KYZ", "Wave 125i ปลาวาฬ (2012-2017)", "38770-KYZ-713", "4000", "7600", "Keihin", 64, "0100E80F02"),
        EcuProfileSpec("HL6", "Honda Generic ECM", "38770-HL6-A05", "0", "7FFF8", "Keihin", 512, "0801EB0502"),
        EcuProfileSpec("K46", "Honda Generic ECM", "30400-K46-N21", "0", "3FFF8", "Keihin", 256, "0101FA0F01"),
        EcuProfileSpec("K46", "Honda Generic ECM", "30400-K46-N31", "0", "3FFF8", "Keihin", 256, "0101F80F01"),
        EcuProfileSpec("K46", "Honda Generic ECM", "30400-K46-NA1", "0", "3FFF8", "Keihin", 256, "0102F80F01"),
        EcuProfileSpec("K18", "Honda Generic ECM", "38770-K18-902", "4000", "7600", "Keihin", 64, "0101200F01"),
        EcuProfileSpec("K18", "Honda Generic ECM", "38770-K18-941", "8000", "0", "Keihin", 128, "0101F30F01"),
        EcuProfileSpec("MGE", "Honda Generic ECM", "38770-MGE-623", "0", "7FFF8", "Keihin", 512, "0100AA0301"),
        EcuProfileSpec("MGE", "Honda Generic ECM", "38770-MGE-D01", "0", "7FFF8", "Keihin", 512, "0101030101"),
        EcuProfileSpec("MGE", "Honda Generic ECM", "38770-MGE-F11", "0", "7FFF8", "Keihin", 512, "0101030301"),
        EcuProfileSpec("MGE", "Honda Generic ECM", "38770-MGE-D41", "0", "7FFF8", "Keihin", 512, "0101190101"),
        EcuProfileSpec("MGE", "Honda Generic ECM", "38770-MGE-F02", "0", "7FFF8", "Keihin", 512, "0800AB0301"),
        EcuProfileSpec("MGE", "Honda Generic ECM", "38770-MGE-D02", "0", "7FFF8", "Keihin", 512, "0800AB0101"),
        EcuProfileSpec("MGH", "Honda Generic ECM", "38770-MGH-641", "0", "7FFF8", "Keihin", 512, "0100FC0101"),
        EcuProfileSpec("MGH", "Honda Generic ECM", "38770-MGH-D21", "0", "7FFF8", "Keihin", 512, "0801040101"),
        EcuProfileSpec("MGH", "Honda Generic ECM", "38770-MGH-F21", "0", "7FFF8", "Keihin", 512, "0801040301"),
        EcuProfileSpec("MGH", "Honda Generic ECM", "38770-MGH-N12", "0", "7FFF8", "Keihin", 512, "08017D0101"),
        EcuProfileSpec("MGH", "Honda Generic ECM", "38770-MGH-M12", "0", "7FFF8", "Keihin", 512, "08017D0301"),
        EcuProfileSpec("MFR", "Honda Generic ECM", "38770-MFR-642", "0", "3FFF8", "Keihin", 256, "01007B0101"),
        EcuProfileSpec("KWW", "Wave 110i (2009-2018)", "38770-KWW-643", "4000", "7600", "Keihin", 64, "0100CE0D02"),
        EcuProfileSpec("K03", "Wave 110i (2019-2020)", "38770-K03-H01", "8000", "0", "Keihin", 128, "0101880D01"),
        EcuProfileSpec("G90", "Honda Generic ECM", "38770-G90-V02", "8000", "0", "Keihin", 128, "0102681101"),
        EcuProfileSpec("K58", "Wave 110i / Wave 125i (2020-2022)", "38770-K58-TC2", "8000", "0", "Keihin", 128, "01034C0D01"),
        EcuProfileSpec("K58", "Wave 110i / Wave 125i (2020-2022)", "38770-K58-T81", "8000", "0", "Keihin", 128, "0102B90D01"),
        EcuProfileSpec("K73", "Wave 125i LED (2018-2022)", "38770-K73-M41", "8000", "0", "Keihin", 128, "0102AD1801"),
        EcuProfileSpec("K56", "Sonic 150R / Winner 150 / Supra GTR 150", "38770-K56-V01", "8000", "0", "Keihin", 128, "0101CB1101"),
        EcuProfileSpec("K56", "Sonic 150R / Winner 150 / Supra GTR 150", "38770-K56-V51", "8000", "0", "Keihin", 128, "0103591101"),
        EcuProfileSpec("MKH", "X-ADV 750 / Forza 750 / NC750X (2017-2024)", "38770-MKH-D01", "0", "7FFF8", "Keihin", 512, "08024C0101"),
        EcuProfileSpec("MKH", "X-ADV 750 / Forza 750 / NC750X (2017-2024)", "38770-MKH-D22", "0", "7FFF8", "Keihin", 512, "08024CFFFF"),
        EcuProfileSpec("MKH", "X-ADV 750 / Forza 750 / NC750X (2017-2024)", "38770-MKH-C02", "0", "7FFF8", "Keihin", 512, "0802E60E01"),
        EcuProfileSpec("MKH", "X-ADV 750 / Forza 750 / NC750X (2017-2024)", "38770-MKH-C03", "0", "7FFF8", "Keihin", 512, "0802E60E02"),
        EcuProfileSpec("MKH", "X-ADV 750 / Forza 750 / NC750X (2017-2024)", "38770-MKH-D23", "0", "7FFF8", "Keihin", 512, "0802E60102"),
        EcuProfileSpec("MKH", "X-ADV 750 / Forza 750 / NC750X (2017-2024)", "38770-MKH-D42", "0", "7FFF8", "Keihin", 512, "08024CFFFE"),
        EcuProfileSpec("KWT", "Honda Generic ECM", "38770-KWT-703", "E0000", "B000", "Keihin", 1024, "0101310802"),
        EcuProfileSpec("K73", "Wave 125i LED (2018-2022)", "38770-K73-M62", "8000", "0", "Keihin", 128, "01033F1801"),
        EcuProfileSpec("K3F", "Wave 125i (2023-2024)", "38770-K3F-T01", "8000", "0", "Keihin", 128, "01047B0D01"),
        EcuProfileSpec("KYZ", "Wave 125i ปลาวาฬ (2012-2017)", "38770-KYZ-T41", "8000", "0", "Keihin", 128, "0101B30D01"),
        EcuProfileSpec("K73", "Wave 125i LED (2018-2022)", "38770-K73-T32", "8000", "0", "Keihin", 128, "0102580D01"),
        EcuProfileSpec("K73", "Wave 125i LED (2018-2022)", "38770-K73-T61", "8000", "0", "Keihin", 128, "01033E0D01"),
        EcuProfileSpec("K73", "Wave 125i LED (2018-2022)", "38770-K73-TC2", "8000", "0", "Keihin", 128, "01034F1801"),
        EcuProfileSpec("K2J", "Wave 110i / Super Cub (2021-2024)", "38770-K2J-TH1", "8000", "0", "Keihin", 128, "0105550D01"),
        EcuProfileSpec("K2J", "Wave 110i / Super Cub (2021-2024)", "38770-K2J-T01", "8000", "0", "Keihin", 128, "01040F0D01"),
        EcuProfileSpec("K1M", "Wave 110i AT", "38770-K1M-T01", "8000", "0", "Keihin", 128, "0103FA0D01"),
        EcuProfileSpec("K26", "MSX 125 / MSX SF / Grom 125 (2013-2020)", "38770-K26-B02", "8000", "0", "Keihin", 128, "0102130D01"),
        EcuProfileSpec("KWW", "Wave 110i (2009-2018)", "38770-KWW-641", "4000", "7600", "Keihin", 64, "0100CE0D01"),
        EcuProfileSpec("KWW", "Wave 110i (2009-2018)", "38770-KWW-642", "4000", "7600", "Keihin", 64, "0100CE0D01"),
        EcuProfileSpec("KWW", "Wave 110i (2009-2018)", "38770-KWW-643", "4000", "7600", "Keihin", 64, "0100CE0D01"),
        EcuProfileSpec("K03", "Wave 110i (2019-2020)", "38770-K03-T61", "4000", "7600", "Keihin", 64, "0101610D01"),
        EcuProfileSpec("K04", "Forza 300 (2013-2017)", "38770-K04-901", "0", "7FFF8", "Keihin", 512, "01016A0101"),
        EcuProfileSpec("K0B", "Forza 300 (2018-2020)", "38770-K0B-T01", "0", "7FFF8", "Keihin", 512, "0102DA0D01"),
        EcuProfileSpec("K1B", "Forza 350 / ADV 350 (2020-2022)", "38770-K1B-T01", "0", "7FFF8", "Keihin", 512, "0103E80D01"),
        EcuProfileSpec("K1B", "Forza 350 / ADV 350 (2022-2023)", "38770-K1B-T02", "0", "7FFF8", "Keihin", 512, "01041A0D01"),
        EcuProfileSpec("K1B", "Forza 350 (2023-2024)", "38770-K1B-T21", "0", "7FFF8", "Keihin", 512, "01049B0D01"),
        EcuProfileSpec("K1B", "Forza 350 (2024-2025 TFT)", "38770-K1B-T61", "0", "7FFF8", "Keihin", 512, "01053A0D01"),
        EcuProfileSpec("K1ZF", "PCX 160 e:HEV / ABS (2021-2024)", "30400-K1ZF-T01 PCX160 NOABS", "0", "AUTO", "Shindengen", 512, "0103D00D01"),
        EcuProfileSpec("K1ZF", "PCX 160 e:HEV / ABS (2021-2024)", "30400-K1ZF-T11 PCX160ABS", "0", "AUTO", "Shindengen", 512, "0103CF0D01"),
        EcuProfileSpec("K1ZP", "PCX 160 e:HEV / ABS (2021-2024)", "30400-K1ZP-T51 PCX160 NOABS", "0", "AUTO", "Shindengen", 512, "0105050D01"),
        EcuProfileSpec("K1ZP", "PCX 160 e:HEV / ABS (2021-2024)", "30400-K1ZP-T71 PCX160 ABS", "0", "AUTO", "Shindengen", 512, "0105040D01"),
        EcuProfileSpec("K2TA", "Lead 125 4V (2022-2024)", "30400-K2TA-T02 LEAD125 4V", "0", "AUTO", "Shindengen", 512, "0104780D01"),
        EcuProfileSpec("K0WF", "ADV 150 / ADV 160 (2019-2024)", "30400-K0WF-T01 ADV150", "0", "AUTO", "Shindengen", 384, "01037C0D01"),
        EcuProfileSpec("K0WM", "ADV 150 / ADV 160 (2019-2024)", "30400-K0WM-TA1 ADV160", "0", "AUTO", "Shindengen", 512, "01048E0D01"),
        EcuProfileSpec("K2SF", "Scoopy-i (2013-2016)", "30400-K2SF-T01 CLICK160", "0", "AUTO", "Shindengen", 512, "01046D0D01"),
        EcuProfileSpec("K2VH", "Click 125i (2023-2024)", "30400-K2VH-T11 CLICK125 2023", "0", "AUTO", "Shindengen", 384, "0104DC0D01"),
        EcuProfileSpec("K3MF", "Giorno+ 125 (2023-2024)", "30400-K3MF-T01 GIONRO 125", "0", "AUTO", "Shindengen", 512, "01052A0D01"),
        EcuProfileSpec("K20J", "Zoomer-X (2015-2020)", "30400-K20J-T21 Zoomer-X 2015-2017", "0", "AUTO", "Shindengen", 256, "0101FF0D01"),
        EcuProfileSpec("K36F", "PCX 150 (2014-2017)", "30400-K36F-T01 PCX150 2014-2015", "0", "AUTO", "Shindengen", 256, "0101990D01"),
        EcuProfileSpec("K36S", "PCX 150 (2014-2017)", "30400-K36S-T31  PCX150 2016-2017", "0", "AUTO", "Shindengen", 384, "0102180D01"),
        EcuProfileSpec("K59K", "Click 150i (2018-2022)", "30400-K59K-T11 Click150 2018-2020", "0", "AUTO", "Shindengen", 384, "0103070D01"),
        EcuProfileSpec("K60F", "Click 125i LED (2018-2022)", "30400-K60F-T01 Click125 2014-2015", "0", "AUTO", "Shindengen", 256, "0101D00D01"),
        EcuProfileSpec("K60S", "Click 125i LED (2018-2022)", "30400-K60S-T71 Click125 2016-2017", "0", "AUTO", "Shindengen", 384, "01030A0D01"),
        EcuProfileSpec("K97F", "PCX 150 Smart Key (2018-2020)", "30400-K97F-T PCX150 2017-2019", "0", "AUTO", "Shindengen", 384, "010102990D01")
    )

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Load the full 489-record ECU catalog before any identification lookup.
        // Without this, EcmDatabase falls back to its three synthetic sample rows.
        EcmDatabase.init(applicationContext)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enableEdgeToEdge()
        setContent {
            CandsTechEcuFlasherSuite()
        }
    }
}

@Composable
fun CandsTechEcuFlasherSuite() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val usbManager = remember(context) { context.getSystemService(Context.USB_SERVICE) as UsbManager }
    val ecuEngine = remember(usbManager) { HondaProtocolEngine(usbManager) }
    val ecuEngineAdapterOpen by ecuEngine.isAdapterOpen.collectAsState()
    var elmConnected by remember { mutableStateOf(false) }
    var elmSession by remember { mutableStateOf<Elm327Session?>(null) }
    var elmPort by remember { mutableStateOf<UsbSerialDevice?>(null) }
    var selectedUsbDeviceId by remember { mutableIntStateOf(-1) }
    var selectedInterfaceMode by remember { mutableStateOf("AUTO") }
    val adapterUiOpen = ecuEngineAdapterOpen || elmConnected
    val ecuEngineEcuIdentified by ecuEngine.isEcuIdentified.collectAsState()
    val ecuEngineEcuAlive by ecuEngine.isEcuAlive.collectAsState()
    val engineTelemetry by ecuEngine.liveTelemetry.collectAsState()
    val engineLiveDataState by ecuEngine.liveDataState.collectAsState()
    var liveMonitorRequested by remember { mutableStateOf(false) }
    val prefs = remember { context.getSharedPreferences("candstech_flasher_prefs", Context.MODE_PRIVATE) }

    var customFolderUriStr by remember { mutableStateOf(prefs.getString("custom_bin_folder_uri", null)) }
    var activeFolderLabel by remember {
        mutableStateOf(prefs.getString("custom_bin_folder_label", "Documents/candstech") ?: "Documents/candstech")
    }

    val xdfTables = remember { mutableStateMapOf<String, XDFTableInfo>() }
    var selectedTableKey by remember { mutableStateOf<String?>(null) }
    var binBytes by remember { mutableStateOf<ByteArray?>(null) }
    var binName by remember { mutableStateOf("No .BIN loaded") }
    var xdfName by remember { mutableStateOf("Default Keihin Map") }
    var checksumHex by remember { mutableStateOf("0x0000") }
    var tableRefreshTick by remember { mutableIntStateOf(0) }
    var selectedRomSizeKb by remember { mutableIntStateOf(64) }

    var editingCellCoord by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    var editingCellInput by remember { mutableStateOf("") }

    var connStatus by remember { mutableStateOf("DISCONNECTED") }
    var rpm by remember { mutableIntStateOf(0) }
    var tpsDeg by remember { mutableFloatStateOf(0f) }
    var ectTemp by remember { mutableIntStateOf(0) }
    var iatTemp by remember { mutableIntStateOf(0) }
    var mapKpa by remember { mutableIntStateOf(0) }
    var batVolt by remember { mutableFloatStateOf(0f) }
    var ecuSpeed by remember { mutableIntStateOf(0) }
    var topSpeed by remember { mutableIntStateOf(0) }
    var ecmIdHex by remember { mutableStateOf("BELUM TERBACA") }
    var detectedEcuProfile by remember { mutableStateOf<EcuProfileSpec?>(null) }
    var cachedEcmRawHex by remember { mutableStateOf("") }
    var cachedEcmRomKb by remember { mutableStateOf<Int?>(null) }
    var activeSensorTable by remember { mutableIntStateOf(0x17) }
    var dtcResultText by remember { mutableStateOf("Belum di-scan") }
    var showLiveModelPicker by remember { mutableStateOf(false) }
    var showSensorDiagnosis by remember { mutableStateOf(false) }
    var liveModelSearch by remember { mutableStateOf("") }
    var selectedLiveCatalogModel by remember { mutableStateOf<EcmModel?>(null) }
    val liveCatalogModels = remember { EcmDatabase.allModels.sortedBy { it.bikeName.lowercase(Locale.ROOT) } }
    val filteredLiveCatalogModels = remember(liveModelSearch, liveCatalogModels) {
        val q = liveModelSearch.trim().lowercase(Locale.ROOT)
        if (q.isEmpty()) liveCatalogModels else liveCatalogModels.filter {
            listOf(it.bikeName, it.partNumber, it.ecmId, it.id, it.manufacturer, it.yearRange)
                .any { value -> value.lowercase(Locale.ROOT).contains(q) }
        }
    }

    val logs = remember { mutableStateListOf("[SYS] CANDS TECH ECU Flasher (Dynamic ECU Identity + Read-Only Diagnostics) Ready.") }
    var serialPort by remember { mutableStateOf<UsbSerialDevice?>(null) }
    var usbConnection by remember { mutableStateOf<UsbDeviceConnection?>(null) }
    var activeTab by remember { mutableIntStateOf(0) }
    var lastEcuRxHex by remember { mutableStateOf("BELUM ADA RESPON ECU") }
    var totalRxBytesCount by remember { mutableIntStateOf(0) }
    var lastRxDiagLogMs by remember { mutableLongStateOf(0L) }

    val kLineRxQueue = remember { ConcurrentLinkedQueue<Byte>() }
    var isFlashingBusy by remember { mutableStateOf(false) }
    var flashProgress by remember { mutableFloatStateOf(0f) }
    var showWriteConfirmDialog by remember { mutableStateOf(false) }
    var keyCyclePrompt by remember { mutableStateOf<String?>(null) }
    var writeCountdownSec by remember { mutableIntStateOf(10) }

    fun bytesToHex(bytes: ByteArray, maxBytes: Int = 24): String {
        if (bytes.isEmpty()) return "(kosong)"
        val slice = if (bytes.size > maxBytes) bytes.copyOfRange(0, maxBytes) else bytes
        val hex = slice.joinToString(" ") { String.format(Locale.US, "%02X", it.toInt() and 0xFF) }
        return if (bytes.size > maxBytes) "$hex ... (+${bytes.size - maxBytes}B)" else hex
    }

    fun log(msg: String) {
        scope.launch(Dispatchers.Main) {
            if (logs.size > 120) logs.removeAt(0)
            logs.add(msg)
        }
    }

    LaunchedEffect(showWriteConfirmDialog) {
        if (showWriteConfirmDialog) {
            writeCountdownSec = 10
            while (writeCountdownSec > 0 && showWriteConfirmDialog) {
                delay(1000L)
                writeCountdownSec -= 1
            }
        }
    }

    LaunchedEffect(Unit) {
        if (xdfTables.isEmpty()) {
            BinParser.loadDefaultHondaKeihinTables(xdfTables)
            selectedTableKey = xdfTables.keys.firstOrNull()
        }
        try {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                @Suppress("DEPRECATION")
                val docDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "candstech")
                if (!docDir.exists()) docDir.mkdirs()
            }
            log("[DIR] Default: $activeFolderLabel")
        } catch (_: Exception) {
        }
    }

    // One sequential Live Data request per cycle. The next request starts only
    // after the previous transaction and its pacing delay have completed.
    LaunchedEffect(
        liveMonitorRequested,
        ecuEngineAdapterOpen,
        ecuEngineEcuIdentified,
        ecuEngineEcuAlive,
        elmConnected
    ) {
        if (!liveMonitorRequested) return@LaunchedEffect
        if (elmConnected || !ecuEngineAdapterOpen || !ecuEngineEcuIdentified ||
            !ecuEngineEcuAlive || !ecuEngine.isConnected.value || !ecuEngine.liveDataSupported
        ) {
            liveMonitorRequested = false
            log("[LIVE DATA] Monitor dihentikan: koneksi/identitas ECU atau kapabilitas Live Data tidak memenuhi syarat.")
            return@LaunchedEffect
        }

        var consecutiveFailures = 0
        var firstValidFrameLogged = false
        try {
            while (isActive && liveMonitorRequested && ecuEngine.isConnected.value && ecuEngine.isEcuAlive.value) {
                val startedAt = System.currentTimeMillis()
                val telemetry = try {
                    withContext(Dispatchers.IO) { ecuEngine.queryLiveData() }
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (error: Exception) {
                    log("[LIVE DATA] Request error: ${error.message ?: error.javaClass.simpleName}")
                    null
                }
                val transactionMs = (System.currentTimeMillis() - startedAt).coerceAtLeast(0L)

                if (telemetry?.isDataValid == true) {
                    consecutiveFailures = 0
                    if (!firstValidFrameLogged) {
                        firstValidFrameLogged = true
                        log("[LIVE DATA] Monitoring aktif. Tabel=${telemetry.activeTableHex}, RPM=${if (telemetry.isRpmAvailable) telemetry.engineRpm else "N/A"}, TPS=${if (telemetry.isTpsDegreesAvailable) String.format(Locale.US, "%.1f°", telemetry.tpsDegrees) else "N/A"}, ECT=${if (telemetry.isTempAvailable) "${telemetry.engineTempC}°C" else "N/A"}.")
                    }
                } else {
                    consecutiveFailures++
                    log("[LIVE DATA] Tidak ada frame valid (${consecutiveFailures}/${LivePollPolicy.MAX_CONSECUTIVE_FAILURES}); status=${ecuEngine.liveDataState.value}.")
                }

                if (LivePollPolicy.shouldStop(consecutiveFailures)) {
                    log("[LIVE DATA] Monitor dihentikan setelah ${LivePollPolicy.MAX_CONSECUTIVE_FAILURES} kegagalan berturut-turut.")
                    liveMonitorRequested = false
                    break
                }

                val waitMs = LivePollPolicy.nextDelayMs(transactionMs, consecutiveFailures)
                delay(waitMs)
            }
        } finally {
            if (!liveMonitorRequested) {
                log("[LIVE DATA] Monitoring berhenti.")
            }
        }
    }

    fun saveBinToActiveDefaultFolder(fileName: String, data: ByteArray): Boolean {
        val cleanFileName = if (fileName.endsWith(".bin", ignoreCase = true)) fileName else "$fileName.bin"
        val customUriStr = customFolderUriStr

        if (!customUriStr.isNullOrBlank()) {
            try {
                val treeUri = Uri.parse(customUriStr)
                val pickedDir = DocumentFile.fromTreeUri(context, treeUri)
                if (pickedDir != null && pickedDir.canWrite()) {
                    pickedDir.findFile(cleanFileName)?.delete()
                    val newFile = pickedDir.createFile("application/octet-stream", cleanFileName)
                    if (newFile != null) {
                        context.contentResolver.openOutputStream(newFile.uri)?.use { out ->
                            out.write(data)
                        }
                        log("[SAVE] -> $activeFolderLabel/$cleanFileName")
                        return true
                    }
                }
            } catch (e: Exception) {
                log("[WARN] Folder kustom error (${e.message}), ke Documents/candstech...")
            }
        }

        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, cleanFileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/octet-stream")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOCUMENTS + "/candstech")
                }
                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Files.getContentUri("external"), values)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { out -> out.write(data) }
                    log("[SAVE] -> Documents/candstech/$cleanFileName")
                    true
                } else {
                    log("[ERR] Gagal buat file di Documents/candstech")
                    false
                }
            } else {
                @Suppress("DEPRECATION")
                val docDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "candstech")
                if (!docDir.exists()) docDir.mkdirs()
                val outFile = File(docDir, cleanFileName)
                outFile.writeBytes(data)
                log("[SAVE] -> ${outFile.absolutePath}")
                true
            }
        } catch (e: Exception) {
            log("[ERR] Gagal simpan .BIN: ${e.message}")
            false
        }
    }

    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        uri?.let {
            try {
                val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                context.contentResolver.takePersistableUriPermission(it, flags)
                val docFile = DocumentFile.fromTreeUri(context, it)
                val folderTitle = docFile?.name ?: it.lastPathSegment?.substringAfterLast(':') ?: "CustomFolder"
                customFolderUriStr = it.toString()
                activeFolderLabel = folderTitle
                prefs.edit()
                    .putString("custom_bin_folder_uri", it.toString())
                    .putString("custom_bin_folder_label", folderTitle)
                    .apply()
                log("[DIR] Folder default: $folderTitle")
            } catch (e: Exception) {
                log("[ERR] Gagal kunci folder: ${e.message}")
            }
        }
    }

    fun resetToDocumentsCandsTech() {
        customFolderUriStr = null
        activeFolderLabel = "Documents/candstech"
        prefs.edit()
            .remove("custom_bin_folder_uri")
            .putString("custom_bin_folder_label", "Documents/candstech")
            .apply()
        log("[DIR] Reset ke Documents/candstech")
    }

    // Format pesan resmi HondaECU.py: mtype + [msgsize] + data + [checksum8bitHonda]
    // msgsize = 0x02 + mtype.size + data.size (total panjang seluruh frame termasuk checksum)
    fun formatHondaMessage(mtype: ByteArray, data: ByteArray = ByteArray(0)): ByteArray {
        val msgSize = 0x02 + mtype.size + data.size
        val withoutCsum = ByteArray(mtype.size + 1 + data.size)
        System.arraycopy(mtype, 0, withoutCsum, 0, mtype.size)
        withoutCsum[mtype.size] = (msgSize and 0xFF).toByte()
        if (data.isNotEmpty()) {
            System.arraycopy(data, 0, withoutCsum, mtype.size + 1, data.size)
        }
        val csum = BinParser.checksum8bitHonda(withoutCsum).toByte()
        return withoutCsum + csum
    }

    data class HondaResponse(
        val success: Boolean,
        val rmtype: ByteArray = ByteArray(0),
        val rml: Int = 0,
        val rdata: ByteArray = ByteArray(0),
        val rawRx: ByteArray = ByteArray(0),
        val errorNote: String = ""
    )

    // Mencari frame balasan Honda yang valid (lolos panjang & checksum8bitHonda) di dalam stream RX,
    // dengan membuang echo TX yang tergeser (seperti 60 00 60 06 00) dan mengunci header 0x02 / mtype!
    fun extractValidHondaReply(rawBytes: ByteArray, fullTx: ByteArray, ml: Int, expectHeader02: Boolean = false): ByteArray? {
        if (rawBytes.size < ml + 2) return null

        val candidateStarts = LinkedHashSet<Int>()
        // Prioritas 1: setelah panjang paket TX (karena half-duplex K-Line memantulkan TX di awal)
        if (rawBytes.size >= fullTx.size + ml + 2) {
            candidateStarts.add(fullTx.size)
        }
        // Prioritas 2: posisi byte 0x02 (header balasan standar ECU Honda Diag: 02 <len> <cmd> ...)
        for (idx in rawBytes.indices) {
            if ((rawBytes[idx].toInt() and 0xFF) == 0x02) {
                candidateStarts.add(idx)
            }
        }
        // Prioritas 3: semua posisi lain jika response menggunakan mtype khusus (misal 0x82 atau 0x0E)
        if (!expectHeader02) {
            for (idx in 0..(rawBytes.size - (ml + 2))) {
                candidateStarts.add(idx)
            }
        }

        for (start in candidateStarts) {
            val lenPos = start + ml
            if (lenPos >= rawBytes.size) continue
            val totalLen = rawBytes[lenPos].toInt() and 0xFF
            if (totalLen < ml + 2 || start + totalLen > rawBytes.size) continue

            val candidate = rawBytes.copyOfRange(start, start + totalLen)
            if (candidate.contentEquals(fullTx)) continue

            val withoutCsum = candidate.copyOfRange(0, candidate.size - 1)
            val expCsum = BinParser.checksum8bitHonda(withoutCsum)
            val actCsum = candidate.last().toInt() and 0xFF
            if (expCsum == actCsum) {
                return candidate
            }
        }
        return null
    }

    // Kirim perintah HondaECU & tunggu balasan (juga membuang echo yang tergeser bit jika tidak ada header balasan baru)
    suspend fun sendHondaCommand(
        port: UsbSerialDevice,
        mtype: ByteArray,
        data: ByteArray = ByteArray(0),
        retries: Int = 3,
        timeoutMs: Int = 240,
        verboseLog: Boolean = false,
        expectHeader02: Boolean = false
    ): HondaResponse {
        val fullTx = formatHondaMessage(mtype, data)
        val ml = mtype.size
        var attempt = 0

        while (attempt <= retries) {
            kLineRxQueue.clear()
            if (verboseLog) {
                log("[TX >] ${bytesToHex(fullTx)}")
            }
            port.write(fullTx)

            val minWaitBytes = fullTx.size + ml + 2
            var elapsed = 0
            while (kLineRxQueue.size < minWaitBytes && elapsed < timeoutMs) {
                delay(5)
                elapsed += 5
            }
            delay(40)

            val raw = mutableListOf<Byte>()
            while (kLineRxQueue.isNotEmpty()) {
                kLineRxQueue.poll()?.let { raw.add(it) }
            }

            if (raw.isEmpty()) {
                if (verboseLog) log("[RX <] TIMEOUT 0B (try ${attempt + 1})")
                attempt++
                continue
            }

            val rawArr = raw.toByteArray()
            val validFrame = extractValidHondaReply(rawArr, fullTx, ml, expectHeader02)

            if (validFrame == null) {
                if (verboseLog) {
                    log("[RX <] RAW (${rawArr.size}B): ${bytesToHex(rawArr)} (try ${attempt + 1})")
                }
                attempt++
                continue
            }

            val rmtype = validFrame.copyOfRange(0, ml)
            val rml = validFrame[ml].toInt() and 0xFF
            val rdata = validFrame.copyOfRange(ml + 1, validFrame.size - 1)
            val hexStr = bytesToHex(validFrame)
            withContext(Dispatchers.Main) {
                lastEcuRxHex = hexStr
                totalRxBytesCount += validFrame.size
            }
            if (verboseLog) {
                log("[RX <] OK (${validFrame.size}B): $hexStr")
            }
            return HondaResponse(
                success = true,
                rmtype = rmtype,
                rml = rml,
                rdata = rdata,
                rawRx = validFrame
            )
        }

        return HondaResponse(success = false, errorNote = "Max retries exceeded")
    }

    // Handshake CandsTech Diag (70ms break -> 120ms -> FE 04 FF FF -> 72 05 00 F0 99)
    suspend fun wakeupAndEnterDiagHonda(port: UsbSerialDevice): Boolean {
        log("[INIT] ISO 14230 Fast Init: 70ms Break + 130ms High -> FE 04 72 8C -> 72 05 00 F0 99...")
        port.setBreak(true)
        delay(70)
        port.setBreak(false)
        delay(130)
        kLineRxQueue.clear()

        // Tester Present / Fast Init Wake-up: FE 04 72 8C
        val tpResp = sendHondaCommand(
            port = port,
            mtype = byteArrayOf(0xFE.toByte()),
            data = byteArrayOf(0x72),
            retries = 1,
            timeoutMs = 260,
            verboseLog = true,
            expectHeader02 = true
        )
        if (tpResp.success) {
            log("[INIT] Tester Present OK: ${bytesToHex(tpResp.rawRx)}")
        }

        val initResp = sendHondaCommand(
            port = port,
            mtype = byteArrayOf(0x72),
            data = byteArrayOf(0x00, 0xF0.toByte()),
            retries = 2,
            timeoutMs = 320,
            verboseLog = true,
            expectHeader02 = true
        )
        if (initResp.success) {
            log("[INIT] ECU Terbangun & Merespons: ${bytesToHex(initResp.rawRx)}")
            return true
        }

        // Fallback wake-up FE 04 FF FF bila ECU generasi lama memakai FF FF
        kLineRxQueue.clear()
        port.write(byteArrayOf(0xFE.toByte(), 0x04, 0xFF.toByte(), 0xFF.toByte()))
        delay(60)
        kLineRxQueue.clear()
        val retryInit = sendHondaCommand(
            port = port,
            mtype = byteArrayOf(0x72),
            data = byteArrayOf(0x00, 0xF0.toByte()),
            retries = 2,
            timeoutMs = 320,
            verboseLog = true,
            expectHeader02 = true
        )
        if (retryInit.success) {
            log("[INIT] ECU Terbangun (alt FF FF): ${bytesToHex(retryInit.rawRx)}")
            return true
        }
        return false
    }

    fun resolveHondaPartInfo(rawHexNoSpace: String): Triple<String, Int?, EcuProfileSpec?> {
        val clean = rawHexNoSpace.uppercase(Locale.US).replace(" ", "")
        // Prioritas 0: Cocokkan langsung 5-byte ECM ID Hex dari EcmDatabase (misal 0101C40F01, 0103070D01, 0101340F01, dll.)
        val exactHexMatches = hondaEcuDatabase.filter { spec ->
            spec.ecmIdHex.isNotEmpty() && clean.contains(spec.ecmIdHex)
        }
        val exactHexMatch = exactHexMatches.singleOrNull()
        if (exactHexMatch != null) {
            return Triple(
                "${exactHexMatch.partNo} (${exactHexMatch.model}) [${exactHexMatch.vendor}] | Start:${exactHexMatch.startOffset} | Csum:${exactHexMatch.csumLoc}",
                exactHexMatch.romKb,
                exactHexMatch
            )
        }
        val asciiSb = StringBuilder()
        for (i in 0 until clean.length - 1 step 2) {
            val b = clean.substring(i, i + 2).toIntOrNull(16) ?: 0
            if (b in 32..126) asciiSb.append(b.toChar())
        }
        val asciiStr = asciiSb.toString()
        val partRegex = Regex("(30400-[A-Z0-9]{3}-[A-Z0-9]{3}|38770-[A-Z0-9]{3}-[A-Z0-9]{3}|K[0-9]{2}-[A-Z0-9]{3})")
        val m = partRegex.find(asciiStr)
        if (m != null) {
            val code = m.value
            val spec = hondaEcuDatabase.firstOrNull { code.contains(it.code) }
            val kb = spec?.romKb ?: when {
                code.contains("K15") || code.contains("K56") || code.contains("K45") -> 128
                code.contains("K59") || code.contains("K60") || code.contains("K25") || code.contains("K81") || code.contains("K44") -> 64
                else -> null
            }
            val label = if (spec != null) {
                "$code (${spec.model}) [${spec.vendor}] | Start:${spec.startOffset} | Csum:${spec.csumLoc}"
            } else {
                code
            }
            return Triple(label, kb, spec)
        }

        val matchedSpecs = hondaEcuDatabase.filter { spec ->
            val hexCode = spec.code.replace("-", "").toByteArray(Charsets.US_ASCII)
                .joinToString("") { String.format(Locale.US, "%02X", it.toInt() and 0xFF) }
            clean.contains(spec.code.replace("-", "")) || (hexCode.length >= 6 && clean.contains(hexCode))
        }.distinctBy { it.ecmIdHex.ifBlank { it.code } }
        val matchedSpec = matchedSpecs.singleOrNull()
        if (matchedSpec != null) {
            return Triple(
                "${matchedSpec.partNo} (${matchedSpec.model}) [${matchedSpec.vendor}] | Start:${matchedSpec.startOffset} | Csum:${matchedSpec.csumLoc}",
                matchedSpec.romKb,
                matchedSpec
            )
        }

        // No prefix-based ECU guessing. An unknown or ambiguous identifier must
        // not inherit another model's ROM size, offsets, checksum or profile.
        return Triple("UNKNOWN PART ($clean)", null, null)
    }

    // Membaca ECM ID lewat multi-tabel (0x71 0x00, 0x71 0x01, 0x72 0x00) & menuliskannya ke log
    suspend fun readAndLogEcmIdentity(port: UsbSerialDevice): Pair<String, Int?> {
        val queries = listOf(
            Pair(byteArrayOf(0x72), byteArrayOf(0x71, 0x00)),
            Pair(byteArrayOf(0x72), byteArrayOf(0x71, 0x01)),
            Pair(byteArrayOf(0x72), byteArrayOf(0x72, 0x00))
        )
        for ((mtype, qdata) in queries) {
            val resp = sendHondaCommand(
                port = port,
                mtype = mtype,
                data = qdata,
                retries = 1,
                timeoutMs = 200,
                verboseLog = true,
                expectHeader02 = true
            )
            if (resp.success && resp.rawRx.size >= 8) {
                val idBytes = resp.rawRx.copyOfRange(4, resp.rawRx.size - 1)
                val hexSpaced = bytesToHex(idBytes, 16)
                val hexCompact = idBytes.joinToString("") { String.format(Locale.US, "%02X", it.toInt() and 0xFF) }
                val (partName, detectedKb, matchedProfile) = resolveHondaPartInfo(hexCompact)
                val displayStr = "$partName | HEX: $hexSpaced"
                withContext(Dispatchers.Main) {
                    ecmIdHex = displayStr
                    detectedEcuProfile = matchedProfile
                    cachedEcmRawHex = hexCompact
                    cachedEcmRomKb = detectedKb
                    if (detectedKb != null) selectedRomSizeKb = detectedKb
                }
                log("[ECM ID] Terbaca: $displayStr")
                if (matchedProfile != null) {
                    log("[ECM ID] Vendor: ${matchedProfile.vendor} | Start: 0x${matchedProfile.startOffset} | Csum: ${matchedProfile.csumLoc} | ROM: ${matchedProfile.romKb ?: selectedRomSizeKb}KB")
                } else if (detectedKb != null) {
                    log("[ECM ID] Profil dikenali -> Ukuran ROM otomatis: ${detectedKb}KB")
                } else {
                    log("[ECM ID] Kode part belum ada di database -> Gunakan mode standar!")
                }
                return Pair(hexCompact, detectedKb)
            }
        }
        withContext(Dispatchers.Main) {
            ecmIdHex = "UNKNOWN / TIDAK MERESPON ID"
        }
        log("[ECM ID] ECU tidak membalas tabel ID (0x00/0x01) -> Lanjut Auto-Probe metode baca!")
        return Pair("", null)
    }

    // Parsing paket Tabel 17 / Tabel 10 / Tabel 11 resmi dari CandsTech Diag (HondaKLineManager.kt)
    fun parseHondaDiagFrame(data: ByteArray) {
        if (data.size < 6) return
        val responseType = data[2].toInt() and 0xFF
        val tableId = data[3].toInt() and 0xFF

        if (responseType == 0x71 && (tableId == 0x00 || tableId == 0x01) && data.size >= 8) {
            val idBytes = data.copyOfRange(4, data.size - 1)
            val hexCompact = idBytes.joinToString("") { String.format(Locale.US, "%02X", it.toInt() and 0xFF) }
            val (partName, _, matchedProfile) = resolveHondaPartInfo(hexCompact)
            detectedEcuProfile = matchedProfile
            ecmIdHex = "$partName | HEX: ${bytesToHex(idBytes, 16)}"
            return
        }

        // Format Table 00 00 dari SKILL.md (72 07 72 00 00 0D -> balasan 02 <len> 72 00 00 [RPM_H] [RPM_L] [TPS] [TPS_V] [ECT] [MAP] [IAT] [BAT] ...)
        if (responseType == 0x72 && tableId == 0x00 && data.size >= 14) {
            val rpmH = data[5].toInt() and 0xFF
            val rpmL = data[6].toInt() and 0xFF
            val calculatedRpm = (rpmH shl 8) or rpmL
            if (calculatedRpm in 0..18000) {
                rpm = calculatedRpm
                tpsDeg = ((data[7].toInt() and 0xFF) * 80.0f / 255.0f)
                ectTemp = (data[9].toInt() and 0xFF) - 40
                mapKpa = data[10].toInt() and 0xFF
                iatTemp = (data[11].toInt() and 0xFF) - 40
                batVolt = (data[12].toInt() and 0xFF) * 0.1f
                if (data.size >= 19) {
                    ecuSpeed = data[18].toInt() and 0xFF
                    if (ecuSpeed > topSpeed) topSpeed = ecuSpeed
                }
            }
            return
        }

        if (responseType == 0x71 && (tableId == 0x17 || tableId == 0x10 || tableId == 0x11) && data.size >= 20) {
            val rpmH = data[4].toInt() and 0xFF
            val rpmL = data[5].toInt() and 0xFF
            val calculatedRpm = (rpmH shl 8) or rpmL
            if (calculatedRpm in 0..18000) {
                rpm = calculatedRpm
                tpsDeg = (data[7].toInt() and 0xFF) * 0.5f
                ectTemp = (data[9].toInt() and 0xFF) - 40
                iatTemp = (data[11].toInt() and 0xFF) - 40
                mapKpa = data[13].toInt() and 0xFF
                batVolt = (data[16].toInt() and 0xFF) * 0.1f
                if (data.size >= 22) {
                    ecuSpeed = data[21].toInt() and 0xFF
                    if (ecuSpeed > topSpeed) topSpeed = ecuSpeed
                }
            }
        }
    }

    // Baca ECM ID & Tabel 17 (72 05 71 17 01)
    fun queryEcmIdentityAndTable() {
        val port = serialPort
        if (connStatus != "CONNECTED" || port == null) {
            log("[WARN] Hubungkan FTDI K-Line terlebih dahulu!")
            return
        }
        if (isFlashingBusy) return
        scope.launch(Dispatchers.IO) {
            isFlashingBusy = true
            try {
                wakeupAndEnterDiagHonda(port)
                readAndLogEcmIdentity(port)
                val t17 = sendHondaCommand(port, byteArrayOf(0x72), byteArrayOf(0x71, 0x17), retries = 1, timeoutMs = 220, verboseLog = true, expectHeader02 = true)
                if (t17.success && t17.rawRx.size >= 22) {
                    withContext(Dispatchers.Main) {
                        activeSensorTable = 0x17
                        parseHondaDiagFrame(t17.rawRx)
                    }
                    log("[DIAG] Tabel 17 OK! RPM=$rpm BAT=${batVolt}V TPS=${tpsDeg}°")
                } else {
                    val t10 = sendHondaCommand(port, byteArrayOf(0x72), byteArrayOf(0x71, 0x10), retries = 1, timeoutMs = 220, verboseLog = true, expectHeader02 = true)
                    if (t10.success && t10.rawRx.size >= 22) {
                        withContext(Dispatchers.Main) {
                            activeSensorTable = 0x10
                            parseHondaDiagFrame(t10.rawRx)
                        }
                        log("[DIAG] Tabel 10 OK! RPM=$rpm BAT=${batVolt}V")
                    }
                }
            } finally {
                isFlashingBusy = false
            }
        }
    }

    // Helper membangun payload alamat baca 8-byte (Little-Endian vs Big-Endian)
    fun buildReadAddrPayload(nbyte: Int, readSize: Int, bigEndianAddr: Boolean): ByteArray {
        val bank = ((nbyte / 65536) and 0xFF).toByte()
        val offset16 = nbyte % 65536
        val addrLo = (offset16 and 0xFF).toByte()
        val addrHi = ((offset16 shr 8) and 0xFF).toByte()
        return if (bigEndianAddr) {
            byteArrayOf(bank, addrHi, addrLo, readSize.toByte())
        } else {
            byteArrayOf(bank, addrLo, addrHi, readSize.toByte())
        }
    }

    // READ FLASH (.BIN) 3-TAHAP OTOMATIS:
    // Tahap 1: Wakeup + Baca & Log ECM ID / Part Number (jika belum merespons, ulangi wakeup sekali)
    // Tahap 2: Auto-Probe Metode Baca (1: Direct 0x82 LE [HondaECU.py], 2: Direct 0x82 BE, 3: Session 0xF1 + 0x82, 4: Sec 0x27 + 0x82)
    // Tahap 3: Loop baca 8-byte + Deteksi otomatis batas ukuran ROM (32KB/64KB/128KB) jika terjadi mirror/akhir memori
    fun readRomFromEcu() {
        val port = serialPort
        if (connStatus != "CONNECTED" || port == null) {
            log("[WARN] Hubungkan FTDI K-Line dulu (USB CONNECT)!")
            return
        }
        if (isFlashingBusy) return

        scope.launch(Dispatchers.IO) {
            isFlashingBusy = true
            flashProgress = 0f
            try {
                log("[READ] Turn off bike -> Turn on bike...")
                for (sec in 3 downTo 1) {
                    if (!isActive) break
                    withContext(Dispatchers.Main) {
                        keyCyclePrompt = "MATIKAN KONTAK (OFF)... $sec"
                    }
                    delay(1000L)
                }
                for (sec in 2 downTo 1) {
                    if (!isActive) break
                    withContext(Dispatchers.Main) {
                        keyCyclePrompt = "NYALAKAN KONTAK (ON)... $sec"
                    }
                    delay(1000L)
                }
                kLineRxQueue.clear()
                withContext(Dispatchers.Main) {
                    keyCyclePrompt = null
                }

                log("[READ] Wake-up ECU & entering diagnostic mode...")
                val woke = wakeupAndEnterDiagHonda(port)
                if (!woke) {
                    wakeupAndEnterDiagHonda(port)
                }

                // Gunakan ECM ID yang sudah dibaca 1x saat USB CONNECT agar tidak bentrok dengan sesi baca ROM
                val rawIdHex = cachedEcmRawHex
                val detectedKb = cachedEcmRomKb
                val activeProfile = detectedEcuProfile
                if (rawIdHex.isNotEmpty()) {
                    log("[READ] Memakai ECM ID tersimpan dari koneksi USB: ${activeProfile?.partNo ?: rawIdHex} (${activeProfile?.vendor ?: "Auto"})")
                } else {
                    log("[READ] ECM ID belum tersimpan saat USB CONNECT -> memakai profil/ukuran terpilih (${selectedRomSizeKb}KB).")
                }
                val isShindengen = activeProfile?.vendor.equals("Shindengen", ignoreCase = true) ||
                    rawIdHex.startsWith("0100") || rawIdHex.startsWith("0101") ||
                    rawIdHex.startsWith("0201") || rawIdHex.startsWith("0500")
                val targetKb = detectedKb ?: selectedRomSizeKb
                val romBytesTotal = targetKb * 1024

                val romBuf = ByteArray(romBytesTotal)
                var readSuccessCount = 0

                if (isShindengen) {
                    log("[READ] Profil SHINDENGEN terdeteksi (${activeProfile?.partNo ?: rawIdHex}) -> Memakai protokol K-Line Shindengen (0x72)...")
                    // Shindengen K-Line session init (tanpa password Keihin 0x27 HelloHo/wAreYou)
                    sendHondaCommand(
                        port = port,
                        mtype = byteArrayOf(0x72),
                        data = byteArrayOf(0x00, 0xF1.toByte()),
                        retries = 3,
                        timeoutMs = 300,
                        verboseLog = true
                    )
                    sendHondaCommand(
                        port = port,
                        mtype = byteArrayOf(0x72),
                        data = byteArrayOf(0x71, 0x01),
                        retries = 2,
                        timeoutMs = 300,
                        verboseLog = true
                    )

                    // Probe 1 (SKILL.md): Shindengen Read Chunk Header 0x7B (7B 07 02 00 00 00 [csum]) -> Reply Header 0x7C (128 byte)
                    val probe7B = sendHondaCommand(
                        port = port,
                        mtype = byteArrayOf(0x7B),
                        data = byteArrayOf(0x02, 0x00, 0x00, 0x00),
                        retries = 2,
                        timeoutMs = 380,
                        verboseLog = true
                    )
                    val use7BChunkRead = probe7B.success && probe7B.rdata.size >= 16

                    // Probe 2: Shindengen K-Line 0x72 0x80 (step 4 byte)
                    val probe80 = if (!use7BChunkRead) {
                        sendHondaCommand(
                            port = port,
                            mtype = byteArrayOf(0x72),
                            data = byteArrayOf(0x80.toByte(), 0x00, 0x00, 0x00),
                            retries = 2,
                            timeoutMs = 320,
                            verboseLog = true
                        )
                    } else null
                    val use7280Read = !use7BChunkRead && (probe80?.success == true && probe80.rdata.isNotEmpty())

                    // Probe 3: Shindengen K-Line 0x72 0x73 (8 byte)
                    val probeShindengen = if (!use7BChunkRead && !use7280Read) {
                        sendHondaCommand(
                            port = port,
                            mtype = byteArrayOf(0x72),
                            data = byteArrayOf(0x73, 0x00, 0x00, 0x00, 0x08),
                            retries = 2,
                            timeoutMs = 320,
                            verboseLog = true
                        )
                    } else null
                    val use72Read = !use7BChunkRead && !use7280Read && (probeShindengen?.success == true && (probeShindengen.rdata.size >= 8))

                    if (!use7BChunkRead && !use7280Read && !use72Read) {
                        log("[WARN] ECU Shindengen (${activeProfile?.partNo ?: "30400-xxx"}) merespons Diag/ID, tetapi akses dump ROM (0x7B / 0x72) tidak dibuka ECU.")
                        return@launch
                    }

                    log("[READ] Reading ECU Shindengen (${targetKb}KB)...")
                    var nbyte = 0
                    val stepBytes = when {
                        use7BChunkRead -> 128
                        use7280Read -> 4
                        else -> 8
                    }
                    while (isActive && nbyte < romBytesTotal) {
                        val hi = ((nbyte shr 16) and 0xFF).toByte()
                        val mid = ((nbyte shr 8) and 0xFF).toByte()
                        val lo = (nbyte and 0xFF).toByte()
                        val resp = when {
                            use7BChunkRead -> sendHondaCommand(
                                port = port,
                                mtype = byteArrayOf(0x7B),
                                data = byteArrayOf(0x02, hi, mid, lo),
                                retries = 4,
                                timeoutMs = 450,
                                verboseLog = (nbyte == 0)
                            )
                            use7280Read -> sendHondaCommand(
                                port = port,
                                mtype = byteArrayOf(0x72),
                                data = byteArrayOf(0x80.toByte(), hi, mid, lo),
                                retries = 4,
                                timeoutMs = 380,
                                verboseLog = (nbyte < 16)
                            )
                            else -> sendHondaCommand(
                                port = port,
                                mtype = byteArrayOf(0x72),
                                data = byteArrayOf(0x73, hi, mid, lo, 0x08),
                                retries = 4,
                                timeoutMs = 380,
                                verboseLog = (nbyte == 0)
                            )
                        }
                        if (resp.success && resp.rdata.isNotEmpty()) {
                            val payload = if (use7BChunkRead && resp.rdata.size > 128) {
                                resp.rdata.copyOfRange(resp.rdata.size - 128, resp.rdata.size)
                            } else {
                                resp.rdata
                            }
                            val copyLen = minOf(stepBytes, payload.size, romBytesTotal - nbyte)
                            System.arraycopy(payload, 0, romBuf, nbyte, copyLen)
                            readSuccessCount++
                        } else if (nbyte == 0) {
                            log("[ERR] Gagal membaca blok awal Shindengen (0x0000) -> Proses dihentikan.")
                            return@launch
                        }
                        nbyte += stepBytes
                        withContext(Dispatchers.Main) {
                            flashProgress = (nbyte.toFloat() / romBytesTotal.toFloat()).coerceIn(0f, 1f)
                        }
                    }
                } else {
                    log("[READ] Profil KEIHIN terdeteksi (${activeProfile?.partNo ?: rawIdHex}) -> Security access 0x27...")
                    sendHondaCommand(
                        port = port,
                        mtype = byteArrayOf(0x27),
                        data = byteArrayOf(0xE0.toByte(), 0x48, 0x65, 0x6C, 0x6C, 0x6F, 0x48, 0x6F),
                        retries = 5,
                        timeoutMs = 400,
                        verboseLog = true
                    )
                    sendHondaCommand(
                        port = port,
                        mtype = byteArrayOf(0x27),
                        data = byteArrayOf(0xE0.toByte(), 0x77, 0x41, 0x72, 0x65, 0x59, 0x6F, 0x75),
                        retries = 5,
                        timeoutMs = 400,
                        verboseLog = true
                    )

                    log("[READ] Reading ECU Keihin (${targetKb}KB)...")
                    var nbyte = 0
                    while (isActive && nbyte < romBytesTotal) {
                        val resp = sendHondaCommand(
                            port = port,
                            mtype = byteArrayOf(0x82.toByte(), 0x82.toByte(), 0x00),
                            data = buildReadAddrPayload(nbyte, 8, bigEndianAddr = false),
                            retries = 5,
                            timeoutMs = 400,
                            verboseLog = (nbyte == 0)
                        )
                        if (resp.success && resp.rdata.isNotEmpty()) {
                            val copyLen = minOf(8, resp.rdata.size, romBytesTotal - nbyte)
                            System.arraycopy(resp.rdata, 0, romBuf, nbyte, copyLen)
                            readSuccessCount++
                        } else if (nbyte == 0) {
                            log("[ERR] ECU Keihin tidak merespons baca memori 0x82 di alamat 0x0000 -> Proses dihentikan.")
                            return@launch
                        }
                        nbyte += 8
                        withContext(Dispatchers.Main) {
                            flashProgress = (nbyte.toFloat() / romBytesTotal.toFloat()).coerceIn(0f, 1f)
                        }
                    }
                }

                val cleanId = rawIdHex.replace(Regex("[^A-Za-z0-9_-]"), "").ifBlank { "UNKNOWN_ID" }
                val dateStr = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                val generatedBinName = "ECU_${cleanId}_${targetKb}KB_${dateStr}.bin"

                withContext(Dispatchers.Main) {
                    binBytes = romBuf
                    binName = generatedBinName
                    checksumHex = "0x${BinParser.calculateChecksum16(romBuf).toString(16).uppercase(Locale.US).padStart(4, '0')}"
                    tableRefreshTick++
                    log("[READ] Selesai (${romBuf.size} bytes) -> $generatedBinName")
                }
            } catch (e: Exception) {
                log("[ERR] ${e.message}")
            } finally {
                withContext(Dispatchers.Main) {
                    keyCyclePrompt = null
                    isFlashingBusy = false
                }
            }
        }
    }

    // WRITE / FLASH ROM (.BIN) sesuai do_init_write + do_erase + do_write_flash + do_post_write di HondaECU.py
    fun writeRomToEcu() {
        val port = serialPort
        val rawData = binBytes
        if (connStatus != "CONNECTED" || port == null) {
            log("[WARN] Hubungkan FTDI K-Line terlebih dahulu!")
            return
        }
        if (rawData == null) {
            log("[WARN] Belum ada file .BIN! Klik OPEN .BIN atau READ ECU dulu.")
            return
        }
        if (isFlashingBusy) return

        // Pastikan ukuran kelipatan 128 byte & perbaiki checksum Honda otomatis sebelum write
        val data = rawData.copyOf()
        val customCsumOffset = detectedEcuProfile?.csumLoc?.toIntOrNull(16)?.let { off -> if (off > 0 && off < data.size) off else null }
        if (detectedEcuProfile?.vendor.equals("Shindengen", ignoreCase = true)) {
            val (oldS32, newS32, fixedS32) = BinParser.fixShindengenRomChecksum32(data)
            if (fixedS32) {
                log("[CSUM] Shindengen 32-bit Checksum diperbaiki otomatis: 0x${oldS32.toString(16)} -> 0x${newS32.toString(16)}")
            }
        } else {
            val (oldCsum, newCsum, wasFixed) = BinParser.fixHondaRomChecksum(data, customCsumOffset)
            if (wasFixed) {
                log("[CSUM] Checksum .BIN diperbaiki otomatis: 0x${oldCsum.toString(16)} -> 0x${newCsum.toString(16)}")
            }
        }

        scope.launch(Dispatchers.IO) {
            isFlashingBusy = true
            flashProgress = 0f
            try {
                log("[WRITE] Turn off bike -> Turn on bike...")
                for (sec in 3 downTo 1) {
                    if (!isActive) break
                    withContext(Dispatchers.Main) {
                        keyCyclePrompt = "MATIKAN KONTAK (OFF)... $sec"
                    }
                    delay(1000L)
                }
                for (sec in 2 downTo 1) {
                    if (!isActive) break
                    withContext(Dispatchers.Main) {
                        keyCyclePrompt = "NYALAKAN KONTAK (ON)... $sec"
                    }
                    delay(1000L)
                }
                kLineRxQueue.clear()
                withContext(Dispatchers.Main) {
                    keyCyclePrompt = null
                }

                log("[WRITE] Memulai HondaECU Write/Flash (${data.size / 1024} KB)... JANGAN MATIKAN KONTAK!")
                val initOk = wakeupAndEnterDiagHonda(port)

                // 1. do_init_write (0x7D "PGM" / "-FI"), fallback ke do_init_recover jika gagal
                log("[WRITE] Init Write Mode (0x7D PGM-FI)...")
                val w1 = sendHondaCommand(port, byteArrayOf(0x7D), byteArrayOf(0x01, 0x01, 0x02), retries = 3, verboseLog = true)
                val w2 = sendHondaCommand(port, byteArrayOf(0x7D), byteArrayOf(0x01, 0x01, 0x03), retries = 3, verboseLog = true)
                val w3 = sendHondaCommand(port, byteArrayOf(0x7D), byteArrayOf(0x01, 0x02, 0x50, 0x47, 0x4D), retries = 3, verboseLog = true)
                val w4 = sendHondaCommand(port, byteArrayOf(0x7D), byteArrayOf(0x01, 0x03, 0x2D, 0x46, 0x49), retries = 3, verboseLog = true)

                if (!(w1.success && w2.success && w3.success && w4.success)) {
                    log("[WRITE] Beralih ke Recovery Init Mode (0x7B + 0x72 F1 + 0x27)...")
                    if (initOk) {
                        sendHondaCommand(port, byteArrayOf(0x7B), byteArrayOf(0x00, 0x01, 0x02), retries = 3, verboseLog = true)
                        sendHondaCommand(port, byteArrayOf(0x7B), byteArrayOf(0x00, 0x01, 0x03), retries = 3, verboseLog = true)
                        sendHondaCommand(port, byteArrayOf(0x7B), byteArrayOf(0x00, 0x02, 0x76, 0x03, 0x17), retries = 3, verboseLog = true)
                        sendHondaCommand(port, byteArrayOf(0x7B), byteArrayOf(0x00, 0x03, 0x75, 0x05, 0x13), retries = 3, verboseLog = true)
                        sendHondaCommand(port, byteArrayOf(0x72), byteArrayOf(0x00, 0xF1.toByte()), retries = 3, verboseLog = true)
                        sendHondaCommand(port, byteArrayOf(0x27), byteArrayOf(0x00, 0x9F.toByte(), 0x00), retries = 3, verboseLog = true)
                    }
                }

                // 2. do_erase (0x7E sequence + 12s wait + polling 0x01 0x05)
                log("[ERASE] Menghapus Flash ECU (tunggu ~12 detik)...")
                sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x01, 0x00), retries = 5, verboseLog = true)
                for (sec in 12 downTo 1) {
                    delay(1000L)
                    if (sec % 3 == 0) log("[ERASE] Menunggu erase bootloader... ${sec}s")
                }
                sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x02), retries = 5, verboseLog = true)
                sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x03, 0x00, 0x00), retries = 5, verboseLog = true)
                sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x01, 0x00), retries = 5, verboseLog = true)
                sendHondaCommand(
                    port,
                    byteArrayOf(0x7E),
                    byteArrayOf(0x01, 0x0B, 0x00, 0x00, 0x00, 0xFF.toByte(), 0xFF.toByte(), 0xFF.toByte()),
                    retries = 5,
                    verboseLog = true
                )
                sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x01, 0x00), retries = 5, verboseLog = true)
                sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x0E, 0x01, 0x90.toByte()), retries = 5, verboseLog = true)
                sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x01, 0x01), retries = 5, verboseLog = true)
                sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x04, 0xFF.toByte()), retries = 5, verboseLog = true)
                sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x01, 0x00), retries = 5, verboseLog = true)

                var pollCount = 0
                while (isActive && pollCount < 40) {
                    val statusResp = sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x05), retries = 3, verboseLog = (pollCount == 0))
                    if (statusResp.success && statusResp.rdata.size >= 2 && statusResp.rdata[1] == 0x00.toByte()) {
                        log("[ERASE] Erase selesai & terverifikasi!")
                        break
                    }
                    pollCount++
                    delay(250)
                }
                sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x01, 0x00), retries = 5, verboseLog = true)

                // 3. do_write_flash (128-byte blocks)
                log("[WRITE] Menulis blok 128-byte ke ROM ECU...")
                val writeSize = 128
                val maxI = data.size / writeSize
                var i = 0
                while (i < maxI && isActive) {
                    val startVal = 8 * i
                    val endVal = if (i + 1 == maxI) 0 else 8 * (i + 1)
                    val bytStart = byteArrayOf(((startVal shr 8) and 0xFF).toByte(), (startVal and 0xFF).toByte())
                    val bytEnd = byteArrayOf(((endVal shr 8) and 0xFF).toByte(), (endVal and 0xFF).toByte())
                    val chunk = data.copyOfRange(i * writeSize, (i + 1) * writeSize)

                    val xPayload = bytStart + chunk + bytEnd
                    val c1 = BinParser.checksum8bitBlock(xPayload).toByte()
                    val c2 = BinParser.checksum8bitHonda(xPayload).toByte()
                    val fullData = byteArrayOf(0x01, 0x06) + xPayload + byteArrayOf(c1, c2)

                    val writeResp = sendHondaCommand(port, byteArrayOf(0x7E), fullData, retries = 5, timeoutMs = 300, verboseLog = (i == 0))
                    if (!writeResp.success || writeResp.rml != 5) {
                        log("[ERR] Write gagal pada blok #$i (rml=${writeResp.rml}).")
                        isFlashingBusy = false
                        return@launch
                    }

                    i++
                    if (i % 2 == 0) {
                        sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x08), retries = 5, timeoutMs = 250)
                    }

                    if (i % 16 == 0 || i >= maxI) {
                        val pct = i.toFloat() / maxI.toFloat()
                        withContext(Dispatchers.Main) {
                            flashProgress = pct
                            if (i % 64 == 0 || i >= maxI) {
                                log("[WRITE] ${(pct * 100).toInt()}% (${(i * writeSize) / 1024}KB / ${data.size / 1024}KB)")
                            }
                        }
                    }
                }

                // 4. do_post_write
                log("[WRITE] Finalisasi Post-Write (0x09, 0x0A, 0x0C, 0x0D)...")
                sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x01, 0x00), retries = 5)
                sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x09), retries = 5)
                sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x01, 0x00), retries = 5)
                sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x0A), retries = 5)
                sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x01, 0x00), retries = 5)
                sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x0C), retries = 5)
                sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x01, 0x00), retries = 5)
                sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x0D), retries = 5)
                sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x01, 0x00), retries = 5)

                log("[WRITE] SUKSES 100%! Matikan kontak 5 detik lalu nyalakan ulang.")
            } catch (e: Exception) {
                log("[ERR] Write ROM error: ${e.message}")
            } finally {
                isFlashingBusy = false
            }
        }
    }

    val binPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let {
            try {
                val data = context.contentResolver.openInputStream(it)?.use { s -> s.readBytes() }
                if (data != null) {
                    binBytes = data
                    binName = DocumentFile.fromSingleUri(context, it)?.name
                        ?: it.lastPathSegment?.substringAfterLast('/')
                        ?: "ecu_dump.bin"
                    val csum = BinParser.calculateChecksum16(data)
                    checksumHex = "0x${csum.toString(16).uppercase(Locale.US).padStart(4, '0')}"
                    tableRefreshTick++
                    log("[BIN] Loaded $binName (${data.size} B)")
                }
            } catch (e: Exception) {
                log("[ERR] Gagal baca .BIN: ${e.message}")
            }
        }
    }

    val xdfPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let {
            try {
                context.contentResolver.openInputStream(it)?.use { stream ->
                    val parsed = BinParser.parseXdfStream(stream)
                    xdfTables.clear()
                    xdfTables.putAll(parsed)
                    selectedTableKey = xdfTables.keys.firstOrNull()
                    xdfName = DocumentFile.fromSingleUri(context, it)?.name
                        ?: it.lastPathSegment?.substringAfterLast('/')
                        ?: "custom.xdf"
                    tableRefreshTick++
                    log("[XDF] Loaded $xdfName (${xdfTables.size} tables)")
                }
            } catch (e: Exception) {
                log("[ERR] Gagal baca .XDF: ${e.message}")
            }
        }
    }

    fun connectKLine(deviceOverride: UsbDevice? = null) {
        val devices = usbManager.deviceList.values.toList()
        if (devices.isEmpty()) {
            connStatus = "NO_DEVICE"
            log("[USB] Tidak ada adapter USB yang terdeteksi.")
            return
        }
        val device = deviceOverride ?: devices.firstOrNull { it.deviceId == selectedUsbDeviceId }
            ?: if (devices.size == 1) devices.first() else {
                connStatus = "SELECT_DEVICE"
                log("[USB] ${devices.size} perangkat terdeteksi. Pilih adapter ELM327 atau RAW K-Line; jangan memilih perangkat secara acak.")
                return
            }
        selectedUsbDeviceId = device.deviceId
        val descriptor = UsbAdapterSupport.describe(device)
        val identityText = (device.productName.orEmpty() + " " + device.manufacturerName.orEmpty()).uppercase(Locale.US)
        val isElm = selectedInterfaceMode == "ELM327" || (selectedInterfaceMode == "AUTO" &&
            ("ELM327" in identityText || "ELM 327" in identityText || "OBDII ELM" in identityText))
        if (selectedInterfaceMode == "AUTO" && !isElm) selectedInterfaceMode = "RAW_KLINE"
        if (descriptor.bridgeKind == com.candstech.ecuflasher.core.usb.UsbBridgeKind.OTHER) {
            connStatus = "UNSUPPORTED"
            log("[USB][BLOCKED] ${descriptor.displayName} tidak dikenali sebagai FTDI/CH340/CP210x/CDC.")
            return
        }
        if (!usbManager.hasPermission(device)) {
            val action = "com.candstech.ecuflasher.USB_PERMISSION"
            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
            val permissionIntent = PendingIntent.getBroadcast(
                context, device.deviceId,
                Intent(action).setPackage(context.packageName).putExtra(UsbManager.EXTRA_DEVICE, device),
                flags
            )
            val receiver = object : BroadcastReceiver() {
                override fun onReceive(ctx: Context, intent: Intent) {
                    if (intent.action != action) return
                    try { context.unregisterReceiver(this) } catch (_: Exception) { }
                    val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                    val returnedDevice = intent.getParcelableExtra<UsbDevice>(UsbManager.EXTRA_DEVICE) ?: device
                    if (granted && returnedDevice.deviceId == device.deviceId) {
                        log("[USB] Izin diberikan untuk ${descriptor.displayName}.")
                        connectKLine(device)
                    } else {
                        connStatus = "DENIED"
                        log("[USB] Izin USB ditolak/tidak cocok untuk ${descriptor.displayName}.")
                    }
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.registerReceiver(receiver, IntentFilter(action), Context.RECEIVER_NOT_EXPORTED)
            } else {
                context.registerReceiver(receiver, IntentFilter(action))
            }
            connStatus = "REQUESTING"
            log("[USB] Meminta izin Android untuk ${descriptor.displayName}...")
            usbManager.requestPermission(device, permissionIntent)
            return
        }

        if (isElm) {
            connStatus = "OPENING_ELM"
            scope.launch(Dispatchers.IO) {
                var connection: UsbDeviceConnection? = null
                var port: UsbSerialDevice? = null
                try {
                    connection = usbManager.openDevice(device) ?: error("UsbManager.openDevice gagal")
                    val openedPort = UsbSerialDevice.createUsbSerialDevice(device, connection)
                        ?: error("Driver USB serial tidak mendukung adapter ELM ini")
                    port = openedPort
                    if (!openedPort.open()) error("Gagal membuka port serial ELM327")
                    openedPort.setBaudRate(38400)
                    openedPort.setDataBits(UsbSerialInterface.DATA_BITS_8)
                    openedPort.setStopBits(UsbSerialInterface.STOP_BITS_1)
                    openedPort.setParity(UsbSerialInterface.PARITY_NONE)
                    openedPort.setFlowControl(UsbSerialInterface.FLOW_CONTROL_OFF)
                    val activePort = openedPort
                    val session = Elm327Session(activePort)
                    activePort.read { bytes -> if (bytes != null && bytes.isNotEmpty()) session.onBytes(bytes) }
                    withContext(Dispatchers.Main) {
                        elmPort = activePort
                        elmSession = session
                        elmConnected = true
                        connStatus = "CONNECTED"
                        log("[ELM] ${descriptor.displayName} terbuka; UART 38400 8N1. Jalur AT-command terpisah dari RAW K-Line.")
                    }
                } catch (e: Exception) {
                    try { port?.close() } catch (_: Exception) { }
                    try { connection?.close() } catch (_: Exception) { }
                    withContext(Dispatchers.Main) {
                        elmConnected = false
                        elmSession = null
                        elmPort = null
                        connStatus = "CONNECT_FAILED"
                        log("[ELM][ERROR] ${e.message}")
                    }
                }
            }
            return
        }

        connStatus = "OPENING_ADAPTER"
        scope.launch {
            val opened = withContext(Dispatchers.IO) {
                ecuEngine.openAdapterOnly(device = device, preferNativeFtdi = device.vendorId == 0x0403)
            }
            if (opened) {
                connStatus = "ADAPTER_OPEN"
                log("[CANDSTECH] Adapter RAW K-Line terbuka. Belum mengirim wake-up atau request ECU.")
                log("[CANDSTECH] Tekan START ECU ID untuk menjalankan wake-up K-Line dan identifikasi ECU.")
            } else {
                connStatus = "CONNECT_FAILED"
                log("[CANDSTECH] Gagal membuka adapter RAW K-Line.")
            }
        }
    }

    fun startEcuDiagnosis() {
        if (elmConnected) {
            val session = elmSession ?: run { log("[ELM] Sesi tidak tersedia."); return }
            connStatus = "IDENTIFYING_ECU"
            scope.launch {
                try {
                    val report = withContext(Dispatchers.IO) { session.initialize() }
                    ecmIdHex = "OBD-II / ELM327"
                    connStatus = "ECU_IDENTIFIED"
                    log("[ELM] Adapter dan ECU OBD-II merespons: $report")
                } catch (e: Exception) {
                    connStatus = "CONNECTED"
                    log("[ELM][ERROR] ${e.message}")
                }
            }
            return
        }
        if (connStatus == "IDENTIFYING_ECU") return
        if (!ecuEngineAdapterOpen) {
            log("[WARN] Buka adapter USB terlebih dahulu.")
            return
        }
        if (isFlashingBusy) return
        connStatus = "IDENTIFYING_ECU"
        scope.launch {
            val model = withContext(Dispatchers.IO) {
                // identifyEcu() sendiri menjalankan wake pulse baseline CANDSTECH,
                // lalu query ID 10400 bps, fallback 9600 bps, dan retry sesuai engine.
                ecuEngine.identifyEcu()
            }
            val identity = ecuEngine.ecuIdentity.value
            val identified = ecuEngine.isEcuIdentified.value
            val alive = ecuEngine.isEcuAlive.value
            if (identified && identity != null) {
                ecmIdHex = identity.ecmId ?: identity.canonicalEcuId ?: identity.ecuIdRaw ?: "ID TIDAK TERSEDIA"
                cachedEcmRawHex = identity.rawResponseHex ?: ""
                connStatus = "ECU_IDENTIFIED"
                log("[CANDSTECH] ECU ID teridentifikasi: $ecmIdHex")
                identity.partNumber?.let { log("[CANDSTECH] Part Number: $it") }
                model?.let { log("[CANDSTECH] Kandidat model: ${it.bikeName} | ${it.partNumber}") }
            } else if (alive) {
                ecmIdHex = identity?.ecuIdRaw ?: "ECU MERESPONS, ID BELUM TERVERIFIKASI"
                connStatus = "ECU_RESPONDED"
                log("[CANDSTECH] ECU merespons, tetapi identitas belum berhasil diverifikasi.")
                ecuEngine.identificationError.value?.let { log("[CANDSTECH] $it") }
            } else {
                ecmIdHex = "TIDAK ADA RESPON ECU"
                connStatus = "ADAPTER_OPEN"
                log("[CANDSTECH] Tidak ada respons ECU valid. Adapter tetap terbuka; periksa kontak, K-Line, dan transceiver.")
            }
        }
    }

    fun disconnectKLine() {
        isFlashingBusy = false
        try { elmPort?.close() } catch (_: Exception) { }
        elmPort = null
        elmSession = null
        elmConnected = false
        ecuEngine.disconnect()
        serialPort?.close()
        usbConnection?.close()
        serialPort = null
        usbConnection = null
        connStatus = "DISCONNECTED"
        ecmIdHex = "BELUM TERBACA"
        log("[CANDSTECH] Adapter USB ditutup.")
    }

    // Dialog Peringatan Keamanan 10 Detik Sebelum WRITE ECU
    if (showWriteConfirmDialog) {
        val targetBytes = binBytes
        val sizeKb = (targetBytes?.size ?: 0) / 1024
        AlertDialog(
            onDismissRequest = { showWriteConfirmDialog = false },
            containerColor = CardDark,
            title = {
                Text(
                    text = "PERINGATAN FLASH / WRITE ECU!",
                    color = HondaRed,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Anda akan menulis ulang memori ROM ECU secara permanen!",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "• File: $binName ($sizeKb KB)\n" +
                               "• Checksum: $checksumHex\n" +
                               "• Pastikan aki/adaptor 12V stabil & JANGAN matikan kunci kontak atau cabut kabel USB selama proses flashing berlangsung.",
                        color = Color.LightGray,
                        fontSize = 11.sp
                    )
                    if (writeCountdownSec > 0) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF2B1B1B), RoundedCornerShape(6.dp))
                                .border(1.dp, HondaRed, RoundedCornerShape(6.dp))
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Tunggu $writeCountdownSec detik untuk membuka tombol YES / NO...",
                                color = NeonYellow,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF1B2B1B), RoundedCornerShape(6.dp))
                                .border(1.dp, Color(0xFF00E676), RoundedCornerShape(6.dp))
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Siap! Pilih YES untuk mulai flashing atau NO untuk batal.",
                                color = Color(0xFF00E676),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            },
            confirmButton = {
                if (writeCountdownSec <= 0) {
                    Button(
                        onClick = {
                            showWriteConfirmDialog = false
                            writeRomToEcu()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = HondaRed)
                    ) {
                        Text("YES, FLASH ECU", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            },
            dismissButton = {
                if (writeCountdownSec <= 0) {
                    OutlinedButton(
                        onClick = {
                            showWriteConfirmDialog = false
                            log("[WRITE] Dibatalkan oleh pengguna.")
                        }
                    ) {
                        Text("NO, BATAL", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                } else {
                    TextButton(
                        onClick = {
                            showWriteConfirmDialog = false
                            log("[WRITE] Dibatalkan saat hitung mundur.")
                        }
                    ) {
                        Text("BATAL ($writeCountdownSec)", color = Color.Gray)
                    }
                }
            }
        )
    }

    val activeEditingTable = selectedTableKey?.let { xdfTables[it] }
    val activeBinBytes = binBytes
    if (editingCellCoord != null && activeEditingTable != null && activeBinBytes != null) {
        val (rIdx, cIdx) = editingCellCoord!!
        AlertDialog(
            onDismissRequest = { editingCellCoord = null },
            containerColor = CardDark,
            title = {
                Text(
                    text = "Edit Sel [Baris ${rIdx + 1}, Kolom ${cIdx + 1}]",
                    color = NeonYellow,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "${activeEditingTable.title} (Nilai 0 - 255)",
                        color = Color.LightGray,
                        fontSize = 11.sp
                    )
                    OutlinedTextField(
                        value = editingCellInput,
                        onValueChange = { editingCellInput = it.filter { ch -> ch.isDigit() } },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = NeonYellow,
                            unfocusedBorderColor = BorderDark
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val newVal = editingCellInput.toIntOrNull()
                        if (newVal != null) {
                            BinParser.writeCell(activeBinBytes, activeEditingTable, rIdx, cIdx, newVal)
                            checksumHex = "0x${BinParser.calculateChecksum16(activeBinBytes).toString(16).uppercase(Locale.US).padStart(4, '0')}"
                            tableRefreshTick++
                            log("[EDIT] [${rIdx + 1},${cIdx + 1}] -> ${newVal.coerceIn(0, 255)}")
                        }
                        editingCellCoord = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = HondaRed)
                ) {
                    Text("SIMPAN", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { editingCellCoord = null }) {
                    Text("BATAL", color = Color.Gray)
                }
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDark)
            .statusBarsPadding()
            .displayCutoutPadding()
            .navigationBarsPadding()
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        // Top Header Bar: Tinggi 50.dp, Logo 47.dp
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .background(CardDark, RoundedCornerShape(8.dp))
                .border(1.dp, BorderDark, RoundedCornerShape(8.dp))
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Image(
                    painter = painterResource(id = R.drawable.logo_candstech),
                    contentDescription = "CANDS TECH Logo",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.height(40.dp)
                )
                TabChip("1. FLASH & MAP", activeTab == 0) { activeTab = 0 }
                TabChip("2. AI PRESET", activeTab == 1) { activeTab = 1 }
                TabChip("3. K-LINE DIAG", activeTab == 2) { activeTab = 2 }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(
                    onClick = {
                        selectedInterfaceMode = when (selectedInterfaceMode) {
                            "AUTO" -> "ELM327"
                            "ELM327" -> "RAW_KLINE"
                            else -> "AUTO"
                        }
                        log("[USB] Mode adapter dipilih: $selectedInterfaceMode")
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF303030)),
                    contentPadding = PaddingValues(horizontal = 7.dp, vertical = 1.dp),
                    modifier = Modifier.height(30.dp)
                ) { Text("MODE: $selectedInterfaceMode", color = Color.White, fontSize = 8.sp) }
                Text("CSUM: $checksumHex", color = NeonYellow, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                Button(
                    onClick = { if (adapterUiOpen) disconnectKLine() else connectKLine() },
                    colors = ButtonDefaults.buttonColors(containerColor = if (adapterUiOpen) Color.DarkGray else HondaRed),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                    modifier = Modifier.height(34.dp)
                ) {
                    Text(
                        text = if (adapterUiOpen) "USB ON" else "USB CONNECT",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Button(
                    onClick = { startEcuDiagnosis() },
                    enabled = adapterUiOpen && connStatus != "IDENTIFYING_ECU",
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF154360)),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.height(34.dp)
                ) {
                    Text("START ECU ID", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        if (adapterUiOpen) {
            Text(
                text = when {
                    elmConnected && connStatus == "ECU_IDENTIFIED" -> "CANDSTECH: ELM327 OBD-II TERHUBUNG"
                    elmConnected -> "CANDSTECH: ELM327 AT-COMMAND TERBUKA"
                    connStatus == "IDENTIFYING_ECU" -> "CANDSTECH: IDENTIFIKASI ECU BERJALAN..."
                    ecuEngineEcuIdentified -> "CANDSTECH: ECU ID TERVERIFIKASI — $ecmIdHex"
                    ecuEngineEcuAlive -> "CANDSTECH: ECU MERESPONS, ID BELUM TERVERIFIKASI"
                    else -> "CANDSTECH: ADAPTER TERBUKA — ECU BELUM DIIDENTIFIKASI"
                },
                color = if (ecuEngineEcuIdentified) NeonYellow else Color.LightGray,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 2.dp)
            )
        }

        if (keyCyclePrompt != null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF2B2200), RoundedCornerShape(6.dp))
                    .border(1.dp, NeonYellow, RoundedCornerShape(6.dp))
                    .padding(horizontal = 8.dp, vertical = 5.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = keyCyclePrompt!!,
                    color = NeonYellow,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        if (isFlashingBusy) {
            LinearProgressIndicator(
                progress = flashProgress.coerceIn(0f, 1f),
                modifier = Modifier.fillMaxWidth().height(6.dp),
                color = NeonYellow,
                trackColor = Color(0xFF2B2B2B)
            )
        }

        when (activeTab) {
            0 -> {
                Row(modifier = Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Column(
                        modifier = Modifier
                            .weight(0.85f)
                            .fillMaxHeight()
                            .background(CardDark, RoundedCornerShape(8.dp))
                            .border(1.dp, BorderDark, RoundedCornerShape(8.dp))
                            .padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                TabChip("32K", selectedRomSizeKb == 32) { selectedRomSizeKb = 32 }
                                TabChip("64K", selectedRomSizeKb == 64) { selectedRomSizeKb = 64 }
                                TabChip("128K", selectedRomSizeKb == 128) { selectedRomSizeKb = 128 }
                                TabChip("256K", selectedRomSizeKb == 256) { selectedRomSizeKb = 256 }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                SmallFolderBtn("PILIH DIR") { folderPicker.launch(null) }
                                if (customFolderUriStr != null) {
                                    SmallFolderBtn("RESET") { resetToDocumentsCandsTech() }
                                }
                            }
                        }

                        Text("DIR: $activeFolderLabel", color = NeonYellow, fontSize = 8.sp, maxLines = 1)

                        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            ActionBtn("READ ECU", Color(0xFF154360), Modifier.weight(1f)) { readRomFromEcu() }
                            ActionBtn("WRITE ECU", Color(0xFF922B21), Modifier.weight(1f)) {
                                if (connStatus != "CONNECTED" || serialPort == null) {
                                    log("[WARN] Hubungkan FTDI K-Line terlebih dahulu!")
                                } else if (binBytes == null) {
                                    log("[WARN] Belum ada file .BIN! Klik OPEN .BIN atau READ ECU dulu.")
                                } else if (!isFlashingBusy) {
                                    showWriteConfirmDialog = true
                                }
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            ActionBtn("OPEN .BIN", Color(0xFF2B2B2B), Modifier.weight(1f)) { binPicker.launch(arrayOf("*/*")) }
                            ActionBtn("OPEN .XDF", HondaRed, Modifier.weight(1f)) { xdfPicker.launch(arrayOf("*/*")) }
                        }

                        ActionBtn("SAVE .BIN TO DIR", Color(0xFF2E4A1E), Modifier.fillMaxWidth()) {
                            val data = binBytes
                            if (data != null) {
                                val outName = if (binName == "No .BIN loaded") {
                                    "TUNED_${System.currentTimeMillis() / 1000}.bin"
                                } else {
                                    "TUNED_$binName"
                                }
                                saveBinToActiveDefaultFolder(outName, data)
                            } else {
                                log("[WARN] Klik READ ECU atau OPEN .BIN dulu!")
                            }
                        }

                        Divider(color = BorderDark)

                        val orderedKeys = remember(xdfTables.keys.toList()) {
                            val list = xdfTables.keys.toMutableList()
                            val fuelKey = list.find { it.contains("Main Fuel Base Map", ignoreCase = true) }
                            if (fuelKey != null) {
                                list.remove(fuelKey)
                                list.add(fuelKey)
                            }
                            list
                        }

                        LazyColumn(
                            modifier = Modifier.weight(1.1f).fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            items(orderedKeys) { key ->
                                val isSel = key == selectedTableKey
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(if (isSel) HondaRed else Color(0xFF262626), RoundedCornerShape(4.dp))
                                        .clickable { selectedTableKey = key }
                                        .padding(horizontal = 7.dp, vertical = 6.dp)
                                ) {
                                    Text(key, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        Divider(color = NeonYellow.copy(alpha = 0.4f))

                        Column(
                            modifier = Modifier
                                .weight(1.0f)
                                .fillMaxWidth()
                                .background(Color(0xFF141414), RoundedCornerShape(6.dp))
                                .border(0.5.dp, BorderDark, RoundedCornerShape(6.dp))
                                .padding(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("DEBUG & RESPON ECU (${totalRxBytesCount}B)", color = NeonYellow, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    SmallFolderBtn("PING ECU") {
                                        val port = serialPort
                                        if (connStatus != "CONNECTED" || port == null) {
                                            log("[WARN] Klik USB CONNECT dulu!")
                                        } else {
                                            scope.launch(Dispatchers.IO) {
                                                log("[PING] Tes Wakeup 360bps + ECM ID + Sec 0x27...")
                                                lastRxDiagLogMs = 0L
                                                isFlashingBusy = true
                                                try {
                                                    wakeupAndEnterDiagHonda(port)
                                                    val idResp = sendHondaCommand(port, byteArrayOf(0x72), byteArrayOf(0x71, 0x00), retries = 1, timeoutMs = 240, verboseLog = true)
                                                    if (idResp.success && idResp.rawRx.size >= 10) {
                                                        val idStr = bytesToHex(idResp.rawRx.copyOfRange(4, idResp.rawRx.size - 1), 16)
                                                        withContext(Dispatchers.Main) { ecmIdHex = idStr }
                                                        log("[ECM ID] $idStr")
                                                    }
                                                    sendHondaCommand(
                                                        port,
                                                        byteArrayOf(0x27),
                                                        byteArrayOf(0xE0.toByte(), 0x48, 0x65, 0x6C, 0x6C, 0x6F, 0x48, 0x6F),
                                                        retries = 1,
                                                        timeoutMs = 250,
                                                        verboseLog = true
                                                    )
                                                    sendHondaCommand(
                                                        port,
                                                        byteArrayOf(0x27),
                                                        byteArrayOf(0xE0.toByte(), 0x77, 0x41, 0x72, 0x65, 0x59, 0x6F, 0x75),
                                                        retries = 1,
                                                        timeoutMs = 250,
                                                        verboseLog = true
                                                    )
                                                } finally {
                                                    isFlashingBusy = false
                                                }
                                            }
                                        }
                                    }
                                    SmallFolderBtn("CLR") {
                                        logs.clear()
                                        totalRxBytesCount = 0
                                        lastEcuRxHex = "LOG DIBERSIHKAN"
                                    }
                                }
                            }
                            Text(
                                text = "LAST RX: $lastEcuRxHex",
                                color = if (totalRxBytesCount > 0) Color(0xFF00E676) else Color(0xFFFF5252),
                                fontSize = 8.sp,
                                fontFamily = FontFamily.Monospace,
                                maxLines = 1
                            )
                            Spacer(Modifier.height(2.dp))
                            LazyColumn(modifier = Modifier.fillMaxSize()) {
                                items(logs) { line ->
                                    val lineColor = when {
                                        line.contains("ECU RX") || line.contains("[RX <- ECU]") -> Color(0xFF00E676)
                                        line.contains("[TX -> ECU]") || line.contains("[DIAG TX]") -> Color(0xFF40C4FF)
                                        line.contains("[WARN]") || line.contains("[ERR]") || line.contains("TIMEOUT") -> Color(0xFFFF5252)
                                        else -> Color.LightGray
                                    }
                                    Text(line, color = lineColor, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                                }
                            }
                        }
                    }

                    Column(
                        modifier = Modifier
                            .weight(1.75f)
                            .fillMaxHeight()
                            .background(CardDark, RoundedCornerShape(8.dp))
                            .border(1.dp, BorderDark, RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        val table = selectedTableKey?.let { xdfTables[it] }
                        val bytes = binBytes
                        val tick = tableRefreshTick

                        if (table != null && tick >= 0) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "${table.title} (0x${table.address.toString(16).uppercase(Locale.US)})",
                                        color = NeonYellow,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Ukuran: ${table.rows}x${table.cols} | Ketuk angka sel untuk edit manual",
                                        color = Color.Gray,
                                        fontSize = 9.sp
                                    )
                                }
                                if (bytes != null) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        SmallStepBtn("+5%") {
                                            for (r in 0 until table.rows) {
                                                for (c in 0 until table.cols) {
                                                    val cur = BinParser.readCell(bytes, table, r, c)
                                                    BinParser.writeCell(bytes, table, r, c, (cur * 1.05f).toInt())
                                                }
                                            }
                                            checksumHex = "0x${BinParser.calculateChecksum16(bytes).toString(16).uppercase(Locale.US).padStart(4, '0')}"
                                            tableRefreshTick++
                                            log("[MAP] ${table.title} +5%")
                                        }
                                        SmallStepBtn("+2%") {
                                            for (r in 0 until table.rows) {
                                                for (c in 0 until table.cols) {
                                                    val cur = BinParser.readCell(bytes, table, r, c)
                                                    BinParser.writeCell(bytes, table, r, c, (cur * 1.02f).toInt())
                                                }
                                            }
                                            checksumHex = "0x${BinParser.calculateChecksum16(bytes).toString(16).uppercase(Locale.US).padStart(4, '0')}"
                                            tableRefreshTick++
                                            log("[MAP] ${table.title} +2%")
                                        }
                                        SmallStepBtn("-2%") {
                                            for (r in 0 until table.rows) {
                                                for (c in 0 until table.cols) {
                                                    val cur = BinParser.readCell(bytes, table, r, c)
                                                    BinParser.writeCell(bytes, table, r, c, (cur * 0.98f).toInt())
                                                }
                                            }
                                            checksumHex = "0x${BinParser.calculateChecksum16(bytes).toString(16).uppercase(Locale.US).padStart(4, '0')}"
                                            tableRefreshTick++
                                            log("[MAP] ${table.title} -2%")
                                        }
                                    }
                                }
                            }
                            Spacer(Modifier.height(6.dp))
                            if (bytes == null) {
                                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                    Text(
                                        text = "Klik READ ECU atau OPEN .BIN untuk menampilkan & mengedit tabel besar di sini.",
                                        color = Color.Gray,
                                        fontSize = 12.sp
                                    )
                                }
                            } else {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .verticalScroll(rememberScrollState())
                                        .horizontalScroll(rememberScrollState())
                                ) {
                                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                        Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                            Box(modifier = Modifier.width(34.dp).height(24.dp), contentAlignment = Alignment.Center) {
                                                Text("R\\C", color = Color.Gray, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                            }
                                            for (c in 0 until table.cols.coerceAtMost(24)) {
                                                Box(
                                                    modifier = Modifier
                                                        .width(44.dp)
                                                        .height(24.dp)
                                                        .background(Color(0xFF282828), RoundedCornerShape(3.dp)),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text("C${c + 1}", color = NeonYellow, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                        }

                                        for (r in 0 until table.rows.coerceAtMost(24)) {
                                            Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                                Box(
                                                    modifier = Modifier
                                                        .width(34.dp)
                                                        .height(30.dp)
                                                        .background(Color(0xFF282828), RoundedCornerShape(3.dp)),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text("R${r + 1}", color = NeonYellow, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                                }
                                                for (c in 0 until table.cols.coerceAtMost(24)) {
                                                    val valCell = BinParser.readCell(bytes, table, r, c)
                                                    Box(
                                                        modifier = Modifier
                                                            .width(44.dp)
                                                            .height(30.dp)
                                                            .background(Color(0xFF141414), RoundedCornerShape(3.dp))
                                                            .border(0.7.dp, BorderDark, RoundedCornerShape(3.dp))
                                                            .clickable {
                                                                editingCellCoord = Pair(r, c)
                                                                editingCellInput = valCell.toString()
                                                            },
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        Text(
                                                            text = valCell.toString(),
                                                            color = Color.White,
                                                            fontSize = 11.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            fontFamily = FontFamily.Monospace
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            1 -> {
                Row(modifier = Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Column(
                        modifier = Modifier
                            .weight(1.7f)
                            .fillMaxHeight()
                            .background(CardDark, RoundedCornerShape(8.dp))
                            .border(1.dp, BorderDark, RoundedCornerShape(8.dp))
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text("AI AUTO-TUNING PRESETS & ENGINE SAFEGUARDS", color = NeonYellow, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        LazyColumn(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(AiPresetEngine.presets) { preset ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color(0xFF262626), RoundedCornerShape(6.dp))
                                        .padding(8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(preset.name, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        Text(preset.description, color = Color.LightGray, fontSize = 10.sp)
                                        Text("Target AFR: ${preset.targetAfr} | Limit: ${preset.rpmLimitTarget} RPM", color = NeonYellow, fontSize = 9.sp)
                                    }
                                    Button(
                                        onClick = {
                                            val bytes = binBytes
                                            if (bytes == null) {
                                                log("[WARN] Klik READ ECU atau OPEN .BIN dulu!")
                                            } else {
                                                val (count, check) = AiPresetEngine.applyPresetToBin(bytes, xdfTables, preset)
                                                checksumHex = "0x${BinParser.calculateChecksum16(bytes).toString(16).uppercase(Locale.US).padStart(4, '0')}"
                                                tableRefreshTick++
                                                log("[AI-PRESET] ${preset.name} applied ($count sel).")
                                                if (!check.isSafe) {
                                                    check.warnings.forEach { w -> log("[SAFEGUARD] $w") }
                                                } else {
                                                    log("[SAFEGUARD] Aman dalam batas toleransi mesin.")
                                                }
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = HondaRed),
                                        modifier = Modifier.height(34.dp)
                                    ) {
                                        Text("APPLY", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    Column(
                        modifier = Modifier
                            .weight(0.8f)
                            .fillMaxHeight()
                            .background(CardDark, RoundedCornerShape(8.dp))
                            .border(1.dp, BorderDark, RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        Text("DEBUG & SAFEGUARD LOG", color = NeonYellow, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = "LAST ECU RX (${totalRxBytesCount}B): $lastEcuRxHex",
                            color = if (totalRxBytesCount > 0) Color(0xFF00E676) else Color(0xFFFF5252),
                            fontSize = 8.sp,
                            fontFamily = FontFamily.Monospace,
                            maxLines = 1
                        )
                        Spacer(Modifier.height(2.dp))
                        LazyColumn(modifier = Modifier.fillMaxSize()) {
                            items(logs) { line ->
                                val lineColor = when {
                                    line.contains("ECU RX") || line.contains("[RX <- ECU]") -> Color(0xFF00E676)
                                    line.contains("[TX -> ECU]") || line.contains("[DIAG TX]") -> Color(0xFF40C4FF)
                                    line.contains("[WARN]") || line.contains("[ERR]") || line.contains("TIMEOUT") -> Color(0xFFFF5252)
                                    else -> Color.LightGray
                                }
                                Text(line, color = lineColor, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            }

            2 -> {
                Row(modifier = Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Column(modifier = Modifier.weight(1.7f).fillMaxHeight().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Column(modifier = Modifier.fillMaxWidth().background(CardDark, RoundedCornerShape(8.dp)).border(0.7.dp, BorderDark, RoundedCornerShape(8.dp)).padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("DATABASE MOTOR / ECU", color = NeonYellow, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    Text("${liveCatalogModels.size} record · pencarian motor, part, atau ECU ID", color = Color.LightGray, fontSize = 8.sp)
                                }
                                ActionBtn("CARI MOTOR", Color(0xFF154360), Modifier) { showLiveModelPicker = true }
                            }
                            val detectedCatalogModel = EcmDatabase.findExactModel(ecmIdHex.takeIf { it != "BELUM TERBACA" } ?: "")
                            val shownModel = detectedCatalogModel ?: selectedLiveCatalogModel
                            if (shownModel != null) {
                                val liveCapability = HondaLiveDataProfiles.capabilityForEcu(shownModel.ecmId)
                                Text(shownModel.bikeName, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text("${shownModel.yearRange} · ${shownModel.displacementCc.takeIf { it > 0 }?.let { "${it.toInt()} cc" } ?: "CC tidak tercatat"} · ${shownModel.manufacturer}", color = Color.LightGray, fontSize = 9.sp)
                                Text("ECU ID ${shownModel.ecmId} · Part ${shownModel.partNumber}", color = Color.LightGray, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                                Text(if (liveCapability != null) "PROFIL LIVE DATA TERDAFTAR" else "PROFIL LIVE DATA BELUM TERDAFTAR", color = if (liveCapability != null) Color(0xFF00E676) else Color(0xFFFFC107), fontSize = 8.sp)
                                if (selectedLiveCatalogModel != null && detectedCatalogModel != null && !selectedLiveCatalogModel!!.ecmId.equals(detectedCatalogModel.ecmId, true)) {
                                    Text("Motor pilihan katalog berbeda dari ECU yang terdeteksi. Identitas ECU aktif tetap menjadi acuan Live Data.", color = Color(0xFFFFC107), fontSize = 8.sp)
                                }
                            } else {
                                Text("ECU belum cocok dengan record database. Pilih motor untuk melihat data ECU; Live Data tetap memerlukan identitas ECU yang cocok.", color = Color.LightGray, fontSize = 9.sp)
                            }
                        }
                        Column(modifier = Modifier.fillMaxWidth().background(CardDark, RoundedCornerShape(8.dp)).padding(8.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("ENGINE RPM", color = Color.Gray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                Text(if (engineTelemetry.isRpmAvailable) "${engineTelemetry.engineRpm} RPM" else "-- RPM", color = if (engineTelemetry.isRpmAvailable && engineTelemetry.engineRpm > 9500) HondaRed else NeonYellow, fontSize = 15.sp, fontWeight = FontWeight.Black)
                            }
                            LinearProgressIndicator(
                                progress = (if (engineTelemetry.isRpmAvailable) engineTelemetry.engineRpm / 12000f else 0f).coerceIn(0f, 1f),
                                modifier = Modifier.fillMaxWidth().height(10.dp),
                                color = if (rpm > 9500) HondaRed else NeonYellow,
                                trackColor = Color(0xFF2B2B2B)
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            MetricCard("TPS", if (engineTelemetry.isTpsDegreesAvailable) String.format(Locale.US, "%.1f°", engineTelemetry.tpsDegrees) else "--", "THROTTLE ANGLE", Modifier.weight(1f))
                            MetricCard("BATTERY", if (engineTelemetry.isBattAvailable) String.format(Locale.US, "%.1f V", engineTelemetry.batteryVoltage) else "--", "VOLTAGE", Modifier.weight(1f))
                            MetricCard(engineTelemetry.tempSensorType.code, if (engineTelemetry.isTempAvailable) "${engineTelemetry.engineTempC} °C" else "--", engineTelemetry.tempSensorType.labelEn, Modifier.weight(1f))
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            MetricCard("O2 SENSOR", if (engineTelemetry.isO2Available) String.format(Locale.US, "%.3f V", engineTelemetry.o2Voltage) else "--", "RAW ECU VOLTAGE", Modifier.weight(1f))
                            MetricCard("AFR EST", if (engineTelemetry.isAfrEstimateAvailable) String.format(Locale.US, "%.2f : 1", engineTelemetry.afrEstimate) else "--", "NARROWBAND EST.", Modifier.weight(1f))
                            ActionBtn("DIAGNOSA", Color(0xFF154360), Modifier.weight(1f)) { showSensorDiagnosis = true }
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(CardDark, RoundedCornerShape(6.dp))
                                .border(0.7.dp, BorderDark, RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 5.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("ECM ID: $ecmIdHex", color = NeonYellow, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            Text("LIVE: $engineLiveDataState", color = if (engineLiveDataState.name == "ACTIVE") Color(0xFF00E676) else Color.Gray, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                            Text("DTC: $dtcResultText", color = Color.White, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            ActionBtn("ECM ID", Color(0xFF154360), Modifier.weight(1f)) {
                                startEcuDiagnosis()
                            }
                            ActionBtn(if (liveMonitorRequested) "STOP LIVE" else "LIVE DATA", if (liveMonitorRequested) Color(0xFF6B2525) else Color(0xFF174A3A), Modifier.weight(1f)) {
                                if (liveMonitorRequested) {
                                    liveMonitorRequested = false
                                } else if (elmConnected) {
                                    log("[ELM] Live Data Honda K-Line tidak dikirim melalui ELM327; ELM hanya menggunakan PID OBD-II standar.")
                                } else if (!ecuEngineAdapterOpen || !ecuEngineEcuIdentified || !ecuEngineEcuAlive) {
                                    log("[WARN] Buka adapter, identifikasi ECU, dan pastikan ECU merespons terlebih dahulu.")
                                } else if (!ecuEngine.liveDataSupported) {
                                    log("[LIVE DATA] ECU terdeteksi, tetapi belum memiliki kapabilitas Live Data yang terdaftar. Tidak ada protokol model lain yang dicoba.")
                                } else {
                                    liveMonitorRequested = true
                                    log("[LIVE DATA] Memulai polling berulang...")
                                }
                            }
                            ActionBtn("SCAN DTC", Color(0xFF2B2B2B), Modifier.weight(1f)) {
                                if ((!elmConnected && !ecuEngineAdapterOpen) || (!elmConnected && !ecuEngineEcuIdentified)) {
                                    log("[WARN] Buka adapter dan identifikasi ECU terlebih dahulu.")
                                } else {
                                    scope.launch {
                                        isFlashingBusy = true
                                        dtcResultText = "MEMBACA..."
                                        try {
                                            // Single serialized K-Line engine; do not use the legacy serialPort path.
                                            if (elmConnected) {
                                                val response = withContext(Dispatchers.IO) { elmSession?.readDtc().orEmpty() }
                                                log("[ELM][DTC] $response")
                                                return@launch
                                            }
                                            val result = withContext(Dispatchers.IO) { ecuEngine.readDtcs() }
                                            val display = when (result) {
                                                is com.candstech.engine.core.protocol.DtcReadResult.Success -> {
                                                    val currentText = if (result.currentState == com.candstech.engine.core.protocol.DtcChannelState.OK_EMPTY) {
                                                        "CURRENT: 0 DTC"
                                                    } else if (result.dtcs.isNotEmpty()) {
                                                        "CURRENT: " + result.dtcs.joinToString(" | ") { "${it.standardCode} (${it.titleId})" }
                                                    } else {
                                                        "CURRENT: ${result.currentState}"
                                                    }
                                                    val historyText = if (result.historyState == com.candstech.engine.core.protocol.DtcChannelState.OK_EMPTY) {
                                                        "HISTORY: 0 DTC"
                                                    } else if (result.historyDtcs.isNotEmpty()) {
                                                        "HISTORY: " + result.historyDtcs.joinToString(" | ") { "${it.standardCode} (${it.titleId})" }
                                                    } else {
                                                        "HISTORY: ${result.historyState}"
                                                    }
                                                    "$currentText || $historyText"
                                                }
                                                is com.candstech.engine.core.protocol.DtcReadResult.NoResponse -> "NO RESPONSE: ${result.reason}"
                                                is com.candstech.engine.core.protocol.DtcReadResult.Unrecognized -> "FORMAT TIDAK DIKENALI: ${result.rawHex}"
                                            }
                                            dtcResultText = display
                                            log("[DTC/ENGINE] $display")
                                        } catch (e: Exception) {
                                            dtcResultText = "ERROR: ${e.message ?: e.javaClass.simpleName}"
                                            log("[DTC/ENGINE] ${e.stackTraceToString()}")
                                        } finally {
                                            isFlashingBusy = false
                                        }
                                    }
                                }
                            }
                            ActionBtn("CLEAR DTC", Color(0xFF4A3030), Modifier.weight(1f)) {
                                log("[LOCKED] Clear DTC belum diaktifkan pada Stage 1. Fungsi tulis/perubahan ECU menunggu validasi protokol dan prosedur keselamatan.")
                            }
                            ActionBtn("RESET TP", Color(0xFF3A3A3A), Modifier.weight(1f)) {
                                log("[LOCKED] Reset TP belum termasuk Stage 1.")
                            }
                        }
                    }

                    Column(
                        modifier = Modifier
                            .weight(0.8f)
                            .fillMaxHeight()
                            .background(CardDark, RoundedCornerShape(8.dp))
                            .border(1.dp, BorderDark, RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        Text("DEBUG & K-LINE LOG", color = NeonYellow, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = "LAST ECU RX (${totalRxBytesCount}B): $lastEcuRxHex",
                            color = if (totalRxBytesCount > 0) Color(0xFF00E676) else Color(0xFFFF5252),
                            fontSize = 8.sp,
                            fontFamily = FontFamily.Monospace,
                            maxLines = 1
                        )
                        Spacer(Modifier.height(2.dp))
                        LazyColumn(modifier = Modifier.fillMaxSize()) {
                            items(logs) { line ->
                                val lineColor = when {
                                    line.contains("ECU RX") || line.contains("[RX <- ECU]") -> Color(0xFF00E676)
                                    line.contains("[TX -> ECU]") || line.contains("[DIAG TX]") -> Color(0xFF40C4FF)
                                    line.contains("[WARN]") || line.contains("[ERR]") || line.contains("TIMEOUT") -> Color(0xFFFF5252)
                                    else -> Color.LightGray
                                }
                                Text(line, color = lineColor, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            }
        }
    }
    if (showSensorDiagnosis) {
        val sensorLabels = mapOf(
            LiveSensor.RPM to "RPM", LiveSensor.TPS_DEGREES to "TPS Angle", LiveSensor.TPS_VOLTAGE to "TPS Voltage",
            LiveSensor.TPS_ADC to "TPS ADC", LiveSensor.ECT to "ECT / EOT Temperature", LiveSensor.ECT_VOLTAGE to "ECT / EOT Voltage",
            LiveSensor.IAT to "IAT Temperature", LiveSensor.IAT_VOLTAGE to "IAT Voltage", LiveSensor.MAP to "MAP Pressure",
            LiveSensor.MAP_VOLTAGE to "MAP Voltage", LiveSensor.BATTERY to "Battery Voltage", LiveSensor.INJECTOR to "Injector Pulse",
            LiveSensor.IGNITION_ADVANCE to "Ignition Advance", LiveSensor.SPEED to "Vehicle Speed", LiveSensor.O2 to "O2 Sensor",
            LiveSensor.STF to "STF Fuel Trim", LiveSensor.AP1_VOLTAGE to "AP1 Voltage", LiveSensor.AP2_VOLTAGE to "AP2 Voltage",
            LiveSensor.AP1_DEGREES to "AP1 Angle", LiveSensor.AP2_DEGREES to "AP2 Angle", LiveSensor.TP1_VOLTAGE to "TP1 Voltage",
            LiveSensor.TP2_VOLTAGE to "TP2 Voltage", LiveSensor.TP1_DEGREES to "TP1 Angle", LiveSensor.TP2_DEGREES to "TP2 Angle",
            LiveSensor.COR to "COR", LiveSensor.GEAR_STATE to "Gear State", LiveSensor.FLAG_A to "Status Flag A",
            LiveSensor.FLAG_B to "Status Flag B", LiveSensor.GEAR_POSITION to "Gear Position"
        )
        val units = mapOf(
            LiveSensor.RPM to "rpm", LiveSensor.TPS_DEGREES to "°", LiveSensor.TPS_VOLTAGE to "V", LiveSensor.TPS_ADC to "count",
            LiveSensor.ECT to "°C", LiveSensor.ECT_VOLTAGE to "V", LiveSensor.IAT to "°C", LiveSensor.IAT_VOLTAGE to "V",
            LiveSensor.MAP to "kPa", LiveSensor.MAP_VOLTAGE to "V", LiveSensor.BATTERY to "V", LiveSensor.INJECTOR to "ms",
            LiveSensor.IGNITION_ADVANCE to "°", LiveSensor.SPEED to "km/h", LiveSensor.O2 to "V", LiveSensor.STF to "%",
            LiveSensor.AP1_VOLTAGE to "V", LiveSensor.AP2_VOLTAGE to "V", LiveSensor.AP1_DEGREES to "°", LiveSensor.AP2_DEGREES to "°",
            LiveSensor.TP1_VOLTAGE to "V", LiveSensor.TP2_VOLTAGE to "V", LiveSensor.TP1_DEGREES to "°", LiveSensor.TP2_DEGREES to "°"
        )
        val sensorRows = engineTelemetry.parameterStates.entries
            .filter { it.key != LiveSensor.TPS_PERCENT && it.key != LiveSensor.AFR }
            .sortedBy { sensorLabels[it.key] ?: it.key.name }
        AlertDialog(
            onDismissRequest = { showSensorDiagnosis = false },
            title = { Text("DIAGNOSA SENSOR · ECU ${ecmIdHex}") },
            text = {
                Column(Modifier.fillMaxWidth()) {
                    Text("Tabel hanya menampilkan parameter dari tabel ECU yang sedang terbaca. Nilai yang tidak tersedia tidak diganti nol.", fontSize = 11.sp, color = Color.Gray)
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("PARAMETER", fontWeight = FontWeight.Bold, fontSize = 10.sp)
                        Text("NILAI / STATUS", fontWeight = FontWeight.Bold, fontSize = 10.sp)
                    }
                    Divider()
                    LazyColumn(Modifier.fillMaxWidth().heightIn(max = 420.dp)) {
                        items(sensorRows) { entry ->
                            val sensor = entry.key
                            val state = entry.value
                            val rawValue = engineTelemetry.diagnosticValues[sensor]
                            val unit = units[sensor].orEmpty()
                            val valueText = if (state == LiveParameterState.VALID && rawValue != null) {
                                val formatted = if (rawValue % 1.0 == 0.0) rawValue.toLong().toString() else String.format(Locale.US, "%.3f", rawValue)
                                if (unit.isBlank()) formatted else "$formatted $unit"
                            } else when (state) {
                                LiveParameterState.NOT_AVAILABLE_IN_KOEO -> "TIDAK AKTIF (KOEO)"
                                LiveParameterState.UNSUPPORTED -> "NOT SUPPORTED"
                                LiveParameterState.NOT_RESPONDING -> "NOT READ"
                                LiveParameterState.INVALID_RESPONSE -> "INVALID"
                                LiveParameterState.STALE -> "STALE"
                                LiveParameterState.WAITING_FOR_DATA -> "WAITING"
                                else -> state.name
                            }
                            Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(sensorLabels[sensor] ?: sensor.name, fontSize = 11.sp, modifier = Modifier.weight(1f))
                                Text(valueText, fontSize = 11.sp, color = if (state == LiveParameterState.VALID) Color(0xFF00E676) else Color(0xFFFFC107))
                            }
                            Divider(color = BorderDark)
                        }
                        if (engineTelemetry.isAfrEstimateAvailable) {
                            item {
                                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("AFR EST (host estimate)", fontSize = 11.sp)
                                    Text(String.format(Locale.US, "%.2f : 1", engineTelemetry.afrEstimate), fontSize = 11.sp, color = Color(0xFF00E676))
                                }
                            }
                        }
                    }
                    Text("Tabel aktif: 0x${engineTelemetry.activeTableHex} · status: $engineLiveDataState", fontSize = 9.sp, color = Color.Gray)
                }
            },
            confirmButton = { TextButton(onClick = { showSensorDiagnosis = false }) { Text("TUTUP") } }
        )
    }

    if (showLiveModelPicker) {
        AlertDialog(
            onDismissRequest = { showLiveModelPicker = false },
            title = { Text("Pilih Motor dari Database ECU") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = liveModelSearch,
                        onValueChange = { liveModelSearch = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Cari motor / part number / ECU ID") },
                        singleLine = true
                    )
                    Text("${filteredLiveCatalogModels.size} dari ${liveCatalogModels.size} record", fontSize = 11.sp, color = Color.Gray)
                    LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 420.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        items(filteredLiveCatalogModels) { model ->
                            val hasLiveProfile = HondaLiveDataProfiles.capabilityForEcu(model.ecmId) != null
                            Column(
                                modifier = Modifier.fillMaxWidth().background(CardDark, RoundedCornerShape(6.dp)).clickable {
                                    selectedLiveCatalogModel = model
                                    showLiveModelPicker = false
                                }.padding(8.dp),
                                verticalArrangement = Arrangement.spacedBy(2.dp)
                            ) {
                                Text(model.bikeName, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text("${model.yearRange} · ${model.partNumber}", color = Color.LightGray, fontSize = 10.sp)
                                Text("${model.manufacturer} · ECU ${model.ecmId}", color = Color.Gray, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                Text(if (hasLiveProfile) "PROFIL LIVE DATA TERDAFTAR" else "PROFIL LIVE DATA BELUM TERDAFTAR", color = if (hasLiveProfile) Color(0xFF00E676) else Color(0xFFFFC107), fontSize = 8.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showLiveModelPicker = false }) { Text("TUTUP") } }
        )
    }
}

@Composable
fun TabChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(if (selected) NeonYellow else Color(0xFF2A2A2A), RoundedCornerShape(4.dp))
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 5.dp)
    ) {
        Text(label, color = if (selected) Color.Black else Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun MetricCard(title: String, value: String, sub: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(CardDark, RoundedCornerShape(8.dp))
            .border(1.dp, BorderDark, RoundedCornerShape(8.dp))
            .padding(8.dp)
    ) {
        Text(title, color = Color.Gray, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Text(value, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Black)
        Text(sub, color = NeonYellow, fontSize = 9.sp)
    }
}

@Composable
fun ActionBtn(label: String, bg: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier.height(33.dp),
        shape = RoundedCornerShape(6.dp),
        colors = ButtonDefaults.buttonColors(containerColor = bg),
        contentPadding = PaddingValues(4.dp)
    ) {
        Text(label, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SmallStepBtn(label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(HondaRed, RoundedCornerShape(4.dp))
            .clickable { onClick() }
            .padding(horizontal = 9.dp, vertical = 4.dp)
    ) {
        Text(label, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SmallFolderBtn(label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(Color(0xFF333333), RoundedCornerShape(4.dp))
            .border(0.5.dp, NeonYellow, RoundedCornerShape(4.dp))
            .clickable { onClick() }
            .padding(horizontal = 6.dp, vertical = 3.dp)
    ) {
        Text(label, color = NeonYellow, fontSize = 8.sp, fontWeight = FontWeight.Bold)
    }
}
