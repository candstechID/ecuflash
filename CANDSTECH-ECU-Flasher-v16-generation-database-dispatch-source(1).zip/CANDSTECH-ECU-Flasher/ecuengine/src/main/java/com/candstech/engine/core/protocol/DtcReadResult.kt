package com.candstech.engine.core.protocol

enum class DtcChannelState {
    NOT_ATTEMPTED,
    OK_EMPTY,
    OK_CODES,
    NO_RESPONSE,
    UNRECOGNIZED
}

sealed class DtcReadResult {
    data class Success(
        /** Current/active DTCs. */
        val dtcs: List<HondaDtc>,
        val format: String,
        /** Stored/history DTCs are deliberately kept separate from active codes. */
        val historyDtcs: List<HondaDtc> = emptyList(),
        val currentState: DtcChannelState = if (dtcs.isEmpty()) DtcChannelState.OK_EMPTY else DtcChannelState.OK_CODES,
        val historyState: DtcChannelState = DtcChannelState.NOT_ATTEMPTED,
        val detail: String = ""
    ) : DtcReadResult()
    data class NoResponse(val reason: String) : DtcReadResult()
    data class Unrecognized(val rawHex: String, val reason: String) : DtcReadResult()
}

enum class DtcReadState {
    NOT_PERFORMED,
    OK_EMPTY,
    OK_CODES,
    NO_RESPONSE,
    UNRECOGNIZED
}

data class DtcParse(
    val dtcs: List<HondaDtc>,
    val format: String
)
