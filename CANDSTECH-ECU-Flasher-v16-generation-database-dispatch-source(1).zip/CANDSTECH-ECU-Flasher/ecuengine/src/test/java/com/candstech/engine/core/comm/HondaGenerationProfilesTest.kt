package com.candstech.engine.core.comm

import com.candstech.engine.data.ecu.EcmModel
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Test

class HondaGenerationProfilesTest {
    @Test fun gen2DatabaseRecordSelectsCurrentAndHistoryDtcCommands() {
        val model = EcmModel(
            id = "K59A-A11", partNumber = "30400-K59A-A11", ecmId = "0101C40F01",
            generationGroup = "GEN_2_ESP_SPORT", generationEvidence = "RECONSTRUCTED",
            dtcProfileId = "honda.kline.dtc.71_74"
        )
        val requests = HondaGenerationProfiles.dtcRequests(model)!!
        assertEquals(2, requests.size)
        assertArrayEquals(byteArrayOf(0x72,0x05,0x71,0x74,0xA4.toByte()), requests[0].copyBytes())
        assertArrayEquals(byteArrayOf(0x72,0x05,0x71,0x73,0xA5.toByte()), requests[1].copyBytes())
    }

    @Test fun gen1aHasFallbackAndUsesCalculatedChecksum() {
        val model = EcmModel(
            id = "GEN1A", partNumber = "GEN1A", generationGroup = "GEN_1A_SHINDENGEN",
            generationEvidence = "REFERENCE", dtcProfileId = "honda.kline.dtc.71_74"
        )
        val requests = HondaGenerationProfiles.dtcRequests(model)!!
        assertEquals(3, requests.size)
        assertArrayEquals(byteArrayOf(0x72,0x05,0x71,0x74,0xA4.toByte()), requests[0].copyBytes())
        assertArrayEquals(byteArrayOf(0x72,0x05,0x71,0x72,0xA6.toByte()), requests[1].copyBytes())
        assertArrayEquals(byteArrayOf(0x72,0x05,0x71,0x73,0xA5.toByte()), requests[2].copyBytes())
    }
}
