# CANDSTECH ECU Flasher — integration status

## Work completed in this source pass

- Routed the app's **SCAN DTC** action through `HondaProtocolEngine.readDtcs()` rather than the legacy `UsbSerialDevice` path. The result UI now distinguishes valid empty response, parsed codes, no response, and unrecognized payload.
- Disabled the UI actions for **CLEAR DTC** and **RESET TP** during Stage 1. They now report that the operation is gated instead of sending write/reset requests through the legacy serial path.
- Replaced remaining user-facing `REVCORE` labels in the app connection status and engine log headers with `CANDSTECH`; source attribution and license documents remain intact.

- Integrated the 53 production Kotlin/Java source files and 19 unit-test files from the supplied working-baseline project into the dedicated `:ecuengine` module.
- Renamed internal package namespace from `com.revcore.android` to `com.candstech.engine`; moved source and test paths accordingly.
- Renamed the storage source file/class to CANDSTECH naming.
- Updated Gradle module references to `:ecuengine`.
- Replaced the three-record synthetic demonstration ECM asset with the 489-record vehicle database from the supplied source archive. The JSON records were copied without record-level edits; their verification flags and caveats must remain visible to callers.
- Kept third-party attribution and license notices as separate documentation. Original source provenance is retained there; no third-party attribution was removed.
- Restored the ELM327 AT-command session as a distinct transport path; USB permission is requested for the selected device before the serial port is opened. A manual MODE selector supports AUTO / ELM327 / RAW_KLINE when USB descriptors are ambiguous.

- Connected the main dashboard to `HondaProtocolEngine.liveTelemetry` and `liveDataState` StateFlows. The RPM/TPS/ECT/IAT/MAP/battery/speed cards now render only values whose availability flags are valid; unavailable fields display `--` instead of legacy local variables or fabricated zero readings.
- Added a continuous **LIVE DATA / STOP LIVE** monitor. Requests are sequential on the same serialized engine, paced by transaction duration, and stopped after four consecutive invalid/missing responses. The monitor uses the active Compose lifecycle and does not fall back to the legacy serial connection.
- Live-data table selection is independent of response-header family routing and requires an EXACT database identity plus an explicit ECU-ID capability entry. Unsupported/unknown IDs never inherit another ECU layout.


## Regression correction applied to Stage 1 progress v2 source

- `MainActivity.onCreate()` now initializes `EcmDatabase` from application assets before the Compose UI and ECU engine are created. Previously there was no production call to `EcmDatabase.init(context)`, so identity matching could fall back to the three synthetic sample rows instead of the 489-record asset catalog.
- Added an explicit response layout for the captured `id.7100` (`72 05 71 00 18`) response: one leading selector byte, then the five-byte ECM ID. This matches the previously working capture `02 0F 71 00 01 01 C4 0F 01 EE 00 00 00 00 BA`; bytes after the ID remain preserved as trailing evidence.
- Corrected the legacy in-app lookup table: `0101C40F01` belongs to K59A-A11 / `30400-K59A-A11`, not K59J-A71. The 489-record JSON entry already identifies it as K59A-A11.
- Added a unit regression test for extraction of `0101C40F01` from the captured 0x71/0x00 payload. The test has been added but not executed because Gradle is unavailable in this environment.
- These changes restore the database-loading and response-layout paths in source; they do not establish a successful physical ECU connection until the updated app is built and tested on the user's adapter/ECU.

## Existing integration boundary

- The app UI opens the RAW K-Line transport through `openAdapterOnly(...)` and starts ECU identification through `identifyEcu()`. ELM327 uses its separate FelHR serial transport and AT-command session; it is not passed to the Honda proprietary K-Line engine.
- SCAN DTC and the new LIVE DATA action call the same serialized engine. The dashboard observes engine telemetry state; no sensor value is displayed unless its availability flag is valid. The ROM workflow still uses the legacy serial path and remains outside Stage 1 acceptance.
- The `:ecuengine` module contains transport, K-Line framing/echo handling, Honda protocol logic, identity parsing, Live Data parsing, DTC code, communication logging, and unit tests.
- Tests use fake transports for protocol behavior. They do not prove physical adapter/ECU compatibility.
- DTC clear, TP reset and ROM write remain gated; none is part of the Stage 1 hardware acceptance test.
- Restored the seven table definitions (10, 11, 13, 17, 16, 20, D1) from the user-provided `HondaLiveDataProfiles.java` into the Kotlin profile registry. The four primary tables are tried in declared order; three extension tables are polled after a primary response.
- These definitions are explicitly `RECONSTRUCTED`, not hardware-verified. Transmission and the `liveDataSupported` indicator are gated to the exact identified ECU ID `0101C40F01` (K59A-A11); other IDs remain `UNSUPPORTED_PROFILE` and receive no reconstructed table requests. A source unit test checks all seven request byte sequences and provenance status; it has not been executed. Narrowband O2 voltage is retained as voltage only; no AFR/lambda value is inferred.

## Stage 1 coverage snapshot

- 1A USB serial/adapter transport: source integrated; adapter-open UI path present.
- 1B K-Line transport: source integrated; physical hardware retest pending.
- 1C initialization/framing/checksum/echo: source and unit tests integrated; physical ECU retest pending.
- 1D transaction serialization/retry/recovery: partial coverage exists in session/transport code and tests; reconnect recovery must be reviewed before calling complete.
- 1E communication logger/sniffer: source integrated; UI export and full diagnostic trace workflow require review.
- 1F simulator/test harness: fake-transport unit tests exist for echo, timeout, split/partial response, checksum failure, and retry. This is not a full ECU simulator.

## Build and hardware status

- No Gradle build or Android APK build was run in this pass. ELM routing and reconstructed Live Data integration are source changes only and have not yet been compiled; the new unit test has not been executed; the user is separately compiling the prior progress ZIP. The working container has JDK 21 but no installed Gradle executable or Gradle wrapper JAR; the repository workflow is configured to provision Gradle 8.14 and Android SDK 36 in GitHub Actions.
- No unit tests were executed in this pass.
- No physical ECU test was performed in this environment. User-reported success of the original baseline is treated as prior evidence for its original setup, not as proof of this renamed/integrated source build.
- The supplied project archive lacks `gradle-wrapper.jar`; the wrapper properties alone are insufficient for a local wrapper build. CI/build setup still needs validation.

## Safety and data boundaries

- ECU catalog entries are not all verified diagnostic/remap targets. Preserve record-level evidence and warnings.
- Unknown ECU IDs must not be guessed from partial similarity.
- Unknown protocol requests must not be sent.
- `ORIGINAL.zip` is not included or modified.

## v5 AFR estimate addition
- Host-side narrowband AFR estimate: `17.0 - (O2_Voltage * 4.6)`.
- O2 and STF remain separately visible as ECU-derived values; AFR estimate is explicitly labelled.
- Out-of-range/missing O2 does not produce a numeric AFR estimate.
- Unit tests added; not executed. No build performed.


## v6 source correction (2026-11-26)
- v5 compile error fixed in the generic PID fallback: AFR EST and STF availability are explicitly false on that path; Honda table-20 decode remains the only source for STF and narrowband AFR estimate.
- USB attach filter restored for the supported serial bridge IDs and generic CDC/ACM class interfaces. This is intended to restore Android attach routing for QBD Virtual COM class devices; it does not establish driver compatibility or ECU communication.
- LiveDataProfile catalogue documentation corrected to match the reconstructed profiles and their RECONSTRUCTED evidence status.
- Source-only delivery; no build or physical adapter test performed.


## v7 Live Data correction (2026-11-26)

- Replaced one-shot Live Data request with sequential continuous polling and a stop control.
- Poll delay follows measured transaction time (150–1,000 ms) and failure backoff (300/600/1,200/2,400 ms); polling stops after four consecutive failures.
- Capability resolution is now exact ECU-ID based and independent of the response-header family. The only current capability entry is `0101C40F01`; other IDs are not guessed or sent these reconstructed requests.
- ECU-specific table cache and extension values are reset before a new identification attempt, so switching motorcycles cannot reuse the previous ECU's cached table.
- The change is source-only. No Gradle build, tests, APK, or physical hardware verification was performed.
