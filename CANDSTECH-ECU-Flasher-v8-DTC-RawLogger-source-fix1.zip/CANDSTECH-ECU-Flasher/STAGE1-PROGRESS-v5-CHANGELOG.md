# Stage 1 Progress v5 — narrowband AFR estimate

Based on the complete v4 source. No build was run.

## Changes
- Adds a host-side `AFR EST (NARROWBAND)` value using the explicitly requested scanner approximation: `AFR = 17.0 - (O2_Voltage * 4.6)`.
- O2 voltage is decoded using the Honda table-20 scale `raw * 5 / 256`.
- STF is exposed as percent using `(raw / 128 - 1) * 100`.
- Dashboard shows estimated AFR, raw O2 voltage and STF separately; unavailable/out-of-range O2 displays N/A.
- Adds unit tests for the estimate reference values and invalid input handling.

## Limitations
The AFR figure is a linear narrowband estimate, not ECU-reported AFR and not wideband measurement. Its usefulness is mainly as a rough diagnostic trend near stoichiometry. Live table offsets and response compatibility remain reconstructed and require real ECU captures.

## Validation
Source edits only. No Gradle build, APK build, or physical ECU test performed.
