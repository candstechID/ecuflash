# Stage 1 Progress v4 source-only changes

1. Restored ELM327 as a distinct AT-command transport using the earlier ELM327 source session.
2. Restored chipset descriptor helper for FTDI, CH340/CH341, CP210x and CDC/ACM.
3. Added explicit adapter mode selector: AUTO, ELM327, RAW_KLINE. This is necessary because USB bridge VID/PID identifies the serial chipset, not reliably the vehicle protocol.
4. USB permission request now uses a device-specific PendingIntent (request code = deviceId), explicit app package, mutable flag where required by Android USB permission callbacks, and a receiver that validates the returned device before reopening.
5. ELM opens at 38400 8N1, runs ATI/AT setup/ATSP0/ATRV/0100, and uses standard OBD DTC 03. Honda K-Line engine remains separate.
6. Restored the seven user-provided Honda live-data table definitions (10, 11, 13, 17, 16, 20, D1) with RECONSTRUCTED provenance. Primary tables: 17, 13, 11, 10; extensions: 16, 20, D1.
7. Reconstructed live-data transmission is strictly gated to exact ECU ID 0101C40F01 (K59A-A11). Other ECU IDs do not receive these queries. AFR is not derived from narrowband O2 voltage.

## Verification boundary
- Source inspection and ZIP integrity checks only.
- No Gradle build, APK build, Kotlin compilation, unit tests, or hardware test was run.
- The 2015 Vario 150's table response layout and scaling still require captured ECU replies. The ECU ID maps to the K59A-A11 catalog record, but this does not prove every Live Data field is compatible with the 2015 ECU.
- ELM permission callback and ELM AT startup require user-side USB testing. If the adapter descriptor does not identify ELM327, select MODE: ELM327 manually before connecting.
