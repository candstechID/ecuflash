# CANDSTECH ECU Flasher — Stage 1 Progress v8

## Perbaikan dari v7 berdasarkan hasil compile dan audit statis

- Memulihkan deklarasi `EcuLiveDataCapability` yang hilang. Properti primary/extension tetap bertipe `List<LiveTableProfile>` sehingga pemanggilan pada `HondaProtocolEngine` memiliki tipe yang konsisten.
- Menghapus fallback identitas ECU berbasis awalan ID yang dapat menebak K59A/K60/model lain. Jika identitas tidak cocok secara unik, hasilnya UNKNOWN dan tidak diberi ukuran ROM/offset/checksum tebakan.
- Mengubah pencocokan ID legacy menjadi unik; kandidat ambigu tidak dipilih dengan `firstOrNull()`.
- Menghapus pemakaian fallback PID 0x21 karena pemetaan local identifier Honda belum terbukti dan format respons sebelumnya tidak divalidasi dengan benar.
- DTC kini memakai parser frame lengkap yang memeriksa panjang, checksum, dan struktur respons. Respons yang tidak dikenali tidak diubah menjadi daftar DTC kosong.
- Identifikasi ECU baru mengosongkan bukti keluarga ECU sebelumnya. Exact ID database tidak otomatis dianggap sebagai bukti wire-family; keluarga hanya ditetapkan oleh resolver dari header respons.
- Wake pulse kini memeriksa konfigurasi baud, purge, penerimaan BREAK, dan pelepasan BREAK. Kegagalan setup tidak lagi dilaporkan sebagai jalur siap.
- Invalidasi Live Data juga menonaktifkan flag AFR EST dan STF agar nilai lama tidak dianggap masih tersedia.
- Menyesuaikan dan menambah unit test untuk perilaku reset keluarga ECU.

## Batas verifikasi

- Source ZIP v7 dan screenshot compile menjadi dasar perubahan.
- Tidak ada build Gradle/Android yang dijalankan pada lingkungan ini karena Gradle wrapper JAR dan instalasi Gradle tidak tersedia.
- Tidak ada uji adapter FTDI/ECU fisik.
- Registry Live Data tetap hanya untuk exact ECU ID `0101C40F01` dan status tabel tetap `RECONSTRUCTED`, bukan hardware-verified.
- READ/WRITE ROM masih perlu integrasi transport tersendiri; v8 tidak menyatakan flashing sudah berfungsi.

## Koreksi audit DTC dan RAW K-Line (revisi audit)

- Mengganti parser DTC heuristik pada jalur utama dengan parser halaman Honda PGM-FI: validasi header `0x02`, byte panjang sama dengan ukuran frame, checksum, service `0x74`/`0x73`, halaman 1–11, byte reserved, dan maksimal tiga pasangan kode utama/subkode.
- Respons DTC yang tidak cocok kini menghasilkan `UNRECOGNIZED` dengan HEX mentah, bukan dianggap daftar DTC kosong.
- Menghapus query tebakan `71/20` dan `00/00` dari baseline DTC. Baseline hanya mengirim current DTC page 01 (`72 05 74 01 14`); history belum digabung karena model hasil aplikasi belum memisahkan DTC aktif dan tersimpan.
- Menonaktifkan katalog CLEAR DTC generik sampai command/ACK terbukti pada ECU target. Tidak ada lagi percobaan beberapa subfunction clear secara berurutan.
- Menambahkan validator ACK clear yang memeriksa header `02`, panjang, service `60`, halaman yang diminta, dan checksum. Jalur clear engine juga menolak lebih dari satu kandidat.
- Menampilkan event RAW USB TX/RX sebelum parser pada panel debug K-Line, termasuk timestamp, arah, status, jumlah byte, dan HEX.
- Menambahkan unit test untuk current DTC page berisi tiga kode, halaman kosong, request baseline, dan validasi ACK clear.

## Batas verifikasi revisi audit

- Referensi publik komunitas mendukung format request `72 05 74 <page> <checksum>`, response `02 <len> 74 <page> 00 <pairs> <checksum>`, dan clear `72 05 60 <page> <checksum>`; ini tetap bukti protokol komunitas, bukan konfirmasi hardware K59A-A11.
- CLEAR DTC sengaja tetap terkunci pada profil generik karena belum ada capture ACK dari ECU target.
- Tidak menjalankan Gradle/build APK dan tidak melakukan uji perangkat/ECU fisik.
