# ELM327 and Vario 150 Live Data integration notes

## ELM327 regression found in v3
The v3 MainActivity retains the FelHR USB serial dependency and a generic UsbManager permission request, but it no longer contains the ELM327 session object, AT-command startup path, or interface-mode routing that existed in CANDSTECH-Diagnostic-ELM327-v5.1.2. Therefore v3's USB button routes the selected device into HondaProtocolEngine.openAdapterOnly(), i.e. raw K-Line, and cannot start ELM327 OBD-II diagnostics.

Restored into the v3 source tree (source-only):
- Elm327Session.kt (ATI, ATE0, ATL0, ATS1, ATH0, ATAT1, ATST64, ATSP0, ATRV, PID 0100, DTC 03/04).
- UsbAdapterSupport.kt (FTDI/CH340/CP210x/CDC identification; conservative chipset identification).

Still required before marking ELM integration complete: route selected USB device to either ELM327 AT session or Honda raw K-Line engine; ensure requestPermission uses a device-specific PendingIntent and a registered receiver; only open serial after permission grant; restore ELM UI action routing for identify/PID/DTC; avoid opening same USB device through both transports.

## Live Data Vario 150
The RevCore reference material defines reconstructed tables 17, 13, 11, 10, 16, 20 and D1. CANDSTECH keeps these layouts separate from protocol-family routing and selects them only through an exact ECU-ID capability registry after EcmDatabase reports an EXACT identity match. The current registry contains only the ECU ID for which the available profile material exists. This is not a default ECU selection and does not imply compatibility with other Honda ECUs. Unknown, partial, ambiguous or unregistered identities do not transmit these requests. The layouts remain RECONSTRUCTED and require physical validation.

The current capability registry has one exact ECU-ID entry (0101C40F01) because that is the only ID represented by the available reconstructed layout material. This is a per-ID capability entry, not an app-wide/default motorcycle selection. Other ECU IDs remain unsupported until their own protocol and layouts are evidenced. The user's physical test vehicle is reported as a 2015 Vario 150; the database's 2016-2017 model-year label is catalog metadata and is not treated as hardware confirmation. The differing table 21 vs table 16 references remain documented and are not silently merged. Table 20 O2 voltage and STF are ECU-derived fields; AFR EST is a separate host-side scanner approximation using `17.0 - (O2_V * 4.6)` only when O2 is in the 0..1 V narrowband range. It must never be labelled as ECU-reported AFR.

## Build policy
No Gradle build or APK build was run. This tree is a source-work area only.
