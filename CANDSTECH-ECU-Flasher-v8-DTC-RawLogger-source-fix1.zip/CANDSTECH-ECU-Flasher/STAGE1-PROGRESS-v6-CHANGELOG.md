# Stage 1 Progress v6 — source correction

## Changes
- Fixed the v5 Kotlin compile failure in the generic PID fallback: the fallback now explicitly reports host AFR estimate and STF as unavailable because that PID path does not decode the Honda table-20 STF payload.
- Restored the broader USB serial attach filter for supported FTDI, CH340/CH341, CP210x and generic CDC/ACM interfaces, including CDC class matching used by virtual COM adapters such as the QBD device shown in the user's screenshot.
- Corrected stale LiveDataProfile documentation so it describes the reconstructed catalogue and its RECONSTRUCTED evidence status rather than claiming the catalogue is empty.

## Not claimed
- No Gradle build or Kotlin compilation has been run in this environment.
- No physical ELM327/QBD adapter or ECU test has been run.
- CDC attach matching only lets Android route the attached device to the app; it does not prove the FelHR serial driver can open every CDC device. Runtime VID/PID, interface descriptors and port-open result still need to be checked.
- ELM initialization/AT commands and ECU OBD-II response remain to be verified on hardware.
