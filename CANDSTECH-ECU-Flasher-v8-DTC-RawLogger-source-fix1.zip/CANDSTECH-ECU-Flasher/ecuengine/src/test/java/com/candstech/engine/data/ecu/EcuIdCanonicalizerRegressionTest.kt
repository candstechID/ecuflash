package com.candstech.engine.data.ecu

import org.junit.Assert.assertEquals
import org.junit.Test

class EcuIdCanonicalizerRegressionTest {
    @Test
    fun captured7100PayloadExtractsFiveByteEcmIdAfterSelector() {
        // Payload decoded from the previously working ECU response:
        // 02 0F 71 00 01 01 C4 0F 01 EE 00 00 00 00 BA
        // Frame parser removes 02 0F 71 and checksum BA, leaving this payload.
        val payload = byteArrayOf(
            0x00, 0x01, 0x01, 0xC4.toByte(), 0x0F, 0x01,
            0xEE.toByte(), 0x00, 0x00, 0x00, 0x00
        )
        val knownIds = setOf("0101C40F01")
        val result = EcuIdCanonicalizer.canonicalizePayload(
            payload = payload,
            layout = IdResponseLayout(
                prefixBytes = 1,
                fieldBytes = 5,
                evidence = "USER_CAPTURED_STAGE_BASELINE",
                description = "selector byte followed by five-byte ECM ID"
            ),
            knownCanonicalIds = knownIds
        )
        assertEquals("0101C40F01", result.canonicalId)
        assertEquals("00", result.protocolPrefixHex)
        assertEquals("EE00000000", result.trailingHex)
    }
}
