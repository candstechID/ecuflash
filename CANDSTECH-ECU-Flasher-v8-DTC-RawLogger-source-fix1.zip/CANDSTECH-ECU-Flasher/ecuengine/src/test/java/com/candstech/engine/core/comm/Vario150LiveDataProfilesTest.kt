package com.candstech.engine.core.comm

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class Vario150LiveDataProfilesTest {
    @Test fun registersFourPrimaryAndThreeExtensionTables() {
        assertEquals(listOf("17", "13", "11", "10"), HondaLiveDataProfiles.primaryTables.map { it.tableId })
        assertEquals(listOf("16", "20", "D1"), HondaLiveDataProfiles.extendedTables.map { it.tableId })
        assertEquals(7, HondaLiveDataProfiles.all.size)
    }

    @Test fun requestFramesMatchTheSuppliedCatalog() {
        val expected = mapOf(
            "17" to "72 05 71 17 01", "13" to "72 05 71 13 05",
            "11" to "72 05 71 11 07", "10" to "72 05 71 10 08",
            "16" to "72 05 71 16 02", "20" to "72 05 71 20 F8",
            "D1" to "72 05 71 D1 47"
        )
        for (table in HondaLiveDataProfiles.all) {
            val actual = table.request.joinToString(" ") { "%02X".format(it.toInt() and 0xFF) }
            assertEquals(expected[table.tableId], actual)
            assertEquals(ProfileVerification.RECONSTRUCTED, table.verification)
            assertNotNull(table.provenance)
        }
        assertTrue(HondaLiveDataProfiles.table20.notes.contains("AFR"))
    }
}
