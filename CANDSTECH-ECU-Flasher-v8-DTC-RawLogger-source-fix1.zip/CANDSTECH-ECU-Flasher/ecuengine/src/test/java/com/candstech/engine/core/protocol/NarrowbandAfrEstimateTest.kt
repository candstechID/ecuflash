package com.candstech.engine.core.protocol

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class NarrowbandAfrEstimateTest {
    @Test fun scannerEstimateAtStoichiometricReference() {
        assertEquals(14.7f, NarrowbandAfrEstimate.fromVoltage(0.5f)!!, 0.0001f)
    }

    @Test fun scannerEstimateUsesRequestedLinearApproximation() {
        assertEquals(16.54f, NarrowbandAfrEstimate.fromVoltage(0.1f)!!, 0.0001f)
        assertEquals(12.86f, NarrowbandAfrEstimate.fromVoltage(0.9f)!!, 0.0001f)
    }

    @Test fun rejectsOutOfRangeVoltage() {
        assertNull(NarrowbandAfrEstimate.fromVoltage(-0.01f))
        assertNull(NarrowbandAfrEstimate.fromVoltage(1.01f))
        assertNull(NarrowbandAfrEstimate.fromVoltage(Float.NaN))
    }
}
