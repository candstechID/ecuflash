# CANDSTECH ECU Flasher — Stage 1 progress v7 (source only)

## Changes

- Replaced the one-shot LIVE DATA action with a continuous start/stop monitor. Requests are sequential and use measured transaction duration plus bounded failure backoff.
- Added automatic stop after four consecutive invalid/missing Live Data cycles, with connection/ECU-alive guards.
- Reconstructed the polling control flow using the supplied RevCore Java and Smali only as behavioral references; no RevCore coroutine implementation was copied into CANDSTECH.
- Added an exact ECU-ID Live Data capability registry. Selection requires `EcmDatabase` identity status `EXACT`; unknown, partial, ambiguous, and unregistered ECU IDs do not inherit a different model's tables.
- Decoupled Live Data table selection from response-header family routing. A Shindengen response family no longer blocks a separately exact-identified ECU capability merely because its family-specific DTC catalog is unresolved.
- Scoped primary and extension table selection to the selected ECU capability rather than a global table lookup.
- Reset cached primary/extension table state whenever ECU identification is started, preventing a previously connected motorcycle's cached table/sensor values from carrying into the next identity.
- Updated contradictory tests and integration notes to reflect the reconstructed catalog, exact-ID capability gate, and host-side AFR estimate distinction.
- Removed the stale `K60 64KB Profile` startup label from the dashboard.

## Evidence and limits

- The current reconstructed Live Data capability registry contains only ECU ID `0101C40F01`, because the available profile material supports only that exact identity. This is not a default model selection. Other ECU IDs remain explicitly unsupported until their own layouts are evidenced.
- The seven table layouts remain marked `RECONSTRUCTED`, not hardware-verified. O2/STF availability while the engine is stopped remains governed by their engine-running-only state.
- Existing USB/K-Line framing and transport code was not rewritten in this pass, to avoid destabilizing the previously working adapter connection path.
- No Gradle build, unit test execution, APK build, or physical ECU test was performed. The user is to compile the source and test it with the real adapter/ECU.
