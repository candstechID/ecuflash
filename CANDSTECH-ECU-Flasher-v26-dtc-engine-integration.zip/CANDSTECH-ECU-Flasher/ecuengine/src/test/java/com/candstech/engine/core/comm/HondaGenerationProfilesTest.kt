package com.candstech.engine.core.comm

import com.candstech.engine.data.ecu.EcmModel
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertEquals
import org.junit.Test

class HondaGenerationProfilesTest {
    @Test fun exactAssignedHondaKlineProfileUsesCurrentAndHistoryRequests() {
        val model = EcmModel(
            id = "K59A-A11", partNumber = "30400-K59A-A11", ecmId = "0101C40F01",
            generationGroup = "GEN_2_ESP_SPORT", generationEvidence = "RECONSTRUCTED",
            dtcProfileId = "honda.kline.dtc.71_74"
        )
        val requests = HondaGenerationProfiles.dtcRequests(model)!!
        assertEquals(2, requests.size)
        assertArrayEquals(byteArrayOf(0x72, 0x05, 0x74, 0x01, 0x14), requests[0].bytes)
        assertArrayEquals(byteArrayOf(0x72, 0x05, 0x73, 0x01, 0x15), requests[1].bytes)
    }

    @Test fun conflictingGenerationDoesNotEnableHondaKlineDtcCommands() {
        val model = EcmModel(
            id = "GEN1A", partNumber = "GEN1A", generationGroup = "GEN_1A_SHINDENGEN",
            generationEvidence = "CONFLICT", dtcProfileId = "honda.kline.dtc.71_74"
        )
        assertNull(HondaGenerationProfiles.dtcRequests(model))
    }

    @Test fun unknownOrConflictedCanProfileDoesNotEnableCandidateCommands() {
        val model = EcmModel(
            id = "PCX160-CANDIDATE", partNumber = "PCX160-CANDIDATE",
            generationGroup = "UNKNOWN", generationCandidate = "GEN_3B_CANBUS_160",
            generationEvidence = "CONFLICT", dtcProfileId = "honda.can.obd2.03_07_0a_04"
        )
        assertNull(HondaGenerationProfiles.canDtcCommands(model))
    }
}
