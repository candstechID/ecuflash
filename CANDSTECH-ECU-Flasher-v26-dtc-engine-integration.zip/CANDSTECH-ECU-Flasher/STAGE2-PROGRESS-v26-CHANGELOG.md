# CANDSTECH ECU Flasher v26 — DTC dispatch and ELM transaction fixes

## Changes
- Enabled the documented Honda K-Line Current DTC request `72 05 74 01 14` and History DTC request `72 05 73 01 15` for records explicitly assigned the Honda K-Line DTC profile, provided generation evidence is not CONFLICT or UNRESOLVED.
- Preserved the exact-ECU identity gate in `HondaProtocolEngine`; this change does not enable broadcast or cross-profile fallback.
- Requests are sent as the Current/History pair only; removed the former dead `dtcRequests() == null` path for eligible profiles.
- Serialized ELM327 AT/OBD commands with a coroutine Mutex to prevent Live Data and DTC transactions from interleaving.
- Corrected ELM protocol reporting: `ATSP0` selects automatic detection; `ATDPN` is queried after a valid OBD response to report the detected protocol.
- Updated standard OBD DTC decoding to skip the count byte only when it exactly matches the number of complete DTC pairs.
- Updated unit tests for the two Honda K-Line request frames and conflict gating.

## Limitations / evidence
- Honda K-Line request layout is marked RECONSTRUCTED pending raw ECU RX capture on the target hardware.
- CAN/ELM327 OBD-II remains a distinct standardized OBD path. This does not add a proprietary Honda K-Line-over-ELM327 implementation; its transport/protocol details still require validated adapter/ECU evidence.
- No Clear DTC or BIN write behavior was enabled by this change.
- Full Android build and hardware test must be performed in an Android SDK/Gradle environment; no successful APK build is claimed here.
