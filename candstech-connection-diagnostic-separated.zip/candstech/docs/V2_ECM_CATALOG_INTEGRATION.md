# Integrasi katalog referensi ECM V2

## Yang ditambahkan
- `app/src/main/assets/ecu/ecm_profiles.json` — salinan data profil V2.
- `app/src/main/assets/ecu/inventory.csv` — manifest metadata inventaris; tidak berisi file basemap.
- `EcmReferenceCatalog.kt` — pembaca read-only yang memvalidasi format dan jumlah record.

## Batas validitas sumber
Berkas V2 menyatakan 163 profil dengan status `RECONSTRUCTED`; seluruh 163 record memiliki `vehicleTested=false`. Karena itu katalog ini sengaja dipisahkan dari database identifikasi ECU aktif. Kode memberi `isSafeForAutomaticEcuMatching=false` dan tidak memetakan data ini ke alamat ROM, checksum, atau perintah flash.

## Basemap original
`ORIGINAL.zip` tidak disalin, diekstrak, diubah, atau ditimpa dalam tahap ini. `inventory.csv` hanya manifest metadata dari paket referensi V2, bukan otorisasi untuk mengubah atau mendistribusikan file basemap.

## Tahap berikutnya
1. Menampilkan katalog ini di layar referensi dengan label RECONSTRUCTED/UNTESTED.
2. Membuat pengaitan profil ke model ECU hanya setelah identitas hardware/ECM ID diverifikasi.
3. Memisahkan basemap read-only dari salinan kerja dan memeriksa checksum sebelum fitur tulis ROM diaktifkan.
