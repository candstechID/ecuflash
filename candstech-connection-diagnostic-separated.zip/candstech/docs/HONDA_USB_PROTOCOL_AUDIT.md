# CANDSTECH Honda USB / Protocol Audit – implementation checkpoint

## Scope

This checkpoint targets Honda motorcycles first, while keeping the architecture open for other manufacturers. `ORIGINAL.zip` is not included, extracted, rewritten, or modified. The basemap archive remains an immutable external reference.

## Source findings

### Main project (`candstech.zip`)

- USB serial dependency: `com.github.felhr85:UsbSerial:6.1.0`.
- The library's published support list includes FTDI, CP210x, CH34x, PL2303 and CDC serial devices. This is USB-UART driver support, not proof that an attached adapter has an automotive K-Line transceiver.
- The original connection routine selected `devices.values.first()` and immediately ran Honda initialization, ECM-ID queries and a background live-data poll. It therefore sent Honda commands before the operator had confirmed the physical adapter or target ECU.
- The original serial settings were hard-coded to 10400 baud, 8 data bits, no parity, 1 stop bit. Those settings are a candidate raw K-Line UART profile, not a universal Honda setting.
- The original Fast Init used a 70 ms break, a 130 ms wait, then Honda-specific requests. No hardware trace or exact ECU part-number evidence was supplied with the project ZIP to validate this sequence across Honda models.
- The original ROM reader contained automatic command/address probing. The original writer contained erase, block-write and post-write sequences. The supplied project did not contain a hardware validation record proving those sequences for every profile.

### V2 reference (`candstech-ecuflasher-v2.zip`)

- V2 contains a `KlineTransceiver.kt` and a large `HondaProtocolEngine.kt`.
- The engine imports `core.usb.UsbTransport`, `UsbSerialLibraryTransport`, `core.ftdi.FtdiSerialDriver`, `FtdiConstants`, plus `core.comm` classes.
- Those required USB/FTDI/comm implementations are absent from the supplied V2 archive. V2 therefore cannot be treated as a complete, standalone communication implementation or copied as-is into the main app.
- V2 also labels parts of its evidence inventory as reconstructed/hypothesis/unresolved; those records are not equivalent to validated hardware behavior.

## Changes made in this checkpoint

1. Added `core/usb/UsbAdapterSupport.kt` to label common FTDI, CH340/CH341, CP210x and CDC devices by VID/PID/interface class. This identifies the USB bridge only; it does not infer ELM327 or the vehicle protocol.
2. Replaced automatic first-device selection with a manual picker whenever more than one USB device is attached.
3. Added an explicit three-state `PILIH MODE` / `RAW K-LINE` / `ELM327` interface mode selector; no mode is selected by default. ELM327 connection is deliberately blocked in this checkpoint because its AT-command transport has not yet been implemented; it cannot be treated as a raw UART K-Line adapter.
4. USB connection now opens the selected serial bridge and configures 10400 8N1 but sends no ECU command automatically. The operator must explicitly request ECM identification.
5. Expanded the USB attach filter for common FTDI, WCH CH340/CH341, Silicon Labs CP210x and CDC/ACM interface IDs/classes.
6. Added fail-closed readiness gates for Honda live-data, DTC, ROM read and ROM write. Until an exact ECU part-number profile has trace-backed validation, the app will not send speculative live-data/DTC/dump/erase/write requests.
7. ROM read is fail-closed at the entry point until a profile is validated; if enabled in a future build it must still abort if Fast Init fails or the ECM identity cannot be matched to a known profile with a known ROM size. It no longer falls through to a generic size/address auto-probe.
8. ROM write/erase is disabled globally pending exact-profile hardware validation and recovery testing.

## Current capability status

| Capability | Status in this checkpoint |
|---|---|
| USB device enumeration | Implemented in source |
| Manual USB device selection | Implemented in source |
| FTDI / CH340 / CP210x / CDC identification | VID/PID/interface classification added; library still makes final driver decision |
| USB serial open / close | Implemented in source; no physical adapter test |
| ELM327 AT transport | Not implemented; blocked explicitly |
| Raw K-Line physical layer | Not hardware-verified; adapter must contain automotive K-Line level-shifter/transceiver |
| Honda Fast Init | Existing implementation retained for manual identification only; not validated across Honda model range |
| Honda ECM ID | Manual query path retained; not validated against a representative ECU matrix |
| Honda live data / DTC | Fail-closed until exact-profile validation |
| Honda ROM read | Fail-closed until exact-profile validation |
| Honda ROM write / erase | Fail-closed globally |
| Android build | Not run: Gradle wrapper JAR / Gradle installation and Android SDK are not available in this execution environment |
| Physical ECU test | Not run: no adapter or ECU hardware is connected to this environment |

## Evidence required to enable a profile

For each exact Honda ECM part number and adapter model, record:

- USB VID/PID, bridge driver and adapter board/transceiver identification.
- Connector pinout, supply voltage and K-Line/CAN physical layer confirmation.
- Raw TX/RX capture including local echo, timing and checksum.
- Repeatable init and ECU identity response, ignition state and ECU part number.
- ROM read procedure, exact size/address map, repeated dump equality and checksum/known-good comparison.
- For writing only: verified seed/key or boot authorization where applicable, erase completion, per-block ACK, full read-back equality, power-loss/recovery behavior and successful ECU restart.

No generic "Honda" flag is sufficient to enable flashing. Validation is per exact ECU profile and adapter/protocol combination.

## Local static checks performed

- `UsbAdapterSupport.kt` compiled against a minimal Android USB API stub.
- USB bridge classifier smoke test passed for FTDI, CH340, CP210x, CDC/ACM and unknown USB device cases (5 cases).
- MainActivity parser scan reported no Kotlin syntax/parser diagnostics. This is not an Android compilation; unresolved Android/Compose/third-party symbols remain because the Android SDK and Gradle environment are unavailable.
- ZIP integrity test passed.

## Protocol design implication

Honda R&D's published multi-protocol diagnostic paper for Honda power products (not a motorcycle-specific protocol specification) documents distinct serial, K-Line and CAN links, with different electrical levels and speeds. It is useful evidence that a universal Honda handshake must not be assumed, but it does not validate a motorcycle ECU command set. See the Honda Technical Review, "Diagnostic System for Power Products Using Automatic Recognition Technology for Multi-protocols", pp. 96–98.

## USB library note

The current source still uses FelHR85 UsbSerial 6.1.0. Its upstream README lists FTDI, CP210x, CH34x and CDC support. The library chooses the concrete driver by device IDs; our new classifier is informational and the actual `createUsbSerialDevice()` result remains the final open check. A future migration to a maintained alternative such as mik3y usb-serial-for-android should be a separate tested change, not mixed into this protocol safety checkpoint.
