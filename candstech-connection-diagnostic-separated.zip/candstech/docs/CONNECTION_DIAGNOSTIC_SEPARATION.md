# CANDSTECH — Pemisahan Koneksi Adapter dan Diagnostik ECU

## Tujuan

Koneksi USB hanya membuka transport adapter. Koneksi USB **tidak** menjalankan Fast Init, wake-up Honda, identifikasi ECU, polling sensor, DTC, atau operasi ROM.

## Alur koneksi adapter

1. Pengguna memilih mode interface secara eksplisit.
2. Aplikasi menampilkan daftar perangkat USB jika ada lebih dari satu perangkat.
3. Android USB permission diminta bila belum tersedia.
4. Aplikasi membuka USB serial dan menerapkan konfigurasi UART untuk mode RAW K-Line.
5. Status adapter menjadi `CONNECTED`; status sesi ECU tetap `NOT_STARTED`.
6. Tidak ada request diagnostik yang dikirim saat koneksi adapter berhasil.

## Alur diagnostik ECU Honda (manual)

1. Pengguna membuka tab `K-LINE DIAG`.
2. Pengguna menekan `START ECU DIAG`.
3. Baru pada tahap ini aplikasi mencoba Honda Fast Init dan identifikasi ECU.
4. Jika Fast Init gagal, status menjadi `INIT_FAILED` dan tidak ada query lanjutan.
5. Jika identitas tidak cocok dengan profil yang dikenal, status menjadi `ECU_UNRECOGNIZED`.
6. Live-data tetap fail-closed karena registry validasi saat ini belum mengesahkan profil apa pun.

## Status yang ditampilkan

- `NOT_STARTED`
- `STARTING`
- `INIT_FAILED`
- `IDENTIFYING`
- `ECU_UNRECOGNIZED`
- `ECU_IDENTIFIED`
- `ERROR`

`ECU_IDENTIFIED` hanya berarti ID cocok dengan katalog saat ini; bukan bukti bahwa semua layanan ECU tervalidasi.

## Proteksi

- SCAN DTC tetap diblokir kecuali profil lolos `HondaProtocolReadiness.isDtcValidated()`.
- CLEAR DTC dan RESET TP kini memakai gate validasi yang sama dan tetap diblokir secara default.
- ROM read dan write tetap mengikuti gate keselamatan yang ada; flashing belum dinyatakan tervalidasi.
- ELM327 belum didukung oleh transport AT-command pada build ini dan tidak boleh dipilih sebagai RAW K-Line.
- Basemap `ORIGINAL.zip` tidak disertakan dalam paket kerja dan tidak diubah.

## Batas verifikasi

Perubahan ini adalah pemisahan alur dan pengamanan kode. Belum ada klaim build Android penuh, USB OTG fisik, komunikasi ECU, atau uji kendaraan. Pengujian tersebut masih diperlukan.
