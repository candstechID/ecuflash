package com.candstech.ecuflasher

import com.felhr.usbserial.UsbSerialDevice
import com.candstech.engine.core.protocol.CommDataStage
import com.candstech.engine.core.protocol.CommEventCategory
import com.candstech.engine.core.protocol.CommunicationSniffer
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicLong

data class ObdPidReading(val pid: String, val name: String, val value: String, val raw: String)
data class ObdDtcSnapshot(
    val stored: List<String>,
    val pending: List<String>,
    val permanent: List<String>,
    val rawStored: String,
    val rawPending: String,
    val rawPermanent: String
)
data class ObdDiscoveryResult(
    val supportedPids: Set<String>,
    val liveData: List<ObdPidReading>,
    val dtcs: ObdDtcSnapshot,
    val protocolSummary: String
)

/** ELM327 AT-command transport. This is OBD-II only; it is not a Honda proprietary K-Line engine. */
class Elm327Session(private val port: UsbSerialDevice) {
    private val rx = ConcurrentLinkedQueue<Byte>()
    // ELM327 is a single command/response channel. Serialize callers so PID and DTC
    // commands cannot clear or consume each other's response bytes.
    private val commandMutex = Mutex()
    private val transactionIds = AtomicLong(1L)
    @Volatile private var activeTransactionId: Long? = null

    fun onBytes(data: ByteArray) {
        data.forEach { rx.add(it) }
        CommunicationSniffer.logEvent(
            category = CommEventCategory.RX,
            stage = CommDataStage.RAW_USB_IN,
            rawBytes = data,
            status = "ELM_RX_FRAGMENT",
            description = "ELM327 serial RX fragment untuk TX #${activeTransactionId ?: "UNMATCHED"}; bytes mentah sebelum decoding"
        )
    }

    fun clear() { rx.clear() }

    suspend fun command(command: String, timeoutMs: Long = 1800): String = commandMutex.withLock {
        val transactionId = transactionIds.getAndIncrement()
        val stale = mutableListOf<Byte>()
        while (true) stale.add(rx.poll() ?: break)
        if (stale.isNotEmpty()) {
            val staleBytes = stale.toByteArray()
            CommunicationSniffer.logEvent(
                category = CommEventCategory.RX,
                stage = CommDataStage.RAW_USB_IN,
                rawBytes = staleBytes,
                status = "ELM_STALE_RX",
                description = "Byte RX tertunda sebelum TX #$transactionId; dipisahkan agar tidak salah dikaitkan dengan command baru"
            )
        }

        activeTransactionId = transactionId
        val tx = (command.trim() + "\r").toByteArray(Charsets.US_ASCII)
        val startedAt = System.currentTimeMillis()
        try {
            CommunicationSniffer.logEvent(
                category = CommEventCategory.TX,
                stage = CommDataStage.RAW_USB_OUT,
                rawBytes = tx,
                status = "ELM_TX",
                description = "ELM327 TX #$transactionId command=${command.trim()} (ASCII + CR)"
            )
            try {
                port.write(tx)
            } catch (e: Exception) {
                CommunicationSniffer.logEvent(
                    category = CommEventCategory.ERROR,
                    stage = CommDataStage.RAW_USB_OUT,
                    rawBytes = tx,
                    status = "ELM_TX_FAILED",
                    description = "ELM327 TX #$transactionId gagal: ${e.message}",
                    errorDetails = e.toString(),
                    durationMs = System.currentTimeMillis() - startedAt
                )
                throw e
            }

            val out = StringBuilder()
            var elapsed = 0L
            while (elapsed < timeoutMs) {
                while (rx.isNotEmpty()) out.append((rx.poll()!!.toInt() and 0xff).toChar())
                if (out.contains(">")) break
                delay(20)
                elapsed += 20
            }
            val response = out.toString().replace("\u0000", "").trim()
            val hasPrompt = out.contains(">")
            val duration = System.currentTimeMillis() - startedAt
            if (response.isNotEmpty()) {
                CommunicationSniffer.logEvent(
                    category = CommEventCategory.PROTOCOL,
                    stage = CommDataStage.PARSED_RESPONSE,
                    status = if (hasPrompt) "ELM_RESPONSE_COMPLETE" else "ELM_RESPONSE_PARTIAL",
                    description = "ELM327 RX #$transactionId response=${response.replace("\n", " | ").replace("\r", "")} " +
                        "| prompt=${if (hasPrompt) "YES" else "NO"} | duration=${duration}ms"
                )
            }
            if (!hasPrompt) {
                CommunicationSniffer.logEvent(
                    category = CommEventCategory.ERROR,
                    stage = CommDataStage.RAW_USB_IN,
                    status = if (response.isEmpty()) "ELM_TIMEOUT_EMPTY" else "ELM_TIMEOUT_PARTIAL",
                    description = "ELM327 RX #$transactionId tidak menerima prompt '>' dalam ${timeoutMs}ms; " +
                        "partial=${response.replace("\n", " | ").replace("\r", "")}",
                    errorDetails = "ELM command response timeout",
                    durationMs = duration
                )
            }
            response
        } finally {
            activeTransactionId = null
        }
    }

    suspend fun initialize(): String {
        val id = command("ATI", 2500)
        require(id.isNotBlank() && !id.contains("TIMEOUT", true)) { "ELM327 tidak merespons ATI" }
        command("ATE0")
        command("ATL0")
        command("ATS1")
        command("ATH0")
        command("ATAT1")
        command("ATST64")
        val protocol = command("ATSP0")
        val voltage = command("ATRV")
        val supported = command("0100", 3500)
        require(!supported.contains("UNABLE TO CONNECT", true) && !supported.contains("CAN ERROR", true) && !supported.contains("BUS INIT", true)) {
            "Adapter merespons, tetapi ECU OBD-II belum terhubung: $supported"
        }
        require(supported.contains("41 00", true) || supported.contains("4100", true)) { "Tidak ada respons PID 0100 yang valid: $supported" }
        return "ID=$id | PROTOCOL=$protocol | VOLT=$voltage | PID=$supported"
    }

    suspend fun readPid(pid: String): String = command("01$pid", 2500)
    suspend fun readDtc(): String = command("03", 3500)

    /**
     * Read-only OBD-II capability discovery. This is intentionally limited to
     * standardized Mode 01 supported-PID bitmaps; it does not guess proprietary
     * Honda K-Line commands and does not send clear/programming services.
     */
    suspend fun discoverSupportedPids(): Set<String> {
        val supported = linkedSetOf<String>()
        var base = 0x00
        for (range in 0 until 8) {
            val pid = "%02X".format(base)
            val response = command("01$pid", 3000)
            val bytes = parseModeResponse(response, "41$pid", 4) ?: break
            for (bit in 0 until 32) {
                val byteValue = bytes[bit / 8].toInt() and 0xFF
                val bitMask = 1 shl (7 - (bit % 8))
                if ((byteValue and bitMask) != 0) {
                    val supportedPid = base + bit + 1
                    if (supportedPid <= 0xFF) supported += "%02X".format(supportedPid)
                }
            }
            val nextBitmapPid = base + 0x20
            val nextSupported = supported.contains("%02X".format(nextBitmapPid))
            if (!nextSupported || base >= 0xE0) break
            base += 0x20
        }
        return supported
    }

    /** Read all supported, implemented standard PIDs. Unsupported PIDs are never queried. */
    suspend fun readSupportedLiveData(supportedPids: Set<String>): List<ObdPidReading> {
        val definitions = listOf(
            "04" to "Calculated Engine Load", "05" to "Coolant Temperature",
            "06" to "Short Term Fuel Trim B1", "07" to "Long Term Fuel Trim B1",
            "08" to "Short Term Fuel Trim B2", "09" to "Long Term Fuel Trim B2",
            "0B" to "Intake Manifold Pressure", "0C" to "Engine RPM",
            "0D" to "Vehicle Speed", "0E" to "Ignition Timing",
            "0F" to "Intake Air Temperature", "10" to "MAF Air Flow",
            "11" to "Throttle Position", "14" to "O2 Sensor 1 Voltage / STFT",
            "15" to "O2 Sensor 2 Voltage / STFT", "16" to "O2 Sensor 3 Voltage / STFT",
            "17" to "O2 Sensor 4 Voltage / STFT", "18" to "O2 Sensor 5 Voltage / STFT",
            "19" to "O2 Sensor 6 Voltage / STFT", "1A" to "O2 Sensor 7 Voltage / STFT",
            "1B" to "O2 Sensor 8 Voltage / STFT",
            "1F" to "Run Time Since Start", "21" to "Distance With MIL On",
            "2F" to "Fuel Tank Level", "33" to "Barometric Pressure",
            "42" to "Control Module Voltage", "46" to "Ambient Air Temperature",
            "5C" to "Engine Oil Temperature"
        )
        val results = mutableListOf<ObdPidReading>()
        for ((pid, name) in definitions) {
            if (pid !in supportedPids) continue
            val raw = readPid(pid)
            val decoded = decodePidValue(pid, raw) ?: continue
            results += ObdPidReading(pid, name, decoded, raw)
        }
        return results
    }

    /** Read current/stored, pending and permanent DTCs separately. No clearing is performed. */
    suspend fun scanDtc(): ObdDtcSnapshot {
        val stored = command("03", 3500)
        val pending = command("07", 3500)
        val permanent = command("0A", 3500)
        return ObdDtcSnapshot(
            stored = decodeDtcMode(stored, "43"),
            pending = decodeDtcMode(pending, "47"),
            permanent = decodeDtcMode(permanent, "4A"),
            rawStored = stored,
            rawPending = pending,
            rawPermanent = permanent
        )
    }

    /** Full OBD discovery for a connected ECU. Does not invoke Mode 04 or any write service. */
    suspend fun autoDiscover(): ObdDiscoveryResult {
        val supported = discoverSupportedPids()
        val live = readSupportedLiveData(supported)
        val dtcs = scanDtc()
        return ObdDiscoveryResult(supported, live, dtcs, "OBD-II ELM327; standardized PID discovery")
    }

    // Kept as an explicit operation; never called by Auto Discovery.
    suspend fun clearDtc(): String = command("04", 3500)

    companion object {
        private fun parseModeResponse(response: String, marker: String, byteCount: Int): ByteArray? {
            val hex = response.uppercase().replace(Regex("[^0-9A-F]"), "")
            val at = hex.indexOf(marker.uppercase())
            if (at < 0) return null
            val start = at + marker.length
            if (hex.length < start + byteCount * 2) return null
            return ByteArray(byteCount) { i -> hex.substring(start + i * 2, start + i * 2 + 2).toInt(16).toByte() }
        }

        private fun decodePidValue(pid: String, response: String): String? {
            val hex = response.uppercase().replace(Regex("[^0-9A-F]"), "")
            val marker = "41$pid"
            val at = hex.indexOf(marker)
            if (at < 0) return null
            val payload = hex.substring(at + marker.length)
            if (payload.length < 2) return null
            val a = payload.substring(0, 2).toIntOrNull(16) ?: return null
            val b = payload.substring(2, 4).toIntOrNull(16) ?: 0
            return when (pid.uppercase()) {
                "04" -> "${a * 100.0 / 255.0} %"
                "05", "0F", "46", "5C" -> "${a - 40} °C"
                "06", "07", "08", "09" -> "${(a - 128) * 100.0 / 128.0} %"
                "0B", "33" -> "$a kPa"
                "0C" -> "${(a * 256 + b) / 4} rpm"
                "0D" -> "$a km/h"
                "0E" -> "${a / 2.0 - 64.0} °"
                "10" -> "${(a * 256 + b) / 100.0} g/s"
                "11" -> "${a * 100.0 / 255.0} %"
                in "14".."1B" -> "${a / 200.0} V; STFT=${(b - 128) * 100.0 / 128.0} %"
                "1F" -> "${a * 256 + b} s"
                "21" -> "${a * 256 + b} km"
                "2F" -> "${a * 100.0 / 255.0} %"
                "42" -> "${(a * 256 + b) / 1000.0} V"
                else -> null
            }
        }

        private fun decodeDtcMode(response: String, positiveService: String): List<String> {
            val hex = response.uppercase().replace(Regex("[^0-9A-F]"), "")
            val start = hex.indexOf(positiveService)
            if (start < 0) return emptyList()
            val payload = hex.substring(start + positiveService.length)
            val result = mutableListOf<String>()
            var i = 0
            while (i + 4 <= payload.length) {
                val raw = payload.substring(i, i + 4)
                i += 4
                if (raw == "0000") continue
                val value = raw.toIntOrNull(16) ?: continue
                val type = when ((value ushr 14) and 3) { 0 -> "P"; 1 -> "C"; 2 -> "B"; else -> "U" }
                val digit1 = (value ushr 12) and 3
                result += "$type$digit1${(value ushr 8) and 15}${(value ushr 4) and 15}${value and 15}"
            }
            return result.distinct()
        }

        fun decodePid(pid: String, response: String): String {
            val hex = response.uppercase().replace(Regex("[^0-9A-F]"), "")
            val marker = "41$pid".uppercase()
            val at = hex.indexOf(marker)
            if (at < 0 || hex.length < at + marker.length + 2) return "N/A"
            val a = hex.substring(at + marker.length, at + marker.length + 2).toIntOrNull(16) ?: return "N/A"
            val b = if (hex.length >= at + marker.length + 4) hex.substring(at + marker.length + 2, at + marker.length + 4).toIntOrNull(16) ?: 0 else 0
            return when (pid.uppercase()) {
                "0C" -> "${((a * 256 + b) / 4)} rpm"
                "0D" -> "$a km/h"
                "11" -> "${(a * 100 / 255)} %"
                "05" -> "${a - 40} °C"
                "0F" -> "${a - 40} °C"
                "0B" -> "$a kPa"
                "42" -> "${(a * 256 + b) / 1000.0} V"
                else -> "$a"
            }
        }

        fun decodeDtc(response: String): List<String> = decodeDtcMode(response, "43")
    }
}
