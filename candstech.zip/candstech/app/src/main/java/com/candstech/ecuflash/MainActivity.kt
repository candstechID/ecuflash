package com.candstech.ecuflash

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val BgDark = Color(0xFF0F0F0F)
val CardDark = Color(0xFF1E1E1E)
val HondaRed = Color(0xFFE10600)
val NeonYellow = Color(0xFFD4FF00)

class MainActivity : ComponentActivity() {
    private lateinit var kLineManager: HondaKLineManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        kLineManager = HondaKLineManager(this)
        setContent {
            EcuFlasherScreen(kLineManager)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        kLineManager.cleanup()
    }
}

@Composable
fun EcuFlasherScreen(manager: HondaKLineManager) {
    val connState by manager.connectionState.collectAsState()
    val sensor by manager.sensorData.collectAsState()
    val logs by manager.logMessages.collectAsState()
    var topSpeed by remember { mutableStateOf(0) }
    var selectedBike by remember { mutableStateOf("Vario 110/125/150 (K25/K59)") }

    if (sensor.ecuSpeed > topSpeed) topSpeed = sensor.ecuSpeed

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDark)
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Header Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(CardDark, RoundedCornerShape(8.dp))
                .border(1.dp, Color(0xFF333333), RoundedCornerShape(8.dp))
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("CANDS TECH", color = NeonYellow, fontWeight = FontWeight.Black, fontSize = 18.sp)
                Text("ECU FLASHER & K-LINE PRO", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = connState,
                    color = if (connState == "CONNECTED") NeonYellow else HondaRed,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
                Button(
                    onClick = { if (connState == "CONNECTED") manager.disconnect() else manager.connect() },
                    colors = ButtonDefaults.buttonColors(containerColor = if (connState == "CONNECTED") Color.DarkGray else HondaRed),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    Text(if (connState == "CONNECTED") "DISCONNECT" else "CONNECT K-LINE", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // RPM Bar
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(CardDark, RoundedCornerShape(8.dp))
                .padding(10.dp)
        ) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("ENGINE RPM", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("${sensor.rpm} RPM", color = if (sensor.rpm > 9500) HondaRed else NeonYellow, fontSize = 18.sp, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.height(4.dp))
            LinearProgressIndicator(
                progress = (sensor.rpm / 12000f).coerceIn(0f, 1f),
                modifier = Modifier.fillMaxWidth().height(12.dp),
                color = if (sensor.rpm > 9500) HondaRed else NeonYellow,
                trackColor = Color(0xFF2B2B2B)
            )
        }

        // Main Gauges + Logs
        Row(modifier = Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            // Left Sensor Grid
            Column(modifier = Modifier.weight(1.4f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SensorCard("ECU SPEED", "${sensor.ecuSpeed} km/h", "TOP: $topSpeed km/h", Modifier.weight(1f))
                    SensorCard("TPS ANGLE", String.format("%.1f°", sensor.tpsDeg), String.format("%.2f V", sensor.tpsVolt), Modifier.weight(1f))
                    SensorCard("AFR RATIO", String.format("%.1f : 1", sensor.afr), "TARGET 14.7", Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SensorCard("ECT TEMP", "${sensor.ectTemp} °C", "COOLANT", Modifier.weight(1f))
                    SensorCard("IAT TEMP", "${sensor.iatTemp} °C", "INTAKE AIR", Modifier.weight(1f))
                    SensorCard("MAP / BAT", "${sensor.mapKpa} kPa", String.format("%.1f V", sensor.batteryVolt), Modifier.weight(1f))
                }
                // Diagnostic Buttons
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DiagButton("SCAN DTC", Color(0xFF2B2B2B), Modifier.weight(1f)) { manager.scanDtc() }
                    DiagButton("CLEAR DTC", HondaRed, Modifier.weight(1f)) { manager.clearDtc() }
                    DiagButton("RESET TP", Color(0xFF2B2B2B), Modifier.weight(1f)) { manager.resetTp() }
                    DiagButton("RESET TOP", Color(0xFF2B2B2B), Modifier.weight(1f)) { topSpeed = 0 }
                }
            }

            // Right Terminal Log
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .background(CardDark, RoundedCornerShape(8.dp))
                    .border(1.dp, Color(0xFF333333), RoundedCornerShape(8.dp))
                    .padding(8.dp)
            ) {
                Text("K-LINE HEX & DIAGNOSTIC LOG", color = NeonYellow, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(logs) { line ->
                        Text(line, color = Color.LightGray, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }
    }
}

@Composable
fun SensorCard(title: String, value: String, sub: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(CardDark, RoundedCornerShape(8.dp))
            .border(1.dp, Color(0xFF2E2E2E), RoundedCornerShape(8.dp))
            .padding(10.dp)
    ) {
        Text(title, color = Color.Gray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Text(value, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)
        Text(sub, color = NeonYellow, fontSize = 10.sp)
    }
}

@Composable
fun DiagButton(label: String, bg: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier.height(42.dp),
        shape = RoundedCornerShape(6.dp),
        colors = ButtonDefaults.buttonColors(containerColor = bg),
        contentPadding = PaddingValues(4.dp)
    ) {
        Text(label, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}
