package com.candstech.ecuflasher

import java.io.InputStream
import javax.xml.parsers.DocumentBuilderFactory
import org.w3c.dom.Element

data class XDFTableInfo(
    val title: String,
    val address: Int,
    val rows: Int,
    val cols: Int,
    val elementSizeBits: Int = 8,
    val equation: String = "X",
    val category: String = "General"
)

object BinParser {
    fun parseXdfStream(inputStream: InputStream): MutableMap<String, XDFTableInfo> {
        val tables = mutableMapOf<String, XDFTableInfo>()
        try {
            val factory = DocumentBuilderFactory.newInstance()
            val builder = factory.newDocumentBuilder()
            val doc = builder.parse(inputStream)
            doc.documentElement.normalize()

            val tableNodes = doc.getElementsByTagName("XDFTABLE")
            for (i in 0 until tableNodes.length) {
                val node = tableNodes.item(i) as? Element ?: continue
                val title = node.getElementsByTagName("title").item(0)?.textContent?.trim()
                    ?: "Table_${i + 1}"

                val embedded = node.getElementsByTagName("EMBEDDEDDATA").item(0) as? Element
                val rawAddr = embedded?.getAttribute("mmedaddress")?.trim() ?: "0x0"
                val cleanAddr = rawAddr.removePrefix("0x").removePrefix("0X")
                val address = cleanAddr.toIntOrNull(16) ?: 0
                val rows = embedded?.getAttribute("mmedrowcount")?.toIntOrNull()?.coerceAtLeast(1) ?: 1
                val cols = embedded?.getAttribute("mmedcolcount")?.toIntOrNull()?.coerceAtLeast(1) ?: 1
                val bits = embedded?.getAttribute("mmedelementsizebits")?.toIntOrNull() ?: 8

                val mathNode = node.getElementsByTagName("MATH").item(0) as? Element
                val eq = mathNode?.getAttribute("equation")?.takeIf { it.isNotBlank() } ?: "X"

                tables[title] = XDFTableInfo(
                    title = title,
                    address = address,
                    rows = rows,
                    cols = cols,
                    elementSizeBits = bits,
                    equation = eq
                )
            }
        } catch (_: Exception) {
        }

        if (tables.isEmpty()) {
            loadDefaultHondaKeihinTables(tables)
        }
        return tables
    }

    fun loadDefaultHondaKeihinTables(targetMap: MutableMap<String, XDFTableInfo>) {
        targetMap["Main Fuel Base Map (TPS vs RPM)"] = XDFTableInfo("Main Fuel Base Map (TPS vs RPM)", 0x4000, 12, 16, 8, "X * 0.05", "Fuel")
        targetMap["Ignition Advance Timing Map"] = XDFTableInfo("Ignition Advance Timing Map", 0x4200, 12, 16, 8, "X * 0.5", "Ignition")
        targetMap["RPM Hard Rev Limiter"] = XDFTableInfo("RPM Hard Rev Limiter", 0x5100, 1, 4, 16, "X", "Limiter")
        targetMap["Target AFR Closed-Loop"] = XDFTableInfo("Target AFR Closed-Loop", 0x5300, 8, 8, 8, "14.7 * (128 / X)", "AFR")
    }

    fun readCell(binData: ByteArray, table: XDFTableInfo, row: Int, col: Int): Int {
        val offset = table.address + (row * table.cols) + col
        return if (offset in binData.indices) {
            binData[offset].toInt() and 0xFF
        } else {
            0
        }
    }

    fun writeCell(binData: ByteArray, table: XDFTableInfo, row: Int, col: Int, newValue: Int): Boolean {
        val offset = table.address + (row * table.cols) + col
        return if (offset in binData.indices) {
            binData[offset] = EngineSafeguards.clampByteValue(newValue)
            true
        } else {
            false
        }
    }

    fun calculateChecksum16(binData: ByteArray): Int {
        var sum = 0
        for (b in binData) {
            sum = (sum + (b.toInt() and 0xFF)) and 0xFFFF
        }
        return sum
    }

    // Checksum 8-bit Honda resmi (dari HondaECU.py: ((sum(data) ^ 0xFF) + 1) & 0xFF)
    fun checksum8bitHonda(data: ByteArray): Int {
        var sum = 0
        for (b in data) {
            sum += (b.toInt() and 0xFF)
        }
        return ((sum xor 0xFF) + 1) and 0xFF
    }

    // Checksum 8-bit blok write (dari HondaECU.py: 0xff - ((sum(data) - 1) >> 8))
    fun checksum8bitBlock(data: ByteArray): Int {
        var sum = 0
        for (b in data) {
            sum += (b.toInt() and 0xFF)
        }
        return (0xFF - ((sum - 1) shr 8)) and 0xFF
    }

    // Validasi & perbaiki checksum file .BIN pada offset standar Honda (ukuran - 8, misal 0x3FFF8 untuk 256KB)
    fun fixHondaRomChecksum(binData: ByteArray, overrideOffset: Int? = null): Triple<Int, Int, Boolean> {
        if (binData.size < 16) return Triple(0, 0, false)
        val cksumOffset = overrideOffset ?: (binData.size - 8)
        val fileCksum = binData[cksumOffset].toInt() and 0xFF
        var sum = 0
        for (i in binData.indices) {
            if (i != cksumOffset) {
                sum += (binData[i].toInt() and 0xFF)
            }
        }
        val calcCksum = ((sum xor 0xFF) + 1) and 0xFF
        val fixed = fileCksum != calcCksum
        if (fixed) {
            binData[cksumOffset] = calcCksum.toByte()
        }
        return Triple(fileCksum, calcCksum, fixed)
    }
}
