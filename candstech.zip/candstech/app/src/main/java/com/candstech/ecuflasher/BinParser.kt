package com.candstech.ecuflasher

import android.content.Context
import android.net.Uri
import org.xmlpull.v1.XmlPullParser
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

data class XDFTableInfo(
    val tableId: String,
    val title: String,
    val description: String,
    val address: Int,
    val rows: Int,
    val cols: Int,
    val elementSize: Int, // 1 or 2 bytes
    val units: String,
    val minVal: Float,
    val maxVal: Float
)

class XDFDefinitionParser(inputStream: InputStream) {
    val tables: MutableMap<String, XDFTableInfo> = mutableMapOf()
    var vehicleName: String = "Honda Vario 160 / Scoopy K2F"
    var ecuName: String = "Keihin 32-bit KWP2000"
    var fileSize: Int = 262144

    init {
        parseXdf(inputStream)
    }

    private fun parseXdf(inputStream: InputStream) {
        try {
            val parser = android.util.Xml.newPullParser()
            parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
            parser.setInput(inputStream, null)

            var eventType = parser.eventType
            var currentTag = ""
            var tId = "0x0002"
            var title = "Fuel Injection Map (16x16)"
            var desc = "Peta Durasi Injeksi Bahan Bakar"
            var addr = 0x2000
            var datasize = 2
            var units = "μs"
            var minVal = 500.0f
            var maxVal = 12000.0f
            var rows = 16
            var cols = 16

            while (eventType != XmlPullParser.END_DOCUMENT) {
                val name = parser.name
                when (eventType) {
                    XmlPullParser.START_TAG -> {
                        currentTag = name ?: ""
                        if (name.equals("XDFTABLE", ignoreCase = true)) {
                            tId = parser.getAttributeValue(null, "uniqueID") ?: "0x0002"
                            title = "Fuel Map"
                            rows = 16
                            cols = 16
                        }
                    }
                    XmlPullParser.TEXT -> {
                        val text = parser.text?.trim() ?: ""
                        if (text.isNotEmpty()) {
                            when {
                                currentTag.equals("TITLE", ignoreCase = true) -> title = text
                                currentTag.equals("ADDR", ignoreCase = true) -> addr = text.toInt(16)
                                currentTag.equals("datasize", ignoreCase = true) -> datasize = text.toIntOrNull() ?: 2
                            }
                        }
                    }
                    XmlPullParser.END_TAG -> {
                        if (name.equals("XDFTABLE", ignoreCase = true)) {
                            tables[tId] = XDFTableInfo(tId, title, desc, addr, rows, cols, datasize, units, minVal, maxVal)
                        }
                        currentTag = ""
                    }
                }
                eventType = parser.next()
            }
            if (tables.isEmpty()) {
                // Default fallback table if xml is empty
                tables["0x0002"] = XDFTableInfo("0x0002", "Fuel Injection Map (16x16)", "Peta Bahan Bakar Utama", 0x2000, 16, 16, 2, "μs", 500f, 12000f)
                tables["0x0003"] = XDFTableInfo("0x0003", "Ignition Advance Map (16x16)", "Kurva Pengapian BTDC", 0x2200, 16, 16, 1, "deg", 0f, 45f)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            tables["0x0002"] = XDFTableInfo("0x0002", "Fuel Injection Map (16x16)", "Peta Bahan Bakar Utama", 0x2000, 16, 16, 2, "μs", 500f, 12000f)
            tables["0x0003"] = XDFTableInfo("0x0003", "Ignition Advance Map (16x16)", "Kurva Pengapian BTDC", 0x2200, 16, 16, 1, "deg", 0f, 45f)
        }
    }
}

class ECUBinFile(var data: ByteArray = ByteArray(0)) {
    var filepath: String? = null

    fun loadFromUri(context: Context, uri: Uri) {
        context.contentResolver.openInputStream(uri)?.use { inputStream ->
            data = inputStream.readBytes()
        }
        filepath = uri.path
    }

    fun createMock(size: Int = 262144, ecuModel: String = "VARIO160") {
        data = ByteArray(size) { 0xFF.toByte() }
        val headerText = "HONDA KEIHIN $ecuModel VER_1.0".toByteArray(Charsets.US_ASCII)
        System.arraycopy(headerText, 0, data, 0x0000, min(headerText.size, data.size))

        // Fuel Map 16x16 at 0x2000
        for (r in 0 until 16) {
            for (c in 0 until 16) {
                val value = (1200 + (r * 140) + (c * 85)).toShort()
                val offset = 0x2000 + (r * 16 + c) * 2
                if (offset + 2 <= data.size) {
                    val bb = ByteBuffer.allocate(2).order(ByteOrder.LITTLE_ENDIAN).putShort(value)
                    System.arraycopy(bb.array(), 0, data, offset, 2)
                }
            }
        }

        // Ignition Map 16x16 at 0x2200
        for (r in 0 until 16) {
            for (c in 0 until 16) {
                val advDeg = 15.0 + (c * 1.2) - (r * 0.4)
                val rawByte = max(10, min(80, (advDeg * 2).toInt())).toByte()
                val offset = 0x2200 + (r * 16 + c)
                if (offset < data.size) {
                    data[offset] = rawByte
                }
            }
        }
    }

    fun readTable(tableInfo: XDFTableInfo): List<List<Float>> {
        val matrix = mutableListOf<MutableList<Float>>()
        val elemSize = tableInfo.elementSize
        val addr = tableInfo.address

        for (r in 0 until tableInfo.rows) {
            val rowVals = mutableListOf<Float>()
            for (c in 0 until tableInfo.cols) {
                val idx = addr + (r * tableInfo.cols + c) * elemSize
                val value = if (idx + elemSize <= data.size) {
                    if (elemSize == 1) {
                        (data[idx].toInt() and 0xFF).toFloat()
                    } else {
                        ByteBuffer.wrap(data, idx, 2).order(ByteOrder.LITTLE_ENDIAN).short.toInt().toFloat()
                    }
                } else {
                    0.0f
                }
                rowVals.add(value)
            }
            matrix.add(rowVals)
        }
        return matrix
    }

    fun writeTableCell(tableInfo: XDFTableInfo, row: Int, col: Int, newVal: Float) {
        val elemSize = tableInfo.elementSize
        val addr = tableInfo.address
        val idx = addr + (row * tableInfo.cols + col) * elemSize
        if (idx + elemSize <= data.size) {
            if (elemSize == 1) {
                data[idx] = (newVal.toInt() and 0xFF).toByte()
            } else {
                val shortVal = newVal.toInt().toShort()
                val bb = ByteBuffer.allocate(2).order(ByteOrder.LITTLE_ENDIAN).putShort(shortVal)
                System.arraycopy(bb.array(), 0, data, idx, 2)
            }
        }
    }
}
