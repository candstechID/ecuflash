package com.candstech.ecuflash

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbManager
import android.os.Build
import com.felhr.usbserial.UsbSerialDevice
import com.felhr.usbserial.UsbSerialInterface
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.concurrent.ConcurrentLinkedQueue

data class EcuSensorData(
    val rpm: Int = 0,
    val ecuSpeed: Int = 0,
    val tpsDeg: Float = 0f,
    val tpsVolt: Float = 0f,
    val ectTemp: Int = 0,
    val iatTemp: Int = 0,
    val mapKpa: Int = 0,
    val batteryVolt: Float = 0f,
    val afr: Float = 14.7f,
    val ignitionAdv: Float = 0f,
    val injectorMs: Float = 0f,
    val dtcCodes: List<String> = emptyList()
)

class HondaKLineManager(private val context: Context) {
    companion object {
        const val ACTION_USB_PERMISSION = "com.candstech.ecuflash.USB_PERMISSION"
        val CMD_WAKEUP = byteArrayOf(0xFE.toByte(), 0x04, 0x72, 0x8C.toByte())
        val CMD_INIT_COMM = byteArrayOf(0x72, 0x05, 0x00, 0xF0.toByte(), 0x99.toByte())
        val CMD_LIVE_DATA = byteArrayOf(0x72, 0x05, 0x71, 0x17, 0x01)
        val CMD_READ_DTC = byteArrayOf(0x72, 0x05, 0x73, 0x01, 0x15)
        val CMD_CLEAR_DTC = byteArrayOf(0x72, 0x05, 0x60, 0x01, 0x28)
        val CMD_RESET_TP = byteArrayOf(0x72, 0x05, 0x60, 0x03, 0x26)
    }

    private val usbManager = context.getSystemService(Context.USB_SERVICE) as UsbManager
    private var usbDevice: UsbDevice? = null
    private var usbConnection: UsbDeviceConnection? = null
    private var serialPort: UsbSerialDevice? = null

    private val _connectionState = MutableStateFlow("DISCONNECTED")
    val connectionState: StateFlow<String> = _connectionState

    private val _logMessages = MutableStateFlow<List<String>>(listOf("[SYS] CandsTech ECU Flasher Ready."))
    val logMessages: StateFlow<List<String>> = _logMessages

    private val _sensorData = MutableStateFlow(EcuSensorData())
    val sensorData: StateFlow<EcuSensorData> = _sensorData

    private val rxBuffer = ConcurrentLinkedQueue<Byte>()
    private var pollingJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val usbReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            if (ACTION_USB_PERMISSION == intent.action) {
                synchronized(this) {
                    val device: UsbDevice? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
                    }
                    if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                        device?.let { openSerialPort(it) }
                    } else {
                        log("[USB] Permission denied by user.")
                        _connectionState.value = "PERMISSION_DENIED"
                    }
                }
            }
        }
    }

    init {
        val filter = IntentFilter(ACTION_USB_PERMISSION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.registerReceiver(usbReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            context.registerReceiver(usbReceiver, filter)
        }
    }

    fun log(msg: String) {
        val current = _logMessages.value.toMutableList()
        if (current.size > 50) current.removeAt(0)
        current.add(msg)
        _logMessages.value = current
    }

    fun connect() {
        val deviceList = usbManager.deviceList
        if (deviceList.isEmpty()) {
            log("[USB] No FTDI/CH340 K-Line adapter found.")
            _connectionState.value = "NO_DEVICE"
            return
        }
        val device = deviceList.values.first()
        usbDevice = device
        if (!usbManager.hasPermission(device)) {
            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
            val pi = PendingIntent.getBroadcast(context, 0, Intent(ACTION_USB_PERMISSION), flags)
            usbManager.requestPermission(device, pi)
            _connectionState.value = "REQUESTING_PERMISSION"
        } else {
            openSerialPort(device)
        }
    }

    private fun openSerialPort(device: UsbDevice) {
        usbConnection = usbManager.openDevice(device)
        if (usbConnection == null) {
            log("[USB] Failed to open USB device connection.")
            _connectionState.value = "ERROR"
            return
        }
        serialPort = UsbSerialDevice.createUsbSerialDevice(device, usbConnection)
        if (serialPort != null && serialPort!!.open()) {
            serialPort!!.setBaudRate(10400)
            serialPort!!.setDataBits(UsbSerialInterface.DATA_BITS_8)
            serialPort!!.setStopBits(UsbSerialInterface.STOP_BITS_1)
            serialPort!!.setParity(UsbSerialInterface.PARITY_NONE)
            serialPort!!.setFlowControl(UsbSerialInterface.FLOW_CONTROL_OFF)
            serialPort!!.read(mCallback)
            log("[K-LINE] Port opened @ 10400 baud 8N1.")
            performHondaInit()
        } else {
            log("[USB] Serial driver not supported or failed to open.")
            _connectionState.value = "DRIVER_ERROR"
        }
    }

    private val mCallback = UsbSerialInterface.UsbReadCallback { data ->
        if (data != null && data.isNotEmpty()) {
            for (b in data) rxBuffer.add(b)
            parseIncomingBuffer()
        }
    }

    private fun performHondaInit() {
        scope.launch {
            _connectionState.value = "INITIALIZING..."
            log("[K-LINE] Sending Honda Fast Init (70ms LOW / 120ms HIGH)...")
            serialPort?.setBreak(true)
            delay(70)
            serialPort?.setBreak(false)
            delay(120)

            rxBuffer.clear()
            sendCommand(CMD_WAKEUP)
            delay(100)
            sendCommand(CMD_INIT_COMM)
            delay(150)

            _connectionState.value = "CONNECTED"
            log("[ECU] Honda PGM-FI K-Line Online!")
            startLivePolling()
        }
    }

    private fun startLivePolling() {
        pollingJob?.cancel()
        pollingJob = scope.launch {
            while (isActive && _connectionState.value == "CONNECTED") {
                sendCommand(CMD_LIVE_DATA)
                delay(120)
            }
        }
    }

    fun sendCommand(cmd: ByteArray) {
        serialPort?.write(cmd)
    }

    fun scanDtc() {
        scope.launch {
            log("[DIAG] Scanning Honda DTC codes...")
            sendCommand(CMD_READ_DTC)
        }
    }

    fun clearDtc() {
        scope.launch {
            log("[DIAG] Clearing ECU DTC memory...")
            sendCommand(CMD_CLEAR_DTC)
            delay(150)
            _sensorData.value = _sensorData.value.copy(dtcCodes = emptyList())
            log("[DIAG] DTC Cleared.")
        }
    }

    fun resetTp() {
        scope.launch {
            log("[DIAG] Executing TP / ECM Reset...")
            sendCommand(CMD_RESET_TP)
            delay(200)
            log("[DIAG] TP Reset Complete.")
        }
    }

    private fun parseIncomingBuffer() {
        val bytes = mutableListOf<Byte>()
        while (rxBuffer.isNotEmpty()) {
            rxBuffer.poll()?.let { bytes.add(it) }
        }
        if (bytes.size >= 16) {
            val rpmHigh = bytes[4].toInt() and 0xFF
            val rpmLow = bytes[5].toInt() and 0xFF
            val rpm = (rpmHigh shl 8) or rpmLow
            val tpsRaw = bytes[7].toInt() and 0xFF
            val tpsDeg = (tpsRaw / 255f) * 80f
            val ectRaw = (bytes[9].toInt() and 0xFF) - 40
            val iatRaw = (bytes[11].toInt() and 0xFF) - 40
            val mapRaw = bytes[12].toInt() and 0xFF
            val batRaw = (bytes[13].toInt() and 0xFF) / 10f
            val spdRaw = bytes[14].toInt() and 0xFF

            if (rpm in 0..16000) {
                _sensorData.value = _sensorData.value.copy(
                    rpm = rpm,
                    tpsDeg = tpsDeg,
                    tpsVolt = (tpsRaw / 255f) * 5.0f,
                    ectTemp = ectRaw,
                    iatTemp = iatRaw,
                    mapKpa = mapRaw,
                    batteryVolt = batRaw,
                    ecuSpeed = spdRaw
                )
            }
        }
    }

    fun disconnect() {
        pollingJob?.cancel()
        serialPort?.close()
        usbConnection?.close()
        _connectionState.value = "DISCONNECTED"
        log("[USB] Disconnected.")
    }

    fun cleanup() {
        disconnect()
        try { context.unregisterReceiver(usbReceiver) } catch (_: Exception) {}
        scope.cancel()
    }
}
