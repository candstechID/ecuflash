package com.candstech.ecuflasher

class EngineSafeguardsMonitor {
    fun evaluateSafeguards(rpm: Int, tpsPercent: Float, afr: Float, fuelDurationUs: Float): Map<String, Any> {
        val pulseWidthMs = fuelDurationUs / 1000.0f
        val idcPercentage = (pulseWidthMs * rpm) / 1200.0f
        val idcRounded = minOf(100.0f, maxOf(0.0f, idcPercentage))

        val baseEgt = 480.0f
        val loadFactor = (tpsPercent / 100.0f) * 0.6f + (rpm / 14000.0f) * 0.4f
        var egt = baseEgt + (loadFactor * 280.0f)
        if (afr > 13.0f) {
            egt += (afr - 13.0f) * 50.0f
        }
        val egtRounded = minOf(980.0f, maxOf(380.0f, egt))

        val idcAlert = idcRounded > 85.0f
        val egtAlert = egtRounded > 780.0f

        return mapOf(
            "egt_c" to egtRounded.toInt(),
            "egt_status" to if (egtAlert) "WARNING" else "Optimal",
            "egt_color" to if (egtAlert) "#F59E0B" else "#10B981",
            "egt_alert" to egtAlert,
            "idc_percent" to String.format("%.1f", idcRounded),
            "idc_status" to if (idcAlert) "HIGH LOAD" else "Aman",
            "idc_color" to if (idcAlert) "#EF4444" else "#10B981",
            "idc_alert" to idcAlert
        )
    }
}
