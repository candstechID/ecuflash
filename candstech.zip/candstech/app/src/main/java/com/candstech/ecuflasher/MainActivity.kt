package com.candstech.ecuflasher

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import com.felhr.usbserial.UsbSerialDevice
import com.felhr.usbserial.UsbSerialInterface
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentLinkedQueue
import kotlinx.coroutines.*

val BgDark = Color(0xFF0F0F0F)
val CardDark = Color(0xFF1E1E1E)
val BorderDark = Color(0xFF333333)
val HondaRed = Color(0xFFE10600)
val NeonYellow = Color(0xFFD4FF00)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CandsTechEcuFlasherSuite()
        }
    }
}

@Composable
fun CandsTechEcuFlasherSuite() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("candstech_flasher_prefs", Context.MODE_PRIVATE) }

    // Custom Default Folder URI (disimpan permanen di SharedPreferences jika user memilih folder sendiri)
    var customFolderUriStr by remember { mutableStateOf(prefs.getString("custom_bin_folder_uri", null)) }
    var activeFolderLabel by remember {
        mutableStateOf(prefs.getString("custom_bin_folder_label", "Documents/candstech") ?: "Documents/candstech")
    }

    val xdfTables = remember { mutableStateMapOf<String, XDFTableInfo>() }
    var selectedTableKey by remember { mutableStateOf<String?>(null) }
    var binBytes by remember { mutableStateOf<ByteArray?>(null) }
    var binName by remember { mutableStateOf("No .BIN loaded") }
    var xdfName by remember { mutableStateOf("Default Keihin Map") }
    var checksumHex by remember { mutableStateOf("0x0000") }
    var tableRefreshTick by remember { mutableIntStateOf(0) }
    var selectedRomSizeKb by remember { mutableIntStateOf(32) }

    var connStatus by remember { mutableStateOf("DISCONNECTED") }
    var rpm by remember { mutableIntStateOf(0) }
    var tpsDeg by remember { mutableFloatStateOf(0f) }
    var ectTemp by remember { mutableIntStateOf(0) }
    var iatTemp by remember { mutableIntStateOf(0) }
    var mapKpa by remember { mutableIntStateOf(0) }
    var batVolt by remember { mutableFloatStateOf(0f) }
    var ecuSpeed by remember { mutableIntStateOf(0) }
    var topSpeed by remember { mutableIntStateOf(0) }

    val logs = remember { mutableStateListOf("[SYS] CANDS TECH ECU Flasher v3.0 Ready.") }
    var serialPort by remember { mutableStateOf<UsbSerialDevice?>(null) }
    var usbConnection by remember { mutableStateOf<UsbDeviceConnection?>(null) }
    var activeTab by remember { mutableIntStateOf(0) }

    val kLineRxQueue = remember { ConcurrentLinkedQueue<Byte>() }
    var isFlashingBusy by remember { mutableStateOf(false) }
    var flashProgress by remember { mutableFloatStateOf(0f) }

    fun log(msg: String) {
        if (logs.size > 80) logs.removeAt(0)
        logs.add(msg)
    }

    // Pastikan folder default Documents/candstech dibuat & siap dipakai saat pertama kali buka aplikasi
    LaunchedEffect(Unit) {
        if (xdfTables.isEmpty()) {
            BinParser.loadDefaultHondaKeihinTables(xdfTables)
            selectedTableKey = xdfTables.keys.firstOrNull()
        }
        try {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                @Suppress("DEPRECATION")
                val docDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "candstech")
                if (!docDir.exists()) docDir.mkdirs()
            }
            log("[DIR] Folder default aktif: $activeFolderLabel")
        } catch (_: Exception) {
        }
    }

    // Fungsi Simpan Otomatis ke Folder Default (Custom Folder pilihan user ATAU Documents/candstech)
    fun saveBinToActiveDefaultFolder(fileName: String, data: ByteArray): Boolean {
        val cleanFileName = if (fileName.endsWith(".bin", ignoreCase = true)) fileName else "$fileName.bin"
        val customUriStr = customFolderUriStr

        // 1. Jika user sudah memilih folder default kustom lewat tombol SET FOLDER
        if (!customUriStr.isNullOrBlank()) {
            try {
                val treeUri = Uri.parse(customUriStr)
                val pickedDir = DocumentFile.fromTreeUri(context, treeUri)
                if (pickedDir != null && pickedDir.canWrite()) {
                    // Hapus file lama dengan nama sama jika ada agar tidak jadi duplikat (1)
                    pickedDir.findFile(cleanFileName)?.delete()
                    val newFile = pickedDir.createFile("application/octet-stream", cleanFileName)
                    if (newFile != null) {
                        context.contentResolver.openOutputStream(newFile.uri)?.use { out ->
                            out.write(data)
                        }
                        log("[SAVE] Tersimpan otomatis di: $activeFolderLabel/$cleanFileName")
                        return true
                    }
                } else {
                    log("[WARN] Izin folder kustom kedaluwarsa, beralih ke Documents/candstech...")
                }
            } catch (e: Exception) {
                log("[WARN] Gagal tulis ke folder kustom (${e.message}), memakai Documents/candstech...")
            }
        }

        // 2. Fallback / Default Standar: Documents/candstech via MediaStore
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, cleanFileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/octet-stream")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOCUMENTS + "/candstech")
                }
                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Files.getContentUri("external"), values)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { out -> out.write(data) }
                    log("[SAVE] Tersimpan otomatis di: Documents/candstech/$cleanFileName")
                    true
                } else {
                    log("[ERR] Gagal membuat file di Documents/candstech")
                    false
                }
            } else {
                @Suppress("DEPRECATION")
                val docDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "candstech")
                if (!docDir.exists()) docDir.mkdirs()
                val outFile = File(docDir, cleanFileName)
                outFile.writeBytes(data)
                log("[SAVE] Tersimpan otomatis di: ${outFile.absolutePath}")
                true
            }
        } catch (e: Exception) {
            log("[ERR] Gagal simpan file .BIN: ${e.message}")
            false
        }
    }

    // Pemilih Folder Default Permanen (OpenDocumentTree)
    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        uri?.let {
            try {
                val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                context.contentResolver.takePersistableUriPermission(it, flags)
                val docFile = DocumentFile.fromTreeUri(context, it)
                val folderTitle = docFile?.name ?: it.lastPathSegment?.substringAfterLast(':') ?: "CustomFolder"
                customFolderUriStr = it.toString()
                activeFolderLabel = folderTitle
                prefs.edit()
                    .putString("custom_bin_folder_uri", it.toString())
                    .putString("custom_bin_folder_label", folderTitle)
                    .apply()
                log("[DIR] Folder default diubah ke: $folderTitle")
            } catch (e: Exception) {
                log("[ERR] Gagal mengunci izin folder: ${e.message}")
            }
        }
    }

    fun resetToDocumentsCandsTech() {
        customFolderUriStr = null
        activeFolderLabel = "Documents/candstech"
        prefs.edit()
            .remove("custom_bin_folder_uri")
            .putString("custom_bin_folder_label", "Documents/candstech")
            .apply()
        log("[DIR] Folder default dikembalikan ke: Documents/candstech")
    }

    fun calcHondaKLineChecksum(frameWithoutChecksum: ByteArray): Byte {
        var sum = 0
        for (b in frameWithoutChecksum) {
            sum += (b.toInt() and 0xFF)
        }
        return ((0x100 - (sum and 0xFF)) and 0xFF).toByte()
    }

    fun buildHondaFrame(payload: ByteArray): ByteArray {
        return payload + calcHondaKLineChecksum(payload)
    }

    suspend fun transceiveHondaKLine(
        port: UsbSerialDevice,
        txPayload: ByteArray,
        expectedReplyMinBytes: Int,
        timeoutMs: Int = 120
    ): ByteArray {
        kLineRxQueue.clear()
        val fullTx = buildHondaFrame(txPayload)
        port.write(fullTx)

        val totalExpected = fullTx.size + expectedReplyMinBytes
        var elapsed = 0
        while (kLineRxQueue.size < totalExpected && elapsed < timeoutMs) {
            delay(4)
            elapsed += 4
        }

        val raw = mutableListOf<Byte>()
        while (kLineRxQueue.isNotEmpty()) {
            kLineRxQueue.poll()?.let { raw.add(it) }
        }
        if (raw.isEmpty()) return ByteArray(0)

        val rxOnly = if (raw.size >= fullTx.size && raw.take(fullTx.size) == fullTx.toList()) {
            raw.drop(fullTx.size)
        } else {
            raw
        }
        return rxOnly.toByteArray()
    }

    // READ ROM (.BIN) DARI ECU + LANGSUNG AUTO-SAVE KE FOLDER DEFAULT (Documents/candstech atau folder pilihan)
    fun readRomFromEcu() {
        val port = serialPort
        if (connStatus != "CONNECTED" || port == null) {
            log("[WARN] Hubungkan adapter FTDI K-Line dulu (USB CONNECT)!")
            return
        }
        if (isFlashingBusy) return

        val romBytesTotal = selectedRomSizeKb * 1024
        scope.launch(Dispatchers.IO) {
            isFlashingBusy = true
            flashProgress = 0f
            try {
                withContext(Dispatchers.Main) {
                    log("[READ] Memulai Honda PGM-FI Wakeup & Read ROM ($selectedRomSizeKb KB)...")
                }

                port.setBreak(true)
                delay(70)
                port.setBreak(false)
                delay(120)
                transceiveHondaKLine(port, byteArrayOf(0xFE.toByte(), 0x04, 0x72), 4, 150)
                delay(40)
                transceiveHondaKLine(port, byteArrayOf(0x72, 0x05, 0x00, 0xF0.toByte()), 5, 150)
                delay(40)
                transceiveHondaKLine(port, byteArrayOf(0x72, 0x05, 0x71, 0x00), 5, 150)
                delay(40)

                val romBuffer = ByteArray(romBytesTotal)
                val blockSize = 16
                var offset = 0
                var validFrames = 0

                while (offset < romBytesTotal && isActive) {
                    val addrHi = ((offset shr 8) and 0xFF).toByte()
                    val addrLo = (offset and 0xFF).toByte()
                    val req = byteArrayOf(0x72, 0x07, 0x74, addrHi, addrLo, blockSize.toByte())
                    val reply = transceiveHondaKLine(port, req, blockSize + 4, 90)

                    if (reply.size >= blockSize + 4) {
                        val payloadStart = reply.size - blockSize - 1
                        for (i in 0 until blockSize) {
                            if (offset + i < romBytesTotal) romBuffer[offset + i] = reply[payloadStart + i]
                        }
                        validFrames++
                    } else {
                        val retryReply = transceiveHondaKLine(port, req, blockSize + 4, 110)
                        if (retryReply.size >= blockSize + 4) {
                            val payloadStart = retryReply.size - blockSize - 1
                            for (i in 0 until blockSize) {
                                if (offset + i < romBytesTotal) romBuffer[offset + i] = retryReply[payloadStart + i]
                            }
                            validFrames++
                        } else {
                            for (i in 0 until blockSize) {
                                if (offset + i < romBytesTotal) romBuffer[offset + i] = 0xFF.toByte()
                            }
                        }
                    }

                    offset += blockSize
                    if (offset % 2048 == 0 || offset >= romBytesTotal) {
                        val pct = offset.toFloat() / romBytesTotal.toFloat()
                        withContext(Dispatchers.Main) {
                            flashProgress = pct
                            if (offset % 8192 == 0 || offset >= romBytesTotal) {
                                log("[READ] ${(pct * 100).toInt()}% ($offset / $romBytesTotal B | ACK: $validFrames)")
                            }
                        }
                    }
                }

                val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                val autoFileName = "ECU_BACKUP_${selectedRomSizeKb}KB_$ts.bin"

                withContext(Dispatchers.Main) {
                    binBytes = romBuffer
                    binName = autoFileName
                    val csum = BinParser.calculateChecksum16(romBuffer)
                    checksumHex = "0x${csum.toString(16).uppercase(Locale.US).padStart(4, '0')}"
                    tableRefreshTick++

                    // Otomatis simpan file hasil READ ke folder default!
                    saveBinToActiveDefaultFolder(autoFileName, romBuffer)

                    if (validFrames > 0) {
                        log("[READ] SUKSES! ($validFrames blok valid) | CSUM: $checksumHex")
                    } else {
                        log("[WARN] Tidak ada balasan ECU. Cek K-Line (Pin 4 DLC), 12V & kontak ON!")
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    log("[ERR] Read ECU gagal: ${e.message}")
                }
            } finally {
                isFlashingBusy = false
            }
        }
    }

    // WRITE / FLASH ROM (.BIN) KE ECU HONDA PGM-FI
    fun writeRomToEcu() {
        val port = serialPort
        val data = binBytes
        if (connStatus != "CONNECTED" || port == null) {
            log("[WARN] Hubungkan adapter FTDI K-Line terlebih dahulu!")
            return
        }
        if (data == null) {
            log("[WARN] Belum ada file .BIN! Klik OPEN .BIN atau READ ECU dulu.")
            return
        }
        if (isFlashingBusy) return

        scope.launch(Dispatchers.IO) {
            isFlashingBusy = true
            flashProgress = 0f
            try {
                withContext(Dispatchers.Main) {
                    log("[WRITE] Memulai Honda PGM-FI Flash Mode (${data.size} B)... JANGAN MATIKAN KONTAK!")
                }

                port.setBreak(true)
                delay(70)
                port.setBreak(false)
                delay(120)
                transceiveHondaKLine(port, byteArrayOf(0xFE.toByte(), 0x04, 0x72), 4, 150)
                delay(40)
                transceiveHondaKLine(port, byteArrayOf(0x72, 0x05, 0x00, 0xF0.toByte()), 5, 150)
                delay(40)

                val eraseAck = transceiveHondaKLine(port, byteArrayOf(0x72, 0x05, 0x75, 0x01), 5, 400)
                withContext(Dispatchers.Main) {
                    log("[WRITE] Bootloader erase response: ${eraseAck.size} bytes")
                }

                val blockSize = 16
                var offset = 0
                var ackCount = 0

                while (offset < data.size && isActive) {
                    val addrHi = ((offset shr 8) and 0xFF).toByte()
                    val addrLo = (offset and 0xFF).toByte()
                    val endIdx = (offset + blockSize).coerceAtMost(data.size)
                    val chunk = data.copyOfRange(offset, endIdx)

                    val frameLen = (chunk.size + 6).toByte()
                    val req = byteArrayOf(0x72, frameLen, 0x76, addrHi, addrLo) + chunk
                    val reply = transceiveHondaKLine(port, req, 4, 90)
                    if (reply.isNotEmpty()) ackCount++

                    offset += blockSize
                    if (offset % 2048 == 0 || offset >= data.size) {
                        val pct = offset.toFloat() / data.size.toFloat()
                        withContext(Dispatchers.Main) {
                            flashProgress = pct
                            if (offset % 8192 == 0 || offset >= data.size) {
                                log("[WRITE] Flashing ${(pct * 100).toInt()}% ($offset / ${data.size} B | ACK: $ackCount)")
                            }
                        }
                    }
                }

                transceiveHondaKLine(port, byteArrayOf(0x72, 0x05, 0x77, 0x00), 5, 200)

                withContext(Dispatchers.Main) {
                    log("[WRITE] SELESAI! Matikan kunci kontak 5 detik lalu nyalakan ulang.")
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    log("[ERR] Write ECU gagal: ${e.message}")
                }
            } finally {
                isFlashingBusy = false
            }
        }
    }

    val binPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let {
            try {
                val data = context.contentResolver.openInputStream(it)?.use { s -> s.readBytes() }
                if (data != null) {
                    binBytes = data
                    binName = DocumentFile.fromSingleUri(context, it)?.name
                        ?: it.lastPathSegment?.substringAfterLast('/')
                        ?: "ecu_dump.bin"
                    val csum = BinParser.calculateChecksum16(data)
                    checksumHex = "0x${csum.toString(16).uppercase(Locale.US).padStart(4, '0')}"
                    tableRefreshTick++
                    log("[BIN] Loaded $binName (${data.size} B) | CSUM: $checksumHex")
                }
            } catch (e: Exception) {
                log("[ERR] Gagal baca .BIN: ${e.message}")
            }
        }
    }

    val xdfPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let {
            try {
                context.contentResolver.openInputStream(it)?.use { stream ->
                    val parsed = BinParser.parseXdfStream(stream)
                    xdfTables.clear()
                    xdfTables.putAll(parsed)
                    selectedTableKey = xdfTables.keys.firstOrNull()
                    xdfName = DocumentFile.fromSingleUri(context, it)?.name
                        ?: it.lastPathSegment?.substringAfterLast('/')
                        ?: "custom.xdf"
                    tableRefreshTick++
                    log("[XDF] Loaded $xdfName (${xdfTables.size} tables)")
                }
            } catch (e: Exception) {
                log("[ERR] Gagal baca .XDF: ${e.message}")
            }
        }
    }

    fun connectKLine() {
        val usbManager = context.getSystemService(Context.USB_SERVICE) as UsbManager
        val devices = usbManager.deviceList
        if (devices.isEmpty()) {
            log("[USB] Adapter FTDI / CH340 K-Line tidak terdeteksi.")
            connStatus = "NO_DEVICE"
            return
        }
        val device: UsbDevice = devices.values.first()
        if (!usbManager.hasPermission(device)) {
            val action = "com.candstech.ecuflasher.USB_PERMISSION"
            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
            val pi = PendingIntent.getBroadcast(context, 0, Intent(action), flags)
            val receiver = object : BroadcastReceiver() {
                override fun onReceive(ctx: Context, intent: Intent) {
                    if (intent.action == action) {
                        try {
                            context.unregisterReceiver(this)
                        } catch (_: Exception) {
                        }
                        if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                            connectKLine()
                        } else {
                            connStatus = "DENIED"
                            log("[USB] Izin USB ditolak.")
                        }
                    }
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.registerReceiver(receiver, IntentFilter(action), Context.RECEIVER_NOT_EXPORTED)
            } else {
                context.registerReceiver(receiver, IntentFilter(action))
            }
            usbManager.requestPermission(device, pi)
            connStatus = "REQUESTING"
            return
        }

        val conn = usbManager.openDevice(device) ?: return
        val port = UsbSerialDevice.createUsbSerialDevice(device, conn)
        if (port != null && port.open()) {
            port.setBaudRate(10400)
            port.setDataBits(UsbSerialInterface.DATA_BITS_8)
            port.setStopBits(UsbSerialInterface.STOP_BITS_1)
            port.setParity(UsbSerialInterface.PARITY_NONE)
            port.setFlowControl(UsbSerialInterface.FLOW_CONTROL_OFF)
            port.read { data ->
                if (data != null && data.isNotEmpty()) {
                    if (isFlashingBusy) {
                        for (b in data) kLineRxQueue.add(b)
                    } else if (data.size >= 16) {
                        val parsedRpm = ((data[4].toInt() and 0xFF) shl 8) or (data[5].toInt() and 0xFF)
                        if (parsedRpm in 0..16000) {
                            rpm = parsedRpm
                            tpsDeg = ((data[7].toInt() and 0xFF) / 255f) * 80f
                            ectTemp = (data[9].toInt() and 0xFF) - 40
                            iatTemp = (data[11].toInt() and 0xFF) - 40
                            mapKpa = data[12].toInt() and 0xFF
                            batVolt = (data[13].toInt() and 0xFF) / 10f
                            ecuSpeed = data[14].toInt() and 0xFF
                            if (ecuSpeed > topSpeed) topSpeed = ecuSpeed
                        }
                    }
                }
            }
            usbConnection = conn
            serialPort = port
            connStatus = "CONNECTED"
            log("[K-LINE] FTDI Online @ 10400 baud 8N1.")

            scope.launch(Dispatchers.IO) {
                port.setBreak(true)
                delay(70)
                port.setBreak(false)
                delay(120)
                port.write(byteArrayOf(0xFE.toByte(), 0x04, 0x72, 0x8C.toByte()))
                delay(100)
                port.write(byteArrayOf(0x72, 0x05, 0x00, 0xF0.toByte(), 0x99.toByte()))
                while (isActive && connStatus == "CONNECTED") {
                    if (!isFlashingBusy) {
                        port.write(byteArrayOf(0x72, 0x05, 0x71, 0x17, 0x01))
                    }
                    delay(150)
                }
            }
        }
    }

    fun disconnectKLine() {
        isFlashingBusy = false
        serialPort?.close()
        usbConnection?.close()
        serialPort = null
        usbConnection = null
        connStatus = "DISCONNECTED"
        log("[USB] Disconnected.")
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDark)
            .padding(6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        // Top Header Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(CardDark, RoundedCornerShape(8.dp))
                .border(1.dp, BorderDark, RoundedCornerShape(8.dp))
                .padding(horizontal = 8.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("CANDS TECH", color = NeonYellow, fontWeight = FontWeight.Black, fontSize = 14.sp)
                TabChip("1. FLASH & MAP", activeTab == 0) { activeTab = 0 }
                TabChip("2. AI PRESET", activeTab == 1) { activeTab = 1 }
                TabChip("3. K-LINE DIAG", activeTab == 2) { activeTab = 2 }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(checksumHex, color = NeonYellow, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                Button(
                    onClick = { if (connStatus == "CONNECTED") disconnectKLine() else connectKLine() },
                    colors = ButtonDefaults.buttonColors(containerColor = if (connStatus == "CONNECTED") Color.DarkGray else HondaRed),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.height(28.dp)
                ) {
                    Text(if (connStatus == "CONNECTED") "USB ON" else "USB CONNECT", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        if (isFlashingBusy) {
            LinearProgressIndicator(
                progress = flashProgress.coerceIn(0f, 1f),
                modifier = Modifier.fillMaxWidth().height(6.dp),
                color = NeonYellow,
                trackColor = Color(0xFF2B2B2B)
            )
        }

        Row(modifier = Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Box(modifier = Modifier.weight(1.75f).fillMaxHeight()) {
                when (activeTab) {
                    0 -> {
                        Row(modifier = Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            // Panel Kiri: Read/Write + Pengaturan Folder Default + Open/Save
                            Column(
                                modifier = Modifier
                                    .weight(1.0f)
                                    .fillMaxHeight()
                                    .background(CardDark, RoundedCornerShape(8.dp))
                                    .border(1.dp, BorderDark, RoundedCornerShape(8.dp))
                                    .padding(6.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                // Baris ROM Size & Folder Default Selector
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.CenterVertically) {
                                        TabChip("32K", selectedRomSizeKb == 32) { selectedRomSizeKb = 32 }
                                        TabChip("64K", selectedRomSizeKb == 64) { selectedRomSizeKb = 64 }
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                        SmallFolderBtn("PILIH DIR") { folderPicker.launch(null) }
                                        if (customFolderUriStr != null) {
                                            SmallFolderBtn("RESET") { resetToDocumentsCandsTech() }
                                        }
                                    }
                                }

                                // Info Folder Default Aktif
                                Text(
                                    text = "DIR: $activeFolderLabel",
                                    color = NeonYellow,
                                    fontSize = 8.sp,
                                    maxLines = 1
                                )

                                // Tombol READ ECU & WRITE ECU via K-Line
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    ActionBtn("READ ECU", Color(0xFF154360), Modifier.weight(1f)) { readRomFromEcu() }
                                    ActionBtn("WRITE ECU", Color(0xFF922B21), Modifier.weight(1f)) { writeRomToEcu() }
                                }

                                // Tombol OPEN .BIN & OPEN .XDF
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    ActionBtn("OPEN .BIN", Color(0xFF2B2B2B), Modifier.weight(1f)) { binPicker.launch(arrayOf("*/*")) }
                                    ActionBtn("OPEN .XDF", HondaRed, Modifier.weight(1f)) { xdfPicker.launch(arrayOf("*/*")) }
                                }

                                // Tombol Langsung Simpan ke Folder Default (tanpa dialog tanya lokasi)
                                ActionBtn("SAVE .BIN TO DIR", Color(0xFF2E4A1E), Modifier.fillMaxWidth()) {
                                    val data = binBytes
                                    if (data != null) {
                                        val outName = if (binName == "No .BIN loaded") {
                                            "TUNED_${System.currentTimeMillis() / 1000}.bin"
                                        } else {
                                            "TUNED_$binName"
                                        }
                                        saveBinToActiveDefaultFolder(outName, data)
                                    } else {
                                        log("[WARN] Klik READ ECU atau OPEN .BIN dulu!")
                                    }
                                }

                                Text("FILE: $binName", color = Color.Gray, fontSize = 8.sp, maxLines = 1)
                                Divider(color = BorderDark)

                                LazyColumn(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                    items(xdfTables.keys.toList()) { key ->
                                        val isSel = key == selectedTableKey
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(if (isSel) HondaRed else Color(0xFF262626), RoundedCornerShape(4.dp))
                                                .clickable { selectedTableKey = key }
                                                .padding(5.dp)
                                        ) {
                                            Text(key, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }

                            // Panel Tengah: Tabel Peta XDF / BIN
                            Column(
                                modifier = Modifier
                                    .weight(1.3f)
                                    .fillMaxHeight()
                                    .background(CardDark, RoundedCornerShape(8.dp))
                                    .border(1.dp, BorderDark, RoundedCornerShape(8.dp))
                                    .padding(6.dp)
                            ) {
                                val table = selectedTableKey?.let { xdfTables[it] }
                                val bytes = binBytes
                                val tick = tableRefreshTick

                                if (table != null && tick >= 0) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "${table.title} (0x${table.address.toString(16).uppercase(Locale.US)})",
                                            color = NeonYellow,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        if (bytes != null) {
                                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                                SmallStepBtn("+2%") {
                                                    for (r in 0 until table.rows) {
                                                        for (c in 0 until table.cols) {
                                                            val cur = BinParser.readCell(bytes, table, r, c)
                                                            BinParser.writeCell(bytes, table, r, c, (cur * 1.02f).toInt())
                                                        }
                                                    }
                                                    checksumHex = "0x${BinParser.calculateChecksum16(bytes).toString(16).uppercase(Locale.US).padStart(4, '0')}"
                                                    tableRefreshTick++
                                                    log("[MAP] ${table.title} +2%")
                                                }
                                                SmallStepBtn("-2%") {
                                                    for (r in 0 until table.rows) {
                                                        for (c in 0 until table.cols) {
                                                            val cur = BinParser.readCell(bytes, table, r, c)
                                                            BinParser.writeCell(bytes, table, r, c, (cur * 0.98f).toInt())
                                                        }
                                                    }
                                                    checksumHex = "0x${BinParser.calculateChecksum16(bytes).toString(16).uppercase(Locale.US).padStart(4, '0')}"
                                                    tableRefreshTick++
                                                    log("[MAP] ${table.title} -2%")
                                                }
                                            }
                                        }
                                    }
                                    Spacer(Modifier.height(4.dp))
                                    if (bytes == null) {
                                        Text("Klik READ ECU (auto-save ke $activeFolderLabel) atau OPEN .BIN untuk edit peta.", color = Color.Gray, fontSize = 10.sp)
                                    } else {
                                        Column(
                                            modifier = Modifier.fillMaxSize().horizontalScroll(rememberScrollState()),
                                            verticalArrangement = Arrangement.spacedBy(2.dp)
                                        ) {
                                            for (r in 0 until table.rows.coerceAtMost(16)) {
                                                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                                    for (c in 0 until table.cols.coerceAtMost(16)) {
                                                        val valCell = BinParser.readCell(bytes, table, r, c)
                                                        Box(
                                                            modifier = Modifier
                                                                .width(32.dp)
                                                                .background(Color(0xFF141414))
                                                                .border(0.5.dp, BorderDark)
                                                                .padding(2.dp),
                                                            contentAlignment = Alignment.Center
                                                        ) {
                                                            Text(valCell.toString(), color = Color.White, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    1 -> {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(CardDark, RoundedCornerShape(8.dp))
                                .border(1.dp, BorderDark, RoundedCornerShape(8.dp))
                                .padding(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text("AI AUTO-TUNING PRESETS & ENGINE SAFEGUARDS", color = NeonYellow, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            LazyColumn(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                items(AiPresetEngine.presets) { preset ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(Color(0xFF262626), RoundedCornerShape(6.dp))
                                            .padding(7.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(preset.name, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            Text(preset.description, color = Color.LightGray, fontSize = 9.sp)
                                            Text("Target AFR: ${preset.targetAfr} | Limit: ${preset.rpmLimitTarget} RPM", color = NeonYellow, fontSize = 9.sp)
                                        }
                                        Button(
                                            onClick = {
                                                val bytes = binBytes
                                                if (bytes == null) {
                                                    log("[WARN] Klik READ ECU atau OPEN .BIN dulu!")
                                                } else {
                                                    val (count, check) = AiPresetEngine.applyPresetToBin(bytes, xdfTables, preset)
                                                    checksumHex = "0x${BinParser.calculateChecksum16(bytes).toString(16).uppercase(Locale.US).padStart(4, '0')}"
                                                    tableRefreshTick++
                                                    log("[AI-PRESET] ${preset.name} applied ($count cells updated).")
                                                    if (!check.isSafe) {
                                                        check.warnings.forEach { w -> log("[SAFEGUARD] $w") }
                                                    } else {
                                                        log("[SAFEGUARD] Parameter aman dalam batas toleransi mesin.")
                                                    }
                                                }
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = HondaRed),
                                            modifier = Modifier.height(30.dp)
                                        ) {
                                            Text("APPLY", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    2 -> {
                        Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Column(modifier = Modifier.fillMaxWidth().background(CardDark, RoundedCornerShape(8.dp)).padding(6.dp)) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("ENGINE RPM", color = Color.Gray, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                    Text("$rpm RPM", color = if (rpm > 9500) HondaRed else NeonYellow, fontSize = 14.sp, fontWeight = FontWeight.Black)
                                }
                                LinearProgressIndicator(
                                    progress = (rpm / 12000f).coerceIn(0f, 1f),
                                    modifier = Modifier.fillMaxWidth().height(8.dp),
                                    color = if (rpm > 9500) HondaRed else NeonYellow,
                                    trackColor = Color(0xFF2B2B2B)
                                )
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                MetricCard("SPEED", "$ecuSpeed km/h", "TOP: $topSpeed", Modifier.weight(1f))
                                MetricCard("TPS", String.format(Locale.US, "%.1f°", tpsDeg), "THROTTLE", Modifier.weight(1f))
                                MetricCard("BATTERY", String.format(Locale.US, "%.1f V", batVolt), "VOLTAGE", Modifier.weight(1f))
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                MetricCard("ECT", "$ectTemp °C", "COOLANT", Modifier.weight(1f))
                                MetricCard("IAT", "$iatTemp °C", "INTAKE", Modifier.weight(1f))
                                MetricCard("MAP", "$mapKpa kPa", "PRESSURE", Modifier.weight(1f))
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                ActionBtn("SCAN DTC", Color(0xFF2B2B2B), Modifier.weight(1f)) {
                                    serialPort?.write(byteArrayOf(0x72, 0x05, 0x73, 0x01, 0x15))
                                    log("[DIAG] Scan DTC sent.")
                                }
                                ActionBtn("CLEAR DTC", HondaRed, Modifier.weight(1f)) {
                                    serialPort?.write(byteArrayOf(0x72, 0x05, 0x60, 0x01, 0x28))
                                    log("[DIAG] Clear DTC sent.")
                                }
                                ActionBtn("RESET TP", Color(0xFF2B2B2B), Modifier.weight(1f)) {
                                    serialPort?.write(byteArrayOf(0x72, 0x05, 0x60, 0x03, 0x26))
                                    log("[DIAG] Reset TP sent.")
                                }
                            }
                        }
                    }
                }
            }

            Column(
                modifier = Modifier
                    .weight(0.8f)
                    .fillMaxHeight()
                    .background(CardDark, RoundedCornerShape(8.dp))
                    .border(1.dp, BorderDark, RoundedCornerShape(8.dp))
                    .padding(6.dp)
            ) {
                Text("K-LINE & FLASH LOG", color = NeonYellow, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(logs) { line ->
                        Text(line, color = Color.LightGray, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }
    }
}

@Composable
fun TabChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(if (selected) NeonYellow else Color(0xFF2A2A2A), RoundedCornerShape(4.dp))
            .clickable { onClick() }
            .padding(horizontal = 6.dp, vertical = 3.dp)
    ) {
        Text(label, color = if (selected) Color.Black else Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun MetricCard(title: String, value: String, sub: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(CardDark, RoundedCornerShape(8.dp))
            .border(1.dp, BorderDark, RoundedCornerShape(8.dp))
            .padding(7.dp)
    ) {
        Text(title, color = Color.Gray, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Text(value, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Black)
        Text(sub, color = NeonYellow, fontSize = 9.sp)
    }
}

@Composable
fun ActionBtn(label: String, bg: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier.height(30.dp),
        shape = RoundedCornerShape(6.dp),
        colors = ButtonDefaults.buttonColors(containerColor = bg),
        contentPadding = PaddingValues(3.dp)
    ) {
        Text(label, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SmallStepBtn(label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(HondaRed, RoundedCornerShape(4.dp))
            .clickable { onClick() }
            .padding(horizontal = 7.dp, vertical = 2.dp)
    ) {
        Text(label, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SmallFolderBtn(label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(Color(0xFF333333), RoundedCornerShape(4.dp))
            .border(0.5.dp, NeonYellow, RoundedCornerShape(4.dp))
            .clickable { onClick() }
            .padding(horizontal = 5.dp, vertical = 2.dp)
    ) {
        Text(label, color = NeonYellow, fontSize = 8.sp, fontWeight = FontWeight.Bold)
    }
}
