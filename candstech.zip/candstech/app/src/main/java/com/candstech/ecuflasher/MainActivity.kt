package com.candstech.ecuflasher

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import com.felhr.usbserial.UsbSerialDevice
import com.felhr.usbserial.UsbSerialInterface
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentLinkedQueue
import kotlinx.coroutines.*

val BgDark = Color(0xFF0F0F0F)
val CardDark = Color(0xFF1E1E1E)
val BorderDark = Color(0xFF333333)
val HondaRed = Color(0xFFE10600)
val NeonYellow = Color(0xFFD4FF00)

// Kamus pencocokan ECM ID / Hex ke Kode Part Motor Honda (K59, K60, K25, K81, K15, K56, dll.)
data class EcuProfileSpec(
    val code: String,
    val model: String,
    val partNo: String,
    val startOffset: String,
    val csumLoc: String,
    val vendor: String,
    val romKb: Int?
)

val hondaEcuDatabase = listOf(
        EcuProfileSpec("K59J", "Vario 150 ISS", "30400-K59J-A71", "0", "AUTO", "Shindengen", 64),
        EcuProfileSpec("K59A", "Vario 150", "30400-K59A-A11", "0", "AUTO", "Shindengen", 64),
        EcuProfileSpec("K59F", "Vario 150", "30400-K59F-A01", "0", "AUTO", "Shindengen", 64),
        EcuProfileSpec("K59", "Vario 150", "30400-K59-M01", "0", "AUTO", "Shindengen", 64),
        EcuProfileSpec("K60R", "Vario 125 ISS", "30400-K60R-B61 / B71", "0", "AUTO", "Shindengen", 64),
        EcuProfileSpec("K60K", "Vario 125", "30400-K60K-B31", "0", "AUTO", "Shindengen", 64),
        EcuProfileSpec("K46N3", "Vario 110", "30400-K46-N31 / N21", "0", "3FFF8", "Keihin", 64),
        EcuProfileSpec("K46N0", "BeAT 110 / Vario LED", "38770-K46-N01", "8000", "0", "Keihin", 64),
        EcuProfileSpec("K93", "Scoopy 110", "30400-K93-N01 / T01", "0", "3FFF8", "Keihin", 64),
        EcuProfileSpec("KYT", "Scoopy 110", "38770-KYT-901", "0", "DFEF", "Keihin", 64),
        EcuProfileSpec("K25G", "BeAT eSP", "30400-K25G-611", "0", "AUTO", "Shindengen", 64),
        EcuProfileSpec("K25", "BeAT 110 / Scoopy 110", "38770-K25-901", "4000", "7600", "Keihin", 64),
        EcuProfileSpec("K81H", "BeAT Street", "30400-K81H-N52", "0", "AUTO", "Shindengen", 64),
        EcuProfileSpec("K1AA-N03", "BeAT", "30400-K1AA-N03", "0", "AUTO", "Shindengen", 256),
        EcuProfileSpec("K1AA", "BeAT Street", "30400-K1AA-N02", "0", "AUTO", "Shindengen", 64),
        EcuProfileSpec("KZRA", "Vario 125 Old", "30400-KZRA-B21 / 601", "0", "AUTO", "Shindengen", 384),
        EcuProfileSpec("KZR", "Vario 125 Old", "30400-KZR-601 / B11", "0", "AUTO", "Shindengen", 64),
        EcuProfileSpec("K15M", "CB150R / CBR150R", "38770-K15M-601", "8000", "0", "Keihin", 128),
        EcuProfileSpec("K15", "CB150R Old", "38770-K15-921", "8000", "0", "Keihin", 128),
        EcuProfileSpec("K56N", "Sonic 150R / Supra GTR", "38770-K56-N01", "8000", "0", "Keihin", 128),
        EcuProfileSpec("K56", "Sonic 150R", "38770-K56-N11", "8000", "0", "Keihin", 128),
        EcuProfileSpec("K45G", "CBR150R K45G", "38770-K45G-N42", "8000", "0", "Keihin", 128),
        EcuProfileSpec("K45A", "CBR150R K45A", "38770-K45A-N01", "8000", "0", "Keihin", 128),
        EcuProfileSpec("K97", "PCX 150", "30400-K97G-N01", "0", "AUTO", "Shindengen", 128),
        EcuProfileSpec("K0WA", "ADV 150", "30400-K0WA-N01", "0", "AUTO", "Shindengen", 128),
        EcuProfileSpec("K0WL", "ADV 160", "30400-K0WL-NB1", "0", "AUTO", "Shindengen", 128),
        EcuProfileSpec("K1Z", "PCX 160", "30400-K1ZG-N21", "0", "AUTO", "Shindengen", 128),
        EcuProfileSpec("K2S", "Vario 160", "30400-K2SA-N02", "0", "AUTO", "Shindengen", 128),
        EcuProfileSpec("K2F", "Scoopy Prestige", "30400-K2F-N11", "0", "AUTO", "Shindengen", 128),
        EcuProfileSpec("K0J", "Genio", "30400-K0J-N01", "0", "AUTO", "Shindengen", 128),
        EcuProfileSpec("K84", "CRF150L", "38770-K84-901", "8000", "0", "Keihin", 128),
        EcuProfileSpec("K64", "CBR250RR", "38770-K64-N04", "8000", "0", "Keihin", 256),
        EcuProfileSpec("K18", "Verza / Megapro", "38770-K18-901", "4000", "7600", "Keihin", 64),
        EcuProfileSpec("KYE", "Mega Pro FI", "38770-KYE-942", "4000", "7600", "Keihin", 64),
        EcuProfileSpec("KZL", "Spacy FI", "30400-KZL-C31", "0", "AUTO", "Shindengen", 64),
        EcuProfileSpec("K03", "Revo FI / Blade FI", "38770-K03-N32", "4000", "7600", "Keihin", 64),
        EcuProfileSpec("K26", "MSX125 / Grom", "38770-K26-901", "4000", "7600", "Keihin", 64),
        EcuProfileSpec("K61", "BeAT POP", "30400-K61-601", "0", "AUTO", "Shindengen", 64),
        EcuProfileSpec("K16", "Scoopy FI Lama", "38770-K16-901", "4000", "7600", "Keihin", 64),
        EcuProfileSpec("K20", "Zoomer-X", "38770-K20-T01", "4000", "7600", "Keihin", 64),
        EcuProfileSpec("K36", "PCX 150 CBU", "38770-K36-J01", "8000", "0", "Keihin", 128),
        EcuProfileSpec("K2V", "New Vario 125", "30400-K2VG-N32", "0", "AUTO", "Shindengen", 128),
        EcuProfileSpec("K12", "Lead 125 / SH Mode", "30400-K12H-931", "0", "AUTO", "Shindengen", 128),
        EcuProfileSpec("K1M", "Super Cub C125", "38770-K1M-T01", "8000", "0", "Keihin", 128),
        EcuProfileSpec("K2E", "CT125 Hunter Cub", "38770-K2E-T02", "8000", "0", "Keihin", 128),
        EcuProfileSpec("K0F", "Monkey 125", "38770-K0F-A01", "8000", "0", "Keihin", 128),
        EcuProfileSpec("K2J", "Wave 110i", "38770-K2J-T01", "4000", "7600", "Keihin", 64),
        EcuProfileSpec("KYZ", "Supra X 125 Helm-In", "38770-KYZ-713", "4000", "7600", "Keihin", 64),
        EcuProfileSpec("K41", "Blade 125 FI", "38770-K41-N01", "4000", "7600", "Keihin", 64),
        EcuProfileSpec("K70", "SH150i", "30400-K70-B01", "0", "AUTO", "Shindengen", 128),
        EcuProfileSpec("K29", "PCX Hybrid / e:HEV", "30400-K29-B01", "0", "AUTO", "Shindengen", 128),
        EcuProfileSpec("K35", "CB190R / Hornet", "38770-K35-V01", "8000", "0", "Keihin", 128),
        EcuProfileSpec("K87", "CBR190R", "38770-K87-A01", "8000", "0", "Keihin", 128),
        EcuProfileSpec("K44", "BeAT eSP K44", "30400-K44-V01", "0", "AUTO", "Shindengen", 64)
    )

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enableEdgeToEdge()
        setContent {
            CandsTechEcuFlasherSuite()
        }
    }
}

@Composable
fun CandsTechEcuFlasherSuite() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("candstech_flasher_prefs", Context.MODE_PRIVATE) }

    var customFolderUriStr by remember { mutableStateOf(prefs.getString("custom_bin_folder_uri", null)) }
    var activeFolderLabel by remember {
        mutableStateOf(prefs.getString("custom_bin_folder_label", "Documents/candstech") ?: "Documents/candstech")
    }

    val xdfTables = remember { mutableStateMapOf<String, XDFTableInfo>() }
    var selectedTableKey by remember { mutableStateOf<String?>(null) }
    var binBytes by remember { mutableStateOf<ByteArray?>(null) }
    var binName by remember { mutableStateOf("No .BIN loaded") }
    var xdfName by remember { mutableStateOf("Default Keihin Map") }
    var checksumHex by remember { mutableStateOf("0x0000") }
    var tableRefreshTick by remember { mutableIntStateOf(0) }
    var selectedRomSizeKb by remember { mutableIntStateOf(64) }

    var editingCellCoord by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    var editingCellInput by remember { mutableStateOf("") }

    var connStatus by remember { mutableStateOf("DISCONNECTED") }
    var rpm by remember { mutableIntStateOf(0) }
    var tpsDeg by remember { mutableFloatStateOf(0f) }
    var ectTemp by remember { mutableIntStateOf(0) }
    var iatTemp by remember { mutableIntStateOf(0) }
    var mapKpa by remember { mutableIntStateOf(0) }
    var batVolt by remember { mutableFloatStateOf(0f) }
    var ecuSpeed by remember { mutableIntStateOf(0) }
    var topSpeed by remember { mutableIntStateOf(0) }
    var ecmIdHex by remember { mutableStateOf("BELUM TERBACA") }
    var detectedEcuProfile by remember { mutableStateOf<EcuProfileSpec?>(null) }
    var cachedEcmRawHex by remember { mutableStateOf("") }
    var cachedEcmRomKb by remember { mutableStateOf<Int?>(null) }
    var activeSensorTable by remember { mutableIntStateOf(0x17) }
    var dtcResultText by remember { mutableStateOf("Belum di-scan") }

    val logs = remember { mutableStateListOf("[SYS] CANDS TECH ECU Flasher v5.46 (Safe Valid-Frame Read Only + K60 64KB Profile) Ready.") }
    var serialPort by remember { mutableStateOf<UsbSerialDevice?>(null) }
    var usbConnection by remember { mutableStateOf<UsbDeviceConnection?>(null) }
    var activeTab by remember { mutableIntStateOf(0) }
    var lastEcuRxHex by remember { mutableStateOf("BELUM ADA RESPON ECU") }
    var totalRxBytesCount by remember { mutableIntStateOf(0) }
    var lastRxDiagLogMs by remember { mutableLongStateOf(0L) }

    val kLineRxQueue = remember { ConcurrentLinkedQueue<Byte>() }
    var isFlashingBusy by remember { mutableStateOf(false) }
    var flashProgress by remember { mutableFloatStateOf(0f) }
    var showWriteConfirmDialog by remember { mutableStateOf(false) }
    var keyCyclePrompt by remember { mutableStateOf<String?>(null) }
    var writeCountdownSec by remember { mutableIntStateOf(10) }

    fun bytesToHex(bytes: ByteArray, maxBytes: Int = 24): String {
        if (bytes.isEmpty()) return "(kosong)"
        val slice = if (bytes.size > maxBytes) bytes.copyOfRange(0, maxBytes) else bytes
        val hex = slice.joinToString(" ") { String.format(Locale.US, "%02X", it.toInt() and 0xFF) }
        return if (bytes.size > maxBytes) "$hex ... (+${bytes.size - maxBytes}B)" else hex
    }

    fun log(msg: String) {
        scope.launch(Dispatchers.Main) {
            if (logs.size > 120) logs.removeAt(0)
            logs.add(msg)
        }
    }

    LaunchedEffect(showWriteConfirmDialog) {
        if (showWriteConfirmDialog) {
            writeCountdownSec = 10
            while (writeCountdownSec > 0 && showWriteConfirmDialog) {
                delay(1000L)
                writeCountdownSec -= 1
            }
        }
    }

    LaunchedEffect(Unit) {
        if (xdfTables.isEmpty()) {
            BinParser.loadDefaultHondaKeihinTables(xdfTables)
            selectedTableKey = xdfTables.keys.firstOrNull()
        }
        try {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                @Suppress("DEPRECATION")
                val docDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "candstech")
                if (!docDir.exists()) docDir.mkdirs()
            }
            log("[DIR] Default: $activeFolderLabel")
        } catch (_: Exception) {
        }
    }

    fun saveBinToActiveDefaultFolder(fileName: String, data: ByteArray): Boolean {
        val cleanFileName = if (fileName.endsWith(".bin", ignoreCase = true)) fileName else "$fileName.bin"
        val customUriStr = customFolderUriStr

        if (!customUriStr.isNullOrBlank()) {
            try {
                val treeUri = Uri.parse(customUriStr)
                val pickedDir = DocumentFile.fromTreeUri(context, treeUri)
                if (pickedDir != null && pickedDir.canWrite()) {
                    pickedDir.findFile(cleanFileName)?.delete()
                    val newFile = pickedDir.createFile("application/octet-stream", cleanFileName)
                    if (newFile != null) {
                        context.contentResolver.openOutputStream(newFile.uri)?.use { out ->
                            out.write(data)
                        }
                        log("[SAVE] -> $activeFolderLabel/$cleanFileName")
                        return true
                    }
                }
            } catch (e: Exception) {
                log("[WARN] Folder kustom error (${e.message}), ke Documents/candstech...")
            }
        }

        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, cleanFileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/octet-stream")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOCUMENTS + "/candstech")
                }
                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Files.getContentUri("external"), values)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { out -> out.write(data) }
                    log("[SAVE] -> Documents/candstech/$cleanFileName")
                    true
                } else {
                    log("[ERR] Gagal buat file di Documents/candstech")
                    false
                }
            } else {
                @Suppress("DEPRECATION")
                val docDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "candstech")
                if (!docDir.exists()) docDir.mkdirs()
                val outFile = File(docDir, cleanFileName)
                outFile.writeBytes(data)
                log("[SAVE] -> ${outFile.absolutePath}")
                true
            }
        } catch (e: Exception) {
            log("[ERR] Gagal simpan .BIN: ${e.message}")
            false
        }
    }

    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        uri?.let {
            try {
                val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                context.contentResolver.takePersistableUriPermission(it, flags)
                val docFile = DocumentFile.fromTreeUri(context, it)
                val folderTitle = docFile?.name ?: it.lastPathSegment?.substringAfterLast(':') ?: "CustomFolder"
                customFolderUriStr = it.toString()
                activeFolderLabel = folderTitle
                prefs.edit()
                    .putString("custom_bin_folder_uri", it.toString())
                    .putString("custom_bin_folder_label", folderTitle)
                    .apply()
                log("[DIR] Folder default: $folderTitle")
            } catch (e: Exception) {
                log("[ERR] Gagal kunci folder: ${e.message}")
            }
        }
    }

    fun resetToDocumentsCandsTech() {
        customFolderUriStr = null
        activeFolderLabel = "Documents/candstech"
        prefs.edit()
            .remove("custom_bin_folder_uri")
            .putString("custom_bin_folder_label", "Documents/candstech")
            .apply()
        log("[DIR] Reset ke Documents/candstech")
    }

    // Format pesan resmi HondaECU.py: mtype + [msgsize] + data + [checksum8bitHonda]
    // msgsize = 0x02 + mtype.size + data.size (total panjang seluruh frame termasuk checksum)
    fun formatHondaMessage(mtype: ByteArray, data: ByteArray = ByteArray(0)): ByteArray {
        val msgSize = 0x02 + mtype.size + data.size
        val withoutCsum = ByteArray(mtype.size + 1 + data.size)
        System.arraycopy(mtype, 0, withoutCsum, 0, mtype.size)
        withoutCsum[mtype.size] = (msgSize and 0xFF).toByte()
        if (data.isNotEmpty()) {
            System.arraycopy(data, 0, withoutCsum, mtype.size + 1, data.size)
        }
        val csum = BinParser.checksum8bitHonda(withoutCsum).toByte()
        return withoutCsum + csum
    }

    data class HondaResponse(
        val success: Boolean,
        val rmtype: ByteArray = ByteArray(0),
        val rml: Int = 0,
        val rdata: ByteArray = ByteArray(0),
        val rawRx: ByteArray = ByteArray(0),
        val errorNote: String = ""
    )

    // Mencari frame balasan Honda yang valid (lolos panjang & checksum8bitHonda) di dalam stream RX,
    // dengan membuang echo TX yang tergeser (seperti 60 00 60 06 00) dan mengunci header 0x02 / mtype!
    fun extractValidHondaReply(rawBytes: ByteArray, fullTx: ByteArray, ml: Int, expectHeader02: Boolean = false): ByteArray? {
        if (rawBytes.size < ml + 2) return null

        val candidateStarts = LinkedHashSet<Int>()
        // Prioritas 1: setelah panjang paket TX (karena half-duplex K-Line memantulkan TX di awal)
        if (rawBytes.size >= fullTx.size + ml + 2) {
            candidateStarts.add(fullTx.size)
        }
        // Prioritas 2: posisi byte 0x02 (header balasan standar ECU Honda Diag: 02 <len> <cmd> ...)
        for (idx in rawBytes.indices) {
            if ((rawBytes[idx].toInt() and 0xFF) == 0x02) {
                candidateStarts.add(idx)
            }
        }
        // Prioritas 3: semua posisi lain jika response menggunakan mtype khusus (misal 0x82 atau 0x0E)
        if (!expectHeader02) {
            for (idx in 0..(rawBytes.size - (ml + 2))) {
                candidateStarts.add(idx)
            }
        }

        for (start in candidateStarts) {
            val lenPos = start + ml
            if (lenPos >= rawBytes.size) continue
            val totalLen = rawBytes[lenPos].toInt() and 0xFF
            if (totalLen < ml + 2 || start + totalLen > rawBytes.size) continue

            val candidate = rawBytes.copyOfRange(start, start + totalLen)
            if (candidate.contentEquals(fullTx)) continue

            val withoutCsum = candidate.copyOfRange(0, candidate.size - 1)
            val expCsum = BinParser.checksum8bitHonda(withoutCsum)
            val actCsum = candidate.last().toInt() and 0xFF
            if (expCsum == actCsum) {
                return candidate
            }
        }
        return null
    }

    // Kirim perintah HondaECU & tunggu balasan (juga membuang echo yang tergeser bit jika tidak ada header balasan baru)
    suspend fun sendHondaCommand(
        port: UsbSerialDevice,
        mtype: ByteArray,
        data: ByteArray = ByteArray(0),
        retries: Int = 3,
        timeoutMs: Int = 240,
        verboseLog: Boolean = false,
        expectHeader02: Boolean = false
    ): HondaResponse {
        val fullTx = formatHondaMessage(mtype, data)
        val ml = mtype.size
        var attempt = 0

        while (attempt <= retries) {
            kLineRxQueue.clear()
            if (verboseLog) {
                log("[TX >] ${bytesToHex(fullTx)}")
            }
            port.write(fullTx)

            val minWaitBytes = fullTx.size + ml + 2
            var elapsed = 0
            while (kLineRxQueue.size < minWaitBytes && elapsed < timeoutMs) {
                delay(5)
                elapsed += 5
            }
            delay(40)

            val raw = mutableListOf<Byte>()
            while (kLineRxQueue.isNotEmpty()) {
                kLineRxQueue.poll()?.let { raw.add(it) }
            }

            if (raw.isEmpty()) {
                if (verboseLog) log("[RX <] TIMEOUT 0B (try ${attempt + 1})")
                attempt++
                continue
            }

            val rawArr = raw.toByteArray()
            val validFrame = extractValidHondaReply(rawArr, fullTx, ml, expectHeader02)

            if (validFrame == null) {
                if (verboseLog) {
                    log("[RX <] RAW (${rawArr.size}B): ${bytesToHex(rawArr)} (try ${attempt + 1})")
                }
                attempt++
                continue
            }

            val rmtype = validFrame.copyOfRange(0, ml)
            val rml = validFrame[ml].toInt() and 0xFF
            val rdata = validFrame.copyOfRange(ml + 1, validFrame.size - 1)
            val hexStr = bytesToHex(validFrame)
            withContext(Dispatchers.Main) {
                lastEcuRxHex = hexStr
                totalRxBytesCount += validFrame.size
            }
            if (verboseLog) {
                log("[RX <] OK (${validFrame.size}B): $hexStr")
            }
            return HondaResponse(
                success = true,
                rmtype = rmtype,
                rml = rml,
                rdata = rdata,
                rawRx = validFrame
            )
        }

        return HondaResponse(success = false, errorNote = "Max retries exceeded")
    }

    // Handshake CandsTech Diag (70ms break -> 120ms -> FE 04 FF FF -> 72 05 00 F0 99)
    suspend fun wakeupAndEnterDiagHonda(port: UsbSerialDevice): Boolean {
        log("[INIT] CandsTech Handshake: 70ms Break + 120ms + FE 04 FF FF + 72 05 00 F0 99...")
        port.setBreak(true)
        delay(70)
        port.setBreak(false)
        delay(120)

        val cmdWakeup = byteArrayOf(0xFE.toByte(), 0x04, 0xFF.toByte(), 0xFF.toByte())
        port.write(cmdWakeup)
        delay(50)
        kLineRxQueue.clear()

        val initResp = sendHondaCommand(
            port = port,
            mtype = byteArrayOf(0x72),
            data = byteArrayOf(0x00, 0xF0.toByte()),
            retries = 3,
            timeoutMs = 350,
            verboseLog = true,
            expectHeader02 = true
        )
        if (initResp.success) {
            log("[INIT] ECU Terbangun & Merespons: ${bytesToHex(initResp.rawRx)}")
            return true
        }
        // Coba alternatif wake-up FE 04 72 8C bila balasan datang terlambat setelah echo
        port.write(byteArrayOf(0xFE.toByte(), 0x04, 0x72, 0x8C.toByte()))
        delay(80)
        val retryInit = sendHondaCommand(
            port = port,
            mtype = byteArrayOf(0x72),
            data = byteArrayOf(0x00, 0xF0.toByte()),
            retries = 2,
            timeoutMs = 350,
            verboseLog = true,
            expectHeader02 = true
        )
        if (retryInit.success) {
            log("[INIT] ECU Terbangun (alt): ${bytesToHex(retryInit.rawRx)}")
            return true
        }
        return false
    }

    fun resolveHondaPartInfo(rawHexNoSpace: String): Triple<String, Int?, EcuProfileSpec?> {
        val clean = rawHexNoSpace.uppercase(Locale.US).replace(" ", "")
        val asciiSb = StringBuilder()
        for (i in 0 until clean.length - 1 step 2) {
            val b = clean.substring(i, i + 2).toIntOrNull(16) ?: 0
            if (b in 32..126) asciiSb.append(b.toChar())
        }
        val asciiStr = asciiSb.toString()
        val partRegex = Regex("(30400-[A-Z0-9]{3}-[A-Z0-9]{3}|38770-[A-Z0-9]{3}-[A-Z0-9]{3}|K[0-9]{2}-[A-Z0-9]{3})")
        val m = partRegex.find(asciiStr)
        if (m != null) {
            val code = m.value
            val spec = hondaEcuDatabase.firstOrNull { code.contains(it.code) }
            val kb = spec?.romKb ?: when {
                code.contains("K15") || code.contains("K56") || code.contains("K45") -> 128
                code.contains("K59") || code.contains("K60") || code.contains("K25") || code.contains("K81") || code.contains("K44") -> 64
                else -> null
            }
            val label = if (spec != null) {
                "$code (${spec.model}) [${spec.vendor}] | Start:${spec.startOffset} | Csum:${spec.csumLoc}"
            } else {
                code
            }
            return Triple(label, kb, spec)
        }

        val matchedSpec = hondaEcuDatabase.firstOrNull { spec ->
            val hexCode = spec.code.replace("-", "").toByteArray(Charsets.US_ASCII)
                .joinToString("") { String.format(Locale.US, "%02X", it.toInt() and 0xFF) }
            clean.contains(spec.code.replace("-", "")) || (hexCode.length >= 6 && clean.contains(hexCode))
        }
        if (matchedSpec != null) {
            return Triple(
                "${matchedSpec.partNo} (${matchedSpec.model}) [${matchedSpec.vendor}] | Start:${matchedSpec.startOffset} | Csum:${matchedSpec.csumLoc}",
                matchedSpec.romKb,
                matchedSpec
            )
        }

        return when {
            clean.startsWith("0100") || clean.contains("4B3539") -> {
                val s = hondaEcuDatabase.firstOrNull { it.code == "K59A" }
                Triple("30400-K59A-A11 (Vario 150) [Shindengen] | Start:0 | Csum:AUTO", 64, s)
            }
            clean.startsWith("0101") || clean.contains("4B3630") -> {
                val s = hondaEcuDatabase.firstOrNull { it.code == "K60R" }
                Triple("30400-K60-B01 (Vario 125/150) [Shindengen] | Start:0 | Csum:AUTO", 64, s)
            }
            clean.startsWith("0200") || clean.contains("4B3235") -> {
                val s = hondaEcuDatabase.firstOrNull { it.code == "K25" }
                Triple("38770-K25-901 (BeAT/Scoopy 110) [Keihin] | Start:4000 | Csum:7600", 64, s)
            }
            clean.startsWith("0201") || clean.contains("4B3831") -> {
                val s = hondaEcuDatabase.firstOrNull { it.code == "K81A" }
                Triple("30400-K81A-N12 (BeAT Sporty/Street) [Shindengen] | Start:0 | Csum:AUTO", 64, s)
            }
            clean.startsWith("0300") || clean.contains("4B3135") -> {
                val s = hondaEcuDatabase.firstOrNull { it.code == "K15" }
                Triple("38770-K15-921 (CB150R) [Keihin] | Start:8000 | Csum:0", 128, s)
            }
            clean.startsWith("0400") || clean.contains("4B3536") -> {
                val s = hondaEcuDatabase.firstOrNull { it.code == "K56N" }
                Triple("38770-K56-N01 (Sonic / Supra GTR / Winner) [Keihin] | Start:8000 | Csum:0", 128, s)
            }
            clean.startsWith("0500") || clean.contains("4B3937") -> {
                val s = hondaEcuDatabase.firstOrNull { it.code == "K97" }
                Triple("30400-K97G-N01 (PCX 150) [Shindengen] | Start:0 | Csum:AUTO", 128, s)
            }
            else -> Triple("UNKNOWN PART ($clean)", null, null)
        }
    }

    // Membaca ECM ID lewat multi-tabel (0x71 0x00, 0x71 0x01, 0x72 0x00) & menuliskannya ke log
    suspend fun readAndLogEcmIdentity(port: UsbSerialDevice): Pair<String, Int?> {
        val queries = listOf(
            Pair(byteArrayOf(0x72), byteArrayOf(0x71, 0x00)),
            Pair(byteArrayOf(0x72), byteArrayOf(0x71, 0x01)),
            Pair(byteArrayOf(0x72), byteArrayOf(0x72, 0x00))
        )
        for ((mtype, qdata) in queries) {
            val resp = sendHondaCommand(
                port = port,
                mtype = mtype,
                data = qdata,
                retries = 1,
                timeoutMs = 200,
                verboseLog = true,
                expectHeader02 = true
            )
            if (resp.success && resp.rawRx.size >= 8) {
                val idBytes = resp.rawRx.copyOfRange(4, resp.rawRx.size - 1)
                val hexSpaced = bytesToHex(idBytes, 16)
                val hexCompact = idBytes.joinToString("") { String.format(Locale.US, "%02X", it.toInt() and 0xFF) }
                val (partName, detectedKb, matchedProfile) = resolveHondaPartInfo(hexCompact)
                val displayStr = "$partName | HEX: $hexSpaced"
                withContext(Dispatchers.Main) {
                    ecmIdHex = displayStr
                    detectedEcuProfile = matchedProfile
                    cachedEcmRawHex = hexCompact
                    cachedEcmRomKb = detectedKb
                    if (detectedKb != null) selectedRomSizeKb = detectedKb
                }
                log("[ECM ID] Terbaca: $displayStr")
                if (matchedProfile != null) {
                    log("[ECM ID] Vendor: ${matchedProfile.vendor} | Start: 0x${matchedProfile.startOffset} | Csum: ${matchedProfile.csumLoc} | ROM: ${matchedProfile.romKb ?: selectedRomSizeKb}KB")
                } else if (detectedKb != null) {
                    log("[ECM ID] Profil dikenali -> Ukuran ROM otomatis: ${detectedKb}KB")
                } else {
                    log("[ECM ID] Kode part belum ada di database -> Gunakan mode standar!")
                }
                return Pair(hexCompact, detectedKb)
            }
        }
        withContext(Dispatchers.Main) {
            ecmIdHex = "UNKNOWN / TIDAK MERESPON ID"
        }
        log("[ECM ID] ECU tidak membalas tabel ID (0x00/0x01) -> Lanjut Auto-Probe metode baca!")
        return Pair("", null)
    }

    // Parsing paket Tabel 17 / Tabel 10 / Tabel 11 resmi dari CandsTech Diag (HondaKLineManager.kt)
    fun parseHondaDiagFrame(data: ByteArray) {
        if (data.size < 6) return
        val responseType = data[2].toInt() and 0xFF
        val tableId = data[3].toInt() and 0xFF

        if (responseType == 0x71 && (tableId == 0x00 || tableId == 0x01) && data.size >= 8) {
            val idBytes = data.copyOfRange(4, data.size - 1)
            val hexCompact = idBytes.joinToString("") { String.format(Locale.US, "%02X", it.toInt() and 0xFF) }
            val (partName, _, matchedProfile) = resolveHondaPartInfo(hexCompact)
            detectedEcuProfile = matchedProfile
            ecmIdHex = "$partName | HEX: ${bytesToHex(idBytes, 16)}"
            return
        }

        if (responseType == 0x71 && (tableId == 0x17 || tableId == 0x10 || tableId == 0x11) && data.size >= 22) {
            val rpmH = data[4].toInt() and 0xFF
            val rpmL = data[5].toInt() and 0xFF
            val calculatedRpm = (rpmH shl 8) or rpmL
            if (calculatedRpm in 0..18000) {
                rpm = calculatedRpm
                tpsDeg = (data[7].toInt() and 0xFF) * 0.5f
                ectTemp = (data[9].toInt() and 0xFF) - 40
                iatTemp = (data[11].toInt() and 0xFF) - 40
                mapKpa = data[13].toInt() and 0xFF
                batVolt = (data[16].toInt() and 0xFF) * 0.1f
                ecuSpeed = data[21].toInt() and 0xFF
                if (ecuSpeed > topSpeed) topSpeed = ecuSpeed
            }
        }
    }

    // Baca ECM ID & Tabel 17 (72 05 71 17 01)
    fun queryEcmIdentityAndTable() {
        val port = serialPort
        if (connStatus != "CONNECTED" || port == null) {
            log("[WARN] Hubungkan FTDI K-Line terlebih dahulu!")
            return
        }
        if (isFlashingBusy) return
        scope.launch(Dispatchers.IO) {
            isFlashingBusy = true
            try {
                wakeupAndEnterDiagHonda(port)
                readAndLogEcmIdentity(port)
                val t17 = sendHondaCommand(port, byteArrayOf(0x72), byteArrayOf(0x71, 0x17), retries = 1, timeoutMs = 220, verboseLog = true, expectHeader02 = true)
                if (t17.success && t17.rawRx.size >= 22) {
                    withContext(Dispatchers.Main) {
                        activeSensorTable = 0x17
                        parseHondaDiagFrame(t17.rawRx)
                    }
                    log("[DIAG] Tabel 17 OK! RPM=$rpm BAT=${batVolt}V TPS=${tpsDeg}°")
                } else {
                    val t10 = sendHondaCommand(port, byteArrayOf(0x72), byteArrayOf(0x71, 0x10), retries = 1, timeoutMs = 220, verboseLog = true, expectHeader02 = true)
                    if (t10.success && t10.rawRx.size >= 22) {
                        withContext(Dispatchers.Main) {
                            activeSensorTable = 0x10
                            parseHondaDiagFrame(t10.rawRx)
                        }
                        log("[DIAG] Tabel 10 OK! RPM=$rpm BAT=${batVolt}V")
                    }
                }
            } finally {
                isFlashingBusy = false
            }
        }
    }

    // Helper membangun payload alamat baca 8-byte (Little-Endian vs Big-Endian)
    fun buildReadAddrPayload(nbyte: Int, readSize: Int, bigEndianAddr: Boolean): ByteArray {
        val bank = ((nbyte / 65536) and 0xFF).toByte()
        val offset16 = nbyte % 65536
        val addrLo = (offset16 and 0xFF).toByte()
        val addrHi = ((offset16 shr 8) and 0xFF).toByte()
        return if (bigEndianAddr) {
            byteArrayOf(bank, addrHi, addrLo, readSize.toByte())
        } else {
            byteArrayOf(bank, addrLo, addrHi, readSize.toByte())
        }
    }

    // READ FLASH (.BIN) 3-TAHAP OTOMATIS:
    // Tahap 1: Wakeup + Baca & Log ECM ID / Part Number (jika belum merespons, ulangi wakeup sekali)
    // Tahap 2: Auto-Probe Metode Baca (1: Direct 0x82 LE [HondaECU.py], 2: Direct 0x82 BE, 3: Session 0xF1 + 0x82, 4: Sec 0x27 + 0x82)
    // Tahap 3: Loop baca 8-byte + Deteksi otomatis batas ukuran ROM (32KB/64KB/128KB) jika terjadi mirror/akhir memori
    fun readRomFromEcu() {
        val port = serialPort
        if (connStatus != "CONNECTED" || port == null) {
            log("[WARN] Hubungkan FTDI K-Line dulu (USB CONNECT)!")
            return
        }
        if (isFlashingBusy) return

        scope.launch(Dispatchers.IO) {
            isFlashingBusy = true
            flashProgress = 0f
            try {
                log("[READ] Turn off bike -> Turn on bike...")
                for (sec in 3 downTo 1) {
                    if (!isActive) break
                    withContext(Dispatchers.Main) {
                        keyCyclePrompt = "MATIKAN KONTAK (OFF)... $sec"
                    }
                    delay(1000L)
                }
                withContext(Dispatchers.Main) {
                    keyCyclePrompt = "NYALAKAN KONTAK (ON)..."
                }
                delay(500L)
                kLineRxQueue.clear()
                withContext(Dispatchers.Main) {
                    keyCyclePrompt = null
                }

                log("[READ] Wake-up ECU & entering diagnostic mode...")
                val woke = wakeupAndEnterDiagHonda(port)
                if (!woke) {
                    wakeupAndEnterDiagHonda(port)
                }

                // Gunakan ECM ID yang sudah dibaca 1x saat USB CONNECT agar tidak bentrok dengan sesi baca ROM
                val rawIdHex = cachedEcmRawHex
                val detectedKb = cachedEcmRomKb
                val activeProfile = detectedEcuProfile
                if (rawIdHex.isNotEmpty()) {
                    log("[READ] Memakai ECM ID tersimpan dari koneksi USB: ${activeProfile?.partNo ?: rawIdHex} (${activeProfile?.vendor ?: "Auto"})")
                } else {
                    log("[READ] ECM ID belum tersimpan saat USB CONNECT -> memakai profil/ukuran terpilih (${selectedRomSizeKb}KB).")
                }
                val isShindengen = activeProfile?.vendor.equals("Shindengen", ignoreCase = true) ||
                    rawIdHex.startsWith("0100") || rawIdHex.startsWith("0101") ||
                    rawIdHex.startsWith("0201") || rawIdHex.startsWith("0500")
                val targetKb = detectedKb ?: selectedRomSizeKb
                val romBytesTotal = targetKb * 1024

                val romBuf = ByteArray(romBytesTotal)
                var readSuccessCount = 0

                if (isShindengen) {
                    log("[READ] Profil SHINDENGEN terdeteksi (${activeProfile?.partNo ?: rawIdHex}) -> Memakai protokol K-Line Shindengen (0x72)...")
                    // Shindengen K-Line session init (tanpa password Keihin 0x27 HelloHo/wAreYou)
                    sendHondaCommand(
                        port = port,
                        mtype = byteArrayOf(0x72),
                        data = byteArrayOf(0x00, 0xF1.toByte()),
                        retries = 3,
                        timeoutMs = 300,
                        verboseLog = true
                    )
                    sendHondaCommand(
                        port = port,
                        mtype = byteArrayOf(0x72),
                        data = byteArrayOf(0x71, 0x01),
                        retries = 2,
                        timeoutMs = 300,
                        verboseLog = true
                    )

                    // Probe 1: Shindengen K-Line 0x80 (pola 72 08 80 <addrHi> <addrMid> <addrLo>, step 4 byte)
                    val probe80 = sendHondaCommand(
                        port = port,
                        mtype = byteArrayOf(0x72),
                        data = byteArrayOf(0x80.toByte(), 0x00, 0x00, 0x00),
                        retries = 3,
                        timeoutMs = 350,
                        verboseLog = true
                    )
                    val use7280Read = probe80.success && probe80.rdata.isNotEmpty()

                    // Probe 2: Shindengen K-Line 0x73 (8 byte)
                    val probeShindengen = if (!use7280Read) {
                        sendHondaCommand(
                            port = port,
                            mtype = byteArrayOf(0x72),
                            data = byteArrayOf(0x73, 0x00, 0x00, 0x00, 0x08),
                            retries = 3,
                            timeoutMs = 350,
                            verboseLog = true
                        )
                    } else null
                    val use72Read = !use7280Read && (probeShindengen?.success == true && (probeShindengen.rdata.size >= 8))

                    // Probe 3: Fallback 0x82 Big-Endian
                    val probe82 = if (!use7280Read && !use72Read) {
                        sendHondaCommand(
                            port = port,
                            mtype = byteArrayOf(0x82.toByte(), 0x82.toByte(), 0x00),
                            data = buildReadAddrPayload(0, 8, bigEndianAddr = true),
                            retries = 3,
                            timeoutMs = 350,
                            verboseLog = true
                        )
                    } else null
                    val use82BeRead = !use7280Read && !use72Read && (probe82?.success == true && (probe82.rdata.size >= 8))

                    if (!use7280Read && !use72Read && !use82BeRead) {
                        log("[WARN] ECU Shindengen (${activeProfile?.partNo ?: "30400-xxx"}) merespons Diag/ID, tetapi firmware tidak membuka akses dump ROM lewat K-Line!")
                        return@launch
                    }

                    log("[READ] Reading ECU Shindengen (${targetKb}KB)...")
                    var nbyte = 0
                    val stepBytes = if (use7280Read) 4 else 8
                    while (isActive && nbyte < romBytesTotal) {
                        val hi = ((nbyte shr 16) and 0xFF).toByte()
                        val mid = ((nbyte shr 8) and 0xFF).toByte()
                        val lo = (nbyte and 0xFF).toByte()
                        val resp = when {
                            use7280Read -> sendHondaCommand(
                                port = port,
                                mtype = byteArrayOf(0x72),
                                data = byteArrayOf(0x80.toByte(), hi, mid, lo),
                                retries = 5,
                                timeoutMs = 400,
                                verboseLog = (nbyte < 20)
                            )
                            use72Read -> sendHondaCommand(
                                port = port,
                                mtype = byteArrayOf(0x72),
                                data = byteArrayOf(0x73, hi, mid, lo, 0x08),
                                retries = 5,
                                timeoutMs = 400,
                                verboseLog = (nbyte == 0)
                            )
                            else -> sendHondaCommand(
                                port = port,
                                mtype = byteArrayOf(0x82.toByte(), 0x82.toByte(), 0x00),
                                data = buildReadAddrPayload(nbyte, 8, bigEndianAddr = true),
                                retries = 5,
                                timeoutMs = 400,
                                verboseLog = (nbyte == 0)
                            )
                        }
                        if (resp.success && resp.rdata.isNotEmpty()) {
                            val copyLen = minOf(stepBytes, resp.rdata.size, romBytesTotal - nbyte)
                            System.arraycopy(resp.rdata, 0, romBuf, nbyte, copyLen)
                            readSuccessCount++
                        } else if (nbyte == 0) {
                            log("[ERR] Gagal membaca blok awal Shindengen (0x0000) -> Proses dihentikan.")
                            return@launch
                        }
                        nbyte += stepBytes
                        withContext(Dispatchers.Main) {
                            flashProgress = (nbyte.toFloat() / romBytesTotal.toFloat()).coerceIn(0f, 1f)
                        }
                    }
                } else {
                    log("[READ] Profil KEIHIN terdeteksi (${activeProfile?.partNo ?: rawIdHex}) -> Security access 0x27...")
                    sendHondaCommand(
                        port = port,
                        mtype = byteArrayOf(0x27),
                        data = byteArrayOf(0xE0.toByte(), 0x48, 0x65, 0x6C, 0x6C, 0x6F, 0x48, 0x6F),
                        retries = 5,
                        timeoutMs = 400,
                        verboseLog = true
                    )
                    sendHondaCommand(
                        port = port,
                        mtype = byteArrayOf(0x27),
                        data = byteArrayOf(0xE0.toByte(), 0x77, 0x41, 0x72, 0x65, 0x59, 0x6F, 0x75),
                        retries = 5,
                        timeoutMs = 400,
                        verboseLog = true
                    )

                    log("[READ] Reading ECU Keihin (${targetKb}KB)...")
                    var nbyte = 0
                    while (isActive && nbyte < romBytesTotal) {
                        val resp = sendHondaCommand(
                            port = port,
                            mtype = byteArrayOf(0x82.toByte(), 0x82.toByte(), 0x00),
                            data = buildReadAddrPayload(nbyte, 8, bigEndianAddr = false),
                            retries = 5,
                            timeoutMs = 400,
                            verboseLog = (nbyte == 0)
                        )
                        if (resp.success && resp.rdata.isNotEmpty()) {
                            val copyLen = minOf(8, resp.rdata.size, romBytesTotal - nbyte)
                            System.arraycopy(resp.rdata, 0, romBuf, nbyte, copyLen)
                            readSuccessCount++
                        } else if (nbyte == 0) {
                            log("[ERR] ECU Keihin tidak merespons baca memori 0x82 di alamat 0x0000 -> Proses dihentikan.")
                            return@launch
                        }
                        nbyte += 8
                        withContext(Dispatchers.Main) {
                            flashProgress = (nbyte.toFloat() / romBytesTotal.toFloat()).coerceIn(0f, 1f)
                        }
                    }
                }

                val cleanId = rawIdHex.replace(Regex("[^A-Za-z0-9_-]"), "").ifBlank { "UNKNOWN_ID" }
                val dateStr = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                val generatedBinName = "ECU_${cleanId}_${targetKb}KB_${dateStr}.bin"

                withContext(Dispatchers.Main) {
                    binBytes = romBuf
                    binName = generatedBinName
                    checksumHex = "0x${BinParser.calculateChecksum16(romBuf).toString(16).uppercase(Locale.US).padStart(4, '0')}"
                    tableRefreshTick++
                    log("[READ] Selesai (${romBuf.size} bytes) -> $generatedBinName")
                }
            } catch (e: Exception) {
                log("[ERR] ${e.message}")
            } finally {
                withContext(Dispatchers.Main) {
                    keyCyclePrompt = null
                    isFlashingBusy = false
                }
            }
        }
    }

    // WRITE / FLASH ROM (.BIN) sesuai do_init_write + do_erase + do_write_flash + do_post_write di HondaECU.py
    fun writeRomToEcu() {
        val port = serialPort
        val rawData = binBytes
        if (connStatus != "CONNECTED" || port == null) {
            log("[WARN] Hubungkan FTDI K-Line terlebih dahulu!")
            return
        }
        if (rawData == null) {
            log("[WARN] Belum ada file .BIN! Klik OPEN .BIN atau READ ECU dulu.")
            return
        }
        if (isFlashingBusy) return

        // Pastikan ukuran kelipatan 128 byte & perbaiki checksum Honda otomatis sebelum write
        val data = rawData.copyOf()
        val customCsumOffset = detectedEcuProfile?.csumLoc?.toIntOrNull(16)?.let { off -> if (off > 0 && off < data.size) off else null }
        val (oldCsum, newCsum, wasFixed) = BinParser.fixHondaRomChecksum(data, customCsumOffset)
        if (wasFixed) {
            log("[CSUM] Checksum .BIN diperbaiki otomatis: 0x${oldCsum.toString(16)} -> 0x${newCsum.toString(16)}")
        }

        scope.launch(Dispatchers.IO) {
            isFlashingBusy = true
            flashProgress = 0f
            try {
                log("[WRITE] Memulai HondaECU Write/Flash (${data.size / 1024} KB)... JANGAN MATIKAN KONTAK!")
                val initOk = wakeupAndEnterDiagHonda(port)

                // 1. do_init_write (0x7D "PGM" / "-FI"), fallback ke do_init_recover jika gagal
                log("[WRITE] Init Write Mode (0x7D PGM-FI)...")
                val w1 = sendHondaCommand(port, byteArrayOf(0x7D), byteArrayOf(0x01, 0x01, 0x02), retries = 3, verboseLog = true)
                val w2 = sendHondaCommand(port, byteArrayOf(0x7D), byteArrayOf(0x01, 0x01, 0x03), retries = 3, verboseLog = true)
                val w3 = sendHondaCommand(port, byteArrayOf(0x7D), byteArrayOf(0x01, 0x02, 0x50, 0x47, 0x4D), retries = 3, verboseLog = true)
                val w4 = sendHondaCommand(port, byteArrayOf(0x7D), byteArrayOf(0x01, 0x03, 0x2D, 0x46, 0x49), retries = 3, verboseLog = true)

                if (!(w1.success && w2.success && w3.success && w4.success)) {
                    log("[WRITE] Beralih ke Recovery Init Mode (0x7B + 0x72 F1 + 0x27)...")
                    if (initOk) {
                        sendHondaCommand(port, byteArrayOf(0x7B), byteArrayOf(0x00, 0x01, 0x02), retries = 3, verboseLog = true)
                        sendHondaCommand(port, byteArrayOf(0x7B), byteArrayOf(0x00, 0x01, 0x03), retries = 3, verboseLog = true)
                        sendHondaCommand(port, byteArrayOf(0x7B), byteArrayOf(0x00, 0x02, 0x76, 0x03, 0x17), retries = 3, verboseLog = true)
                        sendHondaCommand(port, byteArrayOf(0x7B), byteArrayOf(0x00, 0x03, 0x75, 0x05, 0x13), retries = 3, verboseLog = true)
                        sendHondaCommand(port, byteArrayOf(0x72), byteArrayOf(0x00, 0xF1.toByte()), retries = 3, verboseLog = true)
                        sendHondaCommand(port, byteArrayOf(0x27), byteArrayOf(0x00, 0x9F.toByte(), 0x00), retries = 3, verboseLog = true)
                    }
                }

                // 2. do_erase (0x7E sequence + 12s wait + polling 0x01 0x05)
                log("[ERASE] Menghapus Flash ECU (tunggu ~12 detik)...")
                sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x01, 0x00), retries = 5, verboseLog = true)
                for (sec in 12 downTo 1) {
                    delay(1000L)
                    if (sec % 3 == 0) log("[ERASE] Menunggu erase bootloader... ${sec}s")
                }
                sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x02), retries = 5, verboseLog = true)
                sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x03, 0x00, 0x00), retries = 5, verboseLog = true)
                sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x01, 0x00), retries = 5, verboseLog = true)
                sendHondaCommand(
                    port,
                    byteArrayOf(0x7E),
                    byteArrayOf(0x01, 0x0B, 0x00, 0x00, 0x00, 0xFF.toByte(), 0xFF.toByte(), 0xFF.toByte()),
                    retries = 5,
                    verboseLog = true
                )
                sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x01, 0x00), retries = 5, verboseLog = true)
                sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x0E, 0x01, 0x90.toByte()), retries = 5, verboseLog = true)
                sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x01, 0x01), retries = 5, verboseLog = true)
                sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x04, 0xFF.toByte()), retries = 5, verboseLog = true)
                sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x01, 0x00), retries = 5, verboseLog = true)

                var pollCount = 0
                while (isActive && pollCount < 40) {
                    val statusResp = sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x05), retries = 3, verboseLog = (pollCount == 0))
                    if (statusResp.success && statusResp.rdata.size >= 2 && statusResp.rdata[1] == 0x00.toByte()) {
                        log("[ERASE] Erase selesai & terverifikasi!")
                        break
                    }
                    pollCount++
                    delay(250)
                }
                sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x01, 0x00), retries = 5, verboseLog = true)

                // 3. do_write_flash (128-byte blocks)
                log("[WRITE] Menulis blok 128-byte ke ROM ECU...")
                val writeSize = 128
                val maxI = data.size / writeSize
                var i = 0
                while (i < maxI && isActive) {
                    val startVal = 8 * i
                    val endVal = if (i + 1 == maxI) 0 else 8 * (i + 1)
                    val bytStart = byteArrayOf(((startVal shr 8) and 0xFF).toByte(), (startVal and 0xFF).toByte())
                    val bytEnd = byteArrayOf(((endVal shr 8) and 0xFF).toByte(), (endVal and 0xFF).toByte())
                    val chunk = data.copyOfRange(i * writeSize, (i + 1) * writeSize)

                    val xPayload = bytStart + chunk + bytEnd
                    val c1 = BinParser.checksum8bitBlock(xPayload).toByte()
                    val c2 = BinParser.checksum8bitHonda(xPayload).toByte()
                    val fullData = byteArrayOf(0x01, 0x06) + xPayload + byteArrayOf(c1, c2)

                    val writeResp = sendHondaCommand(port, byteArrayOf(0x7E), fullData, retries = 5, timeoutMs = 300, verboseLog = (i == 0))
                    if (!writeResp.success || writeResp.rml != 5) {
                        log("[ERR] Write gagal pada blok #$i (rml=${writeResp.rml}).")
                        isFlashingBusy = false
                        return@launch
                    }

                    i++
                    if (i % 2 == 0) {
                        sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x08), retries = 5, timeoutMs = 250)
                    }

                    if (i % 16 == 0 || i >= maxI) {
                        val pct = i.toFloat() / maxI.toFloat()
                        withContext(Dispatchers.Main) {
                            flashProgress = pct
                            if (i % 64 == 0 || i >= maxI) {
                                log("[WRITE] ${(pct * 100).toInt()}% (${(i * writeSize) / 1024}KB / ${data.size / 1024}KB)")
                            }
                        }
                    }
                }

                // 4. do_post_write
                log("[WRITE] Finalisasi Post-Write (0x09, 0x0A, 0x0C, 0x0D)...")
                sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x01, 0x00), retries = 5)
                sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x09), retries = 5)
                sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x01, 0x00), retries = 5)
                sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x0A), retries = 5)
                sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x01, 0x00), retries = 5)
                sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x0C), retries = 5)
                sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x01, 0x00), retries = 5)
                sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x0D), retries = 5)
                sendHondaCommand(port, byteArrayOf(0x7E), byteArrayOf(0x01, 0x01, 0x00), retries = 5)

                log("[WRITE] SUKSES 100%! Matikan kontak 5 detik lalu nyalakan ulang.")
            } catch (e: Exception) {
                log("[ERR] Write ROM error: ${e.message}")
            } finally {
                isFlashingBusy = false
            }
        }
    }

    val binPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let {
            try {
                val data = context.contentResolver.openInputStream(it)?.use { s -> s.readBytes() }
                if (data != null) {
                    binBytes = data
                    binName = DocumentFile.fromSingleUri(context, it)?.name
                        ?: it.lastPathSegment?.substringAfterLast('/')
                        ?: "ecu_dump.bin"
                    val csum = BinParser.calculateChecksum16(data)
                    checksumHex = "0x${csum.toString(16).uppercase(Locale.US).padStart(4, '0')}"
                    tableRefreshTick++
                    log("[BIN] Loaded $binName (${data.size} B)")
                }
            } catch (e: Exception) {
                log("[ERR] Gagal baca .BIN: ${e.message}")
            }
        }
    }

    val xdfPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let {
            try {
                context.contentResolver.openInputStream(it)?.use { stream ->
                    val parsed = BinParser.parseXdfStream(stream)
                    xdfTables.clear()
                    xdfTables.putAll(parsed)
                    selectedTableKey = xdfTables.keys.firstOrNull()
                    xdfName = DocumentFile.fromSingleUri(context, it)?.name
                        ?: it.lastPathSegment?.substringAfterLast('/')
                        ?: "custom.xdf"
                    tableRefreshTick++
                    log("[XDF] Loaded $xdfName (${xdfTables.size} tables)")
                }
            } catch (e: Exception) {
                log("[ERR] Gagal baca .XDF: ${e.message}")
            }
        }
    }

    fun connectKLine() {
        val usbManager = context.getSystemService(Context.USB_SERVICE) as UsbManager
        val devices = usbManager.deviceList
        if (devices.isEmpty()) {
            log("[USB] Adapter FTDI / CH340 tidak terdeteksi.")
            connStatus = "NO_DEVICE"
            return
        }
        val device: UsbDevice = devices.values.first()
        if (!usbManager.hasPermission(device)) {
            val action = "com.candstech.ecuflasher.USB_PERMISSION"
            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
            val pi = PendingIntent.getBroadcast(context, 0, Intent(action), flags)
            val receiver = object : BroadcastReceiver() {
                override fun onReceive(ctx: Context, intent: Intent) {
                    if (intent.action == action) {
                        try {
                            context.unregisterReceiver(this)
                        } catch (_: Exception) {
                        }
                        if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                            connectKLine()
                        } else {
                            connStatus = "DENIED"
                            log("[USB] Izin USB ditolak.")
                        }
                    }
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.registerReceiver(receiver, IntentFilter(action), Context.RECEIVER_NOT_EXPORTED)
            } else {
                context.registerReceiver(receiver, IntentFilter(action))
            }
            usbManager.requestPermission(device, pi)
            connStatus = "REQUESTING"
            return
        }

        val conn = usbManager.openDevice(device) ?: return
        val port = UsbSerialDevice.createUsbSerialDevice(device, conn)
        if (port != null && port.open()) {
            port.setBaudRate(10400)
            port.setDataBits(UsbSerialInterface.DATA_BITS_8)
            port.setStopBits(UsbSerialInterface.STOP_BITS_1)
            port.setParity(UsbSerialInterface.PARITY_NONE)
            port.setFlowControl(UsbSerialInterface.FLOW_CONTROL_OFF)
            port.read { data ->
                if (data != null && data.isNotEmpty()) {
                    for (b in data) kLineRxQueue.add(b)
                    if (!isFlashingBusy) {
                        val hexStr = bytesToHex(data)
                        val now = System.currentTimeMillis()
                        scope.launch(Dispatchers.Main) {
                            lastEcuRxHex = hexStr
                            totalRxBytesCount += data.size
                            if (now - lastRxDiagLogMs > 600L) {
                                lastRxDiagLogMs = now
                                if (logs.size > 120) logs.removeAt(0)
                                logs.add("[ECU RX ${data.size}B] $hexStr")
                            }
                        }
                    }
                }
            }
            usbConnection = conn
            serialPort = port
            connStatus = "CONNECTED"
            log("[K-LINE] FTDI Online @ 10400 baud 8N1.")

            scope.launch(Dispatchers.IO) {
                // Jalankan handshake CandsTech Diag (70ms break -> 120ms -> FE 04 FF FF -> 72 05 00 F0 99) saat konek
                isFlashingBusy = true
                try {
                    wakeupAndEnterDiagHonda(port)
                    // Baca & log ECM ID / Part Number sekali saat konek
                    readAndLogEcmIdentity(port)
                } finally {
                    isFlashingBusy = false
                }

                var keepAliveCounter = 0
                while (isActive && connStatus == "CONNECTED") {
                    if (!isFlashingBusy) {
                        // Polling Tabel 17 (72 05 71 17 01) persis seperti EcuViewModel.startPolling() di CandsTech Diag
                        kLineRxQueue.clear()
                        port.write(byteArrayOf(0x72, 0x05, 0x71, 0x17, 0x01))
                        delay(85)

                        val raw = mutableListOf<Byte>()
                        while (kLineRxQueue.isNotEmpty()) {
                            kLineRxQueue.poll()?.let { raw.add(it) }
                        }
                        if (raw.isNotEmpty()) {
                            val rawArr = raw.toByteArray()
                            val validFrame = extractValidHondaReply(
                                rawArr,
                                byteArrayOf(0x72, 0x05, 0x71, 0x17, 0x01),
                                1,
                                expectHeader02 = true
                            )
                            if (validFrame != null) {
                                val hexStr = bytesToHex(validFrame)
                                withContext(Dispatchers.Main) {
                                    lastEcuRxHex = hexStr
                                    totalRxBytesCount += validFrame.size
                                    parseHondaDiagFrame(validFrame)
                                }
                            }
                        }

                        keepAliveCounter++
                        if (keepAliveCounter >= 10) {
                            port.write(byteArrayOf(0x72, 0x05, 0x00, 0xF0.toByte(), 0x99.toByte()))
                            delay(40)
                            keepAliveCounter = 0
                        }
                    }
                    delay(150)
                }
            }
        }
    }

    fun disconnectKLine() {
        isFlashingBusy = false
        serialPort?.close()
        usbConnection?.close()
        serialPort = null
        usbConnection = null
        connStatus = "DISCONNECTED"
        log("[USB] Disconnected.")
    }

    // Dialog Peringatan Keamanan 10 Detik Sebelum WRITE ECU
    if (showWriteConfirmDialog) {
        val targetBytes = binBytes
        val sizeKb = (targetBytes?.size ?: 0) / 1024
        AlertDialog(
            onDismissRequest = { showWriteConfirmDialog = false },
            containerColor = CardDark,
            title = {
                Text(
                    text = "PERINGATAN FLASH / WRITE ECU!",
                    color = HondaRed,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Anda akan menulis ulang memori ROM ECU secara permanen!",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "• File: $binName ($sizeKb KB)\n" +
                               "• Checksum: $checksumHex\n" +
                               "• Pastikan aki/adaptor 12V stabil & JANGAN matikan kunci kontak atau cabut kabel USB selama proses flashing berlangsung.",
                        color = Color.LightGray,
                        fontSize = 11.sp
                    )
                    if (writeCountdownSec > 0) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF2B1B1B), RoundedCornerShape(6.dp))
                                .border(1.dp, HondaRed, RoundedCornerShape(6.dp))
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Tunggu $writeCountdownSec detik untuk membuka tombol YES / NO...",
                                color = NeonYellow,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF1B2B1B), RoundedCornerShape(6.dp))
                                .border(1.dp, Color(0xFF00E676), RoundedCornerShape(6.dp))
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Siap! Pilih YES untuk mulai flashing atau NO untuk batal.",
                                color = Color(0xFF00E676),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            },
            confirmButton = {
                if (writeCountdownSec <= 0) {
                    Button(
                        onClick = {
                            showWriteConfirmDialog = false
                            writeRomToEcu()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = HondaRed)
                    ) {
                        Text("YES, FLASH ECU", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            },
            dismissButton = {
                if (writeCountdownSec <= 0) {
                    OutlinedButton(
                        onClick = {
                            showWriteConfirmDialog = false
                            log("[WRITE] Dibatalkan oleh pengguna.")
                        }
                    ) {
                        Text("NO, BATAL", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                } else {
                    TextButton(
                        onClick = {
                            showWriteConfirmDialog = false
                            log("[WRITE] Dibatalkan saat hitung mundur.")
                        }
                    ) {
                        Text("BATAL ($writeCountdownSec)", color = Color.Gray)
                    }
                }
            }
        )
    }

    val activeEditingTable = selectedTableKey?.let { xdfTables[it] }
    val activeBinBytes = binBytes
    if (editingCellCoord != null && activeEditingTable != null && activeBinBytes != null) {
        val (rIdx, cIdx) = editingCellCoord!!
        AlertDialog(
            onDismissRequest = { editingCellCoord = null },
            containerColor = CardDark,
            title = {
                Text(
                    text = "Edit Sel [Baris ${rIdx + 1}, Kolom ${cIdx + 1}]",
                    color = NeonYellow,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "${activeEditingTable.title} (Nilai 0 - 255)",
                        color = Color.LightGray,
                        fontSize = 11.sp
                    )
                    OutlinedTextField(
                        value = editingCellInput,
                        onValueChange = { editingCellInput = it.filter { ch -> ch.isDigit() } },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = NeonYellow,
                            unfocusedBorderColor = BorderDark
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val newVal = editingCellInput.toIntOrNull()
                        if (newVal != null) {
                            BinParser.writeCell(activeBinBytes, activeEditingTable, rIdx, cIdx, newVal)
                            checksumHex = "0x${BinParser.calculateChecksum16(activeBinBytes).toString(16).uppercase(Locale.US).padStart(4, '0')}"
                            tableRefreshTick++
                            log("[EDIT] [${rIdx + 1},${cIdx + 1}] -> ${newVal.coerceIn(0, 255)}")
                        }
                        editingCellCoord = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = HondaRed)
                ) {
                    Text("SIMPAN", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { editingCellCoord = null }) {
                    Text("BATAL", color = Color.Gray)
                }
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDark)
            .statusBarsPadding()
            .displayCutoutPadding()
            .navigationBarsPadding()
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        // Top Header Bar: Tinggi 50.dp, Logo 47.dp
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .background(CardDark, RoundedCornerShape(8.dp))
                .border(1.dp, BorderDark, RoundedCornerShape(8.dp))
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Image(
                    painter = painterResource(id = R.drawable.logo_candstech),
                    contentDescription = "CANDS TECH Logo",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.height(40.dp)
                )
                TabChip("1. FLASH & MAP", activeTab == 0) { activeTab = 0 }
                TabChip("2. AI PRESET", activeTab == 1) { activeTab = 1 }
                TabChip("3. K-LINE DIAG", activeTab == 2) { activeTab = 2 }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("CSUM: $checksumHex", color = NeonYellow, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                Button(
                    onClick = { if (connStatus == "CONNECTED") disconnectKLine() else connectKLine() },
                    colors = ButtonDefaults.buttonColors(containerColor = if (connStatus == "CONNECTED") Color.DarkGray else HondaRed),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                    modifier = Modifier.height(34.dp)
                ) {
                    Text(
                        text = if (connStatus == "CONNECTED") "USB ON" else "USB CONNECT",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        if (keyCyclePrompt != null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF2B2200), RoundedCornerShape(6.dp))
                    .border(1.dp, NeonYellow, RoundedCornerShape(6.dp))
                    .padding(horizontal = 8.dp, vertical = 5.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = keyCyclePrompt!!,
                    color = NeonYellow,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        if (isFlashingBusy) {
            LinearProgressIndicator(
                progress = flashProgress.coerceIn(0f, 1f),
                modifier = Modifier.fillMaxWidth().height(6.dp),
                color = NeonYellow,
                trackColor = Color(0xFF2B2B2B)
            )
        }

        when (activeTab) {
            0 -> {
                Row(modifier = Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Column(
                        modifier = Modifier
                            .weight(0.85f)
                            .fillMaxHeight()
                            .background(CardDark, RoundedCornerShape(8.dp))
                            .border(1.dp, BorderDark, RoundedCornerShape(8.dp))
                            .padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                TabChip("32K", selectedRomSizeKb == 32) { selectedRomSizeKb = 32 }
                                TabChip("64K", selectedRomSizeKb == 64) { selectedRomSizeKb = 64 }
                                TabChip("128K", selectedRomSizeKb == 128) { selectedRomSizeKb = 128 }
                                TabChip("256K", selectedRomSizeKb == 256) { selectedRomSizeKb = 256 }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                SmallFolderBtn("PILIH DIR") { folderPicker.launch(null) }
                                if (customFolderUriStr != null) {
                                    SmallFolderBtn("RESET") { resetToDocumentsCandsTech() }
                                }
                            }
                        }

                        Text("DIR: $activeFolderLabel", color = NeonYellow, fontSize = 8.sp, maxLines = 1)

                        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            ActionBtn("READ ECU", Color(0xFF154360), Modifier.weight(1f)) { readRomFromEcu() }
                            ActionBtn("WRITE ECU", Color(0xFF922B21), Modifier.weight(1f)) {
                                if (connStatus != "CONNECTED" || serialPort == null) {
                                    log("[WARN] Hubungkan FTDI K-Line terlebih dahulu!")
                                } else if (binBytes == null) {
                                    log("[WARN] Belum ada file .BIN! Klik OPEN .BIN atau READ ECU dulu.")
                                } else if (!isFlashingBusy) {
                                    showWriteConfirmDialog = true
                                }
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            ActionBtn("OPEN .BIN", Color(0xFF2B2B2B), Modifier.weight(1f)) { binPicker.launch(arrayOf("*/*")) }
                            ActionBtn("OPEN .XDF", HondaRed, Modifier.weight(1f)) { xdfPicker.launch(arrayOf("*/*")) }
                        }

                        ActionBtn("SAVE .BIN TO DIR", Color(0xFF2E4A1E), Modifier.fillMaxWidth()) {
                            val data = binBytes
                            if (data != null) {
                                val outName = if (binName == "No .BIN loaded") {
                                    "TUNED_${System.currentTimeMillis() / 1000}.bin"
                                } else {
                                    "TUNED_$binName"
                                }
                                saveBinToActiveDefaultFolder(outName, data)
                            } else {
                                log("[WARN] Klik READ ECU atau OPEN .BIN dulu!")
                            }
                        }

                        Divider(color = BorderDark)

                        val orderedKeys = remember(xdfTables.keys.toList()) {
                            val list = xdfTables.keys.toMutableList()
                            val fuelKey = list.find { it.contains("Main Fuel Base Map", ignoreCase = true) }
                            if (fuelKey != null) {
                                list.remove(fuelKey)
                                list.add(fuelKey)
                            }
                            list
                        }

                        LazyColumn(
                            modifier = Modifier.weight(1.1f).fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            items(orderedKeys) { key ->
                                val isSel = key == selectedTableKey
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(if (isSel) HondaRed else Color(0xFF262626), RoundedCornerShape(4.dp))
                                        .clickable { selectedTableKey = key }
                                        .padding(horizontal = 7.dp, vertical = 6.dp)
                                ) {
                                    Text(key, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        Divider(color = NeonYellow.copy(alpha = 0.4f))

                        Column(
                            modifier = Modifier
                                .weight(1.0f)
                                .fillMaxWidth()
                                .background(Color(0xFF141414), RoundedCornerShape(6.dp))
                                .border(0.5.dp, BorderDark, RoundedCornerShape(6.dp))
                                .padding(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("DEBUG & RESPON ECU (${totalRxBytesCount}B)", color = NeonYellow, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    SmallFolderBtn("PING ECU") {
                                        val port = serialPort
                                        if (connStatus != "CONNECTED" || port == null) {
                                            log("[WARN] Klik USB CONNECT dulu!")
                                        } else {
                                            scope.launch(Dispatchers.IO) {
                                                log("[PING] Tes Wakeup 360bps + ECM ID + Sec 0x27...")
                                                lastRxDiagLogMs = 0L
                                                isFlashingBusy = true
                                                try {
                                                    wakeupAndEnterDiagHonda(port)
                                                    val idResp = sendHondaCommand(port, byteArrayOf(0x72), byteArrayOf(0x71, 0x00), retries = 1, timeoutMs = 240, verboseLog = true)
                                                    if (idResp.success && idResp.rawRx.size >= 10) {
                                                        val idStr = bytesToHex(idResp.rawRx.copyOfRange(4, idResp.rawRx.size - 1), 16)
                                                        withContext(Dispatchers.Main) { ecmIdHex = idStr }
                                                        log("[ECM ID] $idStr")
                                                    }
                                                    sendHondaCommand(
                                                        port,
                                                        byteArrayOf(0x27),
                                                        byteArrayOf(0xE0.toByte(), 0x48, 0x65, 0x6C, 0x6C, 0x6F, 0x48, 0x6F),
                                                        retries = 1,
                                                        timeoutMs = 250,
                                                        verboseLog = true
                                                    )
                                                    sendHondaCommand(
                                                        port,
                                                        byteArrayOf(0x27),
                                                        byteArrayOf(0xE0.toByte(), 0x77, 0x41, 0x72, 0x65, 0x59, 0x6F, 0x75),
                                                        retries = 1,
                                                        timeoutMs = 250,
                                                        verboseLog = true
                                                    )
                                                } finally {
                                                    isFlashingBusy = false
                                                }
                                            }
                                        }
                                    }
                                    SmallFolderBtn("CLR") {
                                        logs.clear()
                                        totalRxBytesCount = 0
                                        lastEcuRxHex = "LOG DIBERSIHKAN"
                                    }
                                }
                            }
                            Text(
                                text = "LAST RX: $lastEcuRxHex",
                                color = if (totalRxBytesCount > 0) Color(0xFF00E676) else Color(0xFFFF5252),
                                fontSize = 8.sp,
                                fontFamily = FontFamily.Monospace,
                                maxLines = 1
                            )
                            Spacer(Modifier.height(2.dp))
                            LazyColumn(modifier = Modifier.fillMaxSize()) {
                                items(logs) { line ->
                                    val lineColor = when {
                                        line.contains("ECU RX") || line.contains("[RX <- ECU]") -> Color(0xFF00E676)
                                        line.contains("[TX -> ECU]") || line.contains("[DIAG TX]") -> Color(0xFF40C4FF)
                                        line.contains("[WARN]") || line.contains("[ERR]") || line.contains("TIMEOUT") -> Color(0xFFFF5252)
                                        else -> Color.LightGray
                                    }
                                    Text(line, color = lineColor, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                                }
                            }
                        }
                    }

                    Column(
                        modifier = Modifier
                            .weight(1.75f)
                            .fillMaxHeight()
                            .background(CardDark, RoundedCornerShape(8.dp))
                            .border(1.dp, BorderDark, RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        val table = selectedTableKey?.let { xdfTables[it] }
                        val bytes = binBytes
                        val tick = tableRefreshTick

                        if (table != null && tick >= 0) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "${table.title} (0x${table.address.toString(16).uppercase(Locale.US)})",
                                        color = NeonYellow,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Ukuran: ${table.rows}x${table.cols} | Ketuk angka sel untuk edit manual",
                                        color = Color.Gray,
                                        fontSize = 9.sp
                                    )
                                }
                                if (bytes != null) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        SmallStepBtn("+5%") {
                                            for (r in 0 until table.rows) {
                                                for (c in 0 until table.cols) {
                                                    val cur = BinParser.readCell(bytes, table, r, c)
                                                    BinParser.writeCell(bytes, table, r, c, (cur * 1.05f).toInt())
                                                }
                                            }
                                            checksumHex = "0x${BinParser.calculateChecksum16(bytes).toString(16).uppercase(Locale.US).padStart(4, '0')}"
                                            tableRefreshTick++
                                            log("[MAP] ${table.title} +5%")
                                        }
                                        SmallStepBtn("+2%") {
                                            for (r in 0 until table.rows) {
                                                for (c in 0 until table.cols) {
                                                    val cur = BinParser.readCell(bytes, table, r, c)
                                                    BinParser.writeCell(bytes, table, r, c, (cur * 1.02f).toInt())
                                                }
                                            }
                                            checksumHex = "0x${BinParser.calculateChecksum16(bytes).toString(16).uppercase(Locale.US).padStart(4, '0')}"
                                            tableRefreshTick++
                                            log("[MAP] ${table.title} +2%")
                                        }
                                        SmallStepBtn("-2%") {
                                            for (r in 0 until table.rows) {
                                                for (c in 0 until table.cols) {
                                                    val cur = BinParser.readCell(bytes, table, r, c)
                                                    BinParser.writeCell(bytes, table, r, c, (cur * 0.98f).toInt())
                                                }
                                            }
                                            checksumHex = "0x${BinParser.calculateChecksum16(bytes).toString(16).uppercase(Locale.US).padStart(4, '0')}"
                                            tableRefreshTick++
                                            log("[MAP] ${table.title} -2%")
                                        }
                                    }
                                }
                            }
                            Spacer(Modifier.height(6.dp))
                            if (bytes == null) {
                                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                    Text(
                                        text = "Klik READ ECU atau OPEN .BIN untuk menampilkan & mengedit tabel besar di sini.",
                                        color = Color.Gray,
                                        fontSize = 12.sp
                                    )
                                }
                            } else {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .verticalScroll(rememberScrollState())
                                        .horizontalScroll(rememberScrollState())
                                ) {
                                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                        Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                            Box(modifier = Modifier.width(34.dp).height(24.dp), contentAlignment = Alignment.Center) {
                                                Text("R\\C", color = Color.Gray, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                            }
                                            for (c in 0 until table.cols.coerceAtMost(24)) {
                                                Box(
                                                    modifier = Modifier
                                                        .width(44.dp)
                                                        .height(24.dp)
                                                        .background(Color(0xFF282828), RoundedCornerShape(3.dp)),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text("C${c + 1}", color = NeonYellow, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                        }

                                        for (r in 0 until table.rows.coerceAtMost(24)) {
                                            Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                                Box(
                                                    modifier = Modifier
                                                        .width(34.dp)
                                                        .height(30.dp)
                                                        .background(Color(0xFF282828), RoundedCornerShape(3.dp)),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text("R${r + 1}", color = NeonYellow, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                                }
                                                for (c in 0 until table.cols.coerceAtMost(24)) {
                                                    val valCell = BinParser.readCell(bytes, table, r, c)
                                                    Box(
                                                        modifier = Modifier
                                                            .width(44.dp)
                                                            .height(30.dp)
                                                            .background(Color(0xFF141414), RoundedCornerShape(3.dp))
                                                            .border(0.7.dp, BorderDark, RoundedCornerShape(3.dp))
                                                            .clickable {
                                                                editingCellCoord = Pair(r, c)
                                                                editingCellInput = valCell.toString()
                                                            },
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        Text(
                                                            text = valCell.toString(),
                                                            color = Color.White,
                                                            fontSize = 11.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            fontFamily = FontFamily.Monospace
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            1 -> {
                Row(modifier = Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Column(
                        modifier = Modifier
                            .weight(1.7f)
                            .fillMaxHeight()
                            .background(CardDark, RoundedCornerShape(8.dp))
                            .border(1.dp, BorderDark, RoundedCornerShape(8.dp))
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text("AI AUTO-TUNING PRESETS & ENGINE SAFEGUARDS", color = NeonYellow, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        LazyColumn(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(AiPresetEngine.presets) { preset ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color(0xFF262626), RoundedCornerShape(6.dp))
                                        .padding(8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(preset.name, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        Text(preset.description, color = Color.LightGray, fontSize = 10.sp)
                                        Text("Target AFR: ${preset.targetAfr} | Limit: ${preset.rpmLimitTarget} RPM", color = NeonYellow, fontSize = 9.sp)
                                    }
                                    Button(
                                        onClick = {
                                            val bytes = binBytes
                                            if (bytes == null) {
                                                log("[WARN] Klik READ ECU atau OPEN .BIN dulu!")
                                            } else {
                                                val (count, check) = AiPresetEngine.applyPresetToBin(bytes, xdfTables, preset)
                                                checksumHex = "0x${BinParser.calculateChecksum16(bytes).toString(16).uppercase(Locale.US).padStart(4, '0')}"
                                                tableRefreshTick++
                                                log("[AI-PRESET] ${preset.name} applied ($count sel).")
                                                if (!check.isSafe) {
                                                    check.warnings.forEach { w -> log("[SAFEGUARD] $w") }
                                                } else {
                                                    log("[SAFEGUARD] Aman dalam batas toleransi mesin.")
                                                }
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = HondaRed),
                                        modifier = Modifier.height(34.dp)
                                    ) {
                                        Text("APPLY", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    Column(
                        modifier = Modifier
                            .weight(0.8f)
                            .fillMaxHeight()
                            .background(CardDark, RoundedCornerShape(8.dp))
                            .border(1.dp, BorderDark, RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        Text("DEBUG & SAFEGUARD LOG", color = NeonYellow, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = "LAST ECU RX (${totalRxBytesCount}B): $lastEcuRxHex",
                            color = if (totalRxBytesCount > 0) Color(0xFF00E676) else Color(0xFFFF5252),
                            fontSize = 8.sp,
                            fontFamily = FontFamily.Monospace,
                            maxLines = 1
                        )
                        Spacer(Modifier.height(2.dp))
                        LazyColumn(modifier = Modifier.fillMaxSize()) {
                            items(logs) { line ->
                                val lineColor = when {
                                    line.contains("ECU RX") || line.contains("[RX <- ECU]") -> Color(0xFF00E676)
                                    line.contains("[TX -> ECU]") || line.contains("[DIAG TX]") -> Color(0xFF40C4FF)
                                    line.contains("[WARN]") || line.contains("[ERR]") || line.contains("TIMEOUT") -> Color(0xFFFF5252)
                                    else -> Color.LightGray
                                }
                                Text(line, color = lineColor, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            }

            2 -> {
                Row(modifier = Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Column(modifier = Modifier.weight(1.7f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Column(modifier = Modifier.fillMaxWidth().background(CardDark, RoundedCornerShape(8.dp)).padding(8.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("ENGINE RPM", color = Color.Gray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                Text("$rpm RPM", color = if (rpm > 9500) HondaRed else NeonYellow, fontSize = 15.sp, fontWeight = FontWeight.Black)
                            }
                            LinearProgressIndicator(
                                progress = (rpm / 12000f).coerceIn(0f, 1f),
                                modifier = Modifier.fillMaxWidth().height(10.dp),
                                color = if (rpm > 9500) HondaRed else NeonYellow,
                                trackColor = Color(0xFF2B2B2B)
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            MetricCard("SPEED", "$ecuSpeed km/h", "TOP: $topSpeed", Modifier.weight(1f))
                            MetricCard("TPS", String.format(Locale.US, "%.1f°", tpsDeg), "THROTTLE", Modifier.weight(1f))
                            MetricCard("BATTERY", String.format(Locale.US, "%.1f V", batVolt), "VOLTAGE", Modifier.weight(1f))
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            MetricCard("ECT", "$ectTemp °C", "COOLANT", Modifier.weight(1f))
                            MetricCard("IAT", "$iatTemp °C", "INTAKE", Modifier.weight(1f))
                            MetricCard("MAP", "$mapKpa kPa", "PRESSURE", Modifier.weight(1f))
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(CardDark, RoundedCornerShape(6.dp))
                                .border(0.7.dp, BorderDark, RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 5.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("ECM ID: $ecmIdHex", color = NeonYellow, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            Text("DTC: $dtcResultText", color = Color.White, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            ActionBtn("ECM ID", Color(0xFF154360), Modifier.weight(1f)) {
                                queryEcmIdentityAndTable()
                            }
                            ActionBtn("SCAN DTC", Color(0xFF2B2B2B), Modifier.weight(1f)) {
                                val port = serialPort
                                if (connStatus != "CONNECTED" || port == null) {
                                    log("[WARN] Hubungkan FTDI K-Line dulu!")
                                } else {
                                    scope.launch(Dispatchers.IO) {
                                        isFlashingBusy = true
                                        try {
                                            val r1 = sendHondaCommand(port, byteArrayOf(0x72), byteArrayOf(0x74, 0x01), retries = 1, timeoutMs = 220, verboseLog = true)
                                            val r2 = sendHondaCommand(port, byteArrayOf(0x72), byteArrayOf(0x73, 0x01), retries = 1, timeoutMs = 220, verboseLog = true)
                                            val dtcHex = when {
                                                r2.success && r2.rdata.size > 2 -> bytesToHex(r2.rdata.copyOfRange(2, r2.rdata.size))
                                                r1.success && r1.rdata.size > 2 -> bytesToHex(r1.rdata.copyOfRange(2, r1.rdata.size))
                                                r1.success || r2.success -> "0 DTC (BERSIH)"
                                                else -> "NO RESP"
                                            }
                                            withContext(Dispatchers.Main) { dtcResultText = dtcHex }
                                            log("[DTC] Hasil Scan: $dtcHex")
                                        } finally {
                                            isFlashingBusy = false
                                        }
                                    }
                                }
                            }
                            ActionBtn("CLEAR DTC", HondaRed, Modifier.weight(1f)) {
                                val port = serialPort
                                if (connStatus != "CONNECTED" || port == null) {
                                    log("[WARN] Hubungkan FTDI K-Line dulu!")
                                } else {
                                    scope.launch(Dispatchers.IO) {
                                        isFlashingBusy = true
                                        try {
                                            val r = sendHondaCommand(port, byteArrayOf(0x72), byteArrayOf(0x60, 0x01), retries = 2, timeoutMs = 240, verboseLog = true)
                                            withContext(Dispatchers.Main) {
                                                dtcResultText = if (r.success) "CLEARED OK" else "NO RESP"
                                            }
                                        } finally {
                                            isFlashingBusy = false
                                        }
                                    }
                                }
                            }
                            ActionBtn("RESET TP", Color(0xFF2B2B2B), Modifier.weight(1f)) {
                                val port = serialPort
                                if (connStatus != "CONNECTED" || port == null) {
                                    log("[WARN] Hubungkan FTDI K-Line dulu!")
                                } else {
                                    scope.launch(Dispatchers.IO) {
                                        isFlashingBusy = true
                                        try {
                                            val r1 = sendHondaCommand(port, byteArrayOf(0x02), byteArrayOf(0x60), retries = 1, timeoutMs = 220, verboseLog = true, expectHeader02 = true)
                                            if (!r1.success) {
                                                sendHondaCommand(port, byteArrayOf(0x72), byteArrayOf(0x60, 0x03), retries = 1, timeoutMs = 220, verboseLog = true, expectHeader02 = true)
                                            }
                                        } finally {
                                            isFlashingBusy = false
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Column(
                        modifier = Modifier
                            .weight(0.8f)
                            .fillMaxHeight()
                            .background(CardDark, RoundedCornerShape(8.dp))
                            .border(1.dp, BorderDark, RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        Text("DEBUG & K-LINE LOG", color = NeonYellow, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = "LAST ECU RX (${totalRxBytesCount}B): $lastEcuRxHex",
                            color = if (totalRxBytesCount > 0) Color(0xFF00E676) else Color(0xFFFF5252),
                            fontSize = 8.sp,
                            fontFamily = FontFamily.Monospace,
                            maxLines = 1
                        )
                        Spacer(Modifier.height(2.dp))
                        LazyColumn(modifier = Modifier.fillMaxSize()) {
                            items(logs) { line ->
                                val lineColor = when {
                                    line.contains("ECU RX") || line.contains("[RX <- ECU]") -> Color(0xFF00E676)
                                    line.contains("[TX -> ECU]") || line.contains("[DIAG TX]") -> Color(0xFF40C4FF)
                                    line.contains("[WARN]") || line.contains("[ERR]") || line.contains("TIMEOUT") -> Color(0xFFFF5252)
                                    else -> Color.LightGray
                                }
                                Text(line, color = lineColor, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TabChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(if (selected) NeonYellow else Color(0xFF2A2A2A), RoundedCornerShape(4.dp))
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 5.dp)
    ) {
        Text(label, color = if (selected) Color.Black else Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun MetricCard(title: String, value: String, sub: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(CardDark, RoundedCornerShape(8.dp))
            .border(1.dp, BorderDark, RoundedCornerShape(8.dp))
            .padding(8.dp)
    ) {
        Text(title, color = Color.Gray, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Text(value, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Black)
        Text(sub, color = NeonYellow, fontSize = 9.sp)
    }
}

@Composable
fun ActionBtn(label: String, bg: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier.height(33.dp),
        shape = RoundedCornerShape(6.dp),
        colors = ButtonDefaults.buttonColors(containerColor = bg),
        contentPadding = PaddingValues(4.dp)
    ) {
        Text(label, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SmallStepBtn(label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(HondaRed, RoundedCornerShape(4.dp))
            .clickable { onClick() }
            .padding(horizontal = 9.dp, vertical = 4.dp)
    ) {
        Text(label, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SmallFolderBtn(label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(Color(0xFF333333), RoundedCornerShape(4.dp))
            .border(0.5.dp, NeonYellow, RoundedCornerShape(4.dp))
            .clickable { onClick() }
            .padding(horizontal = 6.dp, vertical = 3.dp)
    ) {
        Text(label, color = NeonYellow, fontSize = 8.sp, fontWeight = FontWeight.Bold)
    }
}
