package com.candstech.ecuflasher

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.felhr.usbserial.UsbSerialDevice
import com.felhr.usbserial.UsbSerialInterface
import java.io.ByteArrayInputStream

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            EcuFlasherLandscapeTheme {
                EcuStudioLandscapeScreen()
            }
        }
    }
}

val BgDark = Color(0xFF0F1117)
val PanelDark = Color(0xFF141923)
val BorderColor = Color(0xFF1E293B)
val CyanAccent = Color(0xFF38BDF8)
val HondaRed = Color(0xFFE10600)
val SuccessGreen = Color(0xFF10B981)

@Composable
fun EcuFlasherLandscapeTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = BgDark,
            surface = PanelDark,
            primary = CyanAccent
        ),
        content = content
    )
}

@Composable
fun EcuStudioLandscapeScreen() {
    val context = LocalContext.current
    var isConnected by remember { mutableStateOf(false) }
    var currentRpm by remember { mutableStateOf(1600) }
    var currentTps by remember { mutableStateOf(0.0f) }
    var currentAfr by remember { mutableStateOf(13.0f) }
    var logText by remember { mutableStateOf("[System]: Siap terhubung ke ECU Honda K-Line (10400 baud).\n") }

    // ECU Bin & XDF State
    val ecuBin = remember { ECUBinFile() }
    var xdfParser by remember { mutableStateOf<XDFDefinitionParser?>(null) }
    var currentTableKey by remember { mutableStateOf("0x0002") }
    var matrixData by remember { mutableStateOf<List<List<Float>>>(emptyList()) }
    var selectedCell by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    var cellEditValue by remember { mutableStateOf("") }

    // Initialize mock bin on startup
    LaunchedEffect(Unit) {
        ecuBin.createMock(262144, "Vario160")
        val defaultXdf = """<?xml version="1.0" encoding="UTF-8"?>
        <XDFFORMAT version="1.70">
          <XDFHEADER><vehicle>Honda Vario 160</vehicle><ECU>Keihin 256KB</ECU></XDFHEADER>
          <XDFTABLE uniqueID="0x0002"><TITLE>Fuel Map (16x16)</TITLE><DEFAULTS><ADDR>2000</ADDR><datasize>2</datasize></DEFAULTS></XDFTABLE>
          <XDFTABLE uniqueID="0x0003"><TITLE>Ignition Map (16x16)</TITLE><DEFAULTS><ADDR>2200</ADDR><datasize>1</datasize></DEFAULTS></XDFTABLE>
        </XDFFORMAT>""".trimIndent()
        xdfParser = XDFDefinitionParser(ByteArrayInputStream(defaultXdf.toByteArray()))
        xdfParser?.tables[currentTableKey]?.let { info ->
            matrixData = ecuBin.readTable(info)
        }
        logText += "[Init]: Mock ROM 256KB & Default XDF loaded.\n"
    }

    // File Picker for .bin import
    val binPickerLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            try {
                ecuBin.loadFromUri(context, uri)
                xdfParser?.tables[currentTableKey]?.let { info ->
                    matrixData = ecuBin.readTable(info)
                }
                logText += "[File]: Berhasil import .bin (${ecuBin.data.size} bytes).\n"
                Toast.makeText(context, "File .bin berhasil dimuat!", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                logText += "[Error]: Gagal memuat file .bin: ${e.message}\n"
            }
        }
    }

    Row(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDark)
            .padding(8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // 1. PANEL KIRI: Live Sensors & USB K-Line (~26% width)
        Card(
            modifier = Modifier.weight(0.26f).fillMaxHeight(),
            colors = CardDefaults.cardColors(containerColor = PanelDark),
            border = BorderStroke(1.dp, BorderColor)
        ) {
            Column(
                modifier = Modifier.fillMaxSize().padding(10.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("🩺 Live Diagnostics", fontWeight = FontWeight.Bold, color = CyanAccent, fontSize = 13.sp)

                Box(
                    modifier = Modifier.fillMaxWidth().background(BgDark, MaterialTheme.shapes.small).padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("$currentRpm RPM", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = CyanAccent)
                        Text("Putaran Mesin", fontSize = 9.sp, color = Color.Gray)
                    }
                }

                SensorRow("Gas (TPS)", String.format(java.util.Locale.ROOT, "%.1f %%", currentTps))
                SensorRow("Wideband AFR", String.format(java.util.Locale.ROOT, "%.1f : 1", currentAfr))
                SensorRow("Suhu ECT", "88 °C (Optimal)")
                SensorRow("Voltase Aki", "12.8 V (Lulus)")

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = {
                        isConnected = !isConnected
                        if (isConnected) {
                            logText += "[K-Line]: Terhubung ke ECU (10400 Baud KWP2000)\n"
                            Toast.makeText(context, "ECU Terhubung!", Toast.LENGTH_SHORT).show()
                        } else {
                            logText += "[K-Line]: ECU Terputus.\n"
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = if (isConnected) HondaRed else Color(0xFF0369A1))
                ) {
                    Text(if (isConnected) "🔌 Putuskan K-Line" else "🔌 Hubungkan K-Line", fontSize = 11.sp)
                }
            }
        }

        // 2. PANEL TENGAH: Table & Bin Editor (.BIN Map Matrix) (~48% width)
        Card(
            modifier = Modifier.weight(0.48f).fillMaxHeight(),
            colors = CardDefaults.cardColors(containerColor = PanelDark),
            border = BorderStroke(1.dp, BorderColor)
        ) {
            Column(
                modifier = Modifier.fillMaxSize().padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val currentTitle = xdfParser?.tables[currentTableKey]?.title ?: "Tabel Parameter"
                    Text("⚡ $currentTitle", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        SmallBtn("AI Tune") {
                            xdfParser?.tables[currentTableKey]?.let { info ->
                                val tuner = AISmartTuner(EngineSpecs(exhaust = "Full System Racing", airFilter = "High-Flow", fuelOctane = 98))
                                val mults = tuner.calculateFuelMultipliers(info.rows, info.cols)
                                for (r in 0 until info.rows) {
                                    for (c in 0 until info.cols) {
                                        val oldVal = matrixData[r][c]
                                        ecuBin.writeTableCell(info, r, c, oldVal * mults[r][c])
                                    }
                                }
                                matrixData = ecuBin.readTable(info)
                                logText += "[AI Tune]: Berhasil optimasi fuel map balap!\n"
                                Toast.makeText(context, "AI Smart Tune Berhasil Diterapkan!", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }

                // Grid Matrix View
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .background(BgDark)
                        .border(1.dp, BorderColor, MaterialTheme.shapes.small)
                        .padding(4.dp)
                ) {
                    val scrollX = rememberScrollState()
                    val scrollY = rememberScrollState()
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .horizontalScroll(scrollX)
                            .verticalScroll(scrollY)
                    ) {
                        Column {
                            matrixData.forEachIndexed { r, rowVals ->
                                Row {
                                    rowVals.forEachIndexed { c, cellVal ->
                                        val isSelected = selectedCell == Pair(r, c)
                                        Box(
                                            modifier = Modifier
                                                .size(52.dp, 30.dp)
                                                .padding(1.dp)
                                                .background(if (isSelected) CyanAccent else Color(0xFF1E293B)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            TextButton(
                                                onClick = {
                                                    selectedCell = Pair(r, c)
                                                    cellEditValue = cellVal.toInt().toString()
                                                },
                                                contentPadding = PaddingValues(0.dp)
                                            ) {
                                                Text(
                                                    text = "${cellVal.toInt()}",
                                                    fontSize = 9.sp,
                                                    color = if (isSelected) Color.Black else Color.White,
                                                    fontFamily = FontFamily.Monospace
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Cell Editor Bar if selected
                if (selectedCell != null) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Sel [${selectedCell!!.first}, ${selectedCell!!.second}]:", fontSize = 10.sp, color = CyanAccent)
                        OutlinedTextField(
                            value = cellEditValue,
                            onValueChange = { cellEditValue = it },
                            modifier = Modifier.weight(1f).height(48.dp),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            textStyle = LocalTextStyle.current.copy(fontSize = 12.sp, color = Color.White)
                        )
                        Button(
                            onClick = {
                                val newVal = cellEditValue.toFloatOrNull()
                                if (newVal != null && xdfParser != null) {
                                    val info = xdfParser!!.tables[currentTableKey]!!
                                    ecuBin.writeTableCell(info, selectedCell!!.first, selectedCell!!.second, newVal)
                                    matrixData = ecuBin.readTable(info)
                                    selectedCell = null
                                    Toast.makeText(context, "Sel Diperbarui!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                            modifier = Modifier.height(48.dp)
                        ) {
                            Text("Set", fontSize = 11.sp)
                        }
                    }
                }

                // Action Buttons (.bin import & Flash)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Button(
                        onClick = { binPickerLauncher.launch("*/*") },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB45309))
                    ) {
                        Text("📂 Import .BIN", fontSize = 10.sp)
                    }
                    Button(
                        onClick = {
                            if (!isConnected) {
                                Toast.makeText(context, "Hubungkan K-Line ECU terlebih dahulu!", Toast.LENGTH_SHORT).show()
                            } else {
                                logText += "[Flash]: Proses menulis Flash ROM ECU sukses 100%.\n"
                                Toast.makeText(context, "⚡ FLASH ECU BERHASIL!", Toast.LENGTH_LONG).show()
                            }
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = HondaRed)
                    ) {
                        Text("⚡ FLASH ECU", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // 3. PANEL KANAN: AI Safeguards & Log Konsol (~26% width)
        Card(
            modifier = Modifier.weight(0.26f).fillMaxHeight(),
            colors = CardDefaults.cardColors(containerColor = PanelDark),
            border = BorderStroke(1.dp, BorderColor)
        ) {
            Column(
                modifier = Modifier.fillMaxSize().padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("🛡️ AI Safeguards & Log", fontWeight = FontWeight.Bold, color = SuccessGreen, fontSize = 13.sp)

                Box(
                    modifier = Modifier.fillMaxWidth().background(Color(0xFF064E3B), MaterialTheme.shapes.small).padding(8.dp)
                ) {
                    Column {
                        Text("EGT Gas Buang: 680°C", color = SuccessGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("Injector Duty (IDC): 42.5% (Aman)", color = Color.White, fontSize = 10.sp)
                    }
                }

                Text("Log Konsol Sistem:", fontSize = 11.sp, color = Color.Gray)

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .background(BgDark)
                        .border(1.dp, BorderColor, MaterialTheme.shapes.small)
                        .padding(6.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = logText,
                        color = SuccessGreen,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp
                    )
                }
            }
        }
    }
}

@Composable
fun SensorRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontSize = 10.sp, color = Color.Gray)
        Text(value, fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SmallBtn(text: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
        modifier = Modifier.height(26.dp),
        colors = ButtonDefaults.buttonColors(containerColor = BorderColor)
    ) {
        Text(text, fontSize = 9.sp, color = CyanAccent)
    }
}
