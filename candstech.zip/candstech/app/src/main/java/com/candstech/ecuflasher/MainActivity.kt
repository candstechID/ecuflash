package com.candstech.ecuflasher

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.felhr.usbserial.UsbSerialDevice
import com.felhr.usbserial.UsbSerialInterface
import kotlinx.coroutines.*
import org.w3c.dom.Element
import javax.xml.parsers.DocumentBuilderFactory

val BgDark = Color(0xFF0F0F0F)
val CardDark = Color(0xFF1E1E1E)
val BorderDark = Color(0xFF333333)
val HondaRed = Color(0xFFE10600)
val NeonYellow = Color(0xFFD4FF00)

data class XDFTableInfo(
    val title: String,
    val address: Int,
    val rows: Int,
    val cols: Int,
    val equation: String = "X"
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CandsTechEcuFlasherApp()
        }
    }
}

@Composable
fun CandsTechEcuFlasherApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // Non-nullable MutableMap agar bebas dari error null-safety saat kompilasi Kotlin
    val xdfTables = remember { mutableStateMapOf<String, XDFTableInfo>() }
    var selectedTableName by remember { mutableStateOf<String?>(null) }
    var binBytes by remember { mutableStateOf<ByteArray?>(null) }
    var binFileName by remember { mutableStateOf("No .BIN loaded") }
    var xdfFileName by remember { mutableStateOf("No .XDF loaded") }

    // Status K-Line & Sensor Live Data
    var connectionStatus by remember { mutableStateOf("DISCONNECTED") }
    var rpm by remember { mutableIntStateOf(0) }
    var tpsDeg by remember { mutableFloatStateOf(0f) }
    var ectTemp by remember { mutableIntStateOf(0) }
    var iatTemp by remember { mutableIntStateOf(0) }
    var mapKpa by remember { mutableIntStateOf(0) }
    var batVolt by remember { mutableFloatStateOf(0f) }
    var ecuSpeed by remember { mutableIntStateOf(0) }
    var topSpeed by remember { mutableIntStateOf(0) }

    val logs = remember { mutableStateListOf("[SYS] CANDS TECH ECU Flasher v1.0 Ready.") }
    var serialPort by remember { mutableStateOf<UsbSerialDevice?>(null) }
    var usbConnection by remember { mutableStateOf<UsbDeviceConnection?>(null) }
    var activeTab by remember { mutableIntStateOf(0) } // 0 = K-Line Diag, 1 = XDF Bin Table

    fun appendLog(msg: String) {
        if (logs.size > 60) logs.removeAt(0)
        logs.add(msg)
    }

    // Launcher Import File .BIN
    val binPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let {
            try {
                val bytes = context.contentResolver.openInputStream(it)?.use { stream -> stream.readBytes() }
                if (bytes != null) {
                    binBytes = bytes
                    binFileName = it.lastPathSegment?.substringAfterLast('/') ?: "firmware.bin"
                    appendLog("[BIN] Loaded $binFileName (${bytes.size} bytes)")
                }
            } catch (e: Exception) {
                appendLog("[ERR] Failed to read .BIN: ${e.message}")
            }
        }
    }

    // Launcher Import File .XDF
    val xdfPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let {
            try {
                context.contentResolver.openInputStream(it)?.use { stream ->
                    val doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(stream)
                    val tableNodes = doc.getElementsByTagName("XDFTABLE")
                    xdfTables.clear()

                    for (i in 0 until tableNodes.length) {
                        val el = tableNodes.item(i) as? Element ?: continue
                        val title = el.getElementsByTagName("title").item(0)?.textContent?.trim()
                            ?: "Table_${i + 1}"
                        val embedded = el.getElementsByTagName("EMBEDDEDDATA").item(0) as? Element
                        val addrHex = embedded?.getAttribute("mmedaddress")?.removePrefix("0x") ?: "0"
                        val addr = addrHex.toIntOrNull(16) ?: 0
                        val rows = embedded?.getAttribute("mmedrowcount")?.toIntOrNull() ?: 1
                        val cols = embedded?.getAttribute("mmedcolcount")?.toIntOrNull() ?: 1
                        xdfTables[title] = XDFTableInfo(title, addr, rows, cols)
                    }

                    // Fallback tabel standar Honda PGM-FI jika XDF kosong
                    if (xdfTables.isEmpty()) {
                        xdfTables["Fuel Base Map (Main)"] = XDFTableInfo("Fuel Base Map (Main)", 0x4000, 12, 16)
                        xdfTables["Ignition Timing Map"] = XDFTableInfo("Ignition Timing Map", 0x4200, 12, 16)
                        xdfTables["RPM Rev Limiter"] = XDFTableInfo("RPM Rev Limiter", 0x5100, 1, 4)
                    }

                    selectedTableName = xdfTables.keys.firstOrNull()
                    xdfFileName = it.lastPathSegment?.substringAfterLast('/') ?: "definition.xdf"
                    appendLog("[XDF] Loaded $xdfFileName (${xdfTables.size} tables)")
                }
            } catch (e: Exception) {
                appendLog("[ERR] Failed to parse .XDF: ${e.message}")
            }
        }
    }

    fun connectUsbKLine() {
        val usbManager = context.getSystemService(Context.USB_SERVICE) as UsbManager
        val devices = usbManager.deviceList
        if (devices.isEmpty()) {
            appendLog("[USB] No FTDI / CH340 K-Line adapter detected.")
            connectionStatus = "NO_DEVICE"
            return
        }
        val device: UsbDevice = devices.values.first()
        if (!usbManager.hasPermission(device)) {
            val action = "com.candstech.ecuflasher.USB_PERMISSION"
            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
            val pi = PendingIntent.getBroadcast(context, 0, Intent(action), flags)
            val receiver = object : BroadcastReceiver() {
                override fun onReceive(ctx: Context, intent: Intent) {
                    if (intent.action == action) {
                        context.unregisterReceiver(this)
                        if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                            connectUsbKLine()
                        } else {
                            connectionStatus = "DENIED"
                            appendLog("[USB] Permission denied.")
                        }
                    }
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.registerReceiver(receiver, IntentFilter(action), Context.RECEIVER_NOT_EXPORTED)
            } else {
                context.registerReceiver(receiver, IntentFilter(action))
            }
            usbManager.requestPermission(device, pi)
            connectionStatus = "REQUESTING"
            return
        }

        val conn = usbManager.openDevice(device)
        if (conn == null) {
            appendLog("[USB] Unable to open USB connection.")
            connectionStatus = "ERROR"
            return
        }
        val port = UsbSerialDevice.createUsbSerialDevice(device, conn)
        if (port != null && port.open()) {
            port.setBaudRate(10400)
            port.setDataBits(UsbSerialInterface.DATA_BITS_8)
            port.setStopBits(UsbSerialInterface.STOP_BITS_1)
            port.setParity(UsbSerialInterface.PARITY_NONE)
            port.setFlowControl(UsbSerialInterface.FLOW_CONTROL_OFF)
            port.read { data ->
                if (data != null && data.size >= 16) {
                    val parsedRpm = ((data[4].toInt() and 0xFF) shl 8) or (data[5].toInt() and 0xFF)
                    if (parsedRpm in 0..16000) {
                        rpm = parsedRpm
                        val tpsRaw = data[7].toInt() and 0xFF
                        tpsDeg = (tpsRaw / 255f) * 80f
                        ectTemp = (data[9].toInt() and 0xFF) - 40
                        iatTemp = (data[11].toInt() and 0xFF) - 40
                        mapKpa = data[12].toInt() and 0xFF
                        batVolt = (data[13].toInt() and 0xFF) / 10f
                        ecuSpeed = data[14].toInt() and 0xFF
                        if (ecuSpeed > topSpeed) topSpeed = ecuSpeed
                    }
                }
            }
            usbConnection = conn
            serialPort = port
            connectionStatus = "CONNECTED"
            appendLog("[K-LINE] Connected @ 10400 baud 8N1.")

            scope.launch(Dispatchers.IO) {
                port.setBreak(true)
                delay(70)
                port.setBreak(false)
                delay(120)
                port.write(byteArrayOf(0xFE.toByte(), 0x04, 0x72, 0x8C.toByte()))
                delay(100)
                port.write(byteArrayOf(0x72, 0x05, 0x00, 0xF0.toByte(), 0x99.toByte()))
                withContext(Dispatchers.Main) {
                    appendLog("[ECU] Honda PGM-FI Wakeup Sent.")
                }
                while (isActive && connectionStatus == "CONNECTED") {
                    port.write(byteArrayOf(0x72, 0x05, 0x71, 0x17, 0x01))
                    delay(150)
                }
            }
        } else {
            appendLog("[USB] Serial port open failed.")
            connectionStatus = "DRIVER_ERR"
        }
    }

    fun disconnectUsb() {
        serialPort?.close()
        usbConnection?.close()
        serialPort = null
        usbConnection = null
        connectionStatus = "DISCONNECTED"
        appendLog("[USB] Disconnected.")
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDark)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Top Header & Navigation
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(CardDark, RoundedCornerShape(8.dp))
                .border(1.dp, BorderDark, RoundedCornerShape(8.dp))
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("CANDS TECH", color = NeonYellow, fontWeight = FontWeight.Black, fontSize = 16.sp)
                Text("ECU FLASHER", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(Modifier.width(8.dp))
                TabChip("K-LINE DIAG", activeTab == 0) { activeTab = 0 }
                TabChip("XDF / BIN MAP", activeTab == 1) { activeTab = 1 }
            }

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = connectionStatus,
                    color = if (connectionStatus == "CONNECTED") NeonYellow else HondaRed,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                Button(
                    onClick = { if (connectionStatus == "CONNECTED") disconnectUsb() else connectUsbKLine() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (connectionStatus == "CONNECTED") Color.DarkGray else HondaRed
                    ),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                    modifier = Modifier.height(32.dp)
                ) {
                    Text(
                        text = if (connectionStatus == "CONNECTED") "DISCONNECT" else "CONNECT",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        if (activeTab == 0) {
            // TAB 0: K-LINE DIAGNOSTIC & LIVE SENSORS
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CardDark, RoundedCornerShape(8.dp))
                    .padding(8.dp)
            ) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("ENGINE RPM", color = Color.Gray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text("$rpm RPM", color = if (rpm > 9500) HondaRed else NeonYellow, fontSize = 16.sp, fontWeight = FontWeight.Black)
                }
                Spacer(Modifier.height(4.dp))
                LinearProgressIndicator(
                    progress = (rpm / 12000f).coerceIn(0f, 1f),
                    modifier = Modifier.fillMaxWidth().height(10.dp),
                    color = if (rpm > 9500) HondaRed else NeonYellow,
                    trackColor = Color(0xFF2B2B2B)
                )
            }

            Row(modifier = Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Column(modifier = Modifier.weight(1.4f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MetricCard("ECU SPEED", "$ecuSpeed km/h", "TOP: $topSpeed km/h", Modifier.weight(1f))
                        MetricCard("TPS ANGLE", String.format("%.1f°", tpsDeg), "0° - 80°", Modifier.weight(1f))
                        MetricCard("BATTERY", String.format("%.1f V", batVolt), "SYSTEM", Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MetricCard("ECT TEMP", "$ectTemp °C", "ENGINE", Modifier.weight(1f))
                        MetricCard("IAT TEMP", "$iatTemp °C", "INTAKE", Modifier.weight(1f))
                        MetricCard("MAP SENSOR", "$mapKpa kPa", "MANIFOLD", Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ActionBtn("SCAN DTC", Color(0xFF2B2B2B), Modifier.weight(1f)) {
                            serialPort?.write(byteArrayOf(0x72, 0x05, 0x73, 0x01, 0x15))
                            appendLog("[DIAG] Scan DTC sent.")
                        }
                        ActionBtn("CLEAR DTC", HondaRed, Modifier.weight(1f)) {
                            serialPort?.write(byteArrayOf(0x72, 0x05, 0x60, 0x01, 0x28))
                            appendLog("[DIAG] Clear DTC sent.")
                        }
                        ActionBtn("RESET TP", Color(0xFF2B2B2B), Modifier.weight(1f)) {
                            serialPort?.write(byteArrayOf(0x72, 0x05, 0x60, 0x03, 0x26))
                            appendLog("[DIAG] Reset TP / ECM sent.")
                        }
                        ActionBtn("RESET TOP", Color(0xFF2B2B2B), Modifier.weight(1f)) {
                            topSpeed = 0
                        }
                    }
                }

                // Terminal Log
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .background(CardDark, RoundedCornerShape(8.dp))
                        .border(1.dp, BorderDark, RoundedCornerShape(8.dp))
                        .padding(8.dp)
                ) {
                    Text("TERMINAL LOG", color = NeonYellow, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    LazyColumn(modifier = Modifier.fillMaxSize()) {
                        items(logs) { item ->
                            Text(item, color = Color.LightGray, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        } else {
            // TAB 1: XDF & BIN MAP VIEWER
            Row(modifier = Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                // Left Sidebar: Import & Table List
                Column(
                    modifier = Modifier
                        .weight(0.9f)
                        .fillMaxHeight()
                        .background(CardDark, RoundedCornerShape(8.dp))
                        .border(1.dp, BorderDark, RoundedCornerShape(8.dp))
                        .padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ActionBtn("LOAD .BIN", Color(0xFF2E2E2E), Modifier.weight(1f)) {
                            binPicker.launch(arrayOf("*/*"))
                        }
                        ActionBtn("LOAD .XDF", HondaRed, Modifier.weight(1f)) {
                            xdfPicker.launch(arrayOf("*/*"))
                        }
                    }
                    Text("BIN: $binFileName", color = Color.Gray, fontSize = 10.sp, maxLines = 1)
                    Text("XDF: $xdfFileName", color = NeonYellow, fontSize = 10.sp, maxLines = 1)
                    HorizontalDivider(color = BorderDark)

                    val tableKeys = xdfTables.keys.toList()
                    LazyColumn(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        items(tableKeys) { key ->
                            val isSelected = key == selectedTableName
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(if (isSelected) HondaRed else Color(0xFF262626), RoundedCornerShape(4.dp))
                                    .clickable { selectedTableName = key }
                                    .padding(6.dp)
                            ) {
                                Text(key, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // Right Area: Hex / Table Grid Preview
                Column(
                    modifier = Modifier
                        .weight(1.6f)
                        .fillMaxHeight()
                        .background(CardDark, RoundedCornerShape(8.dp))
                        .border(1.dp, BorderDark, RoundedCornerShape(8.dp))
                        .padding(8.dp)
                ) {
                    val activeTable = selectedTableName?.let { xdfTables[it] }
                    if (activeTable != null) {
                        Text(
                            text = "${activeTable.title} @ 0x${activeTable.address.toString(16).uppercase()} (${activeTable.rows}x${activeTable.cols})",
                            color = NeonYellow,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.height(6.dp))
                        val bytes = binBytes
                        if (bytes == null) {
                            Text("Load a .BIN ECU file to view map values.", color = Color.Gray, fontSize = 12.sp)
                        } else {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .horizontalScroll(rememberScrollState()),
                                verticalArrangement = Arrangement.spacedBy(2.dp)
                            ) {
                                for (r in 0 until activeTable.rows.coerceAtMost(16)) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        for (c in 0 until activeTable.cols.coerceAtMost(16)) {
                                            val offset = activeTable.address + (r * activeTable.cols) + c
                                            val cellVal = if (offset in bytes.indices) (bytes[offset].toInt() and 0xFF) else 0
                                            Box(
                                                modifier = Modifier
                                                    .width(36.dp)
                                                    .background(Color(0xFF141414))
                                                    .border(0.5.dp, BorderDark)
                                                    .padding(3.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(
                                                    text = cellVal.toString(),
                                                    color = Color.White,
                                                    fontSize = 10.sp,
                                                    fontFamily = FontFamily.Monospace
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        Text("Load an .XDF definition file to inspect ECU tables.", color = Color.Gray, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun TabChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(if (selected) NeonYellow else Color(0xFF2A2A2A), RoundedCornerShape(4.dp))
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(
            text = label,
            color = if (selected) Color.Black else Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun MetricCard(title: String, value: String, sub: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(CardDark, RoundedCornerShape(8.dp))
            .border(1.dp, BorderDark, RoundedCornerShape(8.dp))
            .padding(8.dp)
    ) {
        Text(title, color = Color.Gray, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Text(value, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black)
        Text(sub, color = NeonYellow, fontSize = 9.sp)
    }
}

@Composable
fun ActionBtn(label: String, bg: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier.height(38.dp),
        shape = RoundedCornerShape(6.dp),
        colors = ButtonDefaults.buttonColors(containerColor = bg),
        contentPadding = PaddingValues(4.dp)
    ) {
        Text(label, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}
