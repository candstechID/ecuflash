package com.candstech.ecuflasher

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.felhr.usbserial.UsbSerialDevice
import com.felhr.usbserial.UsbSerialInterface
import java.util.Locale
import kotlinx.coroutines.*

val BgDark = Color(0xFF0F0F0F)
val CardDark = Color(0xFF1E1E1E)
val BorderDark = Color(0xFF333333)
val HondaRed = Color(0xFFE10600)
val NeonYellow = Color(0xFFD4FF00)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CandsTechEcuFlasherSuite()
        }
    }
}

@Composable
fun CandsTechEcuFlasherSuite() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val xdfTables = remember { mutableStateMapOf<String, XDFTableInfo>() }
    var selectedTableKey by remember { mutableStateOf<String?>(null) }
    var binBytes by remember { mutableStateOf<ByteArray?>(null) }
    var binName by remember { mutableStateOf("No .BIN loaded") }
    var xdfName by remember { mutableStateOf("Default Keihin Map") }
    var checksumHex by remember { mutableStateOf("0x0000") }
    var tableRefreshTick by remember { mutableIntStateOf(0) }

    var connStatus by remember { mutableStateOf("DISCONNECTED") }
    var rpm by remember { mutableIntStateOf(0) }
    var tpsDeg by remember { mutableFloatStateOf(0f) }
    var ectTemp by remember { mutableIntStateOf(0) }
    var iatTemp by remember { mutableIntStateOf(0) }
    var mapKpa by remember { mutableIntStateOf(0) }
    var batVolt by remember { mutableFloatStateOf(0f) }
    var ecuSpeed by remember { mutableIntStateOf(0) }
    var topSpeed by remember { mutableIntStateOf(0) }

    val logs = remember { mutableStateListOf("[SYS] CANDS TECH ECU Flasher & Remap Pro Ready.") }
    var serialPort by remember { mutableStateOf<UsbSerialDevice?>(null) }
    var usbConnection by remember { mutableStateOf<UsbDeviceConnection?>(null) }
    var activeTab by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        if (xdfTables.isEmpty()) {
            BinParser.loadDefaultHondaKeihinTables(xdfTables)
            selectedTableKey = xdfTables.keys.firstOrNull()
        }
    }

    fun log(msg: String) {
        if (logs.size > 60) logs.removeAt(0)
        logs.add(msg)
    }

    val binPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let {
            try {
                val data = context.contentResolver.openInputStream(it)?.use { s -> s.readBytes() }
                if (data != null) {
                    binBytes = data
                    binName = it.lastPathSegment?.substringAfterLast('/') ?: "ecu_dump.bin"
                    val csum = BinParser.calculateChecksum16(data)
                    checksumHex = "0x${csum.toString(16).uppercase(Locale.US).padStart(4, '0')}"
                    tableRefreshTick++
                    log("[BIN] Loaded $binName (${data.size} B) | CSUM: $checksumHex")
                }
            } catch (e: Exception) {
                log("[ERR] Gagal baca .BIN: ${e.message}")
            }
        }
    }

    val binExporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri: Uri? ->
        val data = binBytes
        if (uri != null && data != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { out -> out.write(data) }
                log("[BIN] Exported modified .BIN (${data.size} bytes) | CSUM: $checksumHex")
            } catch (e: Exception) {
                log("[ERR] Gagal simpan .BIN: ${e.message}")
            }
        }
    }

    val xdfPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let {
            try {
                context.contentResolver.openInputStream(it)?.use { stream ->
                    val parsed = BinParser.parseXdfStream(stream)
                    xdfTables.clear()
                    xdfTables.putAll(parsed)
                    selectedTableKey = xdfTables.keys.firstOrNull()
                    xdfName = it.lastPathSegment?.substringAfterLast('/') ?: "custom.xdf"
                    tableRefreshTick++
                    log("[XDF] Loaded $xdfName (${xdfTables.size} tables)")
                }
            } catch (e: Exception) {
                log("[ERR] Gagal baca .XDF: ${e.message}")
            }
        }
    }

    fun connectKLine() {
        val usbManager = context.getSystemService(Context.USB_SERVICE) as UsbManager
        val devices = usbManager.deviceList
        if (devices.isEmpty()) {
            log("[USB] Adapter FTDI / CH340 K-Line tidak terdeteksi.")
            connStatus = "NO_DEVICE"
            return
        }
        val device: UsbDevice = devices.values.first()
        if (!usbManager.hasPermission(device)) {
            val action = "com.candstech.ecuflasher.USB_PERMISSION"
            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
            val pi = PendingIntent.getBroadcast(context, 0, Intent(action), flags)
            val receiver = object : BroadcastReceiver() {
                override fun onReceive(ctx: Context, intent: Intent) {
                    if (intent.action == action) {
                        try {
                            context.unregisterReceiver(this)
                        } catch (_: Exception) {
                        }
                        if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                            connectKLine()
                        } else {
                            connStatus = "DENIED"
                            log("[USB] Izin USB ditolak.")
                        }
                    }
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.registerReceiver(receiver, IntentFilter(action), Context.RECEIVER_NOT_EXPORTED)
            } else {
                context.registerReceiver(receiver, IntentFilter(action))
            }
            usbManager.requestPermission(device, pi)
            connStatus = "REQUESTING"
            return
        }

        val conn = usbManager.openDevice(device) ?: return
        val port = UsbSerialDevice.createUsbSerialDevice(device, conn)
        if (port != null && port.open()) {
            port.setBaudRate(10400)
            port.setDataBits(UsbSerialInterface.DATA_BITS_8)
            port.setStopBits(UsbSerialInterface.STOP_BITS_1)
            port.setParity(UsbSerialInterface.PARITY_NONE)
            port.setFlowControl(UsbSerialInterface.FLOW_CONTROL_OFF)
            port.read { data ->
                if (data != null && data.size >= 16) {
                    val parsedRpm = ((data[4].toInt() and 0xFF) shl 8) or (data[5].toInt() and 0xFF)
                    if (parsedRpm in 0..16000) {
                        rpm = parsedRpm
                        tpsDeg = ((data[7].toInt() and 0xFF) / 255f) * 80f
                        ectTemp = (data[9].toInt() and 0xFF) - 40
                        iatTemp = (data[11].toInt() and 0xFF) - 40
                        mapKpa = data[12].toInt() and 0xFF
                        batVolt = (data[13].toInt() and 0xFF) / 10f
                        ecuSpeed = data[14].toInt() and 0xFF
                        if (ecuSpeed > topSpeed) topSpeed = ecuSpeed
                    }
                }
            }
            usbConnection = conn
            serialPort = port
            connStatus = "CONNECTED"
            log("[K-LINE] Online @ 10400 baud 8N1.")

            scope.launch(Dispatchers.IO) {
                port.setBreak(true)
                delay(70)
                port.setBreak(false)
                delay(120)
                port.write(byteArrayOf(0xFE.toByte(), 0x04, 0x72, 0x8C.toByte()))
                delay(100)
                port.write(byteArrayOf(0x72, 0x05, 0x00, 0xF0.toByte(), 0x99.toByte()))
                while (isActive && connStatus == "CONNECTED") {
                    port.write(byteArrayOf(0x72, 0x05, 0x71, 0x17, 0x01))
                    delay(150)
                }
            }
        }
    }

    fun disconnectKLine() {
        serialPort?.close()
        usbConnection?.close()
        serialPort = null
        usbConnection = null
        connStatus = "DISCONNECTED"
        log("[USB] Disconnected.")
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDark)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(CardDark, RoundedCornerShape(8.dp))
                .border(1.dp, BorderDark, RoundedCornerShape(8.dp))
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("CANDS TECH", color = NeonYellow, fontWeight = FontWeight.Black, fontSize = 15.sp)
                TabChip("1. XDF / BIN EDITOR", activeTab == 0) { activeTab = 0 }
                TabChip("2. AI PRESET & SAFEGUARD", activeTab == 1) { activeTab = 1 }
                TabChip("3. K-LINE DIAG", activeTab == 2) { activeTab = 2 }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("CSUM: $checksumHex", color = NeonYellow, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                Button(
                    onClick = { if (connStatus == "CONNECTED") disconnectKLine() else connectKLine() },
                    colors = ButtonDefaults.buttonColors(containerColor = if (connStatus == "CONNECTED") Color.DarkGray else HondaRed),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                    modifier = Modifier.height(30.dp)
                ) {
                    Text(if (connStatus == "CONNECTED") "USB ON" else "CONNECT USB", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Row(modifier = Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(modifier = Modifier.weight(1.7f).fillMaxHeight()) {
                when (activeTab) {
                    0 -> {
                        Row(modifier = Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Column(
                                modifier = Modifier
                                    .weight(0.85f)
                                    .fillMaxHeight()
                                    .background(CardDark, RoundedCornerShape(8.dp))
                                    .border(1.dp, BorderDark, RoundedCornerShape(8.dp))
                                    .padding(8.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    ActionBtn("OPEN .BIN", Color(0xFF2B2B2B), Modifier.weight(1f)) { binPicker.launch(arrayOf("*/*")) }
                                    ActionBtn("OPEN .XDF", HondaRed, Modifier.weight(1f)) { xdfPicker.launch(arrayOf("*/*")) }
                                }
                                ActionBtn("SAVE MOD .BIN", Color(0xFF2E4A1E), Modifier.fillMaxWidth()) {
                                    if (binBytes != null) binExporter.launch("CANDSTECH_TUNED_$binName")
                                    else log("[WARN] Buka file .BIN terlebih dahulu!")
                                }
                                Text("BIN: $binName", color = Color.Gray, fontSize = 9.sp, maxLines = 1)
                                Text("XDF: $xdfName", color = NeonYellow, fontSize = 9.sp, maxLines = 1)
                                Divider(color = BorderDark)

                                LazyColumn(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    items(xdfTables.keys.toList()) { key ->
                                        val isSel = key == selectedTableKey
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(if (isSel) HondaRed else Color(0xFF262626), RoundedCornerShape(4.dp))
                                                .clickable { selectedTableKey = key }
                                                .padding(6.dp)
                                        ) {
                                            Text(key, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }

                            Column(
                                modifier = Modifier
                                    .weight(1.4f)
                                    .fillMaxHeight()
                                    .background(CardDark, RoundedCornerShape(8.dp))
                                    .border(1.dp, BorderDark, RoundedCornerShape(8.dp))
                                    .padding(8.dp)
                            ) {
                                val table = selectedTableKey?.let { xdfTables[it] }
                                val bytes = binBytes
                                val tick = tableRefreshTick

                                if (table != null && tick >= 0) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "${table.title} (0x${table.address.toString(16).uppercase(Locale.US)})",
                                            color = NeonYellow,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        if (bytes != null) {
                                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                                SmallStepBtn("+2%") {
                                                    for (r in 0 until table.rows) {
                                                        for (c in 0 until table.cols) {
                                                            val cur = BinParser.readCell(bytes, table, r, c)
                                                            BinParser.writeCell(bytes, table, r, c, (cur * 1.02f).toInt())
                                                        }
                                                    }
                                                    checksumHex = "0x${BinParser.calculateChecksum16(bytes).toString(16).uppercase(Locale.US).padStart(4, '0')}"
                                                    tableRefreshTick++
                                                    log("[MAP] ${table.title} +2%")
                                                }
                                                SmallStepBtn("-2%") {
                                                    for (r in 0 until table.rows) {
                                                        for (c in 0 until table.cols) {
                                                            val cur = BinParser.readCell(bytes, table, r, c)
                                                            BinParser.writeCell(bytes, table, r, c, (cur * 0.98f).toInt())
                                                        }
                                                    }
                                                    checksumHex = "0x${BinParser.calculateChecksum16(bytes).toString(16).uppercase(Locale.US).padStart(4, '0')}"
                                                    tableRefreshTick++
                                                    log("[MAP] ${table.title} -2%")
                                                }
                                            }
                                        }
                                    }
                                    Spacer(Modifier.height(6.dp))
                                    if (bytes == null) {
                                        Text("Silakan klik OPEN .BIN untuk menampilkan & mengedit tabel ECU.", color = Color.Gray, fontSize = 11.sp)
                                    } else {
                                        Column(
                                            modifier = Modifier.fillMaxSize().horizontalScroll(rememberScrollState()),
                                            verticalArrangement = Arrangement.spacedBy(2.dp)
                                        ) {
                                            for (r in 0 until table.rows.coerceAtMost(16)) {
                                                Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                                    for (c in 0 until table.cols.coerceAtMost(16)) {
                                                        val valCell = BinParser.readCell(bytes, table, r, c)
                                                        Box(
                                                            modifier = Modifier
                                                                .width(34.dp)
                                                                .background(Color(0xFF141414))
                                                                .border(0.5.dp, BorderDark)
                                                                .padding(2.dp),
                                                            contentAlignment = Alignment.Center
                                                        ) {
                                                            Text(valCell.toString(), color = Color.White, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    1 -> {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(CardDark, RoundedCornerShape(8.dp))
                                .border(1.dp, BorderDark, RoundedCornerShape(8.dp))
                                .padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text("AI AUTO-TUNING PRESETS & ENGINE SAFEGUARDS", color = NeonYellow, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            LazyColumn(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                items(AiPresetEngine.presets) { preset ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(Color(0xFF262626), RoundedCornerShape(6.dp))
                                            .padding(8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(preset.name, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            Text(preset.description, color = Color.LightGray, fontSize = 10.sp)
                                            Text("Target AFR: ${preset.targetAfr} | Limit: ${preset.rpmLimitTarget} RPM", color = NeonYellow, fontSize = 9.sp)
                                        }
                                        Button(
                                            onClick = {
                                                val bytes = binBytes
                                                if (bytes == null) {
                                                    log("[WARN] Buka file .BIN terlebih dahulu sebelum apply preset!")
                                                } else {
                                                    val (count, check) = AiPresetEngine.applyPresetToBin(bytes, xdfTables, preset)
                                                    checksumHex = "0x${BinParser.calculateChecksum16(bytes).toString(16).uppercase(Locale.US).padStart(4, '0')}"
                                                    tableRefreshTick++
                                                    log("[AI-PRESET] ${preset.name} applied ($count cells updated).")
                                                    if (!check.isSafe) {
                                                        check.warnings.forEach { w -> log("[SAFEGUARD] $w") }
                                                    } else {
                                                        log("[SAFEGUARD] Parameter aman dalam batas toleransi mesin.")
                                                    }
                                                }
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = HondaRed),
                                            modifier = Modifier.height(34.dp)
                                        ) {
                                            Text("APPLY", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    2 -> {
                        Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Column(modifier = Modifier.fillMaxWidth().background(CardDark, RoundedCornerShape(8.dp)).padding(8.dp)) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("ENGINE RPM", color = Color.Gray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    Text("$rpm RPM", color = if (rpm > 9500) HondaRed else NeonYellow, fontSize = 15.sp, fontWeight = FontWeight.Black)
                                }
                                LinearProgressIndicator(
                                    progress = (rpm / 12000f).coerceIn(0f, 1f),
                                    modifier = Modifier.fillMaxWidth().height(10.dp),
                                    color = if (rpm > 9500) HondaRed else NeonYellow,
                                    trackColor = Color(0xFF2B2B2B)
                                )
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                MetricCard("SPEED", "$ecuSpeed km/h", "TOP: $topSpeed", Modifier.weight(1f))
                                MetricCard("TPS", String.format(Locale.US, "%.1f°", tpsDeg), "THROTTLE", Modifier.weight(1f))
                                MetricCard("BATTERY", String.format(Locale.US, "%.1f V", batVolt), "VOLTAGE", Modifier.weight(1f))
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                MetricCard("ECT", "$ectTemp °C", "COOLANT", Modifier.weight(1f))
                                MetricCard("IAT", "$iatTemp °C", "INTAKE", Modifier.weight(1f))
                                MetricCard("MAP", "$mapKpa kPa", "PRESSURE", Modifier.weight(1f))
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                ActionBtn("SCAN DTC", Color(0xFF2B2B2B), Modifier.weight(1f)) {
                                    serialPort?.write(byteArrayOf(0x72, 0x05, 0x73, 0x01, 0x15))
                                    log("[DIAG] Scan DTC sent.")
                                }
                                ActionBtn("CLEAR DTC", HondaRed, Modifier.weight(1f)) {
                                    serialPort?.write(byteArrayOf(0x72, 0x05, 0x60, 0x01, 0x28))
                                    log("[DIAG] Clear DTC sent.")
                                }
                                ActionBtn("RESET TP", Color(0xFF2B2B2B), Modifier.weight(1f)) {
                                    serialPort?.write(byteArrayOf(0x72, 0x05, 0x60, 0x03, 0x26))
                                    log("[DIAG] Reset TP sent.")
                                }
                            }
                        }
                    }
                }
            }

            Column(
                modifier = Modifier
                    .weight(0.8f)
                    .fillMaxHeight()
                    .background(CardDark, RoundedCornerShape(8.dp))
                    .border(1.dp, BorderDark, RoundedCornerShape(8.dp))
                    .padding(8.dp)
            ) {
                Text("SYSTEM & SAFEGUARD LOG", color = NeonYellow, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(logs) { line ->
                        Text(line, color = Color.LightGray, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }
    }
}

@Composable
fun TabChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(if (selected) NeonYellow else Color(0xFF2A2A2A), RoundedCornerShape(4.dp))
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(label, color = if (selected) Color.Black else Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun MetricCard(title: String, value: String, sub: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(CardDark, RoundedCornerShape(8.dp))
            .border(1.dp, BorderDark, RoundedCornerShape(8.dp))
            .padding(8.dp)
    ) {
        Text(title, color = Color.Gray, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Text(value, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Black)
        Text(sub, color = NeonYellow, fontSize = 9.sp)
    }
}

@Composable
fun ActionBtn(label: String, bg: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier.height(34.dp),
        shape = RoundedCornerShape(6.dp),
        colors = ButtonDefaults.buttonColors(containerColor = bg),
        contentPadding = PaddingValues(4.dp)
    ) {
        Text(label, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SmallStepBtn(label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(HondaRed, RoundedCornerShape(4.dp))
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(label, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}
