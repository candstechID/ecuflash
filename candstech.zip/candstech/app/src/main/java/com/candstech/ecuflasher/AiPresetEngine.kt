package com.candstech.ecuflasher

import kotlin.math.max
import kotlin.math.pow
import kotlin.math.round

data class EngineSpecs(
    val exhaust: String = "Standard",
    val airFilter: String = "Standard",
    val camshaft: String = "Standard",
    val fuelOctane: Int = 92,
    val boreCc: Int = 160
)

class AISmartTuner(private val specs: EngineSpecs) {
    fun calculateFuelMultipliers(rows: Int = 16, cols: Int = 16): List<List<Float>> {
        val baseEnrichment = 1.0f
        val exhaustFactor = when (specs.exhaust) {
            "Full System Racing" -> 0.08f
            "Slip-On" -> 0.04f
            else -> 0.0f
        }
        val filterFactor = when (specs.airFilter) {
            "Open Velocity Stack" -> 0.06f
            "High-Flow" -> 0.03f
            else -> 0.0f
        }
        val camFactor = when (specs.camshaft) {
            "Stage 2 Racing" -> 0.10f
            "Stage 1 Street" -> 0.05f
            else -> 0.0f
        }

        val matrix = mutableListOf<MutableList<Float>>()
        for (r in 0 until rows) {
            val rowMultipliers = mutableListOf<Float>()
            val tpsRatio = r / max(1, rows - 1).toFloat()
            for (c in 0 until cols) {
                val rpmRatio = c / max(1, cols - 1).toFloat()
                val gain = (exhaustFactor * (rpmRatio.toDouble().pow(1.3).toFloat()) * (tpsRatio.toDouble().pow(0.8).toFloat())) +
                        (filterFactor * rpmRatio * tpsRatio) +
                        (camFactor * (rpmRatio.toDouble().pow(1.5).toFloat()))
                val mult = round((baseEnrichment + gain) * 10000) / 10000f
                rowMultipliers.add(mult)
            }
            matrix.add(rowMultipliers)
        }
        return matrix
    }
}
