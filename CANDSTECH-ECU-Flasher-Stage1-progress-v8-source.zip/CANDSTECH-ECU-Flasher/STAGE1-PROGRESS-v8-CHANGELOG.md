# CANDSTECH ECU Flasher — Stage 1 Progress v8

## Perbaikan dari v7 berdasarkan hasil compile dan audit statis

- Memulihkan deklarasi `EcuLiveDataCapability` yang hilang. Properti primary/extension tetap bertipe `List<LiveTableProfile>` sehingga pemanggilan pada `HondaProtocolEngine` memiliki tipe yang konsisten.
- Menghapus fallback identitas ECU berbasis awalan ID yang dapat menebak K59A/K60/model lain. Jika identitas tidak cocok secara unik, hasilnya UNKNOWN dan tidak diberi ukuran ROM/offset/checksum tebakan.
- Mengubah pencocokan ID legacy menjadi unik; kandidat ambigu tidak dipilih dengan `firstOrNull()`.
- Menghapus pemakaian fallback PID 0x21 karena pemetaan local identifier Honda belum terbukti dan format respons sebelumnya tidak divalidasi dengan benar.
- DTC kini memakai parser frame lengkap yang memeriksa panjang, checksum, dan struktur respons. Respons yang tidak dikenali tidak diubah menjadi daftar DTC kosong.
- Identifikasi ECU baru mengosongkan bukti keluarga ECU sebelumnya. Exact ID database tidak otomatis dianggap sebagai bukti wire-family; keluarga hanya ditetapkan oleh resolver dari header respons.
- Wake pulse kini memeriksa konfigurasi baud, purge, penerimaan BREAK, dan pelepasan BREAK. Kegagalan setup tidak lagi dilaporkan sebagai jalur siap.
- Invalidasi Live Data juga menonaktifkan flag AFR EST dan STF agar nilai lama tidak dianggap masih tersedia.
- Menyesuaikan dan menambah unit test untuk perilaku reset keluarga ECU.

## Batas verifikasi

- Source ZIP v7 dan screenshot compile menjadi dasar perubahan.
- Tidak ada build Gradle/Android yang dijalankan pada lingkungan ini karena Gradle wrapper JAR dan instalasi Gradle tidak tersedia.
- Tidak ada uji adapter FTDI/ECU fisik.
- Registry Live Data tetap hanya untuk exact ECU ID `0101C40F01` dan status tabel tetap `RECONSTRUCTED`, bukan hardware-verified.
- READ/WRITE ROM masih perlu integrasi transport tersendiri; v8 tidak menyatakan flashing sudah berfungsi.
