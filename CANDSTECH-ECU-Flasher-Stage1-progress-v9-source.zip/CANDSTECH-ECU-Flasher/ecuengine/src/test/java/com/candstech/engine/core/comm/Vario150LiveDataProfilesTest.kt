package com.candstech.engine.core.comm

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class Vario150LiveDataProfilesTest {
    @Test fun registersFourPrimaryAndThreeExtensionTables() {
        assertEquals(listOf("17", "13", "11", "10"), HondaLiveDataProfiles.primaryTables.map { it.tableId })
        assertEquals(listOf("16", "20", "D1"), HondaLiveDataProfiles.extendedTables.map { it.tableId })
        assertEquals(7, HondaLiveDataProfiles.all.size)
    }

    @Test fun requestFramesMatchTheSuppliedCatalog() {
        val expected = mapOf(
            "17" to "72 05 71 17 01", "13" to "72 05 71 13 05",
            "11" to "72 05 71 11 07", "10" to "72 05 71 10 08",
            "16" to "72 05 71 16 02", "20" to "72 05 71 20 F8",
            "D1" to "72 05 71 D1 47"
        )
        for (table in HondaLiveDataProfiles.all) {
            val actual = table.request.joinToString(" ") { "%02X".format(it.toInt() and 0xFF) }
            assertEquals(expected[table.tableId], actual)
            assertEquals(ProfileVerification.RECONSTRUCTED, table.verification)
            assertNotNull(table.provenance)
        }
        assertTrue(HondaLiveDataProfiles.table20.notes.contains("AFR"))
    }
    @Test fun tpsPercentComesFromAngleByteNotAdcVoltageByte() {
        val profile = HondaLiveDataProfiles.table17
        val payload = ByteArray(profile.minPayload)
        payload[0] = 0x05 // RPM high
        payload[1] = 0xDC.toByte() // RPM low
        payload[2] = 24 // TPS ADC -> 0.46875 V
        payload[3] = 80 // TPS angle raw -> 40 deg -> 50%
        val parsed = LiveDataFrameParser.parse(payload, profile)

        assertEquals(24.0, parsed.values.getValue(LiveSensor.TPS_ADC), 0.001)
        assertEquals(24.0 * 5.0 / 256.0, parsed.values.getValue(LiveSensor.TPS_VOLTAGE), 0.001)
        assertEquals(40.0, parsed.values.getValue(LiveSensor.TPS_DEGREES), 0.001)
        assertEquals(50.0, parsed.values.getValue(LiveSensor.TPS_PERCENT), 0.001)
    }

    @Test fun table20UsesFiveOver256O2ScaleAndKeepsAfrHostDerived() {
        val profile = HondaLiveDataProfiles.table20
        val parsed = LiveDataFrameParser.parse(byteArrayOf(46, 128.toByte()), profile)
        val o2 = 46.0 * 5.0 / 256.0
        assertEquals(o2, parsed.values.getValue(LiveSensor.O2), 0.001)
        assertEquals(0.0, parsed.values.getValue(LiveSensor.STF), 0.001)
        assertTrue(profile.notes.contains("14.7 - ((O2_V - 0.45) x 3.0)"))
    }

    @Test fun table17UsesIndependentSensorOffsetsAndConversions() {
        val profile = HondaLiveDataProfiles.table17
        val payload = ByteArray(profile.minPayload)
        payload[0] = 0x05
        payload[1] = 0xDC.toByte() // 1500 RPM
        payload[2] = 24 // TPS ADC
        payload[3] = 80 // TPS2 angle raw
        payload[6] = 64 // IAT voltage ADC
        payload[7] = 70 // IAT = 30 C
        payload[8] = 128.toByte() // ECT voltage ADC
        payload[9] = 120 // ECT = 80 C
        payload[10] = 124 // battery = 12.4 V
        payload[11] = 2
        payload[12] = 0 // injector raw 512 -> 2.0 ms
        payload[13] = 158.toByte() // ignition = 15 deg BTDC
        payload[14] = 1
        payload[15] = 60 // speed 60 km/h

        val parsed = LiveDataFrameParser.parse(payload, profile)
        assertEquals(1500.0, parsed.values.getValue(LiveSensor.RPM), 0.001)
        assertEquals(50.0, parsed.values.getValue(LiveSensor.TPS_PERCENT), 0.001)
        assertEquals(40.0, parsed.values.getValue(LiveSensor.TPS_DEGREES), 0.001)
        assertEquals(24.0 * 5.0 / 256.0, parsed.values.getValue(LiveSensor.TPS_VOLTAGE), 0.001)
        assertEquals(128.0 * 5.0 / 256.0, parsed.values.getValue(LiveSensor.ECT_VOLTAGE), 0.001)
        assertEquals(80.0, parsed.values.getValue(LiveSensor.ECT), 0.001)
        assertEquals(64.0 * 5.0 / 256.0, parsed.values.getValue(LiveSensor.IAT_VOLTAGE), 0.001)
        assertEquals(30.0, parsed.values.getValue(LiveSensor.IAT), 0.001)
        assertEquals(12.4, parsed.values.getValue(LiveSensor.BATTERY), 0.001)
        assertEquals(2.0, parsed.values.getValue(LiveSensor.INJECTOR), 0.001)
        assertEquals(15.0, parsed.values.getValue(LiveSensor.IGNITION_ADVANCE), 0.001)
        assertEquals(60.0, parsed.values.getValue(LiveSensor.SPEED), 0.001)
    }

}

