# Live Data Sensor Conversion Audit (v9)

## Scope and evidence

This update starts from `CANDSTECH-ECU-Flasher-Stage1-progress-v8-source.zip` and compares the reconstructed table catalogue with the supplied RevCore decompile (`HondaLiveDataProfiles.java`). The table layouts remain marked `RECONSTRUCTED`; they are not claimed as hardware-verified for every Honda ECU. Live Data remains gated by exact ECU identity. No additional ECU IDs or family-wide compatibility claims were added.

## Corrected TPS interpretation

For the reconstructed table 0x17/0x13/0x11/0x10 layout:

- TPS ADC raw count: payload offset 2.
- TPS voltage: `raw_adc * 5.0 / 256.0`.
- TPS angle raw byte: payload offset 3.
- TPS angle: `raw_angle * 0.5` degrees.
- TPS percentage estimate: `raw_angle * 100.0 / 160.0`, displayed within 0–100%. The 160-count / 80-degree endpoint is the supplied scanner reference, not a universal throttle-body calibration.

Previously, `TPS_PERCENT` was derived from the ADC byte at offset 2 (`raw * 100 / 256`), which caused a voltage-derived ADC percentage (e.g. raw 24 -> 9.375%) to be presented as throttle opening percentage. That was corrected. Raw ADC, voltage, angle and derived percentage are now separate UI readings.

## Other reconstructed fields

- RPM: two-byte big-endian raw value.
- ECT and IAT: raw byte minus 40 °C; negative temperatures remain signed integer results.
- ECT/IAT/MAP voltage: raw ADC multiplied by `5.0 / 256.0` where the selected table carries those voltage fields.
- MAP pressure: raw byte in kPa, only on tables that define it.
- Battery: raw byte multiplied by 0.1 V.
- Injector pulse: two-byte 8.8 fixed-point raw value divided by 256 on the primary tables; table 0x16 uses its separate one-byte /200 layout.
- Ignition advance: raw byte multiplied by 0.5 then minus 64 degrees.
- Vehicle speed: raw byte in km/h on tables that define VSS.
- O2: table 0x20 raw byte multiplied by `5.0 / 256.0` V.
- STF: `(raw * 100.0 / 128.0) - 100.0` percent; 128 maps to 0%.

## AFR estimate

The app uses the supplied scanner approximation:

`Est_AFR = 14.7 - ((O2_voltage - 0.45) * 3.0)`

Reference points: 0.85 V -> 13.5:1; 0.45 V -> 14.7:1; 0.10 V -> 15.75:1. This is a rough linear display estimate only. A narrowband O2 sensor is nonlinear and does not measure quantitative AFR across the mixture range. The ECU does not transmit AFR; the UI label remains `AFR EST`. Use a wideband sensor for actual AFR measurement.

## Unresolved / intentionally not guessed

- The decompiled source does not provide a confirmed IACV field mapping in the reconstructed table catalogue; no IACV byte offset or conversion is invented.
- The table 0x16 AP/TP dual-channel fields, D1 status flags and other extension values remain subject to their existing reconstruction/evidence labels.
- The ADC and throttle endpoint formulas are reference conversions, not per-ECU/per-throttle-body calibration.
- No physical ECU/adapter validation or Gradle build was run as part of this source update.
