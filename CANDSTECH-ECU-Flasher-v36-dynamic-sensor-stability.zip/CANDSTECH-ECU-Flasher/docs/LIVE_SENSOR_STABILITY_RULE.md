# Live Sensor Stability Rule

- Sensor classification is evaluated against the active ECU response/profile; it is not hardcoded to a motorcycle model.
- `DUMMY` is shown only when the active ECU profile explicitly marks that sensor origin as DUMMY.
- While valid RPM confirms the engine is running, each valid non-RPM/non-speed parameter is observed for unchanged numeric values.
- An unchanged value for at least 2,000 ms is labelled `STUCK? (2s)` in DIAGNOSA. This is a suspicion flag, not proof of a dummy sensor.
- A healthy sensor can remain constant under steady operating conditions. Therefore, the stability detector does not automatically promote `STUCK?` to `DUMMY`.
- `NO DATA`, `INVALID DATA`, `STALE`, `NOT SUPPORTED`, and `WAITING` remain separate states.
- Numeric decoder formulas and values are not changed by the condition evaluator.
