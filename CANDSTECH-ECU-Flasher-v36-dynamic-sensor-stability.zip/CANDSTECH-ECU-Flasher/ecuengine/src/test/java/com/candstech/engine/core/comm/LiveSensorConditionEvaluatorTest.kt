package com.candstech.engine.core.comm

import com.candstech.engine.data.ecu.EcmModel
import org.junit.Assert.assertEquals
import org.junit.Test

class LiveSensorConditionEvaluatorTest {
    @Test fun rpmZeroWithValidFrameIsEngineOff() {
        assertEquals("ENGINE OFF", LiveSensorConditionEvaluator.evaluate(
            LiveSensor.RPM, 0.0, LiveParameterState.VALID, EcmModel("id", "part")
        ))
    }

    @Test fun rpmRequiresProfileSpecificLimitsForIdleRunWarning() {
        val model = EcmModel("id", "part")
        assertEquals("CONFIG NOT VERIFIED", LiveSensorConditionEvaluator.evaluate(
            LiveSensor.RPM, 1500.0, LiveParameterState.VALID, model
        ))
    }

    @Test fun vssIsClassifiedWithoutInventingThresholds() {
        val model = EcmModel("id", "part")
        assertEquals("STOPPED", LiveSensorConditionEvaluator.evaluate(
            LiveSensor.SPEED, 0.0, LiveParameterState.VALID, model
        ))
        assertEquals("MOVING", LiveSensorConditionEvaluator.evaluate(
            LiveSensor.SPEED, 1.0, LiveParameterState.VALID, model
        ))
    }

    @Test fun dummyOriginIsNotReportedAsFaultOrPhysicalRange() {
        val model = EcmModel("id", "part", sensorOrigins = mapOf("IAT" to "DUMMY"))
        assertEquals("DUMMY", LiveSensorConditionEvaluator.evaluate(
            LiveSensor.IAT, 20.0, LiveParameterState.VALID, model
        ))
    }

    @Test fun noResponseIsNoDataNotEngineOff() {
        assertEquals("NO DATA", LiveSensorConditionEvaluator.evaluate(
            LiveSensor.RPM, null, LiveParameterState.NOT_RESPONDING, EcmModel("id", "part")
        ))
    }

    @Test fun configuredRpmUsesProfileThresholds() {
        val model = EcmModel("id", "part", conditionThresholds = mapOf("RPM" to listOf(1300.0, 1800.0, 9000.0)))
        assertEquals("IDLE", LiveSensorConditionEvaluator.evaluate(
            LiveSensor.RPM, 1500.0, LiveParameterState.VALID, model
        ))
        assertEquals("WARNING", LiveSensorConditionEvaluator.evaluate(
            LiveSensor.RPM, 9000.0, LiveParameterState.VALID, model
        ))
    }
}
