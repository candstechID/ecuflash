package com.candstech.engine.core.comm

import com.candstech.engine.data.ecu.EcmModel
import java.util.Locale

/**
 * Human-readable condition labels. Numeric decoding remains exclusively in
 * LiveDataFrameParser/LiveTelemetry and is never modified here.
 *
 * Threshold arrays are ECU-record metadata, keyed by LiveSensor.name:
 * RPM=[idleMin,idleMax,warningRpm]
 * AFR=[richUpper,leanLower]
 * IAT/MAP=[lowUpper,highLower]
 * ECT=[coldUpper,warmUpper,normalUpper,hotUpper]
 * TPS_VOLTAGE=[lowUpper,normalUpper,highUpper,faultLow,faultHigh]
 * TPS_DEGREES=[closedUpper,wideOpenLower]
 * BATTERY=[lowUpper,normalUpper,highUpper,overvoltageLower]
 * O2=[faultLow,faultHigh]
 * STF=[negativeUpper,positiveLower]
 * IGNITION_ADVANCE=[retardedUpper,advancedLower]
 * INJECTOR=[lowUpper,highLower]
 *
 * Missing thresholds produce CONFIG NOT VERIFIED, never guessed classifications.
 */
object LiveSensorConditionEvaluator {
    fun evaluate(
        sensor: LiveSensor,
        value: Double?,
        state: LiveParameterState,
        model: EcmModel?
    ): String? {
        if (state != LiveParameterState.VALID || value == null || !value.isFinite()) {
            return when (state) {
                LiveParameterState.NOT_RESPONDING -> "NO DATA"
                LiveParameterState.INVALID_RESPONSE -> "INVALID DATA"
                LiveParameterState.UNSUPPORTED -> "NOT SUPPORTED"
                LiveParameterState.WAITING_FOR_DATA -> "WAITING"
                LiveParameterState.STALE -> "STALE"
                LiveParameterState.NOT_AVAILABLE_IN_KOEO -> "NO DATA"
                LiveParameterState.VALID -> null
            }
        }

        val origin = model?.sensorOrigins?.get(sensor.name)?.uppercase(Locale.ROOT)
        if (origin == "DUMMY") return "DUMMY"

        val limits = model?.conditionThresholds?.get(sensor.name)
        val t = limits.orEmpty()
        fun configured(size: Int): Boolean = t.size == size && t.all { it.isFinite() }

        return when (sensor) {
            LiveSensor.RPM -> {
                if (value == 0.0) "ENGINE OFF"
                else if (!configured(3)) "CONFIG NOT VERIFIED"
                else when {
                    value >= t[2] -> "WARNING"
                    value >= t[0] && value <= t[1] -> "IDLE"
                    else -> "RUN"
                }
            }
            LiveSensor.SPEED -> if (value <= 0.0) "STOPPED" else "MOVING"
            LiveSensor.AFR -> if (!configured(2)) "CONFIG NOT VERIFIED" else when {
                value <= t[0] -> "RICH"
                value >= t[1] -> "LEAN"
                else -> "NORMAL"
            }
            LiveSensor.IAT, LiveSensor.MAP -> if (!configured(2)) "CONFIG NOT VERIFIED" else when {
                value < t[0] -> "LOW"
                value > t[1] -> "HIGH"
                else -> "NORMAL"
            }
            LiveSensor.ECT -> if (!configured(4)) "CONFIG NOT VERIFIED" else when {
                value <= t[0] -> "COLD"
                value <= t[1] -> "WARM"
                value <= t[2] -> "NORMAL"
                value <= t[3] -> "HOT"
                else -> "OVERHEAT"
            }
            LiveSensor.TPS_VOLTAGE -> if (!configured(5)) "CONFIG NOT VERIFIED" else when {
                value < t[3] || value > t[4] -> "FAULT"
                value < t[0] -> "LOW"
                value <= t[1] -> "NORMAL"
                else -> "HIGH"
            }
            LiveSensor.TPS_DEGREES -> if (!configured(2)) "CONFIG NOT VERIFIED" else when {
                value <= t[0] -> "CLOSED"
                value >= t[1] -> "WIDE OPEN"
                else -> "PARTIAL"
            }
            LiveSensor.BATTERY -> if (!configured(4)) "CONFIG NOT VERIFIED" else when {
                value < t[0] -> "LOW"
                value <= t[1] -> "NORMAL"
                value <= t[2] -> "HIGH"
                value >= t[3] -> "OVERVOLTAGE"
                else -> "HIGH"
            }
            LiveSensor.O2 -> if (!configured(2)) "CONFIG NOT VERIFIED" else
                if (value < t[0] || value > t[1]) "FAULT" else "NORMAL"
            LiveSensor.STF -> if (!configured(2)) "CONFIG NOT VERIFIED" else when {
                value < t[0] -> "NEGATIVE CORRECTION"
                value > t[1] -> "POSITIVE CORRECTION"
                else -> "NORMAL"
            }
            LiveSensor.IGNITION_ADVANCE -> if (!configured(2)) "CONFIG NOT VERIFIED" else when {
                value < t[0] -> "RETARDED"
                value > t[1] -> "ADVANCED"
                else -> "NORMAL"
            }
            LiveSensor.INJECTOR -> if (!configured(2)) "CONFIG NOT VERIFIED" else when {
                value < t[0] -> "LOW"
                value > t[1] -> "HIGH"
                else -> "NORMAL"
            }
            else -> origin ?: "STATUS NOT MAPPED"
        }
    }
}

/**
 * Runtime detector for unchanged live-data values while RPM confirms the engine
 * is running. This is deliberately a suspicion flag, not proof of a dummy sensor:
 * a healthy sensor can legitimately remain constant under steady conditions.
 * ECU-profile metadata remains the only way to promote a sensor to DUMMY.
 */
class LiveSensorStabilityTracker(
    private val stableDurationMs: Long = 2_000L
) {
    private data class Sample(val value: Double, val sinceNanos: Long)
    private val samples = mutableMapOf<LiveSensor, Sample>()

    @Synchronized
    fun isSuspectedStuck(
        sensor: LiveSensor,
        value: Double?,
        state: LiveParameterState,
        engineRunning: Boolean,
        nowNanos: Long = System.nanoTime()
    ): Boolean {
        if (!engineRunning || state != LiveParameterState.VALID || value == null || !value.isFinite() ||
            sensor == LiveSensor.RPM || sensor == LiveSensor.SPEED) {
            samples.remove(sensor)
            return false
        }

        val previous = samples[sensor]
        if (previous == null || previous.value != value) {
            samples[sensor] = Sample(value, nowNanos)
            return false
        }
        return nowNanos - previous.sinceNanos >= stableDurationMs * 1_000_000L
    }

    @Synchronized
    fun reset() = samples.clear()
}
