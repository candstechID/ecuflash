# ELM327 and Vario 150 Live Data integration notes

## ELM327 regression found in v3
The v3 MainActivity retains the FelHR USB serial dependency and a generic UsbManager permission request, but it no longer contains the ELM327 session object, AT-command startup path, or interface-mode routing that existed in CANDSTECH-Diagnostic-ELM327-v5.1.2. Therefore v3's USB button routes the selected device into HondaProtocolEngine.openAdapterOnly(), i.e. raw K-Line, and cannot start ELM327 OBD-II diagnostics.

Restored into the v3 source tree (source-only):
- Elm327Session.kt (ATI, ATE0, ATL0, ATS1, ATH0, ATAT1, ATST64, ATSP0, ATRV, PID 0100, DTC 03/04).
- UsbAdapterSupport.kt (FTDI/CH340/CP210x/CDC identification; conservative chipset identification).

Still required before marking ELM integration complete: route selected USB device to either ELM327 AT session or Honda raw K-Line engine; ensure requestPermission uses a device-specific PendingIntent and a registered receiver; only open serial after permission grant; restore ELM UI action routing for identify/PID/DTC; avoid opening same USB device through both transports.

## Live Data Vario 150
The RevCore HondaLiveDataProfiles.java source defines tables 17, 13, 11, 10, 16, 20 and D1. The v3 engine currently selects a family profile from session family; the family remains GENERIC until sufficient protocol evidence is available. Its generic profile has an empty liveDataTables list, so queryLiveData() returns UNSUPPORTED_PROFILE before transmitting any request. Merely attaching the tables to all generic Honda ECUs would be unsafe.

The profile integration must be gated to the identified ECU ID 0101C40F01 (K59A-A11 / Vario 150 LED 2016-2017 as identified by v3 database), with table definitions preserved as RECONSTRUCTED and no claim of confirmed response/scale compatibility until tested on the user's 2015 vehicle. The source Java catalog's provenance and its differing table 21 vs table 16 references must remain documented; no AFR calculation may be derived from narrowband O2 voltage.

## Build policy
No Gradle build or APK build was run. This tree is a source-work area only.
